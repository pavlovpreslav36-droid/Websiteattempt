# Roadmap

## In progress
- [ ] CinematicHero wired into Home (component created, needs mount)
- [ ] Verified chef recipes added to Recipes.tsx (data added, needs display section with chef credit + video)

## New (from РЗИ Враца letter — school project requirement)
- [ ] New "Без тютюн" (Tobacco-Free) section/page: anti-smoking prevention, foods & habits that reduce cigarette cravings, "Посланици на здравето" context, World No Tobacco Day 2027
- [ ] Route + navigation entry for the new section

## Pending from earlier
- [ ] Cooking Focus Mode (big steps, voice, timers) — not started
- [ ] AI meal plan by goal/budget, fridge scan, chef profiles — not started

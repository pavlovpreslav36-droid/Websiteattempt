export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      achievements: {
        Row: {
          category: string
          created_at: string
          description: string
          description_bg: string
          icon: string
          id: string
          name: string
          name_bg: string
          points: number
          requirement_type: string
          requirement_value: number
        }
        Insert: {
          category: string
          created_at?: string
          description: string
          description_bg: string
          icon: string
          id?: string
          name: string
          name_bg: string
          points?: number
          requirement_type: string
          requirement_value?: number
        }
        Update: {
          category?: string
          created_at?: string
          description?: string
          description_bg?: string
          icon?: string
          id?: string
          name?: string
          name_bg?: string
          points?: number
          requirement_type?: string
          requirement_value?: number
        }
        Relationships: []
      }
      blocked_ips: {
        Row: {
          blocked_at: string | null
          blocked_until: string | null
          id: string
          ip_address: string
          permanent: boolean | null
          reason: string
        }
        Insert: {
          blocked_at?: string | null
          blocked_until?: string | null
          id?: string
          ip_address: string
          permanent?: boolean | null
          reason: string
        }
        Update: {
          blocked_at?: string | null
          blocked_until?: string | null
          id?: string
          ip_address?: string
          permanent?: boolean | null
          reason?: string
        }
        Relationships: []
      }
      chat_history: {
        Row: {
          created_at: string
          id: string
          message: string
          role: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          role: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          role?: string
          user_id?: string | null
        }
        Relationships: []
      }
      failed_login_attempts: {
        Row: {
          attempted_at: string | null
          email: string
          id: string
          ip_address: string
        }
        Insert: {
          attempted_at?: string | null
          email: string
          id?: string
          ip_address: string
        }
        Update: {
          attempted_at?: string | null
          email?: string
          id?: string
          ip_address?: string
        }
        Relationships: []
      }
      friendships: {
        Row: {
          created_at: string
          friend_id: string
          id: string
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          friend_id: string
          id?: string
          status?: string
          user_id: string
        }
        Update: {
          created_at?: string
          friend_id?: string
          id?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      health_challenges: {
        Row: {
          challenge_type: string
          challenger_id: string | null
          challenger_progress: number
          created_at: string
          creator_id: string
          creator_progress: number
          ends_at: string
          id: string
          status: string
          target_value: number
          winner_id: string | null
        }
        Insert: {
          challenge_type: string
          challenger_id?: string | null
          challenger_progress?: number
          created_at?: string
          creator_id: string
          creator_progress?: number
          ends_at?: string
          id?: string
          status?: string
          target_value: number
          winner_id?: string | null
        }
        Update: {
          challenge_type?: string
          challenger_id?: string | null
          challenger_progress?: number
          created_at?: string
          creator_id?: string
          creator_progress?: number
          ends_at?: string
          id?: string
          status?: string
          target_value?: number
          winner_id?: string | null
        }
        Relationships: []
      }
      meal_journal: {
        Row: {
          ai_analysis: string | null
          allergens: Json | null
          calories: number | null
          carbs: number | null
          created_at: string
          description: string | null
          fat: number | null
          fiber: number | null
          health_score: number | null
          id: string
          ingredients: Json | null
          meal_name: string
          meal_type: string
          media_type: string | null
          photo_url: string | null
          portion_size: string | null
          protein: number | null
          sodium: number | null
          sugar: number | null
          user_id: string
          warnings: Json | null
        }
        Insert: {
          ai_analysis?: string | null
          allergens?: Json | null
          calories?: number | null
          carbs?: number | null
          created_at?: string
          description?: string | null
          fat?: number | null
          fiber?: number | null
          health_score?: number | null
          id?: string
          ingredients?: Json | null
          meal_name: string
          meal_type?: string
          media_type?: string | null
          photo_url?: string | null
          portion_size?: string | null
          protein?: number | null
          sodium?: number | null
          sugar?: number | null
          user_id: string
          warnings?: Json | null
        }
        Update: {
          ai_analysis?: string | null
          allergens?: Json | null
          calories?: number | null
          carbs?: number | null
          created_at?: string
          description?: string | null
          fat?: number | null
          fiber?: number | null
          health_score?: number | null
          id?: string
          ingredients?: Json | null
          meal_name?: string
          meal_type?: string
          media_type?: string | null
          photo_url?: string | null
          portion_size?: string | null
          protein?: number | null
          sodium?: number | null
          sugar?: number | null
          user_id?: string
          warnings?: Json | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          email: string | null
          full_name: string | null
          gamertag: string | null
          health_goal: string | null
          id: string
          updated_at: string
          xp: number
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          gamertag?: string | null
          health_goal?: string | null
          id: string
          updated_at?: string
          xp?: number
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          gamertag?: string | null
          health_goal?: string | null
          id?: string
          updated_at?: string
          xp?: number
        }
        Relationships: []
      }
      quiz_scores: {
        Row: {
          best_streak: number
          created_at: string
          id: string
          score: number
          time_taken_seconds: number
          total_questions: number
          user_id: string
          username: string
        }
        Insert: {
          best_streak?: number
          created_at?: string
          id?: string
          score: number
          time_taken_seconds?: number
          total_questions?: number
          user_id: string
          username?: string
        }
        Update: {
          best_streak?: number
          created_at?: string
          id?: string
          score?: number
          time_taken_seconds?: number
          total_questions?: number
          user_id?: string
          username?: string
        }
        Relationships: []
      }
      ripple_moments: {
        Row: {
          created_at: string
          id: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      saved_recipes: {
        Row: {
          chef_name: string | null
          cooked_count: number
          created_at: string
          id: string
          recipe_name: string
          recipe_slug: string
          user_id: string
        }
        Insert: {
          chef_name?: string | null
          cooked_count?: number
          created_at?: string
          id?: string
          recipe_name: string
          recipe_slug: string
          user_id: string
        }
        Update: {
          chef_name?: string | null
          cooked_count?: number
          created_at?: string
          id?: string
          recipe_name?: string
          recipe_slug?: string
          user_id?: string
        }
        Relationships: []
      }
      security_events: {
        Row: {
          created_at: string | null
          details: Json | null
          event_type: string
          id: string
          ip_address: string
          severity: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          details?: Json | null
          event_type: string
          id?: string
          ip_address: string
          severity: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          details?: Json | null
          event_type?: string
          id?: string
          ip_address?: string
          severity?: string
          user_id?: string | null
        }
        Relationships: []
      }
      user_achievements: {
        Row: {
          achievement_id: string
          earned_at: string
          id: string
          user_id: string
        }
        Insert: {
          achievement_id: string
          earned_at?: string
          id?: string
          user_id: string
        }
        Update: {
          achievement_id?: string
          earned_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_achievements_achievement_id_fkey"
            columns: ["achievement_id"]
            isOneToOne: false
            referencedRelation: "achievements"
            referencedColumns: ["id"]
          },
        ]
      }
      weekly_health_reports: {
        Row: {
          ai_summary: string | null
          created_at: string
          health_score: number | null
          id: string
          report_data: Json
          user_id: string
          week_start: string
        }
        Insert: {
          ai_summary?: string | null
          created_at?: string
          health_score?: number | null
          id?: string
          report_data: Json
          user_id: string
          week_start: string
        }
        Update: {
          ai_summary?: string | null
          created_at?: string
          health_score?: number | null
          id?: string
          report_data?: Json
          user_id?: string
          week_start?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      block_ip: {
        Args: {
          p_duration_hours?: number
          p_ip_address: string
          p_permanent?: boolean
          p_reason: string
        }
        Returns: string
      }
      is_ip_blocked: { Args: { check_ip: string }; Returns: boolean }
      log_security_event: {
        Args: {
          p_details: Json
          p_event_type: string
          p_ip_address: string
          p_severity: string
          p_user_id: string
        }
        Returns: string
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const

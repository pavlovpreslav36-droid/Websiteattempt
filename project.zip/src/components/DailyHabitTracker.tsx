import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, Droplet, Moon, Activity, BookOpen, Flame } from "lucide-react";

type HabitKey = "hydration" | "sleep" | "movement" | "mindset";
const HABITS: { key: HabitKey; label: string; icon: any }[] = [
  { key: "hydration", label: "Хидратация (2L вода)", icon: Droplet },
  { key: "sleep", label: "8 часа сън", icon: Moon },
  { key: "movement", label: "Активно движение", icon: Activity },
  { key: "mindset", label: "Четене / Mindset", icon: BookOpen },
];

const STORAGE_KEY = "ahm_daily_tracker_v1";
const todayISO = () => new Date().toISOString().slice(0, 10);

type State = {
  date: string;
  habits: Record<HabitKey, boolean>;
  streak: number;
  lastCompleted: string | null;
};

const defaultHabits: Record<HabitKey, boolean> = {
  hydration: false, sleep: false, movement: false, mindset: false,
};

function loadState(): State {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const s: State = JSON.parse(raw);
      if (s.date !== todayISO()) {
        // reset habits for new day, keep streak
        return { ...s, date: todayISO(), habits: { ...defaultHabits } };
      }
      return s;
    }
  } catch {}
  return { date: todayISO(), habits: { ...defaultHabits }, streak: 0, lastCompleted: null };
}

export function DailyHabitTracker() {
  const [state, setState] = useState<State>(() => loadState());

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const completedCount = Object.values(state.habits).filter(Boolean).length;
  const total = HABITS.length;
  const progress = completedCount / total;
  const allDone = completedCount === total;

  // bump streak when all habits become complete today
  useEffect(() => {
    if (!allDone) return;
    if (state.lastCompleted === todayISO()) return;
    setState((prev) => {
      const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
      const yISO = yesterday.toISOString().slice(0, 10);
      const newStreak = prev.lastCompleted === yISO ? prev.streak + 1 : 1;
      return { ...prev, streak: newStreak, lastCompleted: todayISO() };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allDone]);

  const toggle = (k: HabitKey) =>
    setState((p) => ({ ...p, habits: { ...p.habits, [k]: !p.habits[k] } }));

  // SVG ring
  const size = 160, stroke = 12, r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - progress);

  return (
    <div className="rounded-3xl bg-card border border-border shadow-card p-6 md:p-8">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h3 className="text-2xl md:text-3xl font-display font-bold text-foreground">Дневен трекер</h3>
          <p className="text-sm text-muted-foreground">Изграждай дисциплина, ден след ден.</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-accent/15 shadow-sm">
          <Flame className="w-5 h-5 text-accent" />
          <span className="font-semibold text-foreground">{state.streak}</span>
          <span className="text-xs text-muted-foreground">дни поред</span>
        </div>
      </div>

      <div className="grid md:grid-cols-[auto,1fr] gap-8 items-center">
        <div className="relative mx-auto">
          <svg width={size} height={size} className="-rotate-90">
            <circle cx={size / 2} cy={size / 2} r={r} stroke="hsl(var(--muted))" strokeWidth={stroke} fill="none" />
            <motion.circle
              cx={size / 2} cy={size / 2} r={r}
              stroke="hsl(var(--primary))" strokeWidth={stroke} fill="none"
              strokeLinecap="round" strokeDasharray={c}
              animate={{ strokeDashoffset: offset }}
              transition={{ duration: 0.6, ease: "easeOut" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-display font-bold gradient-text">{Math.round(progress * 100)}%</span>
            <span className="text-xs text-muted-foreground">{completedCount}/{total}</span>
          </div>
        </div>

        <div className="space-y-3 w-full">
          {HABITS.map(({ key, label, icon: Icon }) => {
            const done = state.habits[key];
            return (
              <motion.button
                key={key}
                whileTap={{ scale: 0.98 }}
                onClick={() => toggle(key)}
                className={`w-full flex items-center gap-3 p-3 md:p-4 rounded-2xl transition-all duration-300 ${
                  done ? "bg-primary/10 shadow-sm shadow-primary/10" : "bg-background/40 hover:bg-background/70 hover:shadow-sm"
                }`}
              >
                <div className={`w-6 h-6 rounded-md border-2 flex items-center justify-center transition-all duration-300 ${
                  done ? "bg-primary border-primary" : "border-muted-foreground/40"
                }`}>
                  <AnimatePresence>
                    {done && (
                      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
                        <Check className="w-4 h-4 text-primary-foreground" />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
                <Icon className={`w-5 h-5 ${done ? "text-primary" : "text-muted-foreground"}`} />
                <span className={`text-sm md:text-base font-medium text-left ${done ? "text-foreground" : "text-foreground/80"}`}>
                  {label}
                </span>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
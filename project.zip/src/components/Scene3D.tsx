import { useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Sphere, Box, Torus } from "@react-three/drei";
import * as THREE from "three";

function FloatingShape({ position, shape }: { position: [number, number, number]; shape: "sphere" | "box" | "torus" }) {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (!meshRef.current) return;
    meshRef.current.rotation.x += 0.01;
    meshRef.current.rotation.y += 0.01;
    meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime) * 0.3;
  });

  const material = (
    <meshStandardMaterial
      color={shape === "sphere" ? "#00D9FF" : shape === "box" ? "#FF6B35" : "#C44EFF"}
      emissive={shape === "sphere" ? "#00D9FF" : shape === "box" ? "#FF6B35" : "#C44EFF"}
      emissiveIntensity={0.2}
      roughness={0.2}
      metalness={0.8}
    />
  );

  return (
    <mesh ref={meshRef} position={position}>
      {shape === "sphere" && <Sphere args={[1, 32, 32]}>{material}</Sphere>}
      {shape === "box" && <Box args={[1.5, 1.5, 1.5]}>{material}</Box>}
      {shape === "torus" && <Torus args={[1, 0.4, 16, 100]}>{material}</Torus>}
    </mesh>
  );
}

const Scene3D = () => {
  return (
    <div className="w-full h-full absolute inset-0">
      <Canvas camera={{ position: [0, 0, 8], fov: 50 }} style={{ background: 'transparent' }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} />
        <pointLight position={[-10, -10, -10]} color="#00D9FF" intensity={0.5} />
        
        <FloatingShape position={[-2, 0, 0]} shape="sphere" />
        <FloatingShape position={[2, 1, -1]} shape="box" />
        <FloatingShape position={[0, -1, 1]} shape="torus" />
        
        <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
      </Canvas>
    </div>
  );
};

export default Scene3D;

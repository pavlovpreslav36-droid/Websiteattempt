import QRCodeSVG from 'react-qr-code';
import { Card } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';

export const QRCodeDisplay = () => {
  const { language } = useLanguage();
  const siteUrl = "https://steps-to-a-healthy-life.lovable.app";

  return (
    <Card className="p-6 bg-card">
      <div className="text-center space-y-4">
        <h3 className="text-xl font-semibold gradient-text">
          {language === 'bg' ? 'Сканирай QR кода' : 'Scan QR Code'}
        </h3>
        <p className="text-muted-foreground">
          {language === 'bg' 
            ? 'Сканирайте този код за достъп до сайта от мобилно устройство' 
            : 'Scan this code to access the site from mobile device'}
        </p>
        <div className="flex justify-center p-4 bg-white rounded-lg">
          <QRCodeSVG 
            value={siteUrl} 
            size={200}
            level="H"
          />
        </div>
        <p className="text-sm text-muted-foreground">{siteUrl}</p>
      </div>
    </Card>
  );
};

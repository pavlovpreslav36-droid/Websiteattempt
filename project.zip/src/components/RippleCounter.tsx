import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Reveal } from "@/components/Reveal";

const STORAGE_KEY = "ripple_last_moment";
const COOLDOWN_MS = 60_000; // 1 minute between clicks per device

function AnimatedNumber({ value }: { value: number }) {
  const digits = value.toLocaleString("bg-BG").split("");
  return (
    <span className="inline-flex tabular-nums">
      {digits.map((d, i) => (
        <AnimatePresence mode="popLayout" key={`${i}-${digits.length}`}>
          <motion.span
            key={`${i}-${d}`}
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="inline-block"
          >
            {d}
          </motion.span>
        </AnimatePresence>
      ))}
    </span>
  );
}

export const RippleCounter = () => {
  const [count, setCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [pulse, setPulse] = useState(false);
  const [cooldown, setCooldown] = useState(false);

  // Initial fetch + realtime subscription
  useEffect(() => {
    let mounted = true;

    const fetchCount = async () => {
      const { count: c } = await supabase
        .from("ripple_moments")
        .select("*", { count: "exact", head: true });
      if (mounted && typeof c === "number") {
        setCount(c);
        setLoading(false);
      }
    };
    fetchCount();

    const channel = supabase
      .channel("ripple_moments_changes")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "ripple_moments" },
        () => {
          setCount((prev) => prev + 1);
          setPulse(true);
          setTimeout(() => setPulse(false), 800);
        }
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, []);

  // Restore cooldown on mount
  useEffect(() => {
    const last = localStorage.getItem(STORAGE_KEY);
    if (last) {
      const elapsed = Date.now() - parseInt(last, 10);
      if (elapsed < COOLDOWN_MS) {
        setCooldown(true);
        const remaining = COOLDOWN_MS - elapsed;
        const t = setTimeout(() => setCooldown(false), remaining);
        return () => clearTimeout(t);
      }
    }
  }, []);

  const handleMoment = async () => {
    if (submitting || cooldown) return;
    setSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase
        .from("ripple_moments")
        .insert({ user_id: user?.id ?? null });

      if (error) throw error;

      localStorage.setItem(STORAGE_KEY, Date.now().toString());
      setCooldown(true);
      setTimeout(() => setCooldown(false), COOLDOWN_MS);
      toast.success("✨ Благодарим, че отдели момент за себе си!", {
        description: "Вълничка тръгва из общността ни.",
      });
    } catch (e) {
      toast.error("Нещо се обърка. Опитай отново.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Reveal direction="up">
      <div className="relative overflow-hidden rounded-3xl bg-card border border-border shadow-card p-8 md:p-12 text-center">
        {/* Decorative ripples */}
        <AnimatePresence>
          {pulse && (
            <>
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-primary/40 pointer-events-none"
                  initial={{ width: 80, height: 80, opacity: 0.7 }}
                  animate={{ width: 600, height: 600, opacity: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 1.5, delay: i * 0.15, ease: "easeOut" }}
                />
              ))}
            </>
          )}
        </AnimatePresence>

        <div className="relative z-10 flex flex-col items-center gap-6">
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-xs font-medium text-primary">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ефект на вълничката</span>
          </div>

          <div>
            <p className="text-sm md:text-base text-muted-foreground mb-3">
              Днес нашата общност отдели
            </p>
            <div className="text-5xl md:text-7xl font-display font-bold gradient-text leading-none mb-3">
              {loading ? "—" : <AnimatedNumber value={count} />}
            </div>
            <p className="text-base md:text-lg text-foreground/80 font-medium">
              осъзнати моменти за себе си
            </p>
          </div>

          <Button
            size="lg"
            onClick={handleMoment}
            disabled={submitting || cooldown}
            className="h-14 px-8 text-base rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.03] disabled:opacity-60 disabled:hover:scale-100"
          >
            <Heart className={`mr-2 w-5 h-5 ${pulse ? "animate-pulse" : ""}`} />
            {cooldown
              ? "Благодарим ти ❤️"
              : submitting
                ? "Изпращане..."
                : "Отделих момент за себе си"}
          </Button>

          <p className="text-xs text-muted-foreground max-w-md">
            Всяко натискане се добавя в реално време и вдъхновява останалите.
          </p>
        </div>
      </div>
    </Reveal>
  );
};
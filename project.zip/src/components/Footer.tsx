import { Link } from "react-router-dom";
import alekoImage from "@/assets/aleko-konstantinov.jpg";

const columns = [
  {
    title: "Храна",
    links: [
      { to: "/recipes", label: "Рецепти" },
      { to: "/diets", label: "Диети и режими" },
      { to: "/drinks", label: "Напитки" },
      { to: "/shopping-list", label: "Списък за пазаруване" },
      { to: "/meal-planner", label: "Планер" },
      { to: "/meal-journal", label: "Хранителен дневник" },
      { to: "/product-scanner", label: "Скенер" },
    ],
  },
  {
    title: "Здраве",
    links: [
      { to: "/health-dashboard", label: "Дневник" },
      { to: "/exercises", label: "Упражнения" },
      { to: "/breathing", label: "Дишане" },
      { to: "/weekly-report", label: "Седмичен доклад" },
    ],
  },
  {
    title: "Открий",
    links: [
      { to: "/quiz", label: "Викторина" },
      { to: "/fun-facts", label: "Факти" },
      { to: "/ambassadors", label: "Посланици на здравето" },
      { to: "/quit-kitchen", label: "Кухня за отказване" },
      { to: "/tobacco-free", label: "Без тютюн" },
      { to: "/social", label: "Класация" },
      { to: "/special-thanks", label: "Благодарности" },
    ],
  },
];

const Footer = () => {
  return (
    <footer className="px-3 md:px-6 pb-3 md:pb-6">
      <div className="rounded-[2.5rem] bg-wine text-cream px-6 md:px-14 pt-14 md:pt-20 pb-8 overflow-hidden">
        <p className="display text-[clamp(2.4rem,9.5vw,8rem)] text-cream leading-[0.95]">
          Steps to a <span className="text-flame">Healthy</span> Life
        </p>

        <div className="mt-12 md:mt-16 grid gap-10 md:grid-cols-[1.3fr_repeat(3,1fr)]">
          <p className="max-w-xs text-cream/75 leading-relaxed">
            Личен помощник за здравословен начин на живот: рецепти, дневник, тренировки и още.
          </p>

          {columns.map((col) => (
            <div key={col.title}>
              <h4 className="eyebrow text-flame mb-4">{col.title}</h4>
              <ul className="space-y-2">
                {col.links.map((link) => (
                  <li key={link.to}>
                    <Link to={link.to} className="text-cream/85 hover:text-cream underline-offset-4 hover:underline transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-6 border-t border-cream/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img src={alekoImage} alt="Алеко Константинов" className="w-10 h-10 rounded-full object-cover border border-cream/30" />
            <p className="text-sm text-cream/75">
              Направено в град Мездра от <span className="font-semibold text-cream">Преслав Миков</span>
            </p>
          </div>
          <p className="text-xs text-cream/60">© {new Date().getFullYear()} Steps to a Healthy Life</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

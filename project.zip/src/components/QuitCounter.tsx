import { useEffect, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CigaretteOff, PiggyBank, Target, RotateCcw, Pencil, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

/**
 * Брояч „Без дим“: дни, неизпушени цигари и спестени пари от последната цигара.
 * Данните се пазят само в този браузър (localStorage) и никъде не се изпращат.
 */

interface Saved {
  start: string; // ISO
  perDay: number;
  price: number; // цена на кутия от 20 цигари, в евро
}

const KEY = "quit-counter-v1";
const PACK = 20;

const milestones = [
  { label: "20 минути", ms: 20 * 60 * 1000, text: "Пулсът и кръвното налягане започват да се подобряват." },
  { label: "12 часа", ms: 12 * 3600 * 1000, text: "Въглеродният оксид в кръвта пада до нормални нива." },
  { label: "2 седмици", ms: 14 * 86400 * 1000, text: "Кръвообращението и белодробната функция се подобряват." },
  { label: "1 година", ms: 365 * 86400 * 1000, text: "Рискът от сърдечно-съдови заболявания намалява наполовина." },
  { label: "10 години", ms: 3650 * 86400 * 1000, text: "Рискът от рак на белия дроб е около наполовина спрямо този на пушач." },
];

const pad = (n: number) => String(n).padStart(2, "0");

const toLocalInput = (d: Date) =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;

const load = (): Saved | null => {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const v = JSON.parse(raw);
    if (typeof v.start === "string" && !Number.isNaN(new Date(v.start).getTime()) && Number(v.perDay) > 0 && Number(v.price) >= 0) {
      return { start: v.start, perDay: Number(v.perDay), price: Number(v.price) };
    }
  } catch {
    /* ignore broken data */
  }
  return null;
};

const remainingText = (ms: number) => {
  const d = Math.floor(ms / 86400000);
  const h = Math.floor(ms / 3600000) % 24;
  const m = Math.floor(ms / 60000) % 60;
  if (d >= 1) return `${d} ${d === 1 ? "ден" : "дни"} и ${h} ч`;
  if (h >= 1) return `${h} ч и ${m} мин`;
  return `${Math.max(1, m)} мин`;
};

export const QuitCounter = () => {
  const [saved, setSaved] = useState<Saved | null>(load);
  const [editing, setEditing] = useState(false);
  const [now, setNow] = useState(() => Date.now());

  const [startInput, setStartInput] = useState(() => toLocalInput(new Date()));
  const [perDay, setPerDay] = useState("10");
  const [price, setPrice] = useState("5");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!saved) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [saved]);

  const openEditor = () => {
    if (saved) {
      setStartInput(toLocalInput(new Date(saved.start)));
      setPerDay(String(saved.perDay));
      setPrice(String(saved.price));
    } else {
      setStartInput(toLocalInput(new Date()));
    }
    setError("");
    setEditing(true);
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const start = new Date(startInput);
    const perDayNum = Number(perDay);
    const priceNum = Number(price.replace(",", "."));
    if (Number.isNaN(start.getTime())) return setError("Избери дата и час.");
    if (start.getTime() > Date.now() + 60_000) return setError("Датата не може да е в бъдещето.");
    if (!Number.isFinite(perDayNum) || perDayNum < 1 || perDayNum > 100) return setError("Цигарите на ден трябва да са между 1 и 100.");
    if (!Number.isFinite(priceNum) || priceNum < 0 || priceNum > 100) return setError("Цената на кутия трябва да е между 0 и 100 €.");
    const next: Saved = { start: start.toISOString(), perDay: Math.round(perDayNum), price: priceNum };
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch {
      /* private mode: counter still works until the tab closes */
    }
    setSaved(next);
    setNow(Date.now());
    setEditing(false);
  };

  const reset = () => {
    if (!window.confirm("Да изтрием ли брояча? Можеш да започнеш нов по всяко време.")) return;
    try {
      localStorage.removeItem(KEY);
    } catch {
      /* ignore */
    }
    setSaved(null);
    setEditing(false);
  };

  /* ─── Form ─── */
  if (!saved || editing) {
    return (
      <form onSubmit={submit} className="rounded-3xl bg-card border border-border shadow-card p-6 md:p-8">
        <div className="flex items-center gap-3 mb-2">
          <span className="grid place-items-center w-11 h-11 rounded-xl bg-primary/10 text-primary">
            <CigaretteOff className="w-5 h-5" aria-hidden="true" />
          </span>
          <h2 className="text-xl md:text-2xl font-bold text-foreground">Твоят брояч „Без дим“</h2>
        </div>
        <p className="text-muted-foreground mb-6">Виж колко време си без цигара, колко цигари не си изпушил и колко пари си спестил. Данните остават само на това устройство.</p>

        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="qc-start">Последна цигара</Label>
            <Input id="qc-start" type="datetime-local" value={startInput} max={toLocalInput(new Date())} onChange={(e) => setStartInput(e.target.value)} className="mt-2 h-11" />
          </div>
          <div>
            <Label htmlFor="qc-per-day">Цигари на ден</Label>
            <Input id="qc-per-day" type="number" inputMode="numeric" min={1} max={100} value={perDay} onChange={(e) => setPerDay(e.target.value)} className="mt-2 h-11" />
          </div>
          <div>
            <Label htmlFor="qc-price">Цена на кутия (€)</Label>
            <Input id="qc-price" type="text" inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} className="mt-2 h-11" />
          </div>
        </div>

        {error && <p role="alert" className="mt-4 text-sm font-medium text-destructive">{error}</p>}

        <div className="mt-6 flex flex-wrap gap-3">
          <Button type="submit" className="rounded-full h-11 px-7">{saved ? "Запази промените" : "Започни брояча"}</Button>
          {saved && (
            <Button type="button" variant="outline" className="rounded-full h-11" onClick={() => setEditing(false)}>Отказ</Button>
          )}
        </div>
      </form>
    );
  }

  /* ─── Live counter ─── */
  const startMs = new Date(saved.start).getTime();
  const elapsed = Math.max(0, now - startMs);
  const days = Math.floor(elapsed / 86400000);
  const hours = Math.floor(elapsed / 3600000) % 24;
  const mins = Math.floor(elapsed / 60000) % 60;
  const secs = Math.floor(elapsed / 1000) % 60;
  const cigarettes = Math.floor((elapsed / 86400000) * saved.perDay);
  const money = (cigarettes / PACK) * saved.price;
  const next = milestones.find((m) => m.ms > elapsed);
  const prev = [...milestones].reverse().find((m) => m.ms <= elapsed);
  const prevMs = prev ? prev.ms : 0;
  const progress = next ? Math.min(100, ((elapsed - prevMs) / (next.ms - prevMs)) * 100) : 100;

  const units: [number, string][] = [
    [days, days === 1 ? "ден" : "дни"],
    [hours, "часа"],
    [mins, "мин"],
    [secs, "сек"],
  ];

  return (
    <div className="rounded-3xl bg-card border border-border shadow-card p-6 md:p-8">
      <div className="flex items-start justify-between gap-4 mb-5">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-foreground">Без дим от</h2>
          <p className="text-sm text-muted-foreground">
            {new Date(saved.start).toLocaleString("bg-BG", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}
          </p>
        </div>
        <div className="flex gap-1.5">
          <button onClick={openEditor} className="grid place-items-center w-10 h-10 rounded-full bg-muted text-foreground hover:bg-secondary transition-colors" aria-label="Промени данните">
            <Pencil className="w-4 h-4" />
          </button>
          <button onClick={reset} className="grid place-items-center w-10 h-10 rounded-full bg-muted text-foreground hover:bg-secondary transition-colors" aria-label="Изтрий брояча">
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2 md:gap-3" role="timer" aria-label="Време без цигара">
        {units.map(([v, label], i) => (
          <div key={label + i} className="rounded-2xl bg-primary/10 py-3 md:py-4 text-center overflow-hidden">
            <div className="h-9 md:h-11 relative">
              <AnimatePresence mode="popLayout" initial={false}>
                <motion.span
                  key={v}
                  initial={i === 3 ? { y: -14, opacity: 0 } : false}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 14, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="absolute inset-0 grid place-items-center font-brand text-2xl md:text-4xl font-bold text-primary tabular-nums"
                >
                  {i === 0 ? v : pad(v)}
                </motion.span>
              </AnimatePresence>
            </div>
            <span className="block text-xs text-muted-foreground mt-1">{label}</span>
          </div>
        ))}
      </div>

      <div className="mt-4 grid sm:grid-cols-2 gap-3">
        <div className="rounded-2xl border border-border p-4 flex items-center gap-3">
          <span className="grid place-items-center w-11 h-11 rounded-xl bg-tomato/10 text-tomato shrink-0"><CigaretteOff className="w-5 h-5" aria-hidden="true" /></span>
          <div>
            <p className="text-2xl font-bold text-foreground tabular-nums leading-none">{cigarettes.toLocaleString("bg-BG")}</p>
            <p className="text-sm text-muted-foreground mt-1">неизпушени цигари</p>
          </div>
        </div>
        <div className="rounded-2xl border border-border p-4 flex items-center gap-3">
          <span className="grid place-items-center w-11 h-11 rounded-xl bg-honey/20 text-foreground shrink-0"><PiggyBank className="w-5 h-5" aria-hidden="true" /></span>
          <div>
            <p className="text-2xl font-bold text-foreground tabular-nums leading-none">{money.toLocaleString("bg-BG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</p>
            <p className="text-sm text-muted-foreground mt-1">спестени пари</p>
          </div>
        </div>
      </div>

      <div className="mt-5 rounded-2xl bg-muted p-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
          <Target className="w-4 h-4 text-primary" aria-hidden="true" />
          {next ? `Следваща цел: ${next.label}` : "Всички цели са постигнати"}
          {next && <span className="ml-auto text-xs font-medium text-muted-foreground">остават {remainingText(next.ms - elapsed)}</span>}
        </div>
        <div className="mt-3 h-2.5 rounded-full bg-background overflow-hidden" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(progress)}>
          <div className="h-full rounded-full bg-primary transition-[width] duration-1000" style={{ width: `${progress}%` }} />
        </div>
        {next && <p className="mt-2 text-sm text-muted-foreground">{next.text}</p>}
      </div>

      <ul className="mt-5 flex flex-wrap gap-2">
        {milestones.map((m) => {
          const reached = elapsed >= m.ms;
          return (
            <li
              key={m.label}
              className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold border ${
                reached ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground border-border"
              }`}
            >
              {reached && <Check className="w-3.5 h-3.5" aria-hidden="true" />}
              {m.label}
            </li>
          );
        })}
      </ul>

      <p className="mt-5 text-sm text-muted-foreground leading-relaxed">
        Ако пак изпушиш цигара, това не е край. Задай нова дата и продължи. За помощ при отказване говори с личния лекар.
      </p>
    </div>
  );
};

export default QuitCounter;

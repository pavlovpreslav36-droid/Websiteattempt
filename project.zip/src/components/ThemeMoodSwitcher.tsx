import { motion } from "framer-motion";
import { Moon, Sun, Sparkles } from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import { Reveal } from "@/components/Reveal";

const moods = [
  { mode: "dark" as const, label: "Спокойствие", emoji: "🌙", icon: Moon, gradient: "from-indigo-500/30 via-purple-500/20 to-cyan-500/30" },
  { mode: "light" as const, label: "Енергия", emoji: "☀️", icon: Sun, gradient: "from-amber-300/40 via-orange-300/30 to-pink-300/30" },
  { mode: "custom" as const, label: "Творчество", emoji: "✨", icon: Sparkles, gradient: "from-fuchsia-500/30 via-pink-500/20 to-violet-500/30" },
];

export const ThemeMoodSwitcher = () => {
  const { mode, setMode } = useTheme();

  return (
    <section className="py-20 md:py-24 px-6">
      <div className="max-w-5xl mx-auto">
        <Reveal>
          <h2 className="text-3xl md:text-5xl font-display font-bold text-center mb-4 text-foreground">
            Изберете вашето настроение
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="text-center text-muted-foreground text-lg mb-12 max-w-xl mx-auto">
            Темата на сайта се променя според вашето усещане за деня
          </p>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {moods.map((m, i) => {
            const active = mode === m.mode;
            const Icon = m.icon;
            return (
              <Reveal key={m.mode} delay={0.1 + i * 0.08} direction="scale">
                <motion.button
                  whileHover={{ y: -6, scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  onClick={() => setMode(m.mode)}
                  className={`relative w-full h-44 rounded-3xl border overflow-hidden text-left p-6 transition-colors duration-500 ${
                    active ? "border-primary shadow-2xl shadow-primary/20" : "border-border hover:border-primary/40"
                  }`}
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${m.gradient} opacity-90`} />
                  <motion.div
                    className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-white/10 blur-3xl"
                    animate={{ scale: active ? [1, 1.2, 1] : 1 }}
                    transition={{ duration: 4, repeat: active ? Infinity : 0, ease: "easeInOut" }}
                  />
                  <div className="relative z-10 flex flex-col h-full justify-between">
                    <div className="flex items-center justify-between">
                      <span className="text-4xl">{m.emoji}</span>
                      <Icon className="w-6 h-6 text-foreground/80" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-display font-bold text-foreground">{m.label}</h3>
                      <p className="text-sm text-foreground/70 mt-1">
                        {active ? "✓ Активна тема" : "Натиснете за смяна"}
                      </p>
                    </div>
                  </div>
                </motion.button>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
};

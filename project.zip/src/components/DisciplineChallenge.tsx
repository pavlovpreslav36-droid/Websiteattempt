import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Zap, Check } from "lucide-react";

const STORAGE_KEY = "ahm_discipline_challenge_v1";
const todayISO = () => new Date().toISOString().slice(0, 10);

export function DisciplineChallenge() {
  const [completedDate, setCompletedDate] = useState<string | null>(null);
  const [celebrate, setCelebrate] = useState(false);

  useEffect(() => {
    const v = localStorage.getItem(STORAGE_KEY);
    if (v) setCompletedDate(v);
  }, []);

  const done = completedDate === todayISO();

  const handleComplete = () => {
    const d = todayISO();
    localStorage.setItem(STORAGE_KEY, d);
    setCompletedDate(d);
    setCelebrate(true);
    setTimeout(() => setCelebrate(false), 1600);
  };

  return (
    <div className="relative rounded-3xl p-6 md:p-10 overflow-hidden bg-card border border-border shadow-card">
      <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-accent/10 blur-3xl" />
      <div className="absolute -bottom-20 -left-20 w-64 h-64 rounded-full bg-primary/10 blur-3xl" />

      <div className="relative">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-10 h-10 rounded-2xl bg-accent/20 shadow-sm flex items-center justify-center">
            <Zap className="w-5 h-5 text-accent" />
          </div>
          <span className="uppercase tracking-[0.2em] text-xs font-bold text-accent">Daily Discipline Challenge</span>
        </div>

        <h3 className="text-2xl md:text-4xl font-display font-bold text-foreground leading-tight mb-3">
          Комфортът е врагът.
        </h3>
        <p className="text-base md:text-lg text-muted-foreground leading-relaxed mb-6 max-w-2xl">
          Днес направи <span className="text-foreground font-semibold">2-минутен студен душ</span> или{" "}
          <span className="text-foreground font-semibold">50 лицеви опори</span>, преди да погледнеш телефона си. Без извинения.
        </p>

        <motion.button
          whileHover={!done ? { scale: 1.03 } : undefined}
          whileTap={!done ? { scale: 0.97 } : undefined}
          onClick={handleComplete}
          disabled={done}
          className={`relative inline-flex items-center gap-2 px-6 md:px-8 py-3 md:py-4 rounded-full font-semibold transition-all duration-300 ${
            done
              ? "bg-primary/15 text-primary shadow-sm cursor-not-allowed"
              : "bg-accent text-accent-foreground hover:shadow-[0_0_30px_-5px_hsl(var(--accent)/0.7)]"
          }`}
        >
          {done ? <Check className="w-5 h-5" /> : <Zap className="w-5 h-5" />}
          {done ? "Изпълнено за днес" : "Завърших предизвикателството"}
        </motion.button>

        <AnimatePresence>
          {celebrate && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.4 }}
              transition={{ duration: 0.6 }}
              className="absolute inset-0 flex items-center justify-center pointer-events-none"
            >
              <div className="text-6xl md:text-8xl">🔥</div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
import { motion, useScroll, useSpring, useTransform } from "framer-motion";
import { ProduceIcon } from "@/components/art/Produce";

/** A thin line under the header that fills as you scroll, with a tomato rolling along it. */
export const ScrollProgress = () => {
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 24, mass: 0.3 });
  const left = useTransform(progress, [0, 1], ["0%", "calc(100% - 18px)"]);
  const rotate = useTransform(progress, [0, 1], [0, 1800]);

  return (
    <div
      className="fixed inset-x-0 z-[55] h-[3px] pointer-events-none top-[calc(var(--nav-h)_+_env(safe-area-inset-top,0px))]"
      aria-hidden="true"
    >
      <motion.div style={{ scaleX: progress }} className="h-full origin-left bg-gradient-to-r from-primary via-honey to-flame" />
      <motion.div style={{ left, rotate }} className="absolute -top-[7px] w-[18px] h-[18px]">
        <ProduceIcon name="tomato" size={18} />
      </motion.div>
    </div>
  );
};

export default ScrollProgress;

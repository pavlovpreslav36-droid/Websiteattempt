import { useRef, useMemo } from "react";
import { motion, useScroll, useTransform, useSpring, MotionValue } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowDown, Sparkles } from "lucide-react";

/**
 * CinematicHero — full-screen scroll-driven cinematic intro.
 * A tall sticky section: as the user scrolls, three "scenes" crossfade
 * with scaling typography, drifting light particles and a progress rail.
 */

interface Particle {
  left: string;
  top: string;
  size: number;
  delay: number;
  duration: number;
  drift: number;
}

function useParticles(count: number): Particle[] {
  return useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        left: `${(i * 37 + 13) % 100}%`,
        top: `${(i * 53 + 7) % 100}%`,
        size: 2 + ((i * 7) % 4),
        delay: (i * 0.7) % 6,
        duration: 8 + ((i * 3) % 8),
        drift: 20 + ((i * 11) % 40),
      })),
    [count]
  );
}

function Scene({
  progress,
  range,
  children,
}: {
  progress: MotionValue<number>;
  range: [number, number];
  children: React.ReactNode;
}) {
  const [start, end] = range;
  const fade = 0.08;
  // First scene is fully visible on load; later scenes fade in
  const opacity = useTransform(
    progress,
    [start, start + fade, end - fade, end],
    start === 0 ? [1, 1, 1, 0] : [0, 1, 1, 0]
  );
  const scale = useTransform(progress, [start, end], [0.92, 1.06]);
  const y = useTransform(progress, [start, end], [40, -40]);

  return (
    <motion.div
      style={{ opacity, scale, y }}
      className="absolute inset-0 flex items-center justify-center pointer-events-none"
    >
      {children}
    </motion.div>
  );
}

export function CinematicHero() {
  const navigate = useNavigate();
  const ref = useRef<HTMLDivElement>(null);
  const particles = useParticles(28);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end end"],
  });
  const smooth = useSpring(scrollYProgress, { stiffness: 60, damping: 20 });

  // Background glow shifts hue across the scroll
  const glowX = useTransform(smooth, [0, 1], ["20%", "80%"]);
  const glowY = useTransform(smooth, [0, 1], ["30%", "70%"]);
  const railHeight = useTransform(smooth, [0, 1], ["0%", "100%"]);
  const hintOpacity = useTransform(smooth, [0, 0.06], [1, 0]);
  const exitOpacity = useTransform(smooth, [0.92, 1], [1, 0]);

  return (
    <section ref={ref} className="relative h-[320vh]" aria-label="Кинематографично въведение">
      <div className="sticky top-0 h-screen overflow-hidden flex items-center justify-center">
        {/* Ambient glow */}
        <motion.div
          className="absolute w-[60vmax] h-[60vmax] rounded-full blur-3xl opacity-30"
          style={{
            left: glowX,
            top: glowY,
            x: "-50%",
            y: "-50%",
            background:
              "radial-gradient(circle, hsl(var(--primary) / 0.5), hsl(var(--accent) / 0.25), transparent 70%)",
          }}
        />

        {/* Drifting light particles */}
        {particles.map((p, i) => (
          <motion.span
            key={i}
            className="absolute rounded-full bg-primary/40"
            style={{ left: p.left, top: p.top, width: p.size, height: p.size }}
            animate={{ y: [0, -p.drift, 0], opacity: [0.15, 0.7, 0.15] }}
            transition={{ duration: p.duration, delay: p.delay, repeat: Infinity, ease: "easeInOut" }}
          />
        ))}

        {/* Progress rail */}
        <div className="absolute right-5 md:right-10 top-1/2 -translate-y-1/2 h-40 w-px bg-border/50 rounded-full overflow-hidden">
          <motion.div className="w-full bg-primary rounded-full origin-top" style={{ height: railHeight }} />
        </div>

        {/* Scenes */}
        <Scene progress={smooth} range={[0, 0.33]}>
          <div className="text-center px-6 max-w-4xl">
            <motion.p className="text-primary font-medium tracking-[0.3em] uppercase text-xs md:text-sm mb-6 flex items-center justify-center gap-2">
              <Sparkles className="w-4 h-4" /> Aleko Health Matters
            </motion.p>
            <h2 className="text-4xl md:text-7xl font-display font-bold text-foreground leading-[1.05] tracking-tight">
              Едно решение.
              <br />
              <span className="gradient-text">Един ден.</span>
            </h2>
          </div>
        </Scene>

        <Scene progress={smooth} range={[0.33, 0.66]}>
          <div className="text-center px-6 max-w-4xl">
            <h2 className="text-4xl md:text-7xl font-display font-bold text-foreground leading-[1.05] tracking-tight">
              Малките стъпки
              <br />
              <span className="gradient-text">стават навик.</span>
            </h2>
            <p className="mt-6 text-muted-foreground text-base md:text-xl max-w-xl mx-auto">
              Вода. Движение. Сън. Дишане. Всичко на едно място.
            </p>
          </div>
        </Scene>

        <Scene progress={smooth} range={[0.66, 0.97]}>
          <div className="text-center px-6 max-w-4xl pointer-events-auto">
            <h2 className="text-4xl md:text-7xl font-display font-bold text-foreground leading-[1.05] tracking-tight">
              Навикът става
              <br />
              <span className="gradient-text">твой живот.</span>
            </h2>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <button
                onClick={() => navigate("/recipes")}
                className="px-8 h-12 rounded-full bg-primary text-primary-foreground font-medium shadow-lg hover:scale-[1.04] transition-transform duration-300"
              >
                Разгледай рецептите
              </button>
              <button
                onClick={() => navigate("/quiz")}
                className="px-8 h-12 rounded-full border border-primary/40 text-foreground font-medium hover:bg-primary/10 hover:scale-[1.04] transition-all duration-300"
              >
                Започни викторината
              </button>
            </div>
          </div>
        </Scene>

        {/* Scroll hint */}
        <motion.div
          style={{ opacity: hintOpacity }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-muted-foreground"
        >
          <span className="text-xs tracking-[0.25em] uppercase">Скролни</span>
          <motion.div animate={{ y: [0, 8, 0] }} transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}>
            <ArrowDown className="w-5 h-5" />
          </motion.div>
        </motion.div>

        {/* Soft fade out at the very end */}
        <motion.div style={{ opacity: exitOpacity }} className="absolute inset-0 pointer-events-none" />
      </div>
    </section>
  );
}

export default CinematicHero;

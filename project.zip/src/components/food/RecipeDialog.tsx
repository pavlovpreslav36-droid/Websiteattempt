import { Clock, Copy, Flame, ShoppingCart } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import type { DietRecipe } from "@/data/dietRecipes";
import { tagLabels, visibleTags } from "@/data/diets";
import { addItems } from "@/lib/shoppingList";
import { copyText } from "@/lib/copyText";

export const RecipeDialog = ({ recipe, onClose }: { recipe: DietRecipe | null; onClose: () => void }) => {
  const addToList = () => {
    if (!recipe) return;
    const n = addItems(recipe.ingredients, recipe.name);
    toast.success(n ? `Добавени в списъка: ${n}` : "Всичко вече е в списъка");
  };

  const copy = async () => {
    if (!recipe) return;
    const text = [
      recipe.name,
      `${recipe.minutes} мин, ${recipe.kcal} kcal, ${recipe.protein} г протеин`,
      "",
      "Съставки:",
      ...recipe.ingredients.map((i) => `- ${i}`),
      "",
      "Приготвяне:",
      ...recipe.steps.map((s, i) => `${i + 1}. ${s}`),
    ].join("\n");
    const ok = await copyText(text);
    toast[ok ? "success" : "error"](ok ? "Рецептата е копирана" : "Не успях да копирам");
  };

  return (
    <Dialog open={!!recipe} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 rounded-[2rem] gap-0">
        {recipe && (
          <>
            <div className="relative aspect-[16/9] bg-muted">
              <img src={recipe.photo} alt="" className="w-full h-full object-cover" />
              <span className="absolute left-5 bottom-[-1.25rem] grid place-items-center w-12 h-12 rounded-full bg-card text-2xl ring-4 ring-card shadow-md" aria-hidden="true">
                {recipe.emoji}
              </span>
            </div>
            <div className="p-6 md:p-8 pt-9">
              <p className="eyebrow text-primary">{recipe.meal}</p>
              <DialogTitle className="mt-1 font-brand text-2xl md:text-3xl leading-tight font-normal">{recipe.name}</DialogTitle>
              <DialogDescription className="sr-only">Съставки и начин на приготвяне за {recipe.name}</DialogDescription>

              <ul className="mt-4 flex flex-wrap gap-1.5">
                {visibleTags.filter((t) => recipe.tags.includes(t as never)).map((t) => (
                  <li key={t} className="rounded-full border border-border bg-background/70 px-2.5 py-1 text-xs font-semibold text-foreground/80">{tagLabels[t]}</li>
                ))}
              </ul>

              <div className="mt-5 grid grid-cols-3 gap-3 text-center">
                <div className="rounded-2xl bg-muted py-3">
                  <Clock className="w-4 h-4 mx-auto text-muted-foreground" aria-hidden="true" />
                  <p className="mt-1 font-bold text-foreground">{recipe.minutes} мин</p>
                </div>
                <div className="rounded-2xl bg-muted py-3">
                  <Flame className="w-4 h-4 mx-auto text-primary" aria-hidden="true" />
                  <p className="mt-1 font-bold text-foreground">{recipe.kcal} kcal</p>
                </div>
                <div className="rounded-2xl bg-muted py-3">
                  <p className="text-xs text-muted-foreground">Протеин</p>
                  <p className="font-bold text-foreground">{recipe.protein} г</p>
                </div>
              </div>

              <h3 className="mt-7 font-brand text-xl">Съставки <span className="text-sm font-sans text-muted-foreground">(1 порция)</span></h3>
              <ul className="mt-3 space-y-2">
                {recipe.ingredients.map((ing) => (
                  <li key={ing} className="flex items-start gap-3 text-foreground">
                    <span className="mt-2 w-1.5 h-1.5 rounded-full bg-primary shrink-0" aria-hidden="true" />
                    {ing}
                  </li>
                ))}
              </ul>

              <h3 className="mt-7 font-brand text-xl">Приготвяне</h3>
              <ol className="mt-3 space-y-3">
                {recipe.steps.map((step, i) => (
                  <li key={step} className="flex items-start gap-3">
                    <span className="grid place-items-center w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-bold shrink-0">{i + 1}</span>
                    <span className="pt-0.5 text-foreground">{step}</span>
                  </li>
                ))}
              </ol>

              {recipe.note && <p className="mt-6 rounded-2xl bg-secondary p-4 text-sm text-secondary-foreground">{recipe.note}</p>}

              <div className="mt-7 flex flex-wrap gap-3">
                <Button onClick={addToList}><ShoppingCart className="w-4 h-4 mr-2" aria-hidden="true" />Добави в списъка</Button>
                <Button variant="outline" onClick={copy}><Copy className="w-4 h-4 mr-2" aria-hidden="true" />Копирай рецептата</Button>
              </div>

              <p className="mt-6 text-xs text-muted-foreground leading-relaxed">
                Хранителните стойности са приблизителни. При алергия, непоносимост или заболяване провери етикетите на продуктите и се консултирай с лекар.
              </p>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default RecipeDialog;

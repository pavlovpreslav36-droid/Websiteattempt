import { useId, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Minus, Plus } from "lucide-react";

const KEY = "hydration-v1";
const ML = 250;

interface State {
  date: string;
  count: number;
  goal: number;
}

const today = () => new Date().toLocaleDateString("sv-SE");

function load(): State {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || "null");
    if (v && typeof v.count === "number" && typeof v.goal === "number") {
      return v.date === today() ? { date: v.date, count: v.count, goal: v.goal } : { date: today(), count: 0, goal: v.goal };
    }
  } catch {
    /* ignore broken data */
  }
  return { date: today(), count: 0, goal: 8 };
}

const MiniGlass = ({ filled }: { filled: boolean }) => {
  const id = `mg-${useId().replace(/:/g, "")}`;
  return (
    <svg viewBox="0 0 28 38" className="w-7 h-9" aria-hidden="true">
      <defs>
        <clipPath id={id}>
          <path d="M3 3 H25 L22 33 Q21.8 35 20 35 H8 Q6.2 35 6 33 Z" />
        </clipPath>
      </defs>
      <path d="M3 3 H25 L22 33 Q21.8 35 20 35 H8 Q6.2 35 6 33 Z" fill="#fff" fillOpacity=".5" />
      <g clipPath={`url(#${id})`}>
        <motion.rect
          x="0"
          width="28"
          fill="#6EC3E8"
          initial={false}
          animate={{ y: filled ? 11 : 38, height: filled ? 27 : 0 }}
          transition={{ type: "spring", stiffness: 140, damping: 16 }}
        />
      </g>
      <path d="M3 3 H25 L22 33 Q21.8 35 20 35 H8 Q6.2 35 6 33 Z" fill="none" stroke="#3a0d1c" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
};

/** Counts the glasses of water drunk today. Saved on this device only. */
export const HydrationTracker = () => {
  const [s, setS] = useState<State>(load);

  const save = (next: State) => {
    setS(next);
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch {
      /* private mode */
    }
  };

  const done = s.count >= s.goal;
  const pct = Math.min(100, Math.round((s.count / s.goal) * 100));
  const glasses = Math.max(s.goal, s.count);

  return (
    <div className="rounded-[2rem] bg-card border border-border shadow-card p-6 md:p-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="eyebrow text-primary">Днес</p>
          <h2 className="mt-1 font-brand text-2xl md:text-3xl">Колко вода изпи?</h2>
          <p className="mt-1 text-sm text-muted-foreground">Една чаша е около {ML} мл. Данните остават само на това устройство.</p>
        </div>
        <div className="text-right">
          <p className="font-brand text-4xl text-primary tabular-nums">
            {s.count}<span className="text-muted-foreground text-2xl">/{s.goal}</span>
          </p>
          <p className="text-sm text-muted-foreground tabular-nums">{s.count * ML} мл</p>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-1.5" role="img" aria-label={`${s.count} от ${s.goal} чаши`}>
        {Array.from({ length: glasses }).map((_, i) => (
          <MiniGlass key={i} filled={i < s.count} />
        ))}
      </div>

      <div className="mt-5 h-2.5 rounded-full bg-muted overflow-hidden" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct}>
        <motion.div className="h-full rounded-full bg-gradient-to-r from-[#6EC3E8] to-primary" animate={{ width: `${pct}%` }} transition={{ type: "spring", stiffness: 120, damping: 20 }} />
      </div>

      <p className="mt-3 text-sm font-medium text-foreground min-h-[1.5rem]" aria-live="polite">
        {done ? "Дневната цел е изпълнена. Браво!" : s.count === 0 ? "Започни деня с чаша вода." : `Остават още ${s.goal - s.count} чаши до целта.`}
      </p>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <Button onClick={() => save({ ...s, count: s.count + 1 })}>
          <Plus className="w-4 h-4 mr-2" aria-hidden="true" />Изпих чаша
        </Button>
        <Button variant="outline" onClick={() => save({ ...s, count: Math.max(0, s.count - 1) })} disabled={s.count === 0} aria-label="Махни една чаша">
          <Minus className="w-4 h-4" aria-hidden="true" />
        </Button>
        <div className="ml-auto flex items-center gap-1.5" role="group" aria-label="Дневна цел">
          <span className="text-xs text-muted-foreground mr-1">Цел:</span>
          {[6, 8, 10, 12].map((g) => (
            <button
              key={g}
              onClick={() => save({ ...s, goal: g })}
              aria-pressed={s.goal === g}
              className={`w-9 h-9 rounded-full text-sm font-semibold border transition-colors ${s.goal === g ? "bg-primary text-primary-foreground border-primary" : "border-border text-foreground hover:border-primary/50"}`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HydrationTracker;

import { useId } from "react";
import type { Drink } from "@/data/drinks";

const INK = "#3a0d1c";
const GLASS = "M24 24 H96 L88 150 Q87.5 156 82 156 H38 Q32.5 156 32 150 Z";

const WAVE = (top: number) => `M-20 ${top} q20 -7 40 0${" t40 0".repeat(5)} V170 H-20 Z`;

/** Floating bits inside the glass, by garnish type. */
const Floaters = ({ garnish, top }: { garnish: Drink["garnish"]; top: number }) => {
  const y = top + 12;
  switch (garnish) {
    case "cucumber":
      return (
        <>
          {[44, 68, 54].map((x, i) => (
            <g key={x} className="dg-bob" style={{ animationDelay: `${i * 0.7}s` }}>
              <circle cx={x} cy={y + i * 14} r="10" fill="#9BCB6B" stroke={INK} strokeWidth="2" />
              <circle cx={x} cy={y + i * 14} r="6.5" fill="#E3F5D0" />
            </g>
          ))}
        </>
      );
    case "berry":
      return (
        <>
          {[42, 66, 52, 74].map((x, i) => (
            <circle key={x} className="dg-bob" style={{ animationDelay: `${i * 0.6}s` }} cx={x} cy={y + i * 11} r="6.5" fill={i % 2 ? "#B8244A" : "#E24B5C"} stroke={INK} strokeWidth="2" />
          ))}
        </>
      );
    case "apple":
      return (
        <>
          {[46, 70].map((x, i) => (
            <path key={x} className="dg-bob" style={{ animationDelay: `${i * 0.9}s` }} d={`M${x - 9} ${y + i * 18} q9 -12 18 0 q-9 10 -18 0Z`} fill="#F4D7A0" stroke="#C0392B" strokeWidth="2.5" />
          ))}
        </>
      );
    case "melon":
      return (
        <>
          {[44, 70, 56].map((x, i) => (
            <g key={x} className="dg-bob" style={{ animationDelay: `${i * 0.7}s` }}>
              <rect x={x - 8} y={y + i * 13} width="16" height="16" rx="3" fill="#FF8B94" stroke={INK} strokeWidth="2" />
              <circle cx={x} cy={y + i * 13 + 8} r="1.6" fill={INK} />
            </g>
          ))}
        </>
      );
    case "ginger":
      return (
        <>
          {[46, 70].map((x, i) => (
            <circle key={x} className="dg-bob" style={{ animationDelay: `${i * 0.8}s` }} cx={x} cy={y + i * 16} r="8" fill="#E8C98B" stroke={INK} strokeWidth="2" />
          ))}
        </>
      );
    case "lemon":
    case "lime":
    case "orange": {
      const rind = garnish === "lemon" ? "#F7E04A" : garnish === "lime" ? "#A6D95A" : "#FFA733";
      return (
        <>
          {[50, 70].map((x, i) => (
            <g key={x} className="dg-bob" style={{ animationDelay: `${i * 0.9}s` }}>
              <circle cx={x} cy={y + i * 18} r="11" fill={rind} stroke={INK} strokeWidth="2" />
              <circle cx={x} cy={y + i * 18} r="7" fill="#fff" fillOpacity=".45" />
            </g>
          ))}
        </>
      );
    }
    default:
      return null;
  }
};

/** Garnish that sits on the rim or sticks out of the glass. */
const RimGarnish = ({ garnish, hot }: { garnish: Drink["garnish"]; hot: boolean }) => {
  const rx = hot ? 84 : 96;
  const ry = hot ? 52 : 26;
  switch (garnish) {
    case "lemon":
    case "lime":
    case "orange": {
      const rind = garnish === "lemon" ? "#F7E04A" : garnish === "lime" ? "#A6D95A" : "#FFA733";
      return (
        <g transform={`translate(${rx} ${ry})`}>
          <circle r="14" fill={rind} stroke={INK} strokeWidth="3" />
          <circle r="9" fill="#fff" fillOpacity=".5" />
          {Array.from({ length: 6 }).map((_, i) => (
            <line key={i} x1="0" y1="0" x2="0" y2="-9" stroke={rind} strokeWidth="1.6" transform={`rotate(${i * 60})`} />
          ))}
        </g>
      );
    }
    case "mint":
      return (
        <g transform={`translate(${hot ? 78 : 84} ${hot ? 50 : 24})`}>
          <path d="M0 0 q4 -18 22 -16 q-2 16 -22 16Z" fill="#5FAF5B" stroke={INK} strokeWidth="2.5" strokeLinejoin="round" />
          <path d="M-4 2 q-6 -16 -22 -12 q4 14 22 12Z" fill="#7BC46F" stroke={INK} strokeWidth="2.5" strokeLinejoin="round" />
        </g>
      );
    case "cinnamon":
      return <rect x="62" y="14" width="9" height="62" rx="4" fill="#8B4A2B" stroke={INK} strokeWidth="2.5" transform="rotate(14 66 60)" />;
    case "flower":
      return (
        <g transform="translate(58 58)">
          {Array.from({ length: 8 }).map((_, i) => (
            <ellipse key={i} cx="0" cy="-8" rx="3.4" ry="6" fill="#fff" stroke={INK} strokeWidth="1.4" transform={`rotate(${i * 45})`} />
          ))}
          <circle r="4.4" fill="#F5B82E" stroke={INK} strokeWidth="1.4" />
        </g>
      );
    default:
      return null;
  }
};

interface Props {
  drink: Pick<Drink, "color" | "garnish" | "serve" | "type">;
  className?: string;
  label?: string;
}

/** Animated drink: wavy liquid, rising bubbles, bobbing fruit, steaming mug for hot drinks. */
export const DrinkGlass = ({ drink, className = "", label = "Напитка" }: Props) => {
  const uid = useId().replace(/:/g, "");
  const clipId = `dg-clip-${uid}`;
  const hot = drink.serve === "hot";
  const full = drink.type === "smoothie";
  const top = full ? 44 : 60;
  const { color, garnish } = drink;

  if (hot) {
    return (
      <svg viewBox="0 0 120 170" className={className} role="img" aria-label={label}>
        <ellipse cx="58" cy="158" rx="46" ry="6" fill={INK} opacity=".12" />
        {[44, 58, 72].map((x, i) => (
          <path key={x} className="steam" style={{ animationDelay: `${i * 0.7}s` }} d={`M${x} 40 q-7 -9 0 -18 t0 -18`} fill="none" stroke="#E2A98A" strokeWidth="4" strokeLinecap="round" />
        ))}
        <path d="M90 74 H100 Q114 74 114 92 Q114 110 100 110 H90" fill="none" stroke={INK} strokeWidth="4" strokeLinecap="round" />
        <path d="M26 58 H90 V122 Q90 152 62 152 H54 Q26 152 26 122 Z" fill="#FFF6E5" stroke={INK} strokeWidth="3.5" strokeLinejoin="round" />
        <path d="M34 76 Q34 120 46 142" fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" opacity=".7" />
        <ellipse cx="58" cy="58" rx="32" ry="7" fill="#fff" stroke={INK} strokeWidth="3" />
        <ellipse cx="58" cy="59" rx="27" ry="5" fill={color} />
        <RimGarnish garnish={garnish} hot />
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 120 170" className={className} role="img" aria-label={label}>
      <defs>
        <clipPath id={clipId}>
          <path d={GLASS} />
        </clipPath>
      </defs>
      <ellipse cx="60" cy="160" rx="38" ry="5" fill={INK} opacity=".12" />
      {full && <path d="M76 8 L90 152" stroke="#fff" strokeWidth="7" strokeLinecap="round" />}
      {full && <path d="M76 8 L90 152" stroke={INK} strokeWidth="2" strokeLinecap="round" opacity=".5" />}
      <path d={GLASS} fill="#fff" fillOpacity=".55" />
      <g clipPath={`url(#${clipId})`}>
        <rect x="0" y={top} width="120" height="130" fill={color} />
        <g className="dg-wave">
          <path d={WAVE(top)} fill={color} />
          <path d={WAVE(top)} fill="#fff" opacity=".28" transform="translate(0 -1.5)" />
        </g>
        {!full && [{ x: 46, y: top + 22, r: 11, d: 0 }, { x: 68, y: top + 40, r: 10, d: 1.2 }].map((c) => (
          <rect key={c.x} className="dg-bob" style={{ animationDelay: `${c.d}s` }} x={c.x - c.r} y={c.y - c.r} width={c.r * 2} height={c.r * 2} rx="4" fill="#fff" fillOpacity=".4" stroke="#fff" strokeOpacity=".8" strokeWidth="2" />
        ))}
        <Floaters garnish={garnish} top={top + 10} />
        {[{ x: 44, d: 0 }, { x: 60, d: 1.3 }, { x: 74, d: 2.4 }, { x: 52, d: 3.1 }].map((b) => (
          <circle key={b.x} className="dg-bubble" style={{ animationDelay: `${b.d}s` }} cx={b.x} cy="148" r="2.6" fill="#fff" fillOpacity=".9" />
        ))}
        <path d="M38 40 Q42 100 46 146" fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" opacity=".35" />
      </g>
      <path d={GLASS} fill="none" stroke={INK} strokeWidth="3.5" strokeLinejoin="round" />
      <RimGarnish garnish={garnish} hot={false} />
    </svg>
  );
};

export default DrinkGlass;

import { Clock, Copy, Flame, ShoppingCart } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { drinkTypes, type Drink } from "@/data/drinks";
import { tagLabels, visibleTags } from "@/data/diets";
import { addItems } from "@/lib/shoppingList";
import { copyText } from "@/lib/copyText";
import { DrinkGlass } from "./DrinkGlass";

export const DrinkDialog = ({ drink, onClose }: { drink: Drink | null; onClose: () => void }) => {
  const addToList = () => {
    if (!drink) return;
    const n = addItems(drink.ingredients, drink.name);
    toast.success(n ? `Добавени в списъка: ${n}` : "Всичко вече е в списъка");
  };

  const copy = async () => {
    if (!drink) return;
    const text = [
      drink.name,
      `${drink.minutes} мин, ${drink.kcal} kcal`,
      "",
      "Съставки:",
      ...drink.ingredients.map((i) => `- ${i}`),
      "",
      "Приготвяне:",
      ...drink.steps.map((s, i) => `${i + 1}. ${s}`),
    ].join("\n");
    const ok = await copyText(text);
    toast[ok ? "success" : "error"](ok ? "Рецептата е копирана" : "Не успях да копирам");
  };

  return (
    <Dialog open={!!drink} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 rounded-[2rem] gap-0">
        {drink && (
          <>
            <div className="py-8 grid place-items-center" style={{ background: `${drink.color}55` }}>
              <DrinkGlass drink={drink} label={drink.name} className="h-52 w-auto" />
            </div>
            <div className="p-6 md:p-8">
              <p className="eyebrow text-primary">{drinkTypes.find((t) => t.id === drink.type)?.label}</p>
              <DialogTitle className="mt-1 font-brand text-2xl md:text-3xl leading-tight font-normal">{drink.name}</DialogTitle>
              <DialogDescription className="sr-only">Съставки и приготвяне на {drink.name}</DialogDescription>

              <ul className="mt-4 flex flex-wrap gap-1.5">
                {visibleTags.filter((t) => drink.tags.includes(t as never)).map((t) => (
                  <li key={t} className="rounded-full border border-border bg-background/70 px-2.5 py-1 text-xs font-semibold text-foreground/80">{tagLabels[t]}</li>
                ))}
              </ul>

              <div className="mt-5 grid grid-cols-3 gap-3 text-center">
                <div className="rounded-2xl bg-muted py-3"><Clock className="w-4 h-4 mx-auto text-muted-foreground" aria-hidden="true" /><p className="mt-1 font-bold text-foreground">{drink.minutes} мин</p></div>
                <div className="rounded-2xl bg-muted py-3"><Flame className="w-4 h-4 mx-auto text-primary" aria-hidden="true" /><p className="mt-1 font-bold text-foreground">{drink.kcal} kcal</p></div>
                <div className="rounded-2xl bg-muted py-3"><p className="text-xs text-muted-foreground">Сервира се</p><p className="font-bold text-foreground">{drink.serve === "hot" ? "Топла" : "Студена"}</p></div>
              </div>

              <h3 className="mt-7 font-brand text-xl">Съставки</h3>
              <ul className="mt-3 space-y-2">
                {drink.ingredients.map((ing) => (
                  <li key={ing} className="flex items-start gap-3 text-foreground">
                    <span className="mt-2 w-1.5 h-1.5 rounded-full bg-primary shrink-0" aria-hidden="true" />
                    {ing}
                  </li>
                ))}
              </ul>

              <h3 className="mt-7 font-brand text-xl">Приготвяне</h3>
              <ol className="mt-3 space-y-3">
                {drink.steps.map((step, i) => (
                  <li key={step} className="flex items-start gap-3">
                    <span className="grid place-items-center w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-bold shrink-0">{i + 1}</span>
                    <span className="pt-0.5 text-foreground">{step}</span>
                  </li>
                ))}
              </ol>

              {drink.note && <p className="mt-6 rounded-2xl bg-secondary p-4 text-sm text-secondary-foreground">{drink.note}</p>}

              <div className="mt-7 flex flex-wrap gap-3">
                <Button onClick={addToList}><ShoppingCart className="w-4 h-4 mr-2" aria-hidden="true" />Добави в списъка</Button>
                <Button variant="outline" onClick={copy}><Copy className="w-4 h-4 mr-2" aria-hidden="true" />Копирай рецептата</Button>
              </div>

              <p className="mt-6 text-xs text-muted-foreground leading-relaxed">
                Напитките подкрепят хидратацията и ежедневните навици, но не лекуват. При заболяване или прием на лекарства се консултирай с лекар.
              </p>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default DrinkDialog;

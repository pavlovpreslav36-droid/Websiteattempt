import type { ReactNode } from "react";

/** Big burgundy header used on the food pages. */
export const PageBanner = ({ eyebrow, title, text, children, art }: { eyebrow: string; title: string; text?: string; children?: ReactNode; art?: ReactNode }) => (
  <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] md:rounded-[2.5rem] overflow-hidden bg-wine text-cream">
    <div className="absolute -right-20 -top-20 w-72 h-72 rounded-full bg-flame/20 float-slow" aria-hidden="true" />
    <div className="absolute right-24 -bottom-24 w-56 h-56 rounded-full bg-wine-2 float-slower" aria-hidden="true" />
    <div className="relative container py-12 md:py-20 grid md:grid-cols-[1.3fr_auto] gap-8 items-center">
      <div>
        <p className="eyebrow text-flame">{eyebrow}</p>
        <h1 className="display mt-4 text-[clamp(2.1rem,7.2vw,4.8rem)] text-cream">{title}</h1>
        {text && <p className="mt-5 text-cream/85 text-base md:text-lg max-w-xl leading-relaxed">{text}</p>}
        {children}
      </div>
      {art && <div className="hidden md:block">{art}</div>}
    </div>
  </section>
);

export const SectionTitle = ({ children, text }: { children: ReactNode; text?: string }) => (
  <div className="mb-8 md:mb-10 max-w-2xl">
    <h2 className="display text-[clamp(1.7rem,4.6vw,3rem)] text-primary">{children}</h2>
    {text && <p className="mt-3 text-muted-foreground text-base md:text-lg">{text}</p>}
  </div>
);

export default PageBanner;

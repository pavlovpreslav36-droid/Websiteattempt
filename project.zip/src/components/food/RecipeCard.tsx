import { Clock, Flame } from "lucide-react";
import type { DietRecipe } from "@/data/dietRecipes";
import { tagLabels, visibleTags } from "@/data/diets";

export const TagChips = ({ tags, max = 3 }: { tags: string[]; max?: number }) => {
  const shown = visibleTags.filter((t) => tags.includes(t)).slice(0, max);
  if (!shown.length) return null;
  return (
    <ul className="mt-2 flex flex-wrap gap-1.5">
      {shown.map((t) => (
        <li key={t} className="rounded-full border border-border bg-background/70 px-2 py-0.5 text-[10.5px] font-semibold text-foreground/80">
          {tagLabels[t]}
        </li>
      ))}
    </ul>
  );
};

export const RecipeCard = ({ recipe, onOpen }: { recipe: DietRecipe; onOpen: (r: DietRecipe) => void }) => (
  <button
    onClick={() => onOpen(recipe)}
    className="group text-left w-full rounded-[2rem] bg-card border border-border p-2.5 pb-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-lg active:scale-[0.98]"
  >
    <div className="relative arch aspect-[5/4] bg-muted">
      <img src={recipe.photo} alt="" loading="lazy" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
      <span className="absolute left-2.5 bottom-2.5 grid place-items-center w-9 h-9 rounded-full bg-card text-lg ring-2 ring-card shadow-md" aria-hidden="true">
        {recipe.emoji}
      </span>
    </div>
    <div className="px-2 pt-3">
      <p className="eyebrow text-primary">{recipe.meal}</p>
      <h3 className="mt-1 font-brand text-[1.05rem] leading-snug text-foreground line-clamp-2 min-h-[2.6em]">{recipe.name}</h3>
      <p className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
        <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" aria-hidden="true" />{recipe.minutes} мин</span>
        <span className="flex items-center gap-1"><Flame className="w-3.5 h-3.5 text-primary" aria-hidden="true" />{recipe.kcal} kcal</span>
        <span className="font-semibold text-foreground">{recipe.protein} г протеин</span>
      </p>
      <TagChips tags={recipe.tags} />
    </div>
  </button>
);

export default RecipeCard;

import { Clock, Flame } from "lucide-react";
import { drinkTypes, type Drink } from "@/data/drinks";
import { DrinkGlass } from "./DrinkGlass";
import { TagChips } from "./RecipeCard";

export const DrinkCard = ({ drink, onOpen }: { drink: Drink; onOpen: (d: Drink) => void }) => {
  const typeLabel = drinkTypes.find((t) => t.id === drink.type)?.label ?? "";
  return (
    <button
      onClick={() => onOpen(drink)}
      className="group text-left w-full rounded-[2rem] bg-card border border-border p-2.5 pb-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-lg active:scale-[0.98]"
    >
      <div className="rounded-[1.5rem] py-4 grid place-items-center transition-colors" style={{ background: `${drink.color}40` }}>
        <DrinkGlass drink={drink} label={drink.name} className="h-36 w-auto transition-transform duration-300 group-hover:scale-105" />
      </div>
      <div className="px-2 pt-3">
        <p className="eyebrow text-primary">{typeLabel}</p>
        <h3 className="mt-1 font-brand text-[1.05rem] leading-snug text-foreground line-clamp-2 min-h-[2.6em]">{drink.name}</h3>
        <p className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" aria-hidden="true" />{drink.minutes} мин</span>
          <span className="flex items-center gap-1"><Flame className="w-3.5 h-3.5 text-primary" aria-hidden="true" />{drink.kcal} kcal</span>
        </p>
        <TagChips tags={drink.tags} />
      </div>
    </button>
  );
};

export default DrinkCard;

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Smile, 
  Frown, 
  Zap, 
  Moon, 
  Heart,
  Activity,
  Dumbbell,
  Wind,
  Footprints,
  Waves,
  RefreshCw
} from "lucide-react";

interface Mood {
  id: string;
  label: string;
  emoji: string;
  icon: React.ReactNode;
  color: string;
}

interface Workout {
  name: string;
  description: string;
  duration: string;
  icon: React.ReactNode;
  benefits: string[];
}

const moods: Mood[] = [
  { 
    id: "stressed", 
    label: "Стресиран/а", 
    emoji: "😰", 
    icon: <Frown className="w-6 h-6" />,
    color: "from-orange-500 to-red-500"
  },
  { 
    id: "energetic", 
    label: "Енергичен/а", 
    emoji: "⚡", 
    icon: <Zap className="w-6 h-6" />,
    color: "from-yellow-500 to-orange-500"
  },
  { 
    id: "tired", 
    label: "Уморен/а", 
    emoji: "😴", 
    icon: <Moon className="w-6 h-6" />,
    color: "from-blue-500 to-indigo-500"
  },
  { 
    id: "happy", 
    label: "Щастлив/а", 
    emoji: "😊", 
    icon: <Smile className="w-6 h-6" />,
    color: "from-green-500 to-emerald-500"
  },
  { 
    id: "anxious", 
    label: "Тревожен/а", 
    emoji: "😟", 
    icon: <Heart className="w-6 h-6" />,
    color: "from-purple-500 to-pink-500"
  },
];

const workoutSuggestions: Record<string, Workout> = {
  stressed: {
    name: "Йога",
    description: "Успокояващи пози и дихателни упражнения за намаляване на стреса",
    duration: "20-30 мин",
    icon: <Wind className="w-12 h-12" />,
    benefits: ["Намалява кортизола", "Подобрява съня", "Успокоява ума"]
  },
  energetic: {
    name: "HIIT тренировка",
    description: "Интензивна интервална тренировка за максимално изгаряне на калории",
    duration: "15-25 мин",
    icon: <Dumbbell className="w-12 h-12" />,
    benefits: ["Изгаря калории", "Повишава издръжливостта", "Освобождава ендорфини"]
  },
  tired: {
    name: "Лека разходка",
    description: "Спокойна разходка на открито за освежаване и енергия",
    duration: "15-20 мин",
    icon: <Footprints className="w-12 h-12" />,
    benefits: ["Повишава енергията", "Подобрява настроението", "Не изморява"]
  },
  happy: {
    name: "Танцова тренировка",
    description: "Забавна кардио тренировка с музика и движение",
    duration: "20-30 мин",
    icon: <Activity className="w-12 h-12" />,
    benefits: ["Забавна е", "Подобрява координацията", "Споделя радостта"]
  },
  anxious: {
    name: "Плуване",
    description: "Ритмични движения във вода за успокояване на тялото и ума",
    duration: "30-45 мин",
    icon: <Waves className="w-12 h-12" />,
    benefits: ["Релаксира мускулите", "Регулира дишането", "Медитативен ефект"]
  },
};

export const MoodWorkoutSuggestion = () => {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  const handleMoodSelect = (moodId: string) => {
    setSelectedMood(moodId);
    setTimeout(() => setShowResult(true), 300);
  };

  const handleReset = () => {
    setShowResult(false);
    setTimeout(() => setSelectedMood(null), 300);
  };

  const selectedMoodData = moods.find(m => m.id === selectedMood);
  const suggestedWorkout = selectedMood ? workoutSuggestions[selectedMood] : null;

  return (
    <Card className="w-full max-w-2xl mx-auto overflow-hidden bg-card border border-border rounded-3xl shadow-card">
      <CardHeader className="text-center pb-4">
        <CardTitle className="text-2xl md:text-3xl font-bold gradient-text">
          Как се чувстваш днес? 🤔
        </CardTitle>
        <p className="text-muted-foreground mt-2">
          Избери настроението си и получи персонализирана препоръка за тренировка
        </p>
      </CardHeader>
      
      <CardContent className="p-6">
        <AnimatePresence mode="wait">
          {!showResult ? (
            <motion.div
              key="mood-selection"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-2 md:grid-cols-5 gap-3"
            >
              {moods.map((mood, index) => (
                <motion.div
                  key={mood.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Button
                    variant="outline"
                    className={`w-full h-24 flex flex-col gap-2 hover:scale-105 transition-all duration-300 ${
                      selectedMood === mood.id 
                        ? `bg-gradient-to-br ${mood.color} text-white border-transparent` 
                        : "hover:border-primary"
                    }`}
                    onClick={() => handleMoodSelect(mood.id)}
                  >
                    <span className="text-3xl">{mood.emoji}</span>
                    <span className="text-xs font-medium">{mood.label}</span>
                  </Button>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div
              key="workout-result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="space-y-6"
            >
              {/* Selected mood badge */}
              <div className="flex justify-center">
                <motion.div
                  initial={{ y: -20 }}
                  animate={{ y: 0 }}
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r ${selectedMoodData?.color} text-white font-medium`}
                >
                  <span className="text-xl">{selectedMoodData?.emoji}</span>
                  <span>{selectedMoodData?.label}</span>
                </motion.div>
              </div>

              {/* Workout suggestion card */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="p-6 rounded-3xl bg-gradient-to-br from-primary/10 to-primary/5 shadow-sm"
              >
                <div className="flex flex-col md:flex-row items-center gap-6">
                  <motion.div
                    animate={{ 
                      rotate: [0, 5, -5, 0],
                      scale: [1, 1.05, 1]
                    }}
                    transition={{ 
                      duration: 2, 
                      repeat: Infinity,
                      repeatType: "reverse"
                    }}
                    className="text-primary"
                  >
                    {suggestedWorkout?.icon}
                  </motion.div>
                  
                  <div className="text-center md:text-left flex-1">
                    <h3 className="text-2xl font-bold text-primary mb-2">
                      {suggestedWorkout?.name}
                    </h3>
                    <p className="text-muted-foreground mb-3">
                      {suggestedWorkout?.description}
                    </p>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-medium">
                      ⏱️ {suggestedWorkout?.duration}
                    </div>
                  </div>
                </div>

                {/* Benefits */}
                <div className="mt-6 pt-4 border-t border-primary/10">
                  <p className="text-sm font-medium text-muted-foreground mb-3">
                    Ползи от тази тренировка:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {suggestedWorkout?.benefits.map((benefit, index) => (
                      <motion.span
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.3 + index * 0.1 }}
                        className="px-3 py-1 rounded-full bg-card/70 text-foreground text-sm shadow-sm"
                      >
                        ✓ {benefit}
                      </motion.span>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* Reset button */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="flex justify-center"
              >
                <Button
                  variant="outline"
                  onClick={handleReset}
                  className="gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Избери отново
                </Button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
};

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Plus, Flame, Leaf } from "lucide-react";

export interface CatalogProduct {
  id: string;
  name: string;
  brand: string;
  category: string;
  calories: number;
  carbs: number;
  protein: number;
  fats: number;
  sugars: number;
  fiber: number;
  healthScore: number;
  isHealthy: boolean;
  emoji: string;
}

const catalogProducts: CatalogProduct[] = [
  // Млечни продукти
  { id: "1", name: "Кисело мляко 3.6%", brand: "Верея", category: "Млечни", calories: 57, carbs: 4.5, protein: 3.4, fats: 3.6, sugars: 4.5, fiber: 0, healthScore: 8, isHealthy: true, emoji: "🥛" },
  { id: "2", name: "Кисело мляко 2%", brand: "LB Булгарикум", category: "Млечни", calories: 44, carbs: 4.2, protein: 3.5, fats: 2, sugars: 4.2, fiber: 0, healthScore: 9, isHealthy: true, emoji: "🥛" },
  { id: "3", name: "Бяло саламурено сирене", brand: "Верея", category: "Млечни", calories: 264, carbs: 1, protein: 17, fats: 21, sugars: 0.5, fiber: 0, healthScore: 6, isHealthy: true, emoji: "🧀" },
  { id: "4", name: "Кашкавал от краве мляко", brand: "Маджаров", category: "Млечни", calories: 350, carbs: 2, protein: 25, fats: 27, sugars: 0.5, fiber: 0, healthScore: 5, isHealthy: false, emoji: "🧀" },
  { id: "5", name: "Прясно мляко 3.6%", brand: "Верея", category: "Млечни", calories: 64, carbs: 4.7, protein: 3.3, fats: 3.6, sugars: 4.7, fiber: 0, healthScore: 7, isHealthy: true, emoji: "🥛" },
  { id: "6", name: "Айрян", brand: "Верея", category: "Млечни", calories: 28, carbs: 2.5, protein: 1.5, fats: 1.2, sugars: 2.5, fiber: 0, healthScore: 8, isHealthy: true, emoji: "🥤" },
  { id: "25", name: "Кисело мляко 4.5%", brand: "Бор Чвор", category: "Млечни", calories: 65, carbs: 4.3, protein: 3.3, fats: 4.5, sugars: 4.3, fiber: 0, healthScore: 7, isHealthy: true, emoji: "🥛" },
  { id: "26", name: "Кисело мляко 2%", brand: "Бор Чвор", category: "Млечни", calories: 42, carbs: 4.1, protein: 3.4, fats: 2, sugars: 4.1, fiber: 0, healthScore: 9, isHealthy: true, emoji: "🥛" },
  { id: "27", name: "Сирене от овче мляко", brand: "Бор Чвор", category: "Млечни", calories: 280, carbs: 0.8, protein: 18, fats: 23, sugars: 0.5, fiber: 0, healthScore: 6, isHealthy: true, emoji: "🧀" },
  { id: "28", name: "Цедено мляко", brand: "Верея", category: "Млечни", calories: 52, carbs: 3.8, protein: 5.2, fats: 2, sugars: 3.8, fiber: 0, healthScore: 9, isHealthy: true, emoji: "🥛" },
  { id: "29", name: "Кашкавал Витоша", brand: "Маджаров", category: "Млечни", calories: 340, carbs: 1.5, protein: 26, fats: 26, sugars: 0.3, fiber: 0, healthScore: 5, isHealthy: false, emoji: "🧀" },
  { id: "30", name: "Топено сирене", brand: "Маджаров", category: "Млечни", calories: 245, carbs: 3, protein: 14, fats: 20, sugars: 2, fiber: 0, healthScore: 4, isHealthy: false, emoji: "🧀" },
  { id: "31", name: "Краве масло", brand: "Верея", category: "Млечни", calories: 735, carbs: 0.5, protein: 0.6, fats: 82, sugars: 0.5, fiber: 0, healthScore: 3, isHealthy: false, emoji: "🧈" },
  { id: "32", name: "Сметана 30%", brand: "Верея", category: "Млечни", calories: 292, carbs: 3, protein: 2.2, fats: 30, sugars: 3, fiber: 0, healthScore: 3, isHealthy: false, emoji: "🥛" },
  { id: "33", name: "Извара", brand: "Бор Чвор", category: "Млечни", calories: 98, carbs: 3.4, protein: 11, fats: 4.3, sugars: 3.4, fiber: 0, healthScore: 8, isHealthy: true, emoji: "🧀" },
  { id: "34", name: "Прясно мляко 1.5%", brand: "Бор Чвор", category: "Млечни", calories: 46, carbs: 4.8, protein: 3.2, fats: 1.5, sugars: 4.8, fiber: 0, healthScore: 8, isHealthy: true, emoji: "🥛" },
  { id: "35", name: "Моцарела", brand: "Маджаров", category: "Млечни", calories: 280, carbs: 1, protein: 22, fats: 20, sugars: 0.5, fiber: 0, healthScore: 6, isHealthy: true, emoji: "🧀" },

  // Месни продукти
  { id: "7", name: "Луканка Панагюрска", brand: "Тандем", category: "Месни", calories: 455, carbs: 1, protein: 25, fats: 39, sugars: 0.5, fiber: 0, healthScore: 3, isHealthy: false, emoji: "🥩" },
  { id: "8", name: "Суджук", brand: "Тандем", category: "Месни", calories: 420, carbs: 2, protein: 22, fats: 36, sugars: 1, fiber: 0, healthScore: 3, isHealthy: false, emoji: "🌭" },
  { id: "9", name: "Кренвирши пилешки", brand: "Тандем", category: "Месни", calories: 215, carbs: 4, protein: 12, fats: 17, sugars: 1.5, fiber: 0, healthScore: 4, isHealthy: false, emoji: "🌭" },
  { id: "10", name: "Пастърма говежда", brand: "Елена", category: "Месни", calories: 180, carbs: 0.5, protein: 30, fats: 6, sugars: 0, fiber: 0, healthScore: 7, isHealthy: true, emoji: "🥩" },
  { id: "36", name: "Шунка от свинско бут", brand: "Тандем", category: "Месни", calories: 145, carbs: 1, protein: 20, fats: 7, sugars: 0.5, fiber: 0, healthScore: 6, isHealthy: true, emoji: "🥩" },
  { id: "37", name: "Кайма смесена", brand: "Тандем", category: "Месни", calories: 250, carbs: 0, protein: 18, fats: 20, sugars: 0, fiber: 0, healthScore: 4, isHealthy: false, emoji: "🥩" },
  { id: "38", name: "Филе от пилешки гърди", brand: "Пилко", category: "Месни", calories: 110, carbs: 0, protein: 23, fats: 1.5, sugars: 0, fiber: 0, healthScore: 9, isHealthy: true, emoji: "🍗" },
  { id: "39", name: "Салам Камчия", brand: "Тандем", category: "Месни", calories: 310, carbs: 3, protein: 13, fats: 28, sugars: 1, fiber: 0, healthScore: 3, isHealthy: false, emoji: "🌭" },
  { id: "40", name: "Наденица свинска", brand: "Тандем", category: "Месни", calories: 290, carbs: 1, protein: 16, fats: 25, sugars: 0.5, fiber: 0, healthScore: 4, isHealthy: false, emoji: "🌭" },
  { id: "41", name: "Бекон нарязан", brand: "Тандем", category: "Месни", calories: 340, carbs: 1, protein: 14, fats: 32, sugars: 0.5, fiber: 0, healthScore: 3, isHealthy: false, emoji: "🥓" },
  { id: "42", name: "Пуешко филе", brand: "Пилко", category: "Месни", calories: 105, carbs: 0, protein: 24, fats: 1, sugars: 0, fiber: 0, healthScore: 9, isHealthy: true, emoji: "🍗" },
  { id: "43", name: "Шпек старопланински", brand: "Тандем", category: "Месни", calories: 360, carbs: 2, protein: 19, fats: 31, sugars: 1, fiber: 0, healthScore: 3, isHealthy: false, emoji: "🥩" },

  // Сладкарски
  { id: "11", name: "Шоколад Млечен", brand: "Своге", category: "Сладкарски", calories: 545, carbs: 57, protein: 7, fats: 32, sugars: 52, fiber: 2, healthScore: 2, isHealthy: false, emoji: "🍫" },
  { id: "12", name: "Шоколад Тъмен 70%", brand: "Своге", category: "Сладкарски", calories: 520, carbs: 40, protein: 9, fats: 38, sugars: 28, fiber: 8, healthScore: 4, isHealthy: false, emoji: "🍫" },
  { id: "13", name: "Бисквити Закуска", brand: "Победа", category: "Сладкарски", calories: 435, carbs: 72, protein: 7, fats: 14, sugars: 22, fiber: 2, healthScore: 3, isHealthy: false, emoji: "🍪" },
  { id: "14", name: "Вафла Боровец", brand: "Престиж", category: "Сладкарски", calories: 490, carbs: 60, protein: 5, fats: 25, sugars: 40, fiber: 1, healthScore: 2, isHealthy: false, emoji: "🧇" },
  { id: "44", name: "Вафла Морени", brand: "Престиж", category: "Сладкарски", calories: 510, carbs: 58, protein: 6, fats: 28, sugars: 42, fiber: 1, healthScore: 2, isHealthy: false, emoji: "🧇" },
  { id: "45", name: "Шоколад с лешници", brand: "Своге", category: "Сладкарски", calories: 560, carbs: 50, protein: 9, fats: 36, sugars: 46, fiber: 3, healthScore: 3, isHealthy: false, emoji: "🍫" },
  { id: "46", name: "Бонбони Кара Мела", brand: "Своге", category: "Сладкарски", calories: 400, carbs: 76, protein: 2, fats: 10, sugars: 65, fiber: 0, healthScore: 1, isHealthy: false, emoji: "🍬" },
  { id: "47", name: "Локум рахат", brand: "Захарни заводи", category: "Сладкарски", calories: 350, carbs: 85, protein: 0.5, fats: 0.2, sugars: 70, fiber: 0, healthScore: 1, isHealthy: false, emoji: "🍬" },
  { id: "48", name: "Халва тахан", brand: "Захарни заводи", category: "Сладкарски", calories: 520, carbs: 50, protein: 12, fats: 30, sugars: 40, fiber: 3, healthScore: 3, isHealthy: false, emoji: "🍬" },
  { id: "49", name: "Крем Фантазия шоколад", brand: "Danone", category: "Сладкарски", calories: 135, carbs: 18, protein: 3.5, fats: 5.5, sugars: 15, fiber: 0.5, healthScore: 3, isHealthy: false, emoji: "🍮" },
  { id: "50", name: "Сладолед ванилия", brand: "Изида", category: "Сладкарски", calories: 200, carbs: 24, protein: 3, fats: 10, sugars: 20, fiber: 0, healthScore: 2, isHealthy: false, emoji: "🍦" },

  // Напитки
  { id: "15", name: "Минерална вода", brand: "Девин", category: "Напитки", calories: 0, carbs: 0, protein: 0, fats: 0, sugars: 0, fiber: 0, healthScore: 10, isHealthy: true, emoji: "💧" },
  { id: "16", name: "Кока-Кола", brand: "Coca-Cola", category: "Напитки", calories: 42, carbs: 10.6, protein: 0, fats: 0, sugars: 10.6, fiber: 0, healthScore: 1, isHealthy: false, emoji: "🥤" },
  { id: "17", name: "Натурален сок Портокал", brand: "Cappy", category: "Напитки", calories: 45, carbs: 10, protein: 0.5, fats: 0.1, sugars: 9, fiber: 0.2, healthScore: 5, isHealthy: false, emoji: "🍊" },
  { id: "51", name: "Минерална вода газирана", brand: "Банкя", category: "Напитки", calories: 0, carbs: 0, protein: 0, fats: 0, sugars: 0, fiber: 0, healthScore: 10, isHealthy: true, emoji: "💧" },
  { id: "52", name: "Минерална вода негазирана", brand: "Банкя", category: "Напитки", calories: 0, carbs: 0, protein: 0, fats: 0, sugars: 0, fiber: 0, healthScore: 10, isHealthy: true, emoji: "💧" },
  { id: "53", name: "Изворна вода", brand: "Горна Баня", category: "Напитки", calories: 0, carbs: 0, protein: 0, fats: 0, sugars: 0, fiber: 0, healthScore: 10, isHealthy: true, emoji: "💧" },
  { id: "54", name: "Лимонада", brand: "Банкя", category: "Напитки", calories: 38, carbs: 9.5, protein: 0, fats: 0, sugars: 9, fiber: 0, healthScore: 2, isHealthy: false, emoji: "🍋" },
  { id: "55", name: "Бира Каменица", brand: "Каменица", category: "Напитки", calories: 42, carbs: 3.5, protein: 0.4, fats: 0, sugars: 0, fiber: 0, healthScore: 2, isHealthy: false, emoji: "🍺" },
  { id: "56", name: "Бира Загорка", brand: "Загорка", category: "Напитки", calories: 44, carbs: 3.8, protein: 0.5, fats: 0, sugars: 0, fiber: 0, healthScore: 2, isHealthy: false, emoji: "🍺" },
  { id: "57", name: "Бира Шуменско", brand: "Шуменско", category: "Напитки", calories: 40, carbs: 3.2, protein: 0.4, fats: 0, sugars: 0, fiber: 0, healthScore: 2, isHealthy: false, emoji: "🍺" },
  { id: "58", name: "Студен чай праскова", brand: "Lipton", category: "Напитки", calories: 30, carbs: 7.5, protein: 0, fats: 0, sugars: 7, fiber: 0, healthScore: 2, isHealthy: false, emoji: "🧊" },
  { id: "59", name: "Енергийна напитка", brand: "Hell", category: "Напитки", calories: 48, carbs: 11, protein: 0, fats: 0, sugars: 11, fiber: 0, healthScore: 1, isHealthy: false, emoji: "⚡" },
  { id: "60", name: "Боза", brand: "Бозаджийница", category: "Напитки", calories: 60, carbs: 13, protein: 0.8, fats: 0.3, sugars: 10, fiber: 0.5, healthScore: 4, isHealthy: false, emoji: "🥤" },

  // Хляб и зърнени
  { id: "18", name: "Хляб Добруджа", brand: "Добруджа", category: "Хляб", calories: 250, carbs: 48, protein: 8, fats: 1.5, sugars: 3, fiber: 3, healthScore: 6, isHealthy: true, emoji: "🍞" },
  { id: "19", name: "Пълнозърнест хляб", brand: "Simid", category: "Хляб", calories: 220, carbs: 40, protein: 9, fats: 2, sugars: 2, fiber: 6, healthScore: 8, isHealthy: true, emoji: "🍞" },
  { id: "61", name: "Типов хляб", brand: "Симид", category: "Хляб", calories: 235, carbs: 44, protein: 8.5, fats: 1.8, sugars: 2.5, fiber: 4, healthScore: 7, isHealthy: true, emoji: "🍞" },
  { id: "62", name: "Ръжен хляб", brand: "Симид", category: "Хляб", calories: 210, carbs: 42, protein: 7, fats: 1.5, sugars: 2, fiber: 7, healthScore: 8, isHealthy: true, emoji: "🍞" },
  { id: "63", name: "Козунак", brand: "Елиаз", category: "Хляб", calories: 340, carbs: 52, protein: 8, fats: 12, sugars: 18, fiber: 1.5, healthScore: 3, isHealthy: false, emoji: "🍞" },
  { id: "64", name: "Питка пълнозърнеста", brand: "Симид", category: "Хляб", calories: 230, carbs: 42, protein: 9, fats: 2.5, sugars: 2, fiber: 5, healthScore: 7, isHealthy: true, emoji: "🫓" },
  { id: "65", name: "Баничка със сирене", brand: "Bella Bulgaria", category: "Хляб", calories: 280, carbs: 28, protein: 9, fats: 15, sugars: 2, fiber: 1, healthScore: 4, isHealthy: false, emoji: "🥐" },

  // Консерви и сосове
  { id: "20", name: "Лютеница домашна", brand: "Дерони", category: "Консерви", calories: 95, carbs: 12, protein: 2, fats: 4, sugars: 8, fiber: 2, healthScore: 6, isHealthy: true, emoji: "🫙" },
  { id: "21", name: "Айвар", brand: "Дерони", category: "Консерви", calories: 80, carbs: 10, protein: 1.5, fats: 3.5, sugars: 6, fiber: 2.5, healthScore: 7, isHealthy: true, emoji: "🫙" },
  { id: "22", name: "Кетчуп", brand: "Олинеза", category: "Консерви", calories: 110, carbs: 25, protein: 1.5, fats: 0.3, sugars: 22, fiber: 0.5, healthScore: 3, isHealthy: false, emoji: "🍅" },
  { id: "66", name: "Лютеница люта", brand: "Дерони", category: "Консерви", calories: 90, carbs: 11, protein: 2, fats: 4, sugars: 7, fiber: 2.5, healthScore: 6, isHealthy: true, emoji: "🌶️" },
  { id: "67", name: "Зелен фасул консерва", brand: "Bonduelle", category: "Консерви", calories: 22, carbs: 3.5, protein: 1.5, fats: 0.1, sugars: 1.5, fiber: 2, healthScore: 8, isHealthy: true, emoji: "🫙" },
  { id: "68", name: "Царевица консерва", brand: "Bonduelle", category: "Консерви", calories: 80, carbs: 15, protein: 2.5, fats: 1, sugars: 4, fiber: 2, healthScore: 7, isHealthy: true, emoji: "🌽" },
  { id: "69", name: "Пържен патладжан", brand: "Дерони", category: "Консерви", calories: 110, carbs: 6, protein: 1.5, fats: 9, sugars: 4, fiber: 2, healthScore: 5, isHealthy: false, emoji: "🍆" },
  { id: "70", name: "Горчица", brand: "Олинеза", category: "Консерви", calories: 65, carbs: 5, protein: 4, fats: 3, sugars: 2, fiber: 2, healthScore: 6, isHealthy: true, emoji: "🫙" },
  { id: "71", name: "Майонеза", brand: "Олинеза", category: "Консерви", calories: 680, carbs: 1, protein: 1, fats: 75, sugars: 0.5, fiber: 0, healthScore: 1, isHealthy: false, emoji: "🫙" },
  { id: "72", name: "Кисели краставички", brand: "Дерони", category: "Консерви", calories: 15, carbs: 2.5, protein: 0.5, fats: 0.1, sugars: 1.5, fiber: 0.5, healthScore: 7, isHealthy: true, emoji: "🥒" },

  // Зърнени закуски
  { id: "23", name: "Мюсли с плодове", brand: "Vitalia", category: "Зърнени", calories: 365, carbs: 68, protein: 8, fats: 6, sugars: 22, fiber: 7, healthScore: 6, isHealthy: true, emoji: "🥣" },
  { id: "24", name: "Овесени ядки", brand: "Крина", category: "Зърнени", calories: 370, carbs: 60, protein: 13, fats: 7, sugars: 1, fiber: 10, healthScore: 9, isHealthy: true, emoji: "🥣" },
  { id: "73", name: "Грис", brand: "Крина", category: "Зърнени", calories: 340, carbs: 73, protein: 10, fats: 1, sugars: 0.5, fiber: 2, healthScore: 5, isHealthy: false, emoji: "🥣" },
  { id: "74", name: "Корнфлейкс", brand: "Nestle", category: "Зърнени", calories: 380, carbs: 84, protein: 7, fats: 1, sugars: 8, fiber: 3, healthScore: 4, isHealthy: false, emoji: "🥣" },
  { id: "75", name: "Гранола с мед", brand: "Vitalia", category: "Зърнени", calories: 420, carbs: 62, protein: 10, fats: 14, sugars: 20, fiber: 6, healthScore: 5, isHealthy: false, emoji: "🥣" },
  { id: "76", name: "Ориз Бисер", brand: "Крина", category: "Зърнени", calories: 350, carbs: 78, protein: 7, fats: 0.5, sugars: 0, fiber: 1, healthScore: 5, isHealthy: false, emoji: "🍚" },
  { id: "77", name: "Леща червена", brand: "Крина", category: "Зърнени", calories: 340, carbs: 56, protein: 25, fats: 1.5, sugars: 2, fiber: 11, healthScore: 9, isHealthy: true, emoji: "🫘" },
  { id: "78", name: "Булгур", brand: "Крина", category: "Зърнени", calories: 342, carbs: 63, protein: 12, fats: 1.3, sugars: 0.4, fiber: 12, healthScore: 9, isHealthy: true, emoji: "🌾" },

  // Снакс и чипс
  { id: "79", name: "Чипс солен", brand: "Чипита", category: "Снакс", calories: 530, carbs: 52, protein: 6, fats: 33, sugars: 1, fiber: 4, healthScore: 2, isHealthy: false, emoji: "🥔" },
  { id: "80", name: "Чипс паприка", brand: "Чипита", category: "Снакс", calories: 525, carbs: 53, protein: 6, fats: 32, sugars: 2, fiber: 4, healthScore: 2, isHealthy: false, emoji: "🥔" },
  { id: "81", name: "Крекер солен", brand: "Чипита", category: "Снакс", calories: 440, carbs: 65, protein: 9, fats: 16, sugars: 3, fiber: 2, healthScore: 3, isHealthy: false, emoji: "🍘" },
  { id: "82", name: "Бретцел", brand: "Чипита", category: "Снакс", calories: 380, carbs: 72, protein: 10, fats: 5, sugars: 2, fiber: 2, healthScore: 4, isHealthy: false, emoji: "🥨" },
  { id: "83", name: "Кроасан шоколад", brand: "Чипита", category: "Снакс", calories: 410, carbs: 50, protein: 7, fats: 20, sugars: 22, fiber: 1.5, healthScore: 2, isHealthy: false, emoji: "🥐" },
  { id: "84", name: "Кроасан ванилия", brand: "Чипита", category: "Снакс", calories: 395, carbs: 52, protein: 6, fats: 18, sugars: 20, fiber: 1, healthScore: 2, isHealthy: false, emoji: "🥐" },
  { id: "85", name: "Пуканки масло", brand: "Актуал", category: "Снакс", calories: 460, carbs: 55, protein: 8, fats: 24, sugars: 1, fiber: 10, healthScore: 4, isHealthy: false, emoji: "🍿" },
  { id: "86", name: "Фъстъци солени", brand: "Алба", category: "Снакс", calories: 590, carbs: 15, protein: 26, fats: 49, sugars: 4, fiber: 8, healthScore: 5, isHealthy: false, emoji: "🥜" },
  { id: "87", name: "Стикс солени", brand: "Чипита", category: "Снакс", calories: 410, carbs: 68, protein: 11, fats: 11, sugars: 3, fiber: 2.5, healthScore: 3, isHealthy: false, emoji: "🍘" },
  { id: "88", name: "Грисини", brand: "Роден край", category: "Снакс", calories: 400, carbs: 70, protein: 10, fats: 8, sugars: 3, fiber: 3, healthScore: 4, isHealthy: false, emoji: "🥖" },
  { id: "89", name: "Бадеми сурови", brand: "Алба", category: "Снакс", calories: 575, carbs: 20, protein: 21, fats: 49, sugars: 4, fiber: 12, healthScore: 8, isHealthy: true, emoji: "🌰" },
  { id: "90", name: "Слънчогледови семки", brand: "Алба", category: "Снакс", calories: 580, carbs: 18, protein: 21, fats: 51, sugars: 2, fiber: 9, healthScore: 7, isHealthy: true, emoji: "🌻" },

  // Плодове и зеленчуци
  { id: "91", name: "Ябълки Златна превъзходна", brand: "БГ Ферма", category: "Плодове", calories: 52, carbs: 14, protein: 0.3, fats: 0.2, sugars: 10, fiber: 2.4, healthScore: 9, isHealthy: true, emoji: "🍎" },
  { id: "92", name: "Банани", brand: "БГ Ферма", category: "Плодове", calories: 89, carbs: 23, protein: 1.1, fats: 0.3, sugars: 12, fiber: 2.6, healthScore: 8, isHealthy: true, emoji: "🍌" },
  { id: "93", name: "Домати", brand: "БГ Ферма", category: "Плодове", calories: 18, carbs: 3.9, protein: 0.9, fats: 0.2, sugars: 2.6, fiber: 1.2, healthScore: 10, isHealthy: true, emoji: "🍅" },
  { id: "94", name: "Краставици", brand: "БГ Ферма", category: "Плодове", calories: 15, carbs: 3.6, protein: 0.7, fats: 0.1, sugars: 1.7, fiber: 0.5, healthScore: 10, isHealthy: true, emoji: "🥒" },
  { id: "95", name: "Чушки зелени", brand: "БГ Ферма", category: "Плодове", calories: 20, carbs: 4.6, protein: 0.9, fats: 0.2, sugars: 2.4, fiber: 1.7, healthScore: 10, isHealthy: true, emoji: "🫑" },
  { id: "96", name: "Грозде Мускат", brand: "БГ Ферма", category: "Плодове", calories: 69, carbs: 18, protein: 0.7, fats: 0.2, sugars: 15, fiber: 0.9, healthScore: 7, isHealthy: true, emoji: "🍇" },
  { id: "97", name: "Диня", brand: "БГ Ферма", category: "Плодове", calories: 30, carbs: 7.5, protein: 0.6, fats: 0.2, sugars: 6, fiber: 0.4, healthScore: 8, isHealthy: true, emoji: "🍉" },
  { id: "98", name: "Пъпеш", brand: "БГ Ферма", category: "Плодове", calories: 34, carbs: 8.2, protein: 0.8, fats: 0.2, sugars: 7.9, fiber: 0.9, healthScore: 8, isHealthy: true, emoji: "🍈" },
  { id: "99", name: "Ягоди", brand: "БГ Ферма", category: "Плодове", calories: 32, carbs: 7.7, protein: 0.7, fats: 0.3, sugars: 4.9, fiber: 2, healthScore: 9, isHealthy: true, emoji: "🍓" },
  { id: "100", name: "Картофи", brand: "БГ Ферма", category: "Плодове", calories: 77, carbs: 17, protein: 2, fats: 0.1, sugars: 0.8, fiber: 2.2, healthScore: 7, isHealthy: true, emoji: "🥔" },

  // Яйца и протеин
  { id: "101", name: "Яйца от кокошки на воля", brand: "Алекс Пром", category: "Яйца", calories: 155, carbs: 1.1, protein: 13, fats: 11, sugars: 1.1, fiber: 0, healthScore: 8, isHealthy: true, emoji: "🥚" },
  { id: "102", name: "Яйца M кокоши", brand: "Багряна", category: "Яйца", calories: 150, carbs: 1, protein: 12.5, fats: 10.5, sugars: 1, fiber: 0, healthScore: 7, isHealthy: true, emoji: "🥚" },
  { id: "103", name: "Пъдпъдъчи яйца", brand: "Алекс Пром", category: "Яйца", calories: 158, carbs: 0.4, protein: 13, fats: 11, sugars: 0.4, fiber: 0, healthScore: 8, isHealthy: true, emoji: "🥚" },

  // Тестени изделия
  { id: "104", name: "Спагети", brand: "Bella Donna", category: "Тестени", calories: 355, carbs: 72, protein: 12, fats: 1.5, sugars: 2.5, fiber: 3, healthScore: 5, isHealthy: false, emoji: "🍝" },
  { id: "105", name: "Пене", brand: "Bella Donna", category: "Тестени", calories: 355, carbs: 72, protein: 12, fats: 1.5, sugars: 2.5, fiber: 3, healthScore: 5, isHealthy: false, emoji: "🍝" },
  { id: "106", name: "Пълнозърнести спагети", brand: "Barilla", category: "Тестени", calories: 340, carbs: 62, protein: 14, fats: 2.5, sugars: 2, fiber: 8, healthScore: 7, isHealthy: true, emoji: "🍝" },
  { id: "107", name: "Юфка домашна", brand: "Крина", category: "Тестени", calories: 360, carbs: 70, protein: 11, fats: 2.5, sugars: 2, fiber: 2.5, healthScore: 5, isHealthy: false, emoji: "🍜" },

  // Масла и подправки
  { id: "108", name: "Зехтин Екстра Върджин", brand: "Маслинов рай", category: "Масла", calories: 884, carbs: 0, protein: 0, fats: 100, sugars: 0, fiber: 0, healthScore: 8, isHealthy: true, emoji: "🫒" },
  { id: "109", name: "Слънчогледово олио", brand: "Бисер", category: "Масла", calories: 884, carbs: 0, protein: 0, fats: 100, sugars: 0, fiber: 0, healthScore: 5, isHealthy: false, emoji: "🌻" },
  { id: "110", name: "Мед полифлорен", brand: "Пчелинъ", category: "Масла", calories: 320, carbs: 80, protein: 0.3, fats: 0, sugars: 75, fiber: 0, healthScore: 6, isHealthy: true, emoji: "🍯" },
  { id: "111", name: "Тахан халва", brand: "Захарни заводи", category: "Масла", calories: 520, carbs: 50, protein: 12, fats: 30, sugars: 40, fiber: 3, healthScore: 3, isHealthy: false, emoji: "🫙" },
  { id: "112", name: "Шарена сол", brand: "Биосет", category: "Масла", calories: 15, carbs: 2, protein: 0.5, fats: 0.3, sugars: 0.5, fiber: 1, healthScore: 7, isHealthy: true, emoji: "🧂" },
  { id: "113", name: "Чубрица", brand: "Биосет", category: "Масла", calories: 25, carbs: 4, protein: 1.5, fats: 0.5, sugars: 1, fiber: 3, healthScore: 8, isHealthy: true, emoji: "🌿" },

  // Замразени
  { id: "114", name: "Замразен спанак", brand: "Oerlemans", category: "Замразени", calories: 23, carbs: 1.5, protein: 2.9, fats: 0.4, sugars: 0.4, fiber: 2.2, healthScore: 9, isHealthy: true, emoji: "🥬" },
  { id: "115", name: "Замразен зелен грах", brand: "Oerlemans", category: "Замразени", calories: 75, carbs: 11, protein: 5.5, fats: 0.4, sugars: 4, fiber: 5, healthScore: 9, isHealthy: true, emoji: "🟢" },
  { id: "116", name: "Замразени пилешки хапки", brand: "Bella Bulgaria", category: "Замразени", calories: 240, carbs: 15, protein: 14, fats: 14, sugars: 1, fiber: 1, healthScore: 4, isHealthy: false, emoji: "🍗" },
  { id: "117", name: "Замразена пица Маргарита", brand: "Bella Bulgaria", category: "Замразени", calories: 230, carbs: 30, protein: 10, fats: 8, sugars: 3, fiber: 1.5, healthScore: 4, isHealthy: false, emoji: "🍕" },
  { id: "118", name: "Замразени зеленчуци микс", brand: "Oerlemans", category: "Замразени", calories: 45, carbs: 7, protein: 2.5, fats: 0.3, sugars: 3, fiber: 3, healthScore: 9, isHealthy: true, emoji: "🥦" },

  // Бебешки храни
  { id: "119", name: "Пюре ябълка и банан", brand: "Hipp", category: "Бебешки", calories: 55, carbs: 13, protein: 0.4, fats: 0.1, sugars: 10, fiber: 1.5, healthScore: 7, isHealthy: true, emoji: "🍼" },
  { id: "120", name: "Бебешки бисквити", brand: "Hipp", category: "Бебешки", calories: 420, carbs: 74, protein: 8, fats: 10, sugars: 22, fiber: 2, healthScore: 4, isHealthy: false, emoji: "🍪" },

  // Допълнителни млечни и кисело-млечни
  { id: "121", name: "Кефир 1.5%", brand: "Верея", category: "Млечни", calories: 38, carbs: 3.5, protein: 3.2, fats: 1.5, sugars: 3.5, fiber: 0, healthScore: 9, isHealthy: true, emoji: "🥛" },
  { id: "122", name: "Закваска", brand: "LB Булгарикум", category: "Млечни", calories: 45, carbs: 4, protein: 3.5, fats: 2, sugars: 4, fiber: 0, healthScore: 9, isHealthy: true, emoji: "🥛" },
  { id: "123", name: "Сирене Крема", brand: "Маджаров", category: "Млечни", calories: 210, carbs: 3, protein: 8, fats: 19, sugars: 2.5, fiber: 0, healthScore: 4, isHealthy: false, emoji: "🧀" },
  { id: "124", name: "Рикота", brand: "Маджаров", category: "Млечни", calories: 174, carbs: 3, protein: 11, fats: 13, sugars: 2, fiber: 0, healthScore: 6, isHealthy: true, emoji: "🧀" },
];

const categories = ["Всички", ...Array.from(new Set(catalogProducts.map(p => p.category)))];

interface ProductCatalogProps {
  onAddToCompare?: (product: CatalogProduct) => void;
  compareList?: CatalogProduct[];
}

export const ProductCatalog = ({ onAddToCompare, compareList = [] }: ProductCatalogProps) => {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Всички");

  const filtered = catalogProducts.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.brand.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === "Всички" || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const isInCompare = (id: string) => compareList.some(p => p.id === id);

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Търси продукт или марка..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {categories.map(cat => (
          <Button
            key={cat}
            variant={selectedCategory === cat ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(cat)}
          >
            {cat}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <AnimatePresence mode="popLayout">
          {filtered.map((product, i) => (
            <motion.div
              key={product.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ delay: i * 0.03 }}
            >
              <Card className="p-4 hover:shadow-lg transition-shadow bg-card/80 backdrop-blur-sm">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-2xl">{product.emoji}</span>
                      <div>
                        <h3 className="font-bold text-sm leading-tight">{product.name}</h3>
                        <p className="text-xs text-muted-foreground">{product.brand}</p>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1.5 mt-2">
                      <Badge variant="outline" className="text-[10px] gap-1">
                        <Flame className="w-3 h-3" />{product.calories} kcal
                      </Badge>
                      <Badge variant="outline" className="text-[10px]">П: {product.protein}г</Badge>
                      <Badge variant="outline" className="text-[10px]">В: {product.carbs}г</Badge>
                      <Badge variant="outline" className="text-[10px]">М: {product.fats}г</Badge>
                      {product.fiber > 3 && (
                        <Badge variant="secondary" className="text-[10px] gap-1">
                          <Leaf className="w-3 h-3" />{product.fiber}г
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col items-center gap-2">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold text-white ${
                      product.healthScore >= 7 ? 'bg-green-500' : product.healthScore >= 4 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}>
                      {product.healthScore}
                    </div>
                    {onAddToCompare && (
                      <Button
                        size="sm"
                        variant={isInCompare(product.id) ? "secondary" : "outline"}
                        className="text-xs h-7 px-2"
                        onClick={() => onAddToCompare(product)}
                        disabled={isInCompare(product.id)}
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        {isInCompare(product.id) ? "Добавен" : "Сравни"}
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Search className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Няма намерени продукти</p>
        </div>
      )}
    </div>
  );
};

import { lazy, Suspense } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { PageTransition } from "./PageTransition";
import { ChefBowl } from "./ChefBowl";
import Home from "@/pages/Home";
import NotFound from "@/pages/NotFound";

const Quiz = lazy(() => import("@/pages/Quiz"));
const Recipes = lazy(() => import("@/pages/Recipes"));
const FunFacts = lazy(() => import("@/pages/FunFacts"));
const ProductScanner = lazy(() => import("@/pages/ProductScanner"));
const Settings = lazy(() => import("@/pages/Settings"));
const Auth = lazy(() => import("@/pages/Auth"));
const Blocked = lazy(() => import("@/pages/Blocked"));
const HealthDashboard = lazy(() => import("@/pages/HealthDashboard"));
const Globe = lazy(() => import("@/pages/Globe"));
const BreathingExercise = lazy(() => import("@/pages/BreathingExercise"));
const MealPlanner = lazy(() => import("@/pages/MealPlanner"));
const HealthHoroscope = lazy(() => import("@/pages/HealthHoroscope"));
const SpecialThanks = lazy(() => import("@/pages/SpecialThanks"));
const WeeklyReport = lazy(() => import("@/pages/WeeklyReport"));
const MealJournal = lazy(() => import("@/pages/MealJournal"));
const SocialLeaderboard = lazy(() => import("@/pages/SocialLeaderboard"));
const WorkoutMusic = lazy(() => import("@/pages/WorkoutMusic"));
const Install = lazy(() => import("@/pages/Install"));
const ResetPassword = lazy(() => import("@/pages/ResetPassword"));
const Exercises = lazy(() => import("@/pages/Exercises"));
const TobaccoFree = lazy(() => import("@/pages/TobaccoFree"));
const Ambassadors = lazy(() => import("@/pages/Ambassadors"));
const Diets = lazy(() => import("@/pages/Diets"));
const DietPage = lazy(() => import("@/pages/DietPage"));
const Drinks = lazy(() => import("@/pages/Drinks"));
const QuitKitchen = lazy(() => import("@/pages/QuitKitchen"));
const ShoppingList = lazy(() => import("@/pages/ShoppingList"));

// Shown while a page chunk downloads: the chef keeps stirring
const RouteFallback = () => (
  <div className="min-h-screen grid place-items-center bg-background" role="status" aria-live="polite">
    <div className="text-center">
      <ChefBowl interactive={false} className="w-40 mx-auto" />
      <p className="mt-2 text-sm text-muted-foreground">Зареждане...</p>
    </div>
  </div>
);

export const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <Suspense fallback={<RouteFallback />}>
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<PageTransition><Home /></PageTransition>} />
        <Route path="/quiz" element={<PageTransition><Quiz /></PageTransition>} />
        <Route path="/recipes" element={<PageTransition><Recipes /></PageTransition>} />
        <Route path="/fun-facts" element={<PageTransition><FunFacts /></PageTransition>} />
        <Route path="/product-scanner" element={<PageTransition><ProductScanner /></PageTransition>} />
        <Route path="/health-dashboard" element={<PageTransition><HealthDashboard /></PageTransition>} />
        <Route path="/globe" element={<PageTransition><Globe /></PageTransition>} />
        <Route path="/breathing" element={<PageTransition><BreathingExercise /></PageTransition>} />
        <Route path="/meal-planner" element={<PageTransition><MealPlanner /></PageTransition>} />
        <Route path="/health-horoscope" element={<PageTransition><HealthHoroscope /></PageTransition>} />
        <Route path="/special-thanks" element={<PageTransition><SpecialThanks /></PageTransition>} />
        
        <Route path="/weekly-report" element={<PageTransition><WeeklyReport /></PageTransition>} />
        <Route path="/meal-journal" element={<PageTransition><MealJournal /></PageTransition>} />
        <Route path="/social" element={<PageTransition><SocialLeaderboard /></PageTransition>} />
        <Route path="/workout-music" element={<PageTransition><WorkoutMusic /></PageTransition>} />
        <Route path="/settings" element={<PageTransition><Settings /></PageTransition>} />
        <Route path="/auth" element={<PageTransition><Auth /></PageTransition>} />
        <Route path="/blocked" element={<PageTransition><Blocked /></PageTransition>} />
        <Route path="/install" element={<PageTransition><Install /></PageTransition>} />
        <Route path="/reset-password" element={<PageTransition><ResetPassword /></PageTransition>} />
        <Route path="/exercises" element={<PageTransition><Exercises /></PageTransition>} />
        <Route path="/diets" element={<PageTransition><Diets /></PageTransition>} />
        <Route path="/diets/:slug" element={<PageTransition><DietPage /></PageTransition>} />
        <Route path="/drinks" element={<PageTransition><Drinks /></PageTransition>} />
        <Route path="/quit-kitchen" element={<PageTransition><QuitKitchen /></PageTransition>} />
        <Route path="/shopping-list" element={<PageTransition><ShoppingList /></PageTransition>} />
        <Route path="/ambassadors" element={<PageTransition><Ambassadors /></PageTransition>} />
        <Route path="/tobacco-free" element={<PageTransition><TobaccoFree /></PageTransition>} />
        <Route path="*" element={<PageTransition><NotFound /></PageTransition>} />
      </Routes>
    </AnimatePresence>
    </Suspense>
  );
};

import { useState, useEffect, useRef } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Camera, X, ScanBarcode, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';

interface BarcodeScannerProps {
  onScan: (result: string) => void;
  onClose: () => void;
}

export const BarcodeScanner = ({ onScan, onClose }: BarcodeScannerProps) => {
  const [isScanning, setIsScanning] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const { toast } = useToast();

  const startScanning = async () => {
    setIsInitializing(true);
    try {
      const scanner = new Html5Qrcode("barcode-reader", {
        formatsToSupport: [
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.EAN_8,
          Html5QrcodeSupportedFormats.UPC_A,
          Html5QrcodeSupportedFormats.UPC_E,
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
          Html5QrcodeSupportedFormats.QR_CODE,
        ],
        verbose: false,
      });
      scannerRef.current = scanner;

      await scanner.start(
        { facingMode: "environment" },
        {
          fps: 15,
          qrbox: { width: 280, height: 150 },
          aspectRatio: 1.777,
        },
        (decodedText) => {
          onScan(decodedText);
          stopScanning();
          toast({
            title: "✅ Успех!",
            description: `Баркод сканиран: ${decodedText}`,
          });
        },
        () => {
          // Ignore scanning errors (no barcode found in frame)
        }
      );
      setIsScanning(true);
    } catch (err) {
      console.error("Error starting scanner:", err);
      toast({
        title: "Грешка с камерата",
        description: "Моля, разрешете достъп до камерата и опитайте отново",
        variant: "destructive",
      });
    } finally {
      setIsInitializing(false);
    }
  };

  const stopScanning = async () => {
    if (scannerRef.current) {
      try {
        await scannerRef.current.stop();
        scannerRef.current.clear();
        scannerRef.current = null;
      } catch (err) {
        console.error("Error stopping scanner:", err);
      }
    }
    setIsScanning(false);
  };

  useEffect(() => {
    // Auto-start scanning when component mounts
    startScanning();
    
    return () => {
      stopScanning();
    };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="p-6 bg-card/95 backdrop-blur-xl border-primary/20 shadow-2xl">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold gradient-text flex items-center gap-2">
              <ScanBarcode className="w-6 h-6" />
              Сканирай баркод
            </h3>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => {
                stopScanning();
                onClose();
              }}
              className="hover:bg-destructive/10 hover:text-destructive"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          <p className="text-sm text-muted-foreground">
            Насочете камерата към баркода на продукта
          </p>

          <div className="relative rounded-xl overflow-hidden bg-black/5 border border-border/50">
            <div id="barcode-reader" className="w-full min-h-[280px]"></div>
            
            {/* Scanning overlay animation */}
            <AnimatePresence>
              {isScanning && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 pointer-events-none"
                >
                  <motion.div
                    className="absolute left-1/2 -translate-x-1/2 w-[280px] h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent"
                    animate={{ 
                      top: ["30%", "70%", "30%"],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Loading state */}
            {isInitializing && (
              <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm">
                <div className="flex flex-col items-center gap-3">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  <p className="text-sm text-muted-foreground">Зареждане на камерата...</p>
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-2">
            {!isScanning && !isInitializing ? (
              <Button onClick={startScanning} className="w-full" size="lg">
                <Camera className="w-4 h-4 mr-2" />
                Стартирай сканиране
              </Button>
            ) : (
              <Button 
                onClick={() => {
                  stopScanning();
                  onClose();
                }} 
                variant="outline" 
                className="w-full"
                size="lg"
              >
                Отказ
              </Button>
            )}
          </div>

          <p className="text-xs text-muted-foreground text-center">
            Поддържа: EAN-13, EAN-8, UPC-A, UPC-E, Code 128, Code 39, QR кодове
          </p>
        </div>
      </Card>
    </motion.div>
  );
};

import { useEffect, useRef } from "react";

const StarField = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let stars: { x: number; y: number; r: number; brightness: number; twinkleSpeed: number }[] = [];
    let time = 0;
    let lastFrame = 0;
    const TARGET_FPS = 60;
    const FRAME_INTERVAL = 1000 / TARGET_FPS;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initStars();
    };

    const initStars = () => {
      // Much fewer stars — max 300, scales with screen
      const count = Math.min(300, Math.floor((canvas.width * canvas.height) / 6000));
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.2 + 0.3,
        brightness: Math.random(),
        twinkleSpeed: Math.random() * 0.015 + 0.003,
      }));
    };

    const animate = (timestamp: number) => {
      animationId = requestAnimationFrame(animate);

      // Throttle to target FPS
      if (timestamp - lastFrame < FRAME_INTERVAL) return;
      lastFrame = timestamp;

      time += 1;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (const star of stars) {
        const alpha = 0.4 + 0.6 * Math.sin(time * star.twinkleSpeed + star.brightness * 6.28);
        // Simple circle — no radial gradients (much cheaper)
        ctx.fillStyle = `rgba(220, 230, 255, ${alpha})`;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.r, 0, 6.28);
        ctx.fill();
      }
    };

    resize();
    animationId = requestAnimationFrame(animate);
    window.addEventListener("resize", resize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 0 }}
    />
  );
};

export default StarField;

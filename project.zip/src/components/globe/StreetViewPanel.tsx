import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { MapPin, X, Maximize2, Minimize2 } from "lucide-react";
import { Button } from "@/components/ui/button";

declare const google: any;

interface StreetViewPanelProps {
  lat: number;
  lng: number;
  expanded: boolean;
  googleLoaded: boolean;
  onToggleExpand: () => void;
  onClose: () => void;
}

const StreetViewPanel = ({ lat, lng, expanded, googleLoaded, onToggleExpand, onClose }: StreetViewPanelProps) => {
  const streetViewRef = useRef<HTMLDivElement>(null);
  const panoramaRef = useRef<any | null>(null);
  const [streetViewAvailable, setStreetViewAvailable] = useState(true);

  useEffect(() => {
    if (!googleLoaded || !streetViewRef.current) return;

    const sv = new google.maps.StreetViewService();
    const position = new google.maps.LatLng(lat, lng);

    sv.getPanorama({ location: position, radius: 500 }, (data, status) => {
      if (status === google.maps.StreetViewStatus.OK && data?.location?.latLng) {
        setStreetViewAvailable(true);
        panoramaRef.current = new google.maps.StreetViewPanorama(
          streetViewRef.current!,
          {
            position: data.location.latLng,
            pov: { heading: 165, pitch: 0 },
            zoom: 1,
            addressControl: true,
            linksControl: true,
            panControl: true,
            enableCloseButton: false,
            fullscreenControl: true,
          }
        );
      } else {
        setStreetViewAvailable(false);
      }
    });

    return () => {
      panoramaRef.current = null;
    };
  }, [googleLoaded, lat, lng]);

  return (
    <motion.div
      initial={{ width: 0, opacity: 0 }}
      animate={{ width: expanded ? "100%" : "50%", opacity: 1 }}
      exit={{ width: 0, opacity: 0 }}
      transition={{ duration: 0.5, ease: "easeInOut" }}
      className={`relative h-full border-l border-border bg-background/90 ${expanded ? "absolute inset-0 z-30" : ""}`}
    >
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between px-4 py-2 bg-background/80 backdrop-blur-md border-b border-border">
        <span className="text-sm font-medium text-foreground flex items-center gap-2">
          <MapPin className="w-4 h-4 text-primary" />
          Street View — {lat.toFixed(4)}, {lng.toFixed(4)}
        </span>
        <div className="flex items-center gap-2">
          <Button size="icon" variant="ghost" onClick={onToggleExpand} className="h-7 w-7">
            {expanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </Button>
          <Button size="icon" variant="ghost" onClick={onClose} className="h-7 w-7">
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {!streetViewAvailable ? (
        <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-3">
          <MapPin className="w-12 h-12 opacity-40" />
          <p className="text-sm">Няма Street View за тази локация</p>
          <p className="text-xs text-muted-foreground/60">
            Опитай друго място или кликни двойно на картата
          </p>
        </div>
      ) : (
        <div ref={streetViewRef} className="w-full h-full pt-10" />
      )}
    </motion.div>
  );
};

export default StreetViewPanel;

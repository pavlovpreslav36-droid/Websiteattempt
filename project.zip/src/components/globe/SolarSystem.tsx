import { memo } from "react";

const planets = [
  { name: "Mercury", size: 10, orbit: 80, speed: 18, color: "#9ca3af" },
  { name: "Venus", size: 14, orbit: 130, speed: 25, color: "#f59e0b" },
  { name: "Mars", size: 12, orbit: 190, speed: 30, color: "#ef4444" },
  { name: "Jupiter", size: 28, orbit: 270, speed: 45, color: "#d97706" },
  { name: "Saturn", size: 22, orbit: 360, speed: 55, color: "#eab308", hasRing: true },
];

// Pure CSS animations — no JS overhead, GPU-composited via transform
const SolarSystem = memo(() => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 1 }}>
      {/* Sun glow */}
      <div
        className="absolute -top-24 -right-24 w-48 h-48 rounded-full blur-3xl opacity-20"
        style={{ background: "radial-gradient(circle, #fbbf24, #f97316, transparent)" }}
      />

      <style>{`
        @keyframes orbit {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes counter-rotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(-360deg); }
        }
        .planet-orbit {
          position: absolute;
          top: 15%;
          right: 5%;
          border-radius: 50%;
          animation: orbit var(--speed) linear infinite;
          will-change: transform;
        }
        .planet-body {
          position: absolute;
          border-radius: 50%;
          top: -calc(var(--size) / 2);
          right: 50%;
          animation: counter-rotate var(--speed) linear infinite;
          will-change: transform;
        }
      `}</style>

      {planets.map((planet) => (
        <div
          key={planet.name}
          className="planet-orbit"
          style={{
            width: planet.orbit * 2,
            height: planet.orbit * 2,
            marginTop: -planet.orbit,
            marginRight: -planet.orbit,
            border: "1px solid rgba(255,255,255,0.03)",
            // @ts-ignore
            "--speed": `${planet.speed}s`,
          } as React.CSSProperties}
        >
          {/* Planet positioned at edge of orbit */}
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: 0,
              width: planet.size,
              height: planet.size,
              marginTop: -planet.size / 2,
              marginLeft: -planet.size / 2,
              borderRadius: "50%",
              background: planet.color,
              boxShadow: `0 0 ${planet.size / 2}px ${planet.color}66`,
              animation: `counter-rotate ${planet.speed}s linear infinite`,
            }}
          >
            {planet.hasRing && (
              <div
                style={{
                  position: "absolute",
                  width: planet.size * 1.8,
                  height: planet.size * 0.5,
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%) rotateX(70deg)",
                  border: "1.5px solid rgba(234,179,8,0.3)",
                  borderRadius: "50%",
                  pointerEvents: "none",
                }}
              />
            )}
          </div>
        </div>
      ))}
    </div>
  );
});

SolarSystem.displayName = "SolarSystem";
export default SolarSystem;

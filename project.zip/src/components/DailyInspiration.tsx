import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence, useInView } from "framer-motion";
import { Sparkles } from "lucide-react";

const dailyQuotes = [
  { text: "Грижата за тялото ти е грижа за душата ти.", author: "Хипократ" },
  { text: "Здравето не е всичко, но без здраве всичко е нищо.", author: "Артур Шопенхауер" },
  { text: "Най-доброто лекарство е доброто настроение.", author: "Народна мъдрост" },
  { text: "Движението е живот. Животът е движение.", author: "Аристотел" },
  { text: "Нека храната ти бъде лекарство, а лекарството ти — храна.", author: "Хипократ" },
  { text: "Здравето е най-голямото богатство на човека.", author: "Вергилий" },
  { text: "Тялото постига това, в което умът вярва.", author: "Народна мъдрост" },
  { text: "Всеки ден е нова възможност да бъдеш по-здрав.", author: "Анонимен" },
  { text: "Малките стъпки водят до големи промени.", author: "Лао Дзъ" },
  { text: "Силата не идва от физическата способност, а от непоколебимата воля.", author: "Махатма Ганди" },
  { text: "Инвестирайте в здравето си — то е единственото, което винаги ще ви върне печалба.", author: "Народна мъдрост" },
  { text: "Щастието е най-добрият лек за всяка болест.", author: "Бенджамин Франклин" },
];

function getDailyQuote() {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000
  );
  return dailyQuotes[dayOfYear % dailyQuotes.length];
}

export function DailyInspiration() {
  const quote = getDailyQuote();
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; delay: number; size: number }>>([]);

  useEffect(() => {
    setParticles(
      Array.from({ length: 20 }, (_, i) => ({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        delay: Math.random() * 3,
        size: Math.random() * 4 + 2,
      }))
    );
  }, []);

  return (
    <section
      ref={ref}
      className="relative py-16 md:py-24 px-5 overflow-hidden"
    >
      {/* Gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-background to-accent/8" />

      {/* Floating particles */}
      <AnimatePresence>
        {isInView &&
          particles.map((p) => (
            <motion.div
              key={p.id}
              className="absolute rounded-full bg-primary/20"
              style={{
                left: `${p.x}%`,
                top: `${p.y}%`,
                width: p.size,
                height: p.size,
              }}
              initial={{ opacity: 0, scale: 0 }}
              animate={{
                opacity: [0, 0.6, 0],
                scale: [0, 1.5, 0],
                y: [-20, -60],
              }}
              transition={{
                duration: 4,
                delay: p.delay,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
      </AnimatePresence>

      {/* Content */}
      <div className="relative z-10 max-w-3xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="mb-6"
        >
          <Sparkles className="w-8 h-8 mx-auto text-primary/60" />
        </motion.div>

        <motion.blockquote
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.2, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="text-3xl md:text-5xl font-display font-medium text-foreground leading-snug tracking-tight mb-8"
        >
          „{quote.text}"
        </motion.blockquote>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-lg text-muted-foreground font-medium"
        >
          — {quote.author}
        </motion.p>

        <motion.div
          initial={{ scaleX: 0 }}
          animate={isInView ? { scaleX: 1 } : {}}
          transition={{ duration: 1, delay: 0.7, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="mt-10 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent max-w-xs mx-auto"
        />

        <motion.p
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 1 }}
          className="mt-6 text-xs text-muted-foreground uppercase tracking-widest"
        >
          Вдъхновение на деня
        </motion.p>
      </div>
    </section>
  );
}
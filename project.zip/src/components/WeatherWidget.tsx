import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import {
  Cloud, Sun, CloudRain, CloudSnow, Wind, Droplets, Thermometer,
  Eye, ArrowUp, ShieldAlert, Heart, Loader2
} from "lucide-react";

interface WeatherData {
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  weatherCode: number;
  uvIndex: number;
  isDay: boolean;
  city: string;
}

const weatherDescriptions: Record<number, { label: string; icon: React.ReactNode; bg: string }> = {
  0: { label: "Ясно небе ☀️", icon: <Sun className="w-8 h-8 text-amber-400" />, bg: "from-amber-500/20 to-orange-500/10" },
  1: { label: "Предимно ясно 🌤️", icon: <Sun className="w-8 h-8 text-amber-300" />, bg: "from-amber-400/15 to-sky-500/10" },
  2: { label: "Частична облачност ⛅", icon: <Cloud className="w-8 h-8 text-slate-400" />, bg: "from-slate-400/15 to-sky-500/10" },
  3: { label: "Облачно ☁️", icon: <Cloud className="w-8 h-8 text-slate-500" />, bg: "from-slate-500/15 to-slate-400/10" },
  45: { label: "Мъгла 🌫️", icon: <Eye className="w-8 h-8 text-slate-400" />, bg: "from-slate-400/20 to-slate-300/10" },
  48: { label: "Замръзваща мъгла 🌫️", icon: <Eye className="w-8 h-8 text-blue-300" />, bg: "from-blue-300/20 to-slate-400/10" },
  51: { label: "Лек дъжд 🌦️", icon: <CloudRain className="w-8 h-8 text-blue-400" />, bg: "from-blue-400/15 to-slate-500/10" },
  53: { label: "Умерен дъжд 🌧️", icon: <CloudRain className="w-8 h-8 text-blue-500" />, bg: "from-blue-500/20 to-slate-500/10" },
  55: { label: "Силен дъжд 🌧️", icon: <CloudRain className="w-8 h-8 text-blue-600" />, bg: "from-blue-600/20 to-slate-600/10" },
  61: { label: "Лек дъжд 🌦️", icon: <CloudRain className="w-8 h-8 text-blue-400" />, bg: "from-blue-400/15 to-slate-500/10" },
  63: { label: "Умерен дъжд 🌧️", icon: <CloudRain className="w-8 h-8 text-blue-500" />, bg: "from-blue-500/20 to-slate-500/10" },
  65: { label: "Силен дъжд 🌧️", icon: <CloudRain className="w-8 h-8 text-blue-600" />, bg: "from-blue-600/20 to-slate-600/10" },
  71: { label: "Лек сняг 🌨️", icon: <CloudSnow className="w-8 h-8 text-sky-300" />, bg: "from-sky-300/20 to-blue-200/10" },
  73: { label: "Умерен сняг ❄️", icon: <CloudSnow className="w-8 h-8 text-sky-400" />, bg: "from-sky-400/20 to-blue-300/10" },
  75: { label: "Силен сняг ❄️", icon: <CloudSnow className="w-8 h-8 text-sky-500" />, bg: "from-sky-500/20 to-blue-400/10" },
  80: { label: "Леки превалявания 🌦️", icon: <CloudRain className="w-8 h-8 text-blue-400" />, bg: "from-blue-400/15 to-slate-500/10" },
  81: { label: "Умерени превалявания 🌧️", icon: <CloudRain className="w-8 h-8 text-blue-500" />, bg: "from-blue-500/20 to-slate-500/10" },
  82: { label: "Пороен дъжд ⛈️", icon: <CloudRain className="w-8 h-8 text-blue-700" />, bg: "from-blue-700/20 to-slate-600/10" },
  95: { label: "Гръмотевична буря ⛈️", icon: <ShieldAlert className="w-8 h-8 text-purple-500" />, bg: "from-purple-500/20 to-slate-600/10" },
};

function getWeatherInfo(code: number) {
  return weatherDescriptions[code] || weatherDescriptions[3];
}

function getHealthTips(data: WeatherData): string[] {
  const tips: string[] = [];

  if (data.temperature > 30) {
    tips.push("🥤 Пийте поне 3 литра вода — горещо е!");
    tips.push("🧴 Нанесете слънцезащитен крем SPF 50+");
  } else if (data.temperature > 25) {
    tips.push("💧 Хидратирайте се добре — топло е навън");
  } else if (data.temperature < 0) {
    tips.push("🧣 Облечете се топло — температурата е под нулата!");
    tips.push("🍵 Топъл чай ще ви стопли и подкрепи имунитета");
  } else if (data.temperature < 10) {
    tips.push("🧥 Облечете се на пластове — хладно е");
  }

  if (data.uvIndex > 6) {
    tips.push("🕶️ Високо UV! Носете слънчеви очила и шапка");
  } else if (data.uvIndex > 3) {
    tips.push("☀️ Умерено UV — крем за слънце е препоръчителен");
  }

  if (data.humidity > 80) {
    tips.push("😮‍💨 Висока влажност — избягвайте тежки тренировки навън");
  }

  if (data.windSpeed > 40) {
    tips.push("💨 Силен вятър — бъдете внимателни навън!");
  }

  if ([51, 53, 55, 61, 63, 65, 80, 81, 82].includes(data.weatherCode)) {
    tips.push("☔ Вземете чадър — навън вали!");
    tips.push("🏠 Перфектно време за тренировка на закрито");
  }

  if ([71, 73, 75].includes(data.weatherCode)) {
    tips.push("⛷️ Внимавайте с хлъзгавите пътища!");
  }

  if (data.weatherCode === 0 && data.temperature >= 15 && data.temperature <= 28) {
    tips.push("🏃 Идеално време за разходка или бягане навън!");
    tips.push("🧘 Опитайте йога на открито за допълнително спокойствие");
  }

  if (tips.length === 0) {
    tips.push("✅ Умерено време — чудесен ден за активност навън!");
  }

  return tips.slice(0, 3);
}

const WeatherWidget = () => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tipIndex, setTipIndex] = useState(0);

  useEffect(() => {
    const fetchWeather = async (latitude: number, longitude: number) => {
      try {
        // Get city name
        let city = "Вашето местоположение";
        try {
          const geoRes = await fetch(
            `https://geocoding-api.open-meteo.com/v1/search?name=&latitude=${latitude}&longitude=${longitude}&count=1&language=bg`
          );
          // Fallback: use reverse geocoding via nominatim
          const nomRes = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&accept-language=bg`
          );
          if (nomRes.ok) {
            const nomData = await nomRes.json();
            city = nomData.address?.city || nomData.address?.town || nomData.address?.village || city;
          }
        } catch {
          // City name is optional, continue
        }

        const res = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,is_day&daily=uv_index_max&timezone=auto`
        );
        if (!res.ok) throw new Error("Weather API error");
        const data = await res.json();

        setWeather({
          temperature: Math.round(data.current.temperature_2m),
          feelsLike: Math.round(data.current.apparent_temperature),
          humidity: data.current.relative_humidity_2m,
          windSpeed: Math.round(data.current.wind_speed_10m),
          weatherCode: data.current.weather_code,
          uvIndex: Math.round(data.daily.uv_index_max[0]),
          isDay: data.current.is_day === 1,
          city,
        });
      } catch (e) {
        console.error("Weather fetch error:", e);
        setError("Неуспешно зареждане на времето");
      } finally {
        setLoading(false);
      }
    };

    // Try geolocation, fallback to Sofia
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => fetchWeather(pos.coords.latitude, pos.coords.longitude),
        () => fetchWeather(42.6977, 23.3219), // Sofia fallback
        { timeout: 5000 }
      );
    } else {
      fetchWeather(42.6977, 23.3219);
    }
  }, []);

  // Rotate health tips
  useEffect(() => {
    if (!weather) return;
    const tips = getHealthTips(weather);
    if (tips.length <= 1) return;
    const interval = setInterval(() => {
      setTipIndex((prev) => (prev + 1) % tips.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [weather]);

  if (loading) {
    return (
      <Card className="p-6 bg-card border border-border rounded-3xl shadow-card">
        <div className="flex items-center justify-center gap-3 py-4">
          <Loader2 className="w-5 h-5 animate-spin text-primary" />
          <span className="text-muted-foreground text-sm">Зареждане на времето...</span>
        </div>
      </Card>
    );
  }

  if (error || !weather) {
    return null; // Silently fail — not critical
  }

  const weatherInfo = getWeatherInfo(weather.weatherCode);
  const tips = getHealthTips(weather);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
    >
      <Card className={`relative overflow-hidden border-0 rounded-3xl shadow-md shadow-primary/10 bg-gradient-to-br ${weatherInfo.bg} backdrop-blur-md`}>
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-background/40 backdrop-blur-sm">
                {weatherInfo.icon}
              </div>
              <div>
                <h3 className="text-lg font-bold text-foreground">
                  {weather.city}
                </h3>
                <p className="text-sm text-muted-foreground">{weatherInfo.label}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-4xl font-bold text-foreground">{weather.temperature}°</p>
              <p className="text-xs text-muted-foreground">Усеща се {weather.feelsLike}°</p>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-4 gap-3 mb-4">
            <div className="flex flex-col items-center p-2 rounded-lg bg-background/30">
              <Droplets className="w-4 h-4 text-blue-400 mb-1" />
              <span className="text-xs font-medium text-foreground">{weather.humidity}%</span>
              <span className="text-[10px] text-muted-foreground">Влажност</span>
            </div>
            <div className="flex flex-col items-center p-2 rounded-lg bg-background/30">
              <Wind className="w-4 h-4 text-slate-400 mb-1" />
              <span className="text-xs font-medium text-foreground">{weather.windSpeed} км/ч</span>
              <span className="text-[10px] text-muted-foreground">Вятър</span>
            </div>
            <div className="flex flex-col items-center p-2 rounded-lg bg-background/30">
              <Sun className="w-4 h-4 text-amber-400 mb-1" />
              <span className="text-xs font-medium text-foreground">UV {weather.uvIndex}</span>
              <span className="text-[10px] text-muted-foreground">Индекс</span>
            </div>
            <div className="flex flex-col items-center p-2 rounded-lg bg-background/30">
              <Thermometer className="w-4 h-4 text-red-400 mb-1" />
              <span className="text-xs font-medium text-foreground">{weather.feelsLike}°</span>
              <span className="text-[10px] text-muted-foreground">Усещане</span>
            </div>
          </div>

          {/* Health tip — animated rotation */}
          <div className="rounded-2xl bg-background/40 backdrop-blur-sm p-3 shadow-sm">
            <div className="flex items-center gap-2 mb-1.5">
              <Heart className="w-4 h-4 text-primary" />
              <span className="text-xs font-bold text-primary uppercase tracking-wide">Здравен съвет</span>
            </div>
            <AnimatePresence mode="wait">
              <motion.p
                key={tipIndex}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.3 }}
                className="text-sm text-foreground"
              >
                {tips[tipIndex]}
              </motion.p>
            </AnimatePresence>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default WeatherWidget;

import { Link, useLocation } from "react-router-dom";
import {
  Home,
  ChefHat,
  HeartPulse,
  ScanBarcode,
  Trophy,
  Sun,
  Moon,
  Footprints,
} from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { useTheme } from "@/contexts/ThemeContext";
import { Achievements } from "./Achievements";
import { ProfileMenu } from "./ProfileMenu";

interface NavItem {
  to: string;
  label: string;
}

// The giant numbered links in the full-screen menu
const bigLinks: NavItem[] = [
  { to: "/", label: "Начало" },
  { to: "/recipes", label: "Рецепти" },
  { to: "/diets", label: "Диети" },
  { to: "/drinks", label: "Напитки" },
  { to: "/quit-kitchen", label: "Без цигара" },
  { to: "/health-dashboard", label: "Дневник" },
  { to: "/product-scanner", label: "Скенер" },
  { to: "/exercises", label: "Упражнения" },
  { to: "/quiz", label: "Викторина" },
  { to: "/tobacco-free", label: "Без тютюн" },
  { to: "/ambassadors", label: "Посланици" },
  { to: "/shopping-list", label: "Списък" },
];

// Everything else, in small print under the big links
const smallGroups: { title: string; items: NavItem[] }[] = [
  {
    title: "Храна",
    items: [
      { to: "/meal-planner", label: "Планер за седмицата" },
      { to: "/meal-journal", label: "Хранителен дневник" },
      { to: "/diets/gluten-free", label: "Без глутен" },
      { to: "/diets/lactose-free", label: "Без лактоза" },
      { to: "/diets/vegan", label: "Веган" },
    ],
  },
  {
    title: "Движение",
    items: [
      { to: "/workout-music", label: "Музика за тренировка" },
      { to: "/breathing", label: "Дишане" },
    ],
  },
  {
    title: "Моето здраве",
    items: [{ to: "/weekly-report", label: "Седмичен доклад" }],
  },
  {
    title: "Открий",
    items: [
      { to: "/fun-facts", label: "Интересни факти" },
      { to: "/health-horoscope", label: "Здравен хороскоп" },
      { to: "/globe", label: "Глобус" },
    ],
  },
  {
    title: "Общност",
    items: [
      { to: "/social", label: "Класация" },
      { to: "/special-thanks", label: "Благодарности" },
    ],
  },
  {
    title: "Приложение",
    items: [
      { to: "/settings", label: "Настройки" },
      { to: "/install", label: "Инсталирай" },
    ],
  },
];

const LangPills = ({ onFlame = false, className = "" }: { onFlame?: boolean; className?: string }) => {
  const { language, setLanguage } = useLanguage();
  return (
    <div className={`flex items-center gap-1.5 ${className}`} role="group" aria-label="Език">
      {(["bg", "en"] as const).map((l) => {
        const active = language === l;
        const cls = onFlame
          ? active
            ? "bg-wine text-cream border-wine"
            : "border-wine/60 text-wine hover:bg-wine/10"
          : active
          ? "bg-primary text-primary-foreground border-primary"
          : "border-primary/50 text-primary hover:bg-primary/10";
        return (
          <button
            key={l}
            onClick={() => setLanguage(l)}
            aria-pressed={active}
            className={`grid place-items-center w-8 h-8 rounded-full text-[11px] font-bold uppercase border transition-colors ${cls}`}
          >
            {l}
          </button>
        );
      })}
    </div>
  );
};

const Navigation = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showAchievements, setShowAchievements] = useState(false);
  const location = useLocation();
  const { t } = useLanguage();
  const { mode, setMode } = useTheme();

  const isActive = (path: string) => location.pathname === path;
  const isDark = mode === "dark";

  const tabs = [
    { to: "/", label: t.nav.home, icon: Home },
    { to: "/recipes", label: t.nav.recipes, icon: ChefHat },
    { to: "/health-dashboard", label: "Дневник", icon: HeartPulse },
    { to: "/product-scanner", label: t.nav.productScanner, icon: ScanBarcode },
  ];

  // close the menu on navigation
  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  // lock page scroll and allow Escape while the menu is open
  useEffect(() => {
    if (!menuOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      document.removeEventListener("keydown", onKey);
    };
  }, [menuOpen]);

  const themeButton = (
    <button
      onClick={() => setMode(isDark ? "light" : "dark")}
      className="grid place-items-center w-10 h-10 rounded-full text-foreground/70 hover:text-foreground hover:bg-muted transition-colors"
      aria-label={isDark ? "Светла тема" : "Тъмна тема"}
    >
      {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
    </button>
  );

  const trophyButton = (
    <button
      onClick={() => {
        setMenuOpen(false);
        setShowAchievements(true);
      }}
      className="grid place-items-center w-10 h-10 rounded-full text-primary hover:bg-muted transition-colors"
      aria-label="Постижения"
      title="Постижения"
    >
      <Trophy className="w-5 h-5" />
    </button>
  );

  return (
    <>
      {/* ───────── Top bar ───────── */}
      <header className="fixed top-0 inset-x-0 z-50 bg-background/85 backdrop-blur-md border-b border-border/60 pt-[env(safe-area-inset-top,0px)]">
        <div className="container mx-auto h-16 grid grid-cols-[1fr_auto_1fr] items-center gap-3">
          <div className="hidden md:flex">
            <LangPills />
          </div>

          <Link
            to="/"
            className="flex items-center gap-2 justify-self-start md:justify-self-center col-start-1 md:col-start-2"
            aria-label="Steps to a Healthy Life, начало"
          >
            <span className="grid place-items-center w-9 h-9 rounded-full bg-primary text-primary-foreground">
              <Footprints className="w-[18px] h-[18px]" aria-hidden="true" />
            </span>
            <span className="font-brand text-[17px] md:text-xl text-foreground leading-none whitespace-nowrap">
              <span className="hidden sm:inline">Steps to a Healthy Life</span>
              <span className="sm:hidden">Healthy Life</span>
            </span>
          </Link>

          <div className="flex items-center justify-end gap-1 col-start-3 col-span-1 md:col-start-3">
            <span className="hidden md:flex">{themeButton}</span>
            <span className="hidden md:flex">{trophyButton}</span>
            <ProfileMenu />
            <button
              onClick={() => setMenuOpen(true)}
              aria-haspopup="dialog"
              aria-expanded={menuOpen}
              className="ml-1 flex items-center gap-2.5 h-10 pl-4 pr-2.5 rounded-full border border-primary/70 text-primary text-[11px] font-bold tracking-[0.16em] uppercase hover:bg-primary hover:text-primary-foreground transition-colors group"
            >
              Меню
              <span className="w-4 h-4 rounded-full bg-primary group-hover:bg-primary-foreground transition-colors" aria-hidden="true" />
            </button>
          </div>
        </div>
      </header>

      {/* ───────── Mobile tab bar ───────── */}
      <nav
        className="lg:hidden fixed bottom-0 inset-x-0 z-50 bg-background/95 backdrop-blur-md border-t border-border pb-[env(safe-area-inset-bottom,0px)]"
        aria-label="Бърза навигация"
      >
        <ul className="grid grid-cols-4 h-[var(--tabbar-h)] px-2">
          {tabs.map((tab) => {
            const active = isActive(tab.to);
            return (
              <li key={tab.to}>
                <Link
                  to={tab.to}
                  aria-current={active ? "page" : undefined}
                  className="h-full flex flex-col items-center justify-center gap-1"
                >
                  <span className={`relative grid place-items-center h-8 w-14 rounded-full transition-colors ${active ? "text-primary" : "text-muted-foreground"}`}>
                    {active && (
                      <motion.span
                        layoutId="tab-pill"
                        className="absolute inset-0 rounded-full bg-primary/15"
                        transition={{ type: "spring", stiffness: 420, damping: 34 }}
                      />
                    )}
                    <tab.icon className="relative w-[22px] h-[22px]" aria-hidden="true" />
                  </span>
                  <span className={`text-[11px] leading-none ${active ? "text-primary font-semibold" : "text-muted-foreground"}`}>{tab.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* ───────── Full-screen menu ───────── */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            key="menu"
            role="dialog"
            aria-modal="true"
            aria-label="Меню"
            className="fixed inset-0 z-[70] bg-flame text-wine overflow-y-auto"
            initial={{ clipPath: "circle(0% at calc(100% - 3.2rem) 2.4rem)" }}
            animate={{ clipPath: "circle(150% at calc(100% - 3.2rem) 2.4rem)" }}
            exit={{ clipPath: "circle(0% at calc(100% - 3.2rem) 2.4rem)" }}
            transition={{ duration: 0.55, ease: [0.76, 0, 0.24, 1] }}
          >
            <div className="container mx-auto pt-[calc(env(safe-area-inset-top,0px)_+_0.75rem)] pb-10 min-h-full flex flex-col">
              <div className="h-16 flex items-center justify-between">
                <LangPills onFlame />
                <button
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-2.5 h-10 pl-4 pr-2.5 rounded-full border border-wine/70 text-wine text-[11px] font-bold tracking-[0.16em] uppercase hover:bg-wine hover:text-cream transition-colors"
                >
                  Затвори
                  <span className="w-4 h-4 rounded-full bg-wine" aria-hidden="true" />
                </button>
              </div>

              <ul className="mt-4 md:mt-8 md:grid md:grid-cols-2 md:gap-x-12">
                {bigLinks.map((item, i) => (
                  <li key={item.to} className="border-t border-wine/30 overflow-hidden">
                    <motion.div
                      initial={{ y: "110%" }}
                      animate={{ y: 0 }}
                      exit={{ y: "110%" }}
                      transition={{ duration: 0.5, delay: 0.2 + i * 0.045, ease: [0.22, 1, 0.36, 1] }}
                    >
                      <Link
                        to={item.to}
                        aria-current={isActive(item.to) ? "page" : undefined}
                        className="group flex items-baseline gap-4 py-1.5 md:py-2.5"
                      >
                        <span className="eyebrow w-7 shrink-0 opacity-70">{String(i + 1).padStart(2, "0")}</span>
                        <span className="font-brand uppercase text-[clamp(1.9rem,6.4vw,3.6rem)] leading-[1.05] transition-transform duration-300 group-hover:translate-x-3">
                          {item.label}
                        </span>
                        {isActive(item.to) && <span className="w-3 h-3 rounded-full bg-wine self-center" aria-hidden="true" />}
                      </Link>
                    </motion.div>
                  </li>
                ))}
              </ul>
              <div className="border-t border-wine/30" />

              <motion.div
                className="mt-8 grid grid-cols-2 md:grid-cols-6 gap-x-6 gap-y-6"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ delay: 0.65, duration: 0.4 }}
              >
                {smallGroups.map((g) => (
                  <div key={g.title}>
                    <p className="eyebrow opacity-70 mb-2">{g.title}</p>
                    <ul className="space-y-1">
                      {g.items.map((item) => (
                        <li key={item.to}>
                          <Link to={item.to} className="text-sm font-semibold underline-offset-4 hover:underline">
                            {item.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </motion.div>

              <div className="mt-auto pt-10 flex items-center gap-1 [&_button]:text-wine [&_button:hover]:bg-wine/10">
                {themeButton}
                {trophyButton}
                <span className="ml-2 text-xs font-semibold opacity-70">Steps to a Healthy Life</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {showAchievements && <Achievements onClose={() => setShowAchievements(false)} />}
    </>
  );
};

export default Navigation;

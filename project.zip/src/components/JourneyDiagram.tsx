import { motion } from "framer-motion";
import { Sparkles, Heart, Flame, Trophy } from "lucide-react";

const steps = [
  { icon: Sparkles, label: "Събуждане", desc: "Чаша вода + дъх" },
  { icon: Heart, label: "Движение", desc: "20 минути активност" },
  { icon: Flame, label: "Хранене", desc: "Истинска храна" },
  { icon: Trophy, label: "Победа", desc: "Един по-добър ден" },
];

export const JourneyDiagram = () => {
  return (
    <div className="w-full max-w-4xl mx-auto px-4">
      <div className="relative">
        {/* connecting line */}
        <div className="absolute top-7 left-0 right-0 h-px bg-border/40 hidden md:block" />
        <motion.div
          className="absolute top-7 left-0 h-px bg-gradient-to-r from-primary via-primary/70 to-primary/0 hidden md:block origin-left"
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: false, margin: "-80px" }}
          transition={{ duration: 2.2, ease: [0.25, 0.46, 0.45, 0.94] }}
        />

        <div className="grid grid-cols-2 md:grid-cols-4 gap-y-8 gap-x-4 relative">
          {steps.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: false, margin: "-60px" }}
              transition={{ delay: i * 0.45, duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="flex flex-col items-center text-center"
            >
              <motion.div
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: false, margin: "-60px" }}
                transition={{ delay: i * 0.45 + 0.1, type: "spring", stiffness: 200, damping: 14 }}
                className="w-14 h-14 rounded-full bg-background border border-primary/30 flex items-center justify-center mb-3 relative z-10"
              >
                <s.icon className="w-6 h-6 text-primary" />
                <motion.span
                  className="absolute inset-0 rounded-full border border-primary/40"
                  animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0, 0.6] }}
                  transition={{ duration: 2.4, repeat: Infinity, delay: i * 0.3 }}
                />
              </motion.div>
              <span className="text-sm md:text-base font-semibold text-foreground">{s.label}</span>
              <span className="text-xs text-muted-foreground mt-1">{s.desc}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
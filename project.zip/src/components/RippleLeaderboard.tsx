import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Trophy, User as UserIcon, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Reveal } from "@/components/Reveal";

type Row = {
  user_id: string | null;
  username: string;
  count: number;
  isAnonymous: boolean;
};

const medalColors = ["text-yellow-400", "text-slate-300", "text-amber-600"];

export const RippleLeaderboard = () => {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const fetchLeaderboard = async () => {
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);

      const { data: moments } = await supabase
        .from("ripple_moments")
        .select("user_id")
        .gte("created_at", startOfDay.toISOString());

      if (!mounted || !moments) return;

      // Aggregate
      const counts = new Map<string | null, number>();
      for (const m of moments) {
        const key = m.user_id ?? null;
        counts.set(key, (counts.get(key) ?? 0) + 1);
      }

      // Fetch usernames for known users
      const userIds = Array.from(counts.keys()).filter((k): k is string => !!k);
      let nameMap = new Map<string, string>();
      if (userIds.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, full_name")
          .in("id", userIds);
        if (profiles) {
          for (const p of profiles) {
            nameMap.set(p.id, p.full_name?.trim() || "Потребител");
          }
        }
      }

      const aggregated: Row[] = Array.from(counts.entries()).map(([uid, count]) => ({
        user_id: uid,
        username: uid ? nameMap.get(uid) ?? "Потребител" : "Анонимни",
        count,
        isAnonymous: !uid,
      }));

      aggregated.sort((a, b) => b.count - a.count);
      setRows(aggregated.slice(0, 5));
      setLoading(false);
    };

    fetchLeaderboard();

    const channel = supabase
      .channel("ripple_leaderboard_changes")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "ripple_moments" },
        () => fetchLeaderboard()
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, []);

  return (
    <Reveal direction="up">
      <div className="rounded-3xl bg-card border border-border shadow-card p-6 md:p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Trophy className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg md:text-xl font-display font-semibold text-foreground">
              Топ за днес
            </h3>
            <p className="text-xs text-muted-foreground">
              Най-активни в общността
            </p>
          </div>
        </div>

        {loading ? (
          <div className="space-y-2">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-12 rounded-xl bg-muted/40 animate-pulse" />
            ))}
          </div>
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-6">
            Бъди първият, който отделя момент днес ✨
          </p>
        ) : (
          <ol className="space-y-2">
            {rows.map((row, i) => (
              <motion.li
                key={`${row.user_id ?? "anon"}-${i}`}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05, duration: 0.3 }}
                className="flex items-center justify-between gap-3 rounded-2xl bg-background/40 px-4 py-3 hover:bg-background/70 hover:shadow-sm transition-all"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span
                    className={`text-sm font-bold w-6 text-center ${
                      i < 3 ? medalColors[i] : "text-muted-foreground"
                    }`}
                  >
                    {i + 1}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                    {row.isAnonymous ? (
                      <Users className="w-4 h-4 text-muted-foreground" />
                    ) : (
                      <UserIcon className="w-4 h-4 text-primary" />
                    )}
                  </div>
                  <span className="text-sm font-medium text-foreground truncate">
                    {row.username}
                  </span>
                </div>
                <span className="text-sm font-semibold text-primary tabular-nums shrink-0">
                  {row.count}
                </span>
              </motion.li>
            ))}
          </ol>
        )}
      </div>
    </Reveal>
  );
};
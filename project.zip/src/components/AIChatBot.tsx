import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Send, Loader2, Image, Trash2, Sparkles, Music, Utensils, HeartPulse, HelpCircle, Dumbbell, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { useAchievements } from "@/hooks/useAchievements";
import ReactMarkdown from "react-markdown";
const CHATBOT_AVATAR = "/images/chatbot-avatar.png";

interface Message {
  role: 'user' | 'assistant';
  content: string;
  imageData?: string;
  generatedImage?: string;
  streaming?: boolean;
}

interface AIChatBotProps {
  onClose: () => void;
}

interface QuickReply {
  icon: React.ReactNode;
  label: string;
  message: string;
}

const CHAT_STORAGE_KEY = 'ai_chat_history';

const STREAMING_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-chat`;

export const AIChatBot = ({ onClose }: AIChatBotProps) => {
  const { language } = useLanguage();
  const { user } = useAuth();
  const { trackProgress } = useAchievements();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [showQuickReplies, setShowQuickReplies] = useState(true);
  const [isThinking, setIsThinking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const quickReplies: QuickReply[] = language === 'bg' ? [
    { icon: <Music className="w-3.5 h-3.5" />, label: "Предложи песни 🎵", message: "Предложи ми 5 яки песни за тренировка" },
    { icon: <Utensils className="w-3.5 h-3.5" />, label: "Здравословна рецепта", message: "Дай ми бърза здравословна рецепта" },
    { icon: <HeartPulse className="w-3.5 h-3.5" />, label: "Здравен съвет", message: "Дай ми съвет за по-здравословен живот" },
    { icon: <Dumbbell className="w-3.5 h-3.5" />, label: "Тренировка", message: "Предложи ми бърза домашна тренировка" },
    { icon: <Brain className="w-3.5 h-3.5" />, label: "Забавен факт", message: "Кажи ми интересен факт за здравето" },
    { icon: <HelpCircle className="w-3.5 h-3.5" />, label: "Помощ", message: "Какви функции има в сайта?" },
  ] : [
    { icon: <Music className="w-3.5 h-3.5" />, label: "Suggest songs 🎵", message: "Suggest 5 great workout songs" },
    { icon: <Utensils className="w-3.5 h-3.5" />, label: "Healthy recipe", message: "Give me a quick healthy recipe" },
    { icon: <HeartPulse className="w-3.5 h-3.5" />, label: "Health tip", message: "Give me a tip for a healthier life" },
    { icon: <Dumbbell className="w-3.5 h-3.5" />, label: "Workout", message: "Suggest a quick home workout" },
    { icon: <Brain className="w-3.5 h-3.5" />, label: "Fun fact", message: "Tell me an interesting health fact" },
    { icon: <HelpCircle className="w-3.5 h-3.5" />, label: "Help", message: "What features does this website have?" },
  ];

  useEffect(() => {
    const loadChatHistory = async () => {
      const savedChat = localStorage.getItem(CHAT_STORAGE_KEY);
      if (savedChat) {
        try {
          const parsed = JSON.parse(savedChat);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setMessages(parsed);
            setShowQuickReplies(parsed.length <= 1);
            return;
          }
        } catch (e) { /* ignore */ }
      }

      if (user) {
        try {
          const { data, error } = await supabase
            .from('chat_history').select('*')
            .eq('user_id', user.id)
            .order('created_at', { ascending: true }).limit(100);
          if (!error && data && data.length > 0) {
            const loadedMessages = data.map(m => ({ role: m.role as 'user' | 'assistant', content: m.message }));
            setMessages(loadedMessages);
            setShowQuickReplies(false);
            localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(loadedMessages));
            return;
          }
        } catch (e) { /* ignore */ }
      }

      setMessages([{
        role: 'assistant',
        content: language === 'bg' 
          ? 'Здрасти! 👋✨ Аз съм твоят приятелски AI помощник — тук съм да ти помогна с всичко: песни, рецепти, тренировки, съвети или просто да си побъбрим. С какво да започнем? 😊'
          : 'Hey there! 👋✨ I\'m your friendly AI buddy — here to help with songs, recipes, workouts, tips, or just a chat. What shall we explore? 😊'
      }]);
    };
    loadChatHistory();
  }, [user, language]);

  useEffect(() => {
    if (messages.length > 0) {
      const messagesForStorage = messages
        .filter(m => !m.streaming)
        .map(m => ({ role: m.role, content: m.content }));
      localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messagesForStorage));

      if (user && messages.length > 1) {
        const lastMessage = messages[messages.length - 1];
        if (lastMessage.streaming) return;
        supabase.from('chat_history').insert({
          user_id: user.id, role: lastMessage.role, message: lastMessage.content
        }).then(({ error }) => { if (error) console.error('DB save error:', error); });
      }
    }
  }, [messages, user]);

  useEffect(() => {
    if (scrollRef.current) {
      const scrollEl = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollEl) scrollEl.scrollTop = scrollEl.scrollHeight;
    }
  }, [messages]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error(language === 'bg' ? 'Макс. 5MB' : 'Max 5MB');
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const clearImagePreview = () => {
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const clearChatHistory = () => {
    localStorage.removeItem(CHAT_STORAGE_KEY);
    setMessages([{
      role: 'assistant',
      content: language === 'bg' ? 'Чатът е изчистен. Как мога да помогна?' : 'Chat cleared. How can I help?'
    }]);
    setShowQuickReplies(true);
    if (user) {
      supabase.from('chat_history').delete().eq('user_id', user.id);
    }
    toast.success(language === 'bg' ? 'Изчистено' : 'Cleared');
  };

  const streamMessage = useCallback(async (messagesToSend: any[]) => {
    const resp = await fetch(STREAMING_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
      },
      body: JSON.stringify({ messages: messagesToSend, language, stream: true })
    });

    if (!resp.ok) {
      if (resp.status === 429) throw new Error('rate_limit');
      if (resp.status === 402) throw new Error('credits_exhausted');
      throw new Error('ai_error');
    }

    if (!resp.body) throw new Error('no_body');

    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let textBuffer = '';
    let assistantSoFar = '';
    let streamDone = false;

    while (!streamDone) {
      const { done, value } = await reader.read();
      if (done) break;
      textBuffer += decoder.decode(value, { stream: true });

      let newlineIndex: number;
      while ((newlineIndex = textBuffer.indexOf('\n')) !== -1) {
        let line = textBuffer.slice(0, newlineIndex);
        textBuffer = textBuffer.slice(newlineIndex + 1);
        if (line.endsWith('\r')) line = line.slice(0, -1);
        if (line.startsWith(':') || line.trim() === '') continue;
        if (!line.startsWith('data: ')) continue;
        const jsonStr = line.slice(6).trim();
        if (jsonStr === '[DONE]') { streamDone = true; break; }
        try {
          const parsed = JSON.parse(jsonStr);
          const content = parsed.choices?.[0]?.delta?.content as string | undefined;
          if (content) {
            assistantSoFar += content;
            // Hide thinking indicator once first token arrives
            setIsThinking(false);
            setMessages(prev => {
              const last = prev[prev.length - 1];
              if (last?.role === 'assistant' && last.streaming) {
                return prev.map((m, i) => i === prev.length - 1 ? { ...m, content: assistantSoFar } : m);
              }
              return [...prev, { role: 'assistant', content: assistantSoFar, streaming: true }];
            });
          }
        } catch {
          textBuffer = line + '\n' + textBuffer;
          break;
        }
      }
    }

    // Final flush
    if (textBuffer.trim()) {
      for (let raw of textBuffer.split('\n')) {
        if (!raw) continue;
        if (raw.endsWith('\r')) raw = raw.slice(0, -1);
        if (raw.startsWith(':') || raw.trim() === '') continue;
        if (!raw.startsWith('data: ')) continue;
        const jsonStr = raw.slice(6).trim();
        if (jsonStr === '[DONE]') continue;
        try {
          const parsed = JSON.parse(jsonStr);
          const content = parsed.choices?.[0]?.delta?.content as string | undefined;
          if (content) {
            assistantSoFar += content;
            setMessages(prev => prev.map((m, i) => i === prev.length - 1 ? { ...m, content: assistantSoFar } : m));
          }
        } catch { /* ignore */ }
      }
    }

    // Mark streaming complete
    setMessages(prev => prev.map((m, i) =>
      i === prev.length - 1 && m.streaming ? { ...m, streaming: false } : m
    ));

    return assistantSoFar;
  }, [language]);

  const sendMessage = async (overrideMessage?: string) => {
    const messageText = overrideMessage || input;
    if ((!messageText.trim() && !imagePreview) || isLoading) return;

    const userMessage: Message = { 
      role: 'user', 
      content: messageText || (language === 'bg' ? 'Анализирай това изображение' : 'Analyze this image'),
      imageData: imagePreview || undefined
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setShowQuickReplies(false);
    clearImagePreview();
    setIsLoading(true);
    setIsThinking(true);
    trackProgress('ai_conversations', 1);

    try {
      const messagesToSend = [...messages, userMessage].map(m => ({
        role: m.role, content: m.content, imageData: m.imageData
      }));

      // Use streaming for text-only, non-streaming for images
      if (userMessage.imageData) {
        const { data, error } = await supabase.functions.invoke('ai-chat', {
          body: { messages: messagesToSend, language }
        });
        if (error) throw error;
        setMessages(prev => [...prev, { role: 'assistant', content: data.message }]);
      } else {
        await streamMessage(messagesToSend);
      }
    } catch (error: any) {
      const errMsg = error?.message || '';
      let errorContent: string;
      if (errMsg === 'rate_limit') {
        errorContent = language === 'bg' ? 'Твърде много заявки. Опитайте по-късно.' : 'Too many requests. Try again later.';
      } else if (errMsg === 'credits_exhausted') {
        errorContent = language === 'bg' ? 'AI кредитите са изчерпани.' : 'AI credits exhausted.';
      } else {
        errorContent = language === 'bg' ? 'Възникна грешка. Опитайте отново.' : 'An error occurred. Try again.';
      }
      setMessages(prev => [...prev, { role: 'assistant', content: errorContent }]);
    } finally {
      setIsLoading(false);
      setIsThinking(false);
    }
  };

  const generateImage = async () => {
    if (!input.trim() || isGeneratingImage) return;
    const userMessage: Message = { 
      role: 'user', 
      content: `🎨 ${language === 'bg' ? 'Генерирай:' : 'Generate:'} ${input}`
    };
    setMessages(prev => [...prev, userMessage]);
    const prompt = input;
    setInput('');
    setIsGeneratingImage(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-image', {
        body: { prompt, language }
      });
      if (error) throw error;
      trackProgress('images_generated', 1);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: data.message || '🎨',
        generatedImage: data.imageUrl
      }]);
    } catch {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: language === 'bg' ? 'Грешка при генериране.' : 'Generation error.'
      }]);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleQuickReply = (qr: QuickReply) => {
    sendMessage(qr.message);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-background/60 backdrop-blur-md z-50 flex items-end sm:items-center justify-center sm:p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ y: 100, opacity: 0, scale: 0.95 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          exit={{ y: 100, opacity: 0, scale: 0.95 }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full sm:max-w-xl h-[85vh] sm:h-[650px] sm:rounded-2xl overflow-hidden"
        >
          <Card className="h-full flex flex-col bg-card/98 backdrop-blur-xl border-primary/10 shadow-2xl sm:rounded-2xl rounded-t-2xl rounded-b-none">
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-border/50 bg-gradient-to-r from-primary/5 to-accent/5">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <img
                    src={CHATBOT_AVATAR}
                    alt={language === 'bg' ? 'Здравко — AI асистент' : 'Zdravko — AI assistant'}
                    width={36}
                    height={36}
                    loading="lazy"
                    className="w-9 h-9 rounded-full object-contain p-0.5"
                  />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-foreground">
                    {language === 'bg' ? 'Здравко · AI Асистент' : 'Zdravko · AI Assistant'}
                  </h3>
                  <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block animate-pulse" />
                    {language === 'bg' ? 'Онлайн' : 'Online'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={clearChatHistory}
                  title={language === 'bg' ? 'Изчисти' : 'Clear'}>
                  <Trash2 className="w-3.5 h-3.5 text-muted-foreground" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 px-4 py-3" ref={scrollRef}>
              <div className="space-y-3">
                {messages.map((message, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                      message.role === 'user'
                        ? 'bg-primary text-primary-foreground rounded-br-md'
                        : 'bg-muted/60 text-foreground rounded-bl-md'
                    }`}>
                      {message.imageData && (
                        <img src={message.imageData} alt="Uploaded" 
                          className="max-w-full h-auto rounded-lg mb-2 max-h-40 object-contain" />
                      )}
                      {message.role === 'assistant' ? (
                        <div className={`prose prose-sm dark:prose-invert max-w-none
                          [&>p]:mb-1.5 [&>p:last-child]:mb-0
                          [&_ul]:my-1.5 [&_ul]:pl-4 [&_ul]:space-y-1 [&_ul>li]:marker:text-primary
                          [&_ol]:my-1.5 [&_ol]:pl-4 [&_ol]:space-y-1 [&_ol>li]:marker:text-primary [&_ol>li]:marker:font-semibold
                          [&_li>p]:my-0
                          [&_strong]:text-foreground [&_strong]:font-semibold
                          [&_a]:text-primary [&_a]:font-medium [&_a]:underline [&_a]:underline-offset-2 hover:[&_a]:text-primary/80
                          [&_code]:bg-primary/10 [&_code]:text-primary [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded [&_code]:text-xs
                          ${message.streaming ? 'gemini-streaming' : ''}`}>
                          <ReactMarkdown
                            components={{
                              a: ({ href, children }) => (
                                <a
                                  href={href}
                                  onClick={(e) => {
                                    if (href?.startsWith('/')) {
                                      e.preventDefault();
                                      window.location.href = href;
                                    }
                                  }}
                                >
                                  {children}
                                </a>
                              ),
                            }}
                          >
                            {message.content}
                          </ReactMarkdown>
                          {message.streaming && (
                            <span className="inline-block w-1.5 h-3.5 ml-0.5 bg-gradient-to-b from-primary to-accent rounded-sm align-middle animate-pulse" />
                          )}
                        </div>
                      ) : (
                        <div className="whitespace-pre-wrap">{message.content}</div>
                      )}
                      {message.generatedImage && (
                        <img src={message.generatedImage} alt="Generated" 
                          className="max-w-full h-auto rounded-lg mt-2 max-h-52 object-contain" />
                      )}
                    </div>
                  </motion.div>
                ))}
                {(isThinking || isGeneratingImage) && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="flex justify-start"
                  >
                    <div className="bg-muted/60 rounded-2xl rounded-bl-md px-4 py-2.5 flex items-center gap-2 min-w-[140px]">
                      <Sparkles className="w-3.5 h-3.5 text-primary animate-pulse" />
                      <span className="gemini-shimmer text-sm font-medium">
                        {isGeneratingImage
                          ? (language === 'bg' ? 'Генерирам изображение…' : 'Generating image…')
                          : (language === 'bg' ? 'Размишлявам…' : 'Thinking…')}
                      </span>
                    </div>
                  </motion.div>
                )}
              </div>
            </ScrollArea>

            {/* Quick Replies */}
            {showQuickReplies && !isLoading && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="px-4 pb-2"
              >
                <div className="flex flex-wrap gap-1.5">
                  {quickReplies.map((qr, i) => (
                    <motion.button
                      key={i}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.05 }}
                      onClick={() => handleQuickReply(qr)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium 
                        bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20
                        transition-all hover:scale-105 active:scale-95"
                    >
                      {qr.icon}
                      {qr.label}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Image Preview */}
            {imagePreview && (
              <div className="px-4 pb-2">
                <div className="relative inline-block">
                  <img src={imagePreview} alt="Preview" className="h-16 w-auto rounded-lg border border-primary/20" />
                  <button onClick={clearImagePreview}
                    className="absolute -top-1.5 -right-1.5 bg-destructive text-destructive-foreground rounded-full p-0.5">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              </div>
            )}

            {/* Input */}
            <div className="px-3 py-3 border-t border-border/50 bg-card/50">
              <div className="flex gap-2 items-end">
                <input type="file" ref={fileInputRef} accept="image/*" onChange={handleImageUpload} className="hidden" />
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0 rounded-full"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isLoading || isGeneratingImage}>
                    <Image className="w-4 h-4 text-muted-foreground" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0 rounded-full"
                    onClick={generateImage}
                    disabled={!input.trim() || isLoading || isGeneratingImage}
                    title={language === 'bg' ? 'Генерирай изображение' : 'Generate image'}>
                    <Sparkles className="w-4 h-4 text-accent" />
                  </Button>
                </div>
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                  placeholder={language === 'bg' ? 'Напишете съобщение...' : 'Type a message...'}
                  disabled={isLoading || isGeneratingImage}
                  className="flex-1 rounded-full bg-muted/40 border-border/50 h-9 text-sm"
                />
                <Button onClick={() => sendMessage()} size="icon" className="h-9 w-9 shrink-0 rounded-full"
                  disabled={isLoading || isGeneratingImage || (!input.trim() && !imagePreview)}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

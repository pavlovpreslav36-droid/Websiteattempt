import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Play, Pause, Wind } from "lucide-react";

const PHASES = [
  { label: "Вдишай", scale: 1.4, duration: 4 },
  { label: "Задръж", scale: 1.4, duration: 4 },
  { label: "Издишай", scale: 0.7, duration: 4 },
  { label: "Задръж", scale: 0.7, duration: 4 },
];

export function BoxBreathingWidget() {
  const [active, setActive] = useState(false);
  const [phaseIdx, setPhaseIdx] = useState(0);
  const [count, setCount] = useState(4);
  const tickRef = useRef<number | null>(null);

  useEffect(() => {
    if (!active) return;
    setPhaseIdx(0); setCount(4);
    let i = 0; let c = 4;
    tickRef.current = window.setInterval(() => {
      c -= 1;
      if (c <= 0) {
        i = (i + 1) % PHASES.length;
        c = PHASES[i].duration;
        setPhaseIdx(i);
      }
      setCount(c);
    }, 1000);
    return () => { if (tickRef.current) window.clearInterval(tickRef.current); };
  }, [active]);

  const phase = PHASES[phaseIdx];

  return (
    <div className="rounded-3xl bg-card border border-border shadow-card p-6 md:p-10 text-center">
      <div className="flex items-center justify-center gap-2 mb-2">
        <Wind className="w-5 h-5 text-primary" />
        <span className="uppercase tracking-[0.2em] text-xs font-bold text-primary">Box Breathing</span>
      </div>
      <h3 className="text-2xl md:text-3xl font-display font-bold text-foreground mb-1">Фокус и спокойствие</h3>
      <p className="text-sm text-muted-foreground mb-8">4 секунди — вдишай, задръж, издишай, задръж.</p>

      <div className="relative h-64 md:h-80 flex items-center justify-center mb-6">
        <div className="absolute w-56 h-56 md:w-64 md:h-64 rounded-full bg-primary/5 blur-2xl" />
        <motion.div
          animate={active ? { scale: phase.scale } : { scale: 1 }}
          transition={{ duration: phase.duration, ease: "easeInOut" }}
          className="w-36 h-36 md:w-44 md:h-44 rounded-full bg-gradient-to-br from-primary to-primary/40 shadow-[0_0_60px_-10px_hsl(var(--primary)/0.6)] flex flex-col items-center justify-center text-primary-foreground"
        >
          <span className="text-lg md:text-xl font-semibold">{active ? phase.label : "Готов?"}</span>
          {active && <span className="text-4xl font-display font-bold mt-1">{count}</span>}
        </motion.div>
      </div>

      <button
        onClick={() => setActive((a) => !a)}
        className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-primary text-primary-foreground font-semibold transition-all duration-300 hover:scale-[1.03] hover:shadow-[var(--shadow-glow)]"
      >
        {active ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
        {active ? "Спри" : "Започни дишане"}
      </button>
    </div>
  );
}
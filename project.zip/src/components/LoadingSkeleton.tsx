import { cn } from "@/lib/utils";

interface SkeletonProps {
  className?: string;
}

export const Skeleton = ({ className }: SkeletonProps) => {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-md bg-muted/60",
        "before:absolute before:inset-0 before:-translate-x-full",
        "before:animate-[shimmer_2s_infinite]",
        "before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent",
        className
      )}
    />
  );
};

export const SkeletonText = ({ className }: SkeletonProps) => {
  return <Skeleton className={cn("h-4 w-full rounded", className)} />;
};

export const SkeletonTitle = ({ className }: SkeletonProps) => {
  return <Skeleton className={cn("h-8 w-3/4 rounded", className)} />;
};

export const SkeletonAvatar = ({ className }: SkeletonProps) => {
  return <Skeleton className={cn("h-12 w-12 rounded-full", className)} />;
};

export const SkeletonButton = ({ className }: SkeletonProps) => {
  return <Skeleton className={cn("h-10 w-24 rounded-md", className)} />;
};

export const SkeletonImage = ({ className }: SkeletonProps) => {
  return <Skeleton className={cn("aspect-video w-full rounded-lg", className)} />;
};

// Card skeleton for common card layouts
export const SkeletonCard = ({ className }: SkeletonProps) => {
  return (
    <div className={cn("p-6 rounded-xl border border-border/50 bg-card/30 space-y-4", className)}>
      <div className="flex items-center gap-4">
        <SkeletonAvatar />
        <div className="flex-1 space-y-2">
          <SkeletonText className="w-1/2" />
          <SkeletonText className="w-1/3 h-3" />
        </div>
      </div>
      <div className="space-y-2">
        <SkeletonText />
        <SkeletonText className="w-5/6" />
        <SkeletonText className="w-4/6" />
      </div>
      <div className="flex gap-2 pt-2">
        <SkeletonButton />
        <SkeletonButton className="w-20" />
      </div>
    </div>
  );
};

// Product card skeleton
export const SkeletonProductCard = ({ className }: SkeletonProps) => {
  return (
    <div className={cn("p-6 rounded-xl border border-border/50 bg-card/30 space-y-4", className)}>
      <SkeletonImage />
      <SkeletonTitle className="w-2/3" />
      <div className="space-y-2">
        <SkeletonText className="w-full" />
        <SkeletonText className="w-4/5" />
      </div>
      <div className="flex justify-between items-center pt-2">
        <Skeleton className="h-6 w-16 rounded" />
        <SkeletonButton />
      </div>
    </div>
  );
};

// Stats card skeleton
export const SkeletonStatsCard = ({ className }: SkeletonProps) => {
  return (
    <div className={cn("p-6 rounded-xl border border-border/50 bg-card/30 space-y-3", className)}>
      <div className="flex justify-between items-start">
        <Skeleton className="h-10 w-10 rounded-lg" />
        <Skeleton className="h-5 w-12 rounded" />
      </div>
      <SkeletonTitle className="w-1/2 h-10" />
      <SkeletonText className="w-2/3 h-3" />
    </div>
  );
};

// Table row skeleton
export const SkeletonTableRow = ({ columns = 4, className }: SkeletonProps & { columns?: number }) => {
  return (
    <div className={cn("flex items-center gap-4 p-4 border-b border-border/30", className)}>
      {Array.from({ length: columns }).map((_, i) => (
        <SkeletonText key={i} className={cn("flex-1", i === 0 && "w-1/4")} />
      ))}
    </div>
  );
};

// List skeleton
export const SkeletonList = ({ count = 3, className }: SkeletonProps & { count?: number }) => {
  return (
    <div className={cn("space-y-4", className)}>
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 p-4 rounded-lg border border-border/30 bg-card/20">
          <SkeletonAvatar className="h-10 w-10" />
          <div className="flex-1 space-y-2">
            <SkeletonText className="w-1/3" />
            <SkeletonText className="w-1/2 h-3" />
          </div>
          <Skeleton className="h-8 w-8 rounded" />
        </div>
      ))}
    </div>
  );
};

// Recipe card skeleton
export const SkeletonRecipeCard = ({ className }: SkeletonProps) => {
  return (
    <div className={cn("rounded-xl border border-border/50 bg-card/30 overflow-hidden", className)}>
      <SkeletonImage className="rounded-none" />
      <div className="p-4 space-y-3">
        <SkeletonTitle className="w-3/4 h-6" />
        <div className="flex gap-2">
          <Skeleton className="h-6 w-16 rounded-full" />
          <Skeleton className="h-6 w-20 rounded-full" />
          <Skeleton className="h-6 w-14 rounded-full" />
        </div>
        <div className="space-y-2">
          <SkeletonText />
          <SkeletonText className="w-2/3" />
        </div>
      </div>
    </div>
  );
};

// Full page loading skeleton
export const SkeletonPage = ({ className }: SkeletonProps) => {
  return (
    <div className={cn("min-h-screen pt-20 px-4 pb-8 space-y-8", className)}>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="space-y-4">
          <SkeletonTitle className="h-12 w-1/2" />
          <SkeletonText className="w-2/3" />
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <SkeletonCard />
          <SkeletonCard />
          <SkeletonCard />
        </div>
      </div>
    </div>
  );
};

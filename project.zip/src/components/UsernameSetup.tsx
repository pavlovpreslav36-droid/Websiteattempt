import { AuthModal } from "@/components/AuthModal";

interface UsernameSetupProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/** Kept for backwards compatibility — now renders the unified account modal. */
export const UsernameSetup = ({ open, onOpenChange }: UsernameSetupProps) => (
  <AuthModal open={open} onOpenChange={onOpenChange} />
);

export default UsernameSetup;

import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";

// Common allergens with English and Bulgarian variations
const ALLERGENS = [
  // Nuts
  { name: "Ядки", patterns: ["nut", "nuts", "peanut", "almond", "cashew", "walnut", "hazelnut", "pistachio", "pecan", "macadamia", "ядки", "фъстъци", "бадем", "кашу", "орех", "лешник", "шамфъстък"] },
  // Milk/Dairy
  { name: "Мляко", patterns: ["milk", "lactose", "cream", "butter", "cheese", "whey", "casein", "dairy", "мляко", "лактоза", "сметана", "масло", "сирене", "суроватка", "казеин"] },
  // Eggs
  { name: "Яйца", patterns: ["egg", "eggs", "albumin", "яйце", "яйца", "албумин"] },
  // Gluten
  { name: "Глутен", patterns: ["gluten", "wheat", "barley", "rye", "oat", "spelt", "глутен", "пшеница", "ечемик", "ръж", "овес"] },
  // Soy
  { name: "Соя", patterns: ["soy", "soya", "soybean", "соя", "соев"] },
  // Fish
  { name: "Риба", patterns: ["fish", "cod", "salmon", "tuna", "anchov", "риба", "треска", "сьомга", "тон", "аншоа"] },
  // Shellfish
  { name: "Ракообразни", patterns: ["shellfish", "shrimp", "prawn", "crab", "lobster", "mussel", "oyster", "скариди", "раци", "омар", "миди", "стриди"] },
  // Sesame
  { name: "Сусам", patterns: ["sesame", "сусам"] },
  // Celery
  { name: "Целина", patterns: ["celery", "целина", "celeriac"] },
  // Mustard
  { name: "Горчица", patterns: ["mustard", "горчица"] },
  // Sulphites
  { name: "Сулфити", patterns: ["sulphite", "sulfite", "sulphur", "sulfur", "so2", "сулфит", "сяра"] },
  // Lupin
  { name: "Лупина", patterns: ["lupin", "lupine", "лупина"] },
  // Molluscs
  { name: "Мекотели", patterns: ["mollusc", "mollusk", "squid", "octopus", "snail", "калмар", "октопод", "охлюв"] },
];

interface AllergenHighlighterProps {
  ingredients: string;
}

interface HighlightedSegment {
  text: string;
  isAllergen: boolean;
  allergenName?: string;
}

export function AllergenHighlighter({ ingredients }: AllergenHighlighterProps) {
  const detectedAllergens = new Set<string>();
  
  // Find all allergens in the text
  const lowerIngredients = ingredients.toLowerCase();
  
  ALLERGENS.forEach(allergen => {
    allergen.patterns.forEach(pattern => {
      if (lowerIngredients.includes(pattern.toLowerCase())) {
        detectedAllergens.add(allergen.name);
      }
    });
  });

  // Create highlighted text with allergen markers
  const highlightText = (text: string): HighlightedSegment[] => {
    const segments: HighlightedSegment[] = [];
    let remainingText = text;
    let lastIndex = 0;

    // Find all matches and their positions
    const matches: { start: number; end: number; allergenName: string }[] = [];
    
    ALLERGENS.forEach(allergen => {
      allergen.patterns.forEach(pattern => {
        const regex = new RegExp(`\\b${pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\w*`, 'gi');
        let match;
        while ((match = regex.exec(text)) !== null) {
          matches.push({
            start: match.index,
            end: match.index + match[0].length,
            allergenName: allergen.name
          });
        }
      });
    });

    // Sort by position and merge overlapping
    matches.sort((a, b) => a.start - b.start);
    
    const mergedMatches: typeof matches = [];
    matches.forEach(match => {
      const last = mergedMatches[mergedMatches.length - 1];
      if (last && match.start <= last.end) {
        last.end = Math.max(last.end, match.end);
      } else {
        mergedMatches.push({ ...match });
      }
    });

    // Build segments
    mergedMatches.forEach(match => {
      if (match.start > lastIndex) {
        segments.push({ text: text.slice(lastIndex, match.start), isAllergen: false });
      }
      segments.push({ 
        text: text.slice(match.start, match.end), 
        isAllergen: true,
        allergenName: match.allergenName
      });
      lastIndex = match.end;
    });

    if (lastIndex < text.length) {
      segments.push({ text: text.slice(lastIndex), isAllergen: false });
    }

    return segments.length > 0 ? segments : [{ text, isAllergen: false }];
  };

  const segments = highlightText(ingredients);
  const allergenList = Array.from(detectedAllergens);

  return (
    <div className="space-y-3">
      {allergenList.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 p-3 bg-destructive/10 rounded-lg border border-destructive/20">
          <AlertTriangle className="w-4 h-4 text-destructive shrink-0" />
          <span className="text-sm font-medium text-destructive">Алергени:</span>
          {allergenList.map(allergen => (
            <Badge key={allergen} variant="destructive" className="text-xs">
              {allergen}
            </Badge>
          ))}
        </div>
      )}
      
      <p className="text-sm leading-relaxed text-muted-foreground">
        {segments.map((segment, index) => (
          segment.isAllergen ? (
            <span 
              key={index} 
              className="bg-destructive/20 text-destructive font-medium px-0.5 rounded"
              title={`Алерген: ${segment.allergenName}`}
            >
              {segment.text}
            </span>
          ) : (
            <span key={index}>{segment.text}</span>
          )
        ))}
      </p>
    </div>
  );
}

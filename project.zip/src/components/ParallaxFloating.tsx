import { useEffect, useRef } from "react";
import { motion, useMotionValue, useScroll, useTransform, useSpring } from "framer-motion";

/**
 * Floating parallax layer for the hero.
 * Reacts to both mouse movement (subtle depth) and page scroll (vertical drift).
 * Pure presentation — drop inside a `relative` section.
 */

type FloatItem = {
  emoji: string;
  size: number; // px
  // position in % of container
  x: number;
  y: number;
  depth: number; // 1 = far (slow), 4 = close (fast)
  rotate?: number;
  blur?: number;
  hue?: string; // glow color
};

const ITEMS: FloatItem[] = [
  { emoji: "🥑", size: 88, x: 8,  y: 18, depth: 4, rotate: -12, hue: "160 70% 55%" },
  { emoji: "🍋", size: 64, x: 86, y: 22, depth: 3, rotate: 14,  hue: "48 95% 60%" },
  { emoji: "🥦", size: 72, x: 14, y: 78, depth: 3, rotate: 8,   hue: "140 60% 50%" },
  { emoji: "🍓", size: 56, x: 80, y: 70, depth: 4, rotate: -8,  hue: "350 80% 60%" },
  { emoji: "🫐", size: 44, x: 50, y: 12, depth: 2, rotate: 0,   hue: "220 70% 60%" },
  { emoji: "🥕", size: 60, x: 92, y: 50, depth: 2, rotate: 22,  hue: "24 90% 58%" },
  { emoji: "🍃", size: 52, x: 4,  y: 50, depth: 1, rotate: -20, blur: 1, hue: "150 65% 50%" },
  { emoji: "✨", size: 28, x: 30, y: 30, depth: 2, hue: "180 80% 70%" },
  { emoji: "✨", size: 22, x: 70, y: 40, depth: 1, hue: "180 80% 70%" },
  { emoji: "💧", size: 36, x: 62, y: 84, depth: 3, hue: "200 85% 60%" },
];

export function ParallaxFloating({ scrollTarget }: { scrollTarget: React.RefObject<HTMLElement> }) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const smx = useSpring(mx, { stiffness: 80, damping: 18, mass: 0.6 });
  const smy = useSpring(my, { stiffness: 80, damping: 18, mass: 0.6 });

  const { scrollYProgress } = useScroll({ target: scrollTarget, offset: ["start start", "end start"] });

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      const el = wrapRef.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const nx = (e.clientX - r.left) / r.width - 0.5;  // -0.5..0.5
      const ny = (e.clientY - r.top) / r.height - 0.5;
      mx.set(nx);
      my.set(ny);
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, [mx, my]);

  return (
    <div ref={wrapRef} className="pointer-events-none absolute inset-0 z-[5] overflow-hidden" aria-hidden>
      {ITEMS.map((it, i) => (
        <FloatNode key={i} item={it} smx={smx} smy={smy} scrollYProgress={scrollYProgress} index={i} />
      ))}
    </div>
  );
}

function FloatNode({
  item, smx, smy, scrollYProgress, index,
}: {
  item: FloatItem;
  smx: any; smy: any;
  scrollYProgress: any;
  index: number;
}) {
  // mouse parallax strength scales with depth
  const strength = item.depth * 24; // px
  const tx = useTransform(smx, (v: number) => v * strength);
  const ty = useTransform(smy, (v: number) => v * strength);
  // scroll parallax — closer items drift more
  const sy = useTransform(scrollYProgress, [0, 1], [0, item.depth * 80]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <motion.div
      style={{
        left: `${item.x}%`,
        top: `${item.y}%`,
        x: tx,
        y: useTransform([ty, sy], (latest: number[]) => latest[0] + latest[1]),
        opacity,
        filter: item.blur ? `blur(${item.blur}px)` : undefined,
      }}
      initial={{ opacity: 0, scale: 0.6 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.1 + index * 0.06, duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
      className="absolute -translate-x-1/2 -translate-y-1/2 select-none will-change-transform"
    >
      <motion.div
        animate={{ y: [0, -10, 0], rotate: [item.rotate ?? 0, (item.rotate ?? 0) + 4, item.rotate ?? 0] }}
        transition={{ duration: 6 + (index % 4), repeat: Infinity, ease: "easeInOut", delay: index * 0.2 }}
        style={{
          fontSize: item.size,
          filter: `drop-shadow(0 12px 24px hsl(${item.hue ?? "160 60% 40%"} / 0.45))`,
          textShadow: `0 0 40px hsl(${item.hue ?? "160 60% 40%"} / 0.35)`,
        }}
        className="leading-none"
      >
        {item.emoji}
      </motion.div>
    </motion.div>
  );
}
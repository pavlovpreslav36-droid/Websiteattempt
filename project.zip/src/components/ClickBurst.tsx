import { useEffect } from "react";

const COLORS = ["#D6361C", "#F5B82E", "#FF6A1A", "#FFE9C9", "#6FA83F"];

/** Every tap or click throws a few small confetti dots. Off for people who asked for less motion. */
export const ClickBurst = () => {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const onDown = (e: PointerEvent) => {
      const count = 8;
      for (let i = 0; i < count; i++) {
        const el = document.createElement("span");
        el.className = "burst";
        el.style.left = `${e.clientX}px`;
        el.style.top = `${e.clientY}px`;
        el.style.background = COLORS[i % COLORS.length];
        document.body.appendChild(el);

        const angle = (Math.PI * 2 * i) / count + Math.random() * 0.6;
        const dist = 30 + Math.random() * 34;
        const dx = Math.cos(angle) * dist;
        const dy = Math.sin(angle) * dist;

        const anim = el.animate(
          [
            { transform: "translate(-50%, -50%) scale(1)", opacity: 1 },
            { transform: `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px)) scale(0.2)`, opacity: 0 },
          ],
          { duration: 600 + Math.random() * 250, easing: "cubic-bezier(0.2, 0.7, 0.3, 1)" },
        );
        anim.onfinish = () => el.remove();
      }
    };

    window.addEventListener("pointerdown", onDown, { passive: true });
    return () => window.removeEventListener("pointerdown", onDown);
  }, []);

  return null;
};

export default ClickBurst;

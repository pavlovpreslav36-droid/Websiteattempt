import { Link } from "react-router-dom";
import { Clock, Flame, ScanBarcode, Apple, Candy, Coffee } from "lucide-react";

// Real dishes and values from the recipe library
const dishes = [
  { name: "Шопска салата с пиле", note: "Хрупкави зеленчуци и протеин", image: "/images/food/shopska-salata.jpg", kcal: 680, protein: 48, minutes: 35 },
  { name: "Таратор с ядки и яйца", note: "Свежо, без готвене", image: "/images/food/tarator.jpg", kcal: 620, protein: 32, minutes: 75 },
  { name: "Пилешка супа с фиде", note: "Топла и засищаща", image: "/images/food/pileshka-supa.jpg", kcal: 580, protein: 48, minutes: 100 },
  { name: "Печена риба с картофи", note: "Много протеин", image: "/images/food/pechena-riba.jpg", kcal: 680, protein: 58, minutes: 45 },
];

const habits = [
  {
    icon: Apple,
    title: "Хрупкаво вместо цигара",
    text: "Морковени пръчици, ябълка или шепа ядки заемат ръцете и устата в моментите, в които обикновено пушиш.",
  },
  {
    icon: Candy,
    title: "Следи за сладкото",
    text: "След отказване апетитът за сладко често расте. Плод или кисело мляко са по-добър избор от сладкиш.",
  },
  {
    icon: Coffee,
    title: "Сменя навиците",
    text: "Кафето и алкохолът често се свързват с цигарата. Първите седмици пробвай вода или билков чай на тези места.",
  },
];

export const QuitFoodIdeas = () => {
  return (
    <div>
      <ul className="no-scrollbar -mx-5 md:mx-0 px-5 md:px-0 flex md:grid md:grid-cols-4 gap-4 overflow-x-auto snap-x pb-2">
        {dishes.map((d) => (
          <li key={d.name} className="snap-start shrink-0 w-[220px] md:w-auto">
            <Link to="/recipes" className="group block">
              <div className="aspect-[4/5] overflow-hidden rounded-3xl bg-muted">
                <img src={d.image} alt={d.name} loading="lazy" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
              </div>
              <h3 className="mt-3 text-base font-semibold text-foreground leading-snug group-hover:text-primary transition-colors">{d.name}</h3>
              <p className="text-sm text-muted-foreground">{d.note}</p>
              <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Flame className="w-3.5 h-3.5 text-tomato" aria-hidden="true" />{d.kcal} kcal</span>
                <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" aria-hidden="true" />{d.minutes} мин</span>
                <span className="font-medium text-foreground">{d.protein} г протеин</span>
              </p>
            </Link>
          </li>
        ))}
      </ul>

      <div className="mt-8 grid md:grid-cols-3 gap-4">
        {habits.map((h) => (
          <div key={h.title} className="rounded-3xl bg-card border border-border p-5">
            <span className="grid place-items-center w-11 h-11 rounded-xl bg-primary/10 text-primary mb-3">
              <h.icon className="w-5 h-5" aria-hidden="true" />
            </span>
            <h3 className="font-semibold text-foreground">{h.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{h.text}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 grid sm:grid-cols-2 gap-4">
        <Link to="/quit-kitchen" className="rounded-3xl bg-wine text-cream p-5 md:p-6 transition-transform hover:-translate-y-0.5">
          <span className="block font-bold text-lg leading-tight">Кухня за отказване</span>
          <span className="block text-sm text-cream/80 mt-1">Седемдневен план с рецепти и напитки.</span>
        </Link>
        <Link to="/drinks" className="rounded-3xl bg-wine-2 text-cream p-5 md:p-6 transition-transform hover:-translate-y-0.5">
          <span className="block font-bold text-lg leading-tight">Напитки и брояч за водата</span>
          <span className="block text-sm text-cream/80 mt-1">Овкусени води, чайове и смутита.</span>
        </Link>
      </div>

      <Link
        to="/product-scanner"
        className="mt-4 flex items-center gap-4 rounded-3xl bg-primary text-primary-foreground p-5 md:p-6 transition-transform hover:-translate-y-0.5"
      >
        <span className="grid place-items-center w-12 h-12 rounded-2xl bg-white/15 shrink-0">
          <ScanBarcode className="w-6 h-6" aria-hidden="true" />
        </span>
        <span>
          <span className="block font-bold text-lg leading-tight">Провери продукт преди да го купиш</span>
          <span className="block text-sm text-primary-foreground/85 mt-0.5">Скенерът показва състава и хранителните стойности, за да избираш по-спокойно.</span>
        </span>
      </Link>
    </div>
  );
};

export default QuitFoodIdeas;

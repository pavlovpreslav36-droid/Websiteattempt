import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, Scale } from "lucide-react";
import { CatalogProduct } from "./ProductCatalog";

interface ProductComparisonProps {
  products: CatalogProduct[];
  onRemove: (id: string) => void;
}

const NutrientBar = ({ label, values, max, unit = "г", colors }: { label: string; values: number[]; max: number; unit?: string; colors: string[] }) => (
  <div className="space-y-1">
    <div className="flex justify-between text-xs text-muted-foreground">
      <span>{label}</span>
      <span>{values.map((v, i) => <span key={i} className={i > 0 ? "ml-2" : ""}>{v}{unit}</span>)}</span>
    </div>
    <div className="flex flex-col gap-1">
      {values.map((value, i) => (
        <div key={i} className="h-3 bg-muted rounded-full overflow-hidden">
          <motion.div
            className={`h-full rounded-full ${colors[i]}`}
            initial={{ width: 0 }}
            animate={{ width: `${Math.min((value / max) * 100, 100)}%` }}
            transition={{ duration: 0.6, delay: i * 0.1 }}
          />
        </div>
      ))}
    </div>
  </div>
);

export const ProductComparison = ({ products, onRemove }: ProductComparisonProps) => {
  if (products.length === 0) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <Scale className="w-16 h-16 mx-auto mb-4 opacity-30" />
        <h3 className="text-lg font-semibold mb-2">Няма избрани продукти</h3>
        <p className="text-sm">Добавете продукти от каталога за сравнение</p>
      </div>
    );
  }

  const barColors = ["bg-primary", "bg-orange-500", "bg-emerald-500"];

  const nutrients = [
    { label: "Калории", key: "calories" as const, max: 600, unit: "kcal" },
    { label: "Протеин", key: "protein" as const, max: 35 },
    { label: "Въглехидрати", key: "carbs" as const, max: 80 },
    { label: "Мазнини", key: "fats" as const, max: 45 },
    { label: "Захар", key: "sugars" as const, max: 55 },
    { label: "Фибри", key: "fiber" as const, max: 12 },
  ];

  return (
    <div className="space-y-6">
      {/* Product cards */}
      <div className="flex flex-wrap gap-3">
        {products.map((product, i) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <Card className="p-3 flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full ${barColors[i]}`} />
              <span className="text-2xl">{product.emoji}</span>
              <div>
                <p className="font-semibold text-sm">{product.name}</p>
                <p className="text-xs text-muted-foreground">{product.brand}</p>
              </div>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white ${
                product.healthScore >= 7 ? 'bg-green-500' : product.healthScore >= 4 ? 'bg-yellow-500' : 'bg-red-500'
              }`}>
                {product.healthScore}
              </div>
              <Button size="sm" variant="ghost" onClick={() => onRemove(product.id)} className="h-7 w-7 p-0">
                <X className="w-4 h-4" />
              </Button>
            </Card>
          </motion.div>
        ))}
      </div>

      {products.length >= 2 && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="p-6 space-y-5">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <Scale className="w-5 h-5" />
              Сравнение на 100г
            </h3>
            {nutrients.map(n => (
              <NutrientBar
                key={n.key}
                label={n.label}
                values={products.map(p => p[n.key])}
                max={n.max}
                unit={n.unit || "г"}
                colors={barColors}
              />
            ))}

            {/* Winner summary */}
            <div className="pt-4 border-t space-y-2">
              <h4 className="font-semibold text-sm">📊 Обобщение</h4>
              {(() => {
                const lowest = products.reduce((a, b) => a.calories < b.calories ? a : b);
                const highest = products.reduce((a, b) => a.healthScore > b.healthScore ? a : b);
                const mostProtein = products.reduce((a, b) => a.protein > b.protein ? a : b);
                return (
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="text-xs">🔥 Най-малко калории: {lowest.name}</Badge>
                    <Badge variant="secondary" className="text-xs">⭐ Най-здравословен: {highest.name}</Badge>
                    <Badge variant="secondary" className="text-xs">💪 Най-много протеин: {mostProtein.name}</Badge>
                  </div>
                );
              })()}
            </div>
          </Card>
        </motion.div>
      )}

      {products.length === 1 && (
        <p className="text-center text-sm text-muted-foreground">
          Добавете поне още един продукт за сравнение
        </p>
      )}
    </div>
  );
};

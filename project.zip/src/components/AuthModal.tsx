import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail, Loader2, ArrowLeft, Sparkles, ShieldCheck, Check } from "lucide-react";
import { lovable } from "@/integrations/lovable/index";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface AuthModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const GoogleMark = () => (
  <svg className="w-5 h-5" viewBox="0 0 24 24" aria-hidden="true">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4" />
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
  </svg>
);

const AppleMark = () => (
  <svg className="w-5 h-5 fill-current" viewBox="0 0 384 512" aria-hidden="true">
    <path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z" />
  </svg>
);

export const AuthModal = ({ open, onOpenChange }: AuthModalProps) => {
  const [loading, setLoading] = useState<string | null>(null);
  const [mode, setMode] = useState<"choice" | "magic">("choice");
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const oauth = async (provider: "google" | "apple") => {
    setLoading(provider);
    try {
      const result = await lovable.auth.signInWithOAuth(provider, {
        redirect_uri: window.location.origin,
      });
      if (result.error) throw result.error;
      if (result.redirected) return;
      onOpenChange(false);
    } catch {
      toast({
        title: "Опа, нещо се обърка",
        description: "Опитайте пак или използвайте имейл.",
        variant: "destructive",
      });
    } finally {
      setLoading(null);
    }
  };

  const sendMagicLink = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setLoading("magic");
    const { error } = await supabase.auth.signInWithOtp({
      email: email.trim(),
      options: { emailRedirectTo: window.location.origin },
    });
    setLoading(null);
    if (error) {
      toast({
        title: "Не успяхме да изпратим линка",
        description: "Проверете имейла и опитайте отново.",
        variant: "destructive",
      });
      return;
    }
    setSent(true);
  };

  const close = () => {
    onOpenChange(false);
    setTimeout(() => {
      setMode("choice");
      setSent(false);
      setEmail("");
    }, 250);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => (v ? onOpenChange(true) : close())}>
      <DialogContent className="sm:max-w-[420px] p-0 overflow-hidden rounded-3xl border-border bg-background shadow-[0_40px_120px_-30px_hsl(180_70%_25%/0.6)]">
        {/* Ambient glow */}
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute -top-24 -left-16 w-64 h-64 rounded-full bg-primary/25 blur-3xl" />
          <div className="absolute -bottom-24 -right-10 w-64 h-64 rounded-full bg-accent/25 blur-3xl" />
        </div>

        <div className="px-7 pt-9 pb-7">
          <motion.div
            initial={{ scale: 0.85, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 220, damping: 18 }}
            className="w-14 h-14 rounded-2xl mx-auto flex items-center justify-center bg-gradient-to-br from-primary/25 to-accent/25 ring-1 ring-border"
          >
            <Sparkles className="w-7 h-7 text-primary" />
          </motion.div>

          <AnimatePresence mode="wait">
            {mode === "choice" ? (
              <motion.div
                key="choice"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
              >
                <h2 className="mt-5 text-center text-2xl font-display font-bold text-foreground">
                  Влезте за секунда
                </h2>
                <p className="mt-1.5 text-center text-sm text-muted-foreground">
                  Без пароли. Изберете как да продължите.
                </p>

                <div className="mt-7 space-y-3">
                  <button
                    onClick={() => oauth("google")}
                    disabled={!!loading}
                    className="w-full h-13 py-3.5 rounded-2xl flex items-center justify-center gap-3 text-sm font-semibold bg-white text-neutral-900 border border-border transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-60 shadow-[0_10px_30px_-12px_rgba(0,0,0,0.5)]"
                  >
                    {loading === "google" ? <Loader2 className="w-4 h-4 animate-spin" /> : <GoogleMark />}
                    Продължи с Google
                  </button>

                  <button
                    onClick={() => oauth("apple")}
                    disabled={!!loading}
                    className="w-full py-3.5 rounded-2xl flex items-center justify-center gap-3 text-sm font-semibold bg-foreground text-background transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-60 shadow-[0_10px_30px_-12px_rgba(0,0,0,0.5)]"
                  >
                    {loading === "apple" ? <Loader2 className="w-4 h-4 animate-spin" /> : <AppleMark />}
                    Продължи с Apple
                  </button>

                  <button
                    onClick={() => setMode("magic")}
                    className="w-full py-3.5 rounded-2xl flex items-center justify-center gap-3 text-sm font-semibold bg-muted text-foreground ring-1 ring-border transition-all hover:bg-muted hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <Mail className="w-5 h-5 text-primary" />
                    Вход с магически линк
                  </button>
                </div>

                <button
                  onClick={() => {
                    close();
                    navigate("/auth?tab=signin");
                  }}
                  className="mt-5 w-full text-xs text-muted-foreground hover:text-foreground transition-colors"
                >
                  Предпочитам имейл и парола
                </button>

                <p className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground">
                  <ShieldCheck className="w-3.5 h-3.5 text-primary" />
                  Криптирана връзка. Нищо не се споделя.
                </p>
              </motion.div>
            ) : (
              <motion.div
                key="magic"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
              >
                {sent ? (
                  <div className="text-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 260, damping: 16 }}
                      className="mt-6 mx-auto w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center"
                    >
                      <Check className="w-6 h-6 text-primary" />
                    </motion.div>
                    <h2 className="mt-4 text-xl font-display font-bold">Проверете пощата си</h2>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Изпратихме линк за вход на <span className="text-foreground">{email}</span>.
                      Отворете го от това устройство.
                    </p>
                    <Button variant="ghost" className="mt-6 rounded-xl" onClick={close}>
                      Затвори
                    </Button>
                  </div>
                ) : (
                  <form onSubmit={sendMagicLink}>
                    <h2 className="mt-5 text-center text-2xl font-display font-bold">Магически линк</h2>
                    <p className="mt-1.5 text-center text-sm text-muted-foreground">
                      Пишете имейла си — влизате с едно кликване, без парола.
                    </p>
                    <Input
                      type="email"
                      required
                      autoFocus
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="вашият@имейл.бг"
                      className="mt-6 h-12 rounded-2xl bg-muted border-border text-center"
                    />
                    <Button
                      type="submit"
                      disabled={loading === "magic"}
                      className="mt-3 w-full h-12 rounded-2xl font-semibold"
                    >
                      {loading === "magic" ? <Loader2 className="w-4 h-4 animate-spin" /> : "Изпрати линка"}
                    </Button>
                    <button
                      type="button"
                      onClick={() => setMode("choice")}
                      className="mt-5 w-full flex items-center justify-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      Назад
                    </button>
                  </form>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AuthModal;

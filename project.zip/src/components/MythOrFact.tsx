import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, X, RotateCcw, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Statement {
  text: string;
  isFact: boolean;
  why: string;
}

const statements: Statement[] = [
  {
    text: "Електронните цигари и вейповете са безвредни.",
    isFact: false,
    why: "Съдържат никотин – силно пристрастяващо вещество – и отделят вредни вещества. Не са безопасна алтернатива.",
  },
  {
    text: "Никотиновите пакетчета не вредят, защото няма дим.",
    isFact: false,
    why: "Съдържат никотин и водят до зависимост. Липсата на дим не прави продукта безопасен.",
  },
  {
    text: "Пасивното пушене вреди и на хората около пушача.",
    isFact: true,
    why: "Димът вреди на всички наоколо, особено на деца и бременни жени.",
  },
  {
    text: "Няколко цигари на ден не вредят.",
    isFact: false,
    why: "Дори малко цигари повишават риска за сърцето и белите дробове. Безопасно ниво няма.",
  },
  {
    text: "Пулсът и въглеродният оксид в кръвта започват да се подобряват още в първите часове след последната цигара.",
    isFact: true,
    why: "Възстановяването започва бързо – затова всеки ден без цигара има значение.",
  },
  {
    text: "Желанието за цигара не отминава, ако не го задоволиш.",
    isFact: false,
    why: "Силното желание обикновено отшумява за няколко минути. Вода, дълбоко дишане и движение помагат да го изчакаш.",
  },
];

export const MythOrFact = () => {
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<boolean | null>(null); // true = „Факт“
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  const current = statements[index];
  const answered = picked !== null;
  const correct = answered && picked === current.isFact;

  const choose = (saysFact: boolean) => {
    if (answered) return;
    setPicked(saysFact);
    if (saysFact === current.isFact) setScore((s) => s + 1);
  };

  const next = () => {
    if (index + 1 >= statements.length) {
      setDone(true);
    } else {
      setIndex((i) => i + 1);
      setPicked(null);
    }
  };

  const restart = () => {
    setIndex(0);
    setPicked(null);
    setScore(0);
    setDone(false);
  };

  const progress = ((done ? statements.length : index + (answered ? 1 : 0)) / statements.length) * 100;

  return (
    <div className="rounded-3xl bg-card border border-border shadow-card p-5 md:p-8">
      <div className="flex items-center justify-between gap-4 mb-5">
        <p className="text-sm font-semibold text-muted-foreground">
          {done ? "Готово" : `Твърдение ${index + 1} от ${statements.length}`}
        </p>
        <p className="text-sm font-semibold text-primary">Точки: {score}</p>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden mb-7" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(progress)}>
        <motion.div className="h-full rounded-full bg-primary" animate={{ width: `${progress}%` }} transition={{ type: "spring", stiffness: 140, damping: 22 }} />
      </div>

      <AnimatePresence mode="wait">
        {done ? (
          <motion.div
            key="done"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="text-center py-4"
          >
            <p className="font-brand text-5xl md:text-6xl font-bold text-primary">
              {score}/{statements.length}
            </p>
            <p className="mt-4 text-lg font-semibold text-foreground">
              {score === statements.length
                ? "Отличен резултат! Разпознаваш митовете."
                : score >= statements.length - 2
                ? "Много добре! Прочети обясненията и опитай пак."
                : "Добро начало – митовете са коварни. Опитай отново!"}
            </p>
            <Button onClick={restart} variant="outline" className="mt-6 rounded-full">
              <RotateCcw className="w-4 h-4 mr-2" aria-hidden="true" />
              Играй отново
            </Button>
          </motion.div>
        ) : (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.25 }}
          >
            <h3 className="text-xl md:text-2xl font-bold text-foreground leading-snug min-h-[4.5rem]">{current.text}</h3>

            <div className="mt-6 grid grid-cols-2 gap-3">
              {[
                { label: "Мит", value: false, icon: X },
                { label: "Факт", value: true, icon: Check },
              ].map((opt) => {
                const isPicked = picked === opt.value;
                const isRight = answered && opt.value === current.isFact;
                return (
                  <motion.button
                    key={opt.label}
                    onClick={() => choose(opt.value)}
                    disabled={answered}
                    whileTap={{ scale: answered ? 1 : 0.96 }}
                    animate={isPicked && !isRight ? { x: [0, -8, 8, -6, 6, 0] } : { x: 0 }}
                    transition={{ duration: 0.4 }}
                    className={`h-16 rounded-2xl border-2 text-lg font-bold flex items-center justify-center gap-2 transition-colors ${
                      isRight
                        ? "border-primary bg-primary text-primary-foreground"
                        : isPicked
                        ? "border-destructive bg-destructive/10 text-destructive"
                        : "border-border bg-background text-foreground hover:border-primary/50 disabled:opacity-60"
                    }`}
                  >
                    <opt.icon className="w-5 h-5" aria-hidden="true" />
                    {opt.label}
                  </motion.button>
                );
              })}
            </div>

            <div aria-live="polite" className="min-h-[7.5rem]">
              {answered && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mt-5">
                  <p className={`font-bold ${correct ? "text-primary" : "text-destructive"}`}>
                    {correct ? "Вярно!" : "Не точно."} Това е {current.isFact ? "факт" : "мит"}.
                  </p>
                  <p className="mt-1 text-muted-foreground leading-relaxed">{current.why}</p>
                  <Button onClick={next} className="mt-4 rounded-full">
                    {index + 1 >= statements.length ? "Виж резултата" : "Следващо"}
                    <ArrowRight className="w-4 h-4 ml-2" aria-hidden="true" />
                  </Button>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default MythOrFact;

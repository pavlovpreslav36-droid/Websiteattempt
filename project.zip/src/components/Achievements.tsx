import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Trophy, Star, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

interface Achievement {
  id: string;
  name: string;
  name_bg: string;
  description: string;
  description_bg: string;
  icon: string;
  category: string;
  points: number;
  requirement_type: string;
  requirement_value: number;
}

interface UserAchievement {
  id: string;
  achievement_id: string;
  earned_at: string;
}

interface AchievementsProps {
  onClose: () => void;
}

const categoryColors: Record<string, string> = {
  quiz: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  recipes: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  scanner: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  ai: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  health: 'bg-green-500/20 text-green-400 border-green-500/30',
  facts: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  special: 'bg-pink-500/20 text-pink-400 border-pink-500/30',
};

const categoryNames: Record<string, { en: string; bg: string }> = {
  quiz: { en: 'Quiz', bg: 'Тест' },
  recipes: { en: 'Recipes', bg: 'Рецепти' },
  scanner: { en: 'Scanner', bg: 'Скенер' },
  ai: { en: 'AI', bg: 'AI' },
  health: { en: 'Health', bg: 'Здраве' },
  facts: { en: 'Facts', bg: 'Факти' },
  special: { en: 'Special', bg: 'Специални' },
};

export const Achievements = ({ onClose }: AchievementsProps) => {
  const { language } = useLanguage();
  const { user } = useAuth();
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    loadAchievements();
  }, [user]);

  const loadAchievements = async () => {
    try {
      // Load all achievements
      const { data: allAchievements, error: achievementsError } = await supabase
        .from('achievements')
        .select('*')
        .order('category', { ascending: true })
        .order('points', { ascending: true });

      if (achievementsError) throw achievementsError;
      setAchievements(allAchievements || []);

      // Load user's earned achievements
      if (user) {
        const { data: earned, error: earnedError } = await supabase
          .from('user_achievements')
          .select('*')
          .eq('user_id', user.id);

        if (earnedError) throw earnedError;
        setUserAchievements(earned || []);
      }
    } catch (error) {
      console.error('Error loading achievements:', error);
      toast.error(language === 'bg' ? 'Грешка при зареждане на постиженията' : 'Error loading achievements');
    } finally {
      setIsLoading(false);
    }
  };

  const isEarned = (achievementId: string) => {
    return userAchievements.some(ua => ua.achievement_id === achievementId);
  };

  const getEarnedDate = (achievementId: string) => {
    const ua = userAchievements.find(ua => ua.achievement_id === achievementId);
    if (ua) {
      return new Date(ua.earned_at).toLocaleDateString(language === 'bg' ? 'bg-BG' : 'en-US');
    }
    return null;
  };

  const totalPoints = userAchievements.reduce((total, ua) => {
    const achievement = achievements.find(a => a.id === ua.achievement_id);
    return total + (achievement?.points || 0);
  }, 0);

  const categories = [...new Set(achievements.map(a => a.category))];

  const filteredAchievements = selectedCategory 
    ? achievements.filter(a => a.category === selectedCategory)
    : achievements;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-3xl h-[80vh]"
        >
          <Card className="h-full flex flex-col bg-card/95 backdrop-blur border-primary/20">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-primary/20">
              <div className="flex items-center gap-3">
                <Trophy className="w-6 h-6 text-yellow-400" />
                <h3 className="text-lg font-semibold bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
                  {language === 'bg' ? 'Постижения' : 'Achievements'}
                </h3>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                  <span className="font-bold text-yellow-400">{totalPoints}</span>
                  <span className="text-muted-foreground text-sm">
                    {language === 'bg' ? 'точки' : 'points'}
                  </span>
                </div>
                <Badge variant="outline" className="border-primary/30">
                  {userAchievements.length}/{achievements.length}
                </Badge>
                <Button variant="ghost" size="icon" onClick={onClose}>
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {/* Category Filter */}
            <div className="p-4 border-b border-primary/10">
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={selectedCategory === null ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(null)}
                >
                  {language === 'bg' ? 'Всички' : 'All'}
                </Button>
                {categories.map(cat => (
                  <Button
                    key={cat}
                    variant={selectedCategory === cat ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(cat)}
                    className={selectedCategory !== cat ? categoryColors[cat] : ''}
                  >
                    {language === 'bg' ? categoryNames[cat]?.bg : categoryNames[cat]?.en}
                  </Button>
                ))}
              </div>
            </div>

            {/* Achievements Grid */}
            <ScrollArea className="flex-1 p-4">
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredAchievements.map((achievement, index) => {
                    const earned = isEarned(achievement.id);
                    const earnedDate = getEarnedDate(achievement.id);
                    
                    return (
                      <motion.div
                        key={achievement.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <Card 
                          className={`p-4 transition-all duration-300 ${
                            earned 
                              ? 'bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/30 shadow-lg shadow-primary/10' 
                              : 'bg-card/50 border-muted/30 opacity-60'
                          }`}
                        >
                          <div className="flex items-start gap-4">
                            <div className={`text-4xl ${!earned && 'grayscale opacity-50'}`}>
                              {earned ? achievement.icon : <Lock className="w-10 h-10 text-muted-foreground" />}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between gap-2">
                                <h4 className={`font-semibold ${earned ? 'text-foreground' : 'text-muted-foreground'}`}>
                                  {language === 'bg' ? achievement.name_bg : achievement.name}
                                </h4>
                                <div className="flex items-center gap-1">
                                  <Star className={`w-4 h-4 ${earned ? 'text-yellow-400 fill-yellow-400' : 'text-muted-foreground'}`} />
                                  <span className={`text-sm font-medium ${earned ? 'text-yellow-400' : 'text-muted-foreground'}`}>
                                    {achievement.points}
                                  </span>
                                </div>
                              </div>
                              <p className={`text-sm mt-1 ${earned ? 'text-muted-foreground' : 'text-muted-foreground/60'}`}>
                                {language === 'bg' ? achievement.description_bg : achievement.description}
                              </p>
                              <div className="flex items-center gap-2 mt-2">
                                <Badge 
                                  variant="outline" 
                                  className={`text-xs ${categoryColors[achievement.category]}`}
                                >
                                  {language === 'bg' ? categoryNames[achievement.category]?.bg : categoryNames[achievement.category]?.en}
                                </Badge>
                                {earned && earnedDate && (
                                  <span className="text-xs text-muted-foreground">
                                    {language === 'bg' ? 'Спечелено:' : 'Earned:'} {earnedDate}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </Card>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </ScrollArea>

            {/* Footer */}
            {!user && (
              <div className="p-4 border-t border-primary/20 bg-secondary/10">
                <p className="text-sm text-center text-muted-foreground">
                  {language === 'bg' 
                    ? '🔒 Влезте в профила си, за да запазите постиженията си!' 
                    : '🔒 Log in to save your achievements!'}
                </p>
              </div>
            )}
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

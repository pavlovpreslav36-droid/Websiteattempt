import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AIChatBot } from "./AIChatBot";
import { useLocation } from "react-router-dom";

export const GlobalAIChatButton = () => {
  const [showChat, setShowChat] = useState(false);
  const location = useLocation();

  // Hide on quiz page
  if (location.pathname === "/quiz") {
    return null;
  }

  return (
    <>
      <AnimatePresence>
        {!showChat && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed right-4 bottom-[calc(var(--tabbar-h)_+_env(safe-area-inset-bottom,0px)_+_0.75rem)] lg:bottom-6 lg:right-6 z-40"
          >
            <Button
              onClick={() => setShowChat(true)}
              size="lg"
              className="rounded-full w-14 h-14 lg:w-16 lg:h-16 shadow-lg hover:shadow-xl bg-primary text-primary-foreground hover:bg-primary hover:scale-105 transition-transform"
            >
              <MessageCircle className="w-7 h-7" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {showChat && <AIChatBot onClose={() => setShowChat(false)} />}
    </>
  );
};

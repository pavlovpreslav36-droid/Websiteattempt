/** Three little animated scenes: morning, noon and evening. */
const INK = "#3a0d1c";

export const Morning = () => (
  <svg viewBox="0 0 300 200" className="w-full h-auto block" role="img" aria-label="Изгряващо слънце над хълмове">
    <defs>
      <linearGradient id="dm-sky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#FFE9C9" />
        <stop offset="1" stopColor="#FFB878" />
      </linearGradient>
    </defs>
    <rect width="300" height="200" fill="url(#dm-sky)" />
    <g transform="translate(150 116)">
      <g className="spin-slow">
        {Array.from({ length: 12 }).map((_, i) => (
          <line key={i} x1="0" y1="-44" x2="0" y2="-58" transform={`rotate(${i * 30})`} stroke="#FF5A14" strokeWidth="5" strokeLinecap="round" />
        ))}
      </g>
      <circle r="32" fill="#FF5A14" />
      <path d="M-18 -14 Q-10 -24 2 -24" stroke="#fff" strokeOpacity=".5" strokeWidth="5" fill="none" strokeLinecap="round" />
    </g>
    <path d="M0 150 C60 118 120 142 170 130 S270 118 300 140 V200 H0Z" fill="#B8D97A" />
    <path d="M0 172 C70 146 140 178 210 162 S280 152 300 162 V200 H0Z" fill="#6FA83F" />
    <g className="bird" fill="none" stroke={INK} strokeWidth="2.5" strokeLinecap="round">
      <path d="M52 48 q7 -8 14 0 q7 -8 14 0" />
      <path d="M92 66 q5 -6 10 0 q5 -6 10 0" />
    </g>
  </svg>
);

export const Noon = () => (
  <svg viewBox="0 0 300 200" className="w-full h-auto block" role="img" aria-label="Чиния със салата и пара">
    <rect width="300" height="200" fill="#FFF0DD" />
    <ellipse cx="150" cy="150" rx="104" ry="20" fill="#EBCDB4" />
    <g className="plate-wobble">
      <ellipse cx="150" cy="122" rx="100" ry="34" fill="#fff" stroke={INK} strokeWidth="3" />
      <ellipse cx="150" cy="120" rx="68" ry="21" fill="#FFF0DD" stroke="#E5C7AD" strokeWidth="2" />
      <ellipse cx="126" cy="116" rx="17" ry="8" transform="rotate(-18 126 116)" fill="#6FA83F" stroke={INK} strokeWidth="2" />
      <ellipse cx="170" cy="114" rx="17" ry="8" transform="rotate(16 170 114)" fill="#9BCB6B" stroke={INK} strokeWidth="2" />
      <circle cx="146" cy="112" r="10" fill="#D6361C" stroke={INK} strokeWidth="2" />
      <circle cx="166" cy="124" r="9" fill="#D6361C" stroke={INK} strokeWidth="2" />
      <ellipse cx="132" cy="126" rx="10" ry="7" fill="#fff" stroke={INK} strokeWidth="2" />
      <circle cx="132" cy="126" r="3.5" fill="#F5B82E" />
    </g>
    {[118, 150, 182].map((x, i) => (
      <path key={x} className="steam" style={{ animationDelay: `${i * 0.8}s` }} d={`M${x} 92 q-7 -9 0 -18 t0 -18`} fill="none" stroke="#E2A98A" strokeWidth="4" strokeLinecap="round" />
    ))}
    <g stroke={INK} strokeWidth="3" strokeLinecap="round" fill="none">
      <path d="M32 80 V160 M26 80 V100 M38 80 V100 M26 100 Q32 112 38 100" />
      <path d="M268 80 Q282 110 268 130 V160" />
    </g>
  </svg>
);

export const Evening = () => (
  <svg viewBox="0 0 300 200" className="w-full h-auto block" role="img" aria-label="Луна, звезди и кръгове за дишане">
    <defs>
      <linearGradient id="dm-night" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#2A0713" />
        <stop offset="1" stopColor="#63183A" />
      </linearGradient>
      <mask id="dm-moon">
        <rect width="300" height="200" fill="#fff" />
        <circle cx="232" cy="46" r="19" fill="#000" />
      </mask>
    </defs>
    <rect width="300" height="200" fill="url(#dm-night)" />
    <circle cx="220" cy="52" r="23" fill="#FFE9C9" mask="url(#dm-moon)" />
    {[
      [48, 40, 0],
      [92, 76, 0.6],
      [136, 30, 1.2],
      [262, 98, 1.8],
      [32, 112, 2.4],
      [188, 24, 0.9],
    ].map(([x, y, d]) => (
      <path
        key={`${x}-${y}`}
        className="chef-sparkle"
        style={{ animationDelay: `${d}s` }}
        d={`M${x} ${y - 7} L${x + 2} ${y - 2} L${x + 7} ${y} L${x + 2} ${y + 2} L${x} ${y + 7} L${x - 2} ${y + 2} L${x - 7} ${y} L${x - 2} ${y - 2} Z`}
        fill="#FFE9C9"
      />
    ))}
    {[18, 32, 46].map((r, i) => (
      <circle key={r} className="breath" style={{ animationDelay: `${i * 0.5}s` }} cx="150" cy="140" r={r} fill="none" stroke={i === 1 ? "#F5B82E" : "#FF6A3D"} strokeWidth="3" />
    ))}
  </svg>
);

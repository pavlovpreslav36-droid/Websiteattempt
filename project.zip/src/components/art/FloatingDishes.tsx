import { motion, useScroll, useTransform, type MotionValue } from "framer-motion";

export interface FloatingDish {
  src: string;
  alt: string;
  /** Tailwind position + size classes */
  className: string;
  rotate: number;
  /** pixels the dish drifts while the page scrolls */
  depth: number;
  float?: "float-slow" | "float-slower";
}

const Dish = ({ dish, scrollY }: { dish: FloatingDish; scrollY: MotionValue<number> }) => {
  const y = useTransform(scrollY, [0, 900], [0, dish.depth]);
  return (
    <motion.div style={{ y }} className={`absolute ${dish.className}`}>
      <div style={{ rotate: `${dish.rotate}deg` }}>
        <div className={dish.float ?? "float-slow"}>
          <div className="aspect-[4/5] overflow-hidden rounded-[1.4rem] border-[5px] border-card shadow-xl bg-muted">
            <img src={dish.src} alt={dish.alt} loading="eager" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>
    </motion.div>
  );
};

/** Tilted dish photos that hover around the hero and drift as you scroll. */
export const FloatingDishes = ({ dishes }: { dishes: FloatingDish[] }) => {
  const { scrollY } = useScroll();
  return (
    <div className="absolute inset-0 pointer-events-none select-none" aria-hidden="true">
      {dishes.map((d) => (
        <Dish key={d.src} dish={d} scrollY={scrollY} />
      ))}
    </div>
  );
};

export default FloatingDishes;

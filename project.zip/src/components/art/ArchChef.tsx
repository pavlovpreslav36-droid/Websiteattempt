import { ChefBowl } from "@/components/ChefBowl";

/** Burgundy arch with curved lettering, the chef standing inside. */
export const ArchChef = ({ className = "" }: { className?: string }) => (
  <div className={`relative ${className}`}>
    <svg viewBox="0 0 520 340" className="w-full h-auto block" role="img" aria-label="Арка с надпис: готвим, храним, живеем">
      <defs>
        <path id="arch-text-path" d="M 52 310 C 52 130, 160 48, 260 48 C 360 48, 468 130, 468 310" />
      </defs>
      <path d="M8 340 V296 C8 150 126 10 260 10 C394 10 512 150 512 296 V340 Z" fill="hsl(var(--wine-2))" />
      <text
        fill="hsl(var(--flame))"
        style={{ fontFamily: "var(--font-brand)", fontSize: 25, letterSpacing: 5 }}
      >
        <textPath href="#arch-text-path" startOffset="50%" textAnchor="middle">
          ГОТВИМ, ХРАНИМ, ЖИВЕЕМ
        </textPath>
      </text>
      <text
        x="260"
        y="328"
        textAnchor="middle"
        fill="hsl(var(--cream))"
        style={{ fontFamily: "var(--font-sans)", fontSize: 10, letterSpacing: 3.5, fontWeight: 600 }}
      >
        СКРОЛИРАЙ И ОТКРИЙ
      </text>
    </svg>
    <ChefBowl backdrop={false} className="absolute left-1/2 -translate-x-1/2 bottom-[6%] w-[47%]" />
  </div>
);

export default ArchChef;

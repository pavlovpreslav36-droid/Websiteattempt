/** Endless ticker of big serif words, separated by a slowly spinning sun. */
const Sun = () => (
  <svg viewBox="0 0 40 40" className="w-8 h-8 md:w-12 md:h-12 shrink-0 spin-slow text-flame" aria-hidden="true">
    {Array.from({ length: 8 }).map((_, i) => (
      <rect key={i} x="18" y="2" width="4" height="13" rx="2" fill="currentColor" transform={`rotate(${i * 45} 20 20)`} />
    ))}
    <circle cx="20" cy="20" r="6" fill="currentColor" />
  </svg>
);

export const Marquee = ({ items, className = "" }: { items: string[]; className?: string }) => (
  <div className={`overflow-hidden ${className}`} aria-hidden="true">
    <div className="marquee-track flex w-max">
      {[0, 1].map((k) => (
        <ul key={k} className="flex shrink-0 items-center">
          {items.map((word) => (
            <li key={word} className="flex items-center">
              <span className="px-5 md:px-9 font-brand uppercase text-[clamp(2.2rem,7vw,5rem)] leading-none whitespace-nowrap">{word}</span>
              <Sun />
            </li>
          ))}
        </ul>
      ))}
    </div>
  </div>
);

export default Marquee;

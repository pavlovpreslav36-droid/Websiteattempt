/** Flat, ink-outlined produce drawings used as decoration. */
const INK = "#3a0d1c";
const RED = "#D6361C";
const LEAF = "#5E9F3F";
const LEAF_LIGHT = "#9BCB6B";
const HONEY = "#F5B82E";
const CARROT = "#F28C28";

export type ProduceName = "tomato" | "pepper" | "cucumber" | "carrot" | "leaf" | "lemon" | "garlic" | "egg" | "cheese" | "mushroom";

interface Props {
  name: ProduceName;
  size?: number;
  className?: string;
}

export const ProduceIcon = ({ name, size = 48, className = "" }: Props) => {
  const common = { width: size, height: size, viewBox: "0 0 64 64", className, "aria-hidden": true as const, focusable: false as const };
  switch (name) {
    case "tomato":
      return (
        <svg {...common}>
          <circle cx="32" cy="37" r="21" fill={RED} stroke={INK} strokeWidth="3" />
          <path d="M20 29 Q24 23 30 23" stroke="#fff" strokeOpacity=".5" strokeWidth="3" fill="none" strokeLinecap="round" />
          <path d="M32 18 L27 11 L32 14 L37 8 L36 16 L43 15 L37 20 Z" fill={LEAF} stroke={INK} strokeWidth="2.5" strokeLinejoin="round" />
        </svg>
      );
    case "pepper":
      return (
        <svg {...common}>
          <path d="M16 30 C14 46 22 58 32 58 C42 58 50 46 48 30 C45 22 20 22 16 30Z" fill={HONEY} stroke={INK} strokeWidth="3" strokeLinejoin="round" />
          <path d="M30 22 C30 15 34 12 38 10" stroke={INK} strokeWidth="4" strokeLinecap="round" fill="none" />
          <path d="M24 33 Q23 43 27 50" stroke="#fff" strokeOpacity=".5" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "cucumber":
      return (
        <svg {...common}>
          <g transform="rotate(-35 32 32)">
            <rect x="5" y="22" width="54" height="20" rx="10" fill={LEAF} stroke={INK} strokeWidth="3" />
            <path d="M14 28 H44 M18 36 H50" stroke="#C5E8A8" strokeWidth="2.5" strokeLinecap="round" />
          </g>
        </svg>
      );
    case "carrot":
      return (
        <svg {...common}>
          <g transform="rotate(35 32 32)">
            <path d="M26 14 L38 14 L32 58 Z" fill={CARROT} stroke={INK} strokeWidth="3" strokeLinejoin="round" />
            <path d="M28 26 H34 M30 38 H34" stroke={INK} strokeWidth="2" strokeLinecap="round" />
            <path d="M29 14 L26 5 M32 14 L32 4 M35 14 L38 6" stroke={LEAF} strokeWidth="3.5" strokeLinecap="round" />
          </g>
        </svg>
      );
    case "leaf":
      return (
        <svg {...common}>
          <path d="M32 7 C55 18 55 46 32 58 C9 46 9 18 32 7Z" fill={LEAF_LIGHT} stroke={INK} strokeWidth="3" strokeLinejoin="round" />
          <path d="M32 14 V54 M32 26 L42 20 M32 36 L22 30 M32 44 L42 38" stroke={INK} strokeWidth="2" strokeLinecap="round" fill="none" />
        </svg>
      );
    case "lemon":
      return (
        <svg {...common}>
          <ellipse cx="32" cy="34" rx="24" ry="18" fill="#F7E04A" stroke={INK} strokeWidth="3" />
          <path d="M8 34 L3 33 M56 34 L61 35" stroke={INK} strokeWidth="3" strokeLinecap="round" />
          <path d="M18 28 Q22 23 28 22" stroke="#fff" strokeOpacity=".6" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "garlic":
      return (
        <svg {...common}>
          <path d="M32 9 C40 18 52 24 52 38 C52 50 42 58 32 58 C22 58 12 50 12 38 C12 24 24 18 32 9Z" fill="#FFF3E0" stroke={INK} strokeWidth="3" strokeLinejoin="round" />
          <path d="M32 14 V56 M24 22 Q18 40 24 54 M40 22 Q46 40 40 54" stroke={INK} strokeWidth="2" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "egg":
      return (
        <svg {...common}>
          <ellipse cx="32" cy="34" rx="17" ry="23" fill="#FFF8EC" stroke={INK} strokeWidth="3" />
          <path d="M23 26 Q25 19 31 16" stroke="#E8CBA8" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );
    case "cheese":
      return (
        <svg {...common}>
          <path d="M8 24 L32 12 L56 24 V44 L32 56 L8 44Z" fill="#FFF8E7" stroke={INK} strokeWidth="3" strokeLinejoin="round" />
          <path d="M8 24 L32 36 L56 24 M32 36 V56" stroke={INK} strokeWidth="2.5" fill="none" strokeLinejoin="round" />
          <circle cx="20" cy="38" r="3" fill="#F0DDB4" stroke={INK} strokeWidth="1.5" />
          <circle cx="44" cy="40" r="2.5" fill="#F0DDB4" stroke={INK} strokeWidth="1.5" />
        </svg>
      );
    case "mushroom":
      return (
        <svg {...common}>
          <path d="M24 34 H40 V50 Q40 57 32 57 Q24 57 24 50 Z" fill="#FFF3E0" stroke={INK} strokeWidth="3" strokeLinejoin="round" />
          <path d="M8 36 C8 18 20 9 32 9 C44 9 56 18 56 36 Z" fill={RED} stroke={INK} strokeWidth="3" strokeLinejoin="round" />
          <circle cx="22" cy="26" r="4" fill="#fff" />
          <circle cx="38" cy="20" r="3.5" fill="#fff" />
          <circle cx="44" cy="30" r="3" fill="#fff" />
        </svg>
      );
  }
};

export default ProduceIcon;

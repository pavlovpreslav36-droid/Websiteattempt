import { motion } from "framer-motion";

/** A hand-drawn wave that draws itself when it scrolls into view. */
export const Squiggle = ({ className = "" }: { className?: string }) => (
  <svg viewBox="0 0 120 12" preserveAspectRatio="none" className={className} aria-hidden="true">
    <motion.path
      d="M2 7 C 12 1, 22 1, 32 7 S 52 13, 62 7 S 82 1, 92 7 S 112 13, 118 5"
      fill="none"
      stroke="currentColor"
      strokeWidth="3"
      strokeLinecap="round"
      vectorEffect="non-scaling-stroke"
      initial={{ pathLength: 0 }}
      whileInView={{ pathLength: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 1.1, ease: "easeOut" }}
    />
  </svg>
);

export default Squiggle;

import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { LogOut, User as UserIcon, Settings, Trophy, LayoutGrid, Sparkles } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { AuthModal } from "@/components/AuthModal";

interface ProfileSummary {
  gamertag: string | null;
  full_name: string | null;
  avatar_url: string | null;
  xp: number;
}

const levelFromXp = (xp: number) => Math.max(1, Math.floor(xp / 250) + 1);
const levelProgress = (xp: number) => (xp % 250) / 250;

export const ProfileMenu = () => {
  const { user, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [profile, setProfile] = useState<ProfileSummary | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) {
      setProfile(null);
      return;
    }
    supabase
      .from("profiles")
      .select("gamertag, full_name, avatar_url, xp")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data }) => data && setProfile(data as ProfileSummary));
  }, [user]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const name =
    profile?.gamertag ||
    profile?.full_name ||
    user?.user_metadata?.full_name ||
    user?.email?.split("@")[0] ||
    "Гост";
  const initial = name.charAt(0).toUpperCase();
  const xp = profile?.xp ?? 0;
  const level = levelFromXp(xp);
  const progress = levelProgress(xp);

  if (!user) {
    return (
      <>
        <button
          onClick={() => setAuthOpen(true)}
          className="group relative flex items-center gap-2 pl-2 pr-4 py-1.5 rounded-full bg-muted ring-1 ring-border backdrop-blur-xl transition-all hover:bg-muted hover:scale-[1.03] active:scale-[0.98]"
        >
          <span className="w-7 h-7 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <UserIcon className="w-4 h-4 text-background" />
          </span>
          <span className="text-sm font-medium text-foreground">Вход</span>
        </button>
        <AuthModal open={authOpen} onOpenChange={setAuthOpen} />
      </>
    );
  }

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="relative w-10 h-10 rounded-full transition-transform hover:scale-105 active:scale-95"
        aria-label="Профил"
      >
        {/* Level ring */}
        <svg className="absolute inset-0 -rotate-90" viewBox="0 0 40 40">
          <circle cx="20" cy="20" r="18" fill="none" stroke="hsl(var(--muted))" strokeWidth="2.5" opacity="0.35" />
          <motion.circle
            cx="20"
            cy="20"
            r="18"
            fill="none"
            stroke="hsl(var(--primary))"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeDasharray={2 * Math.PI * 18}
            initial={{ strokeDashoffset: 2 * Math.PI * 18 }}
            animate={{ strokeDashoffset: 2 * Math.PI * 18 * (1 - progress) }}
            transition={{ duration: 0.9, ease: "easeOut" }}
          />
        </svg>
        <span className="absolute inset-[4px] rounded-full bg-gradient-to-br from-primary/80 to-accent/80 flex items-center justify-center text-background font-bold text-sm overflow-hidden">
          {profile?.avatar_url ? (
            <img src={profile.avatar_url} alt={name} className="w-full h-full object-cover" />
          ) : (
            initial
          )}
        </span>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 6, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 6, scale: 0.96 }}
            transition={{ duration: 0.16 }}
            className="absolute right-0 top-full mt-3 w-72 p-3 rounded-3xl bg-popover ring-1 ring-border shadow-[0_30px_80px_-25px_hsl(180_70%_25%/0.7)] z-50"
          >
            <div className="px-3 pt-2 pb-4">
              <p className="text-base font-display font-bold text-foreground truncate">{name}</p>
              <p className="text-xs text-muted-foreground truncate">{user.email}</p>
              <div className="mt-3 flex items-center gap-2">
                <span className="text-[11px] font-semibold text-primary">Ниво {level}</span>
                <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                  <motion.div
                    className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress * 100}%` }}
                    transition={{ duration: 0.8 }}
                  />
                </div>
                <span className="text-[11px] text-muted-foreground">{xp} XP</span>
              </div>
            </div>

            {[
              { to: "/meal-planner", label: "Моят план", icon: LayoutGrid },
              { to: "/health-dashboard", label: "Здравен дневник", icon: Sparkles },
              { to: "/social", label: "Класация", icon: Trophy },
              { to: "/settings", label: "Настройки", icon: Settings },
            ].map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm text-foreground/85 transition-all hover:bg-muted hover:text-foreground hover:scale-[1.02]"
              >
                <item.icon className="w-4 h-4 text-primary" />
                {item.label}
              </Link>
            ))}

            <button
              onClick={() => {
                setOpen(false);
                signOut();
              }}
              className="mt-1 w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm text-muted-foreground transition-all hover:bg-destructive/15 hover:text-destructive"
            >
              <LogOut className="w-4 h-4" />
              Изход
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ProfileMenu;

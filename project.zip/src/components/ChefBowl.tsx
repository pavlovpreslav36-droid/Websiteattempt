import { useEffect, useRef, useState, type CSSProperties } from "react";
import { AnimatePresence, motion } from "framer-motion";

/**
 * Chef with a spinning bowl.
 * - The bowl's pattern scrolls sideways so it reads as spinning
 * - The chef stirs, blinks, bobs, and his hat wobbles
 * - Ingredients are tossed up and fall back into the bowl
 * - His eyes follow the pointer
 * - Tap the chef: he jumps and shares a short health tip
 * All motion is plain CSS (see "Chef" in index.css) and switches off with prefers-reduced-motion.
 */

const TIPS = [
  "Половин чиния зеленчуци – лесно правило за всеки обяд.",
  "Протеин на закуска помага да си сит по-дълго.",
  "Яж бавно – усещането за ситост идва след около 20 минути.",
  "Разходка след вечеря – малка стъпка, голяма разлика.",
  "Чубрица, лимон и чесън дават вкус без излишна сол.",
  "Носи бутилка вода със себе си през деня.",
];

const INK = "#3a0d1c";
const SKIN = "#F7CBA4";
const TOMATO = "#D6361C";
const LEAF = "#3E9B58";
const LEAF_LIGHT = "#79C77F";
const BOWL = "#B92E16";
const BOWL_RIM = "#E2553A";
const CREAM = "#FFF6E5";
const HONEY = "#F5B82E";
const CARROT = "#F28C28";
const WOOD = "#C58B4A";

interface ChefBowlProps {
  className?: string;
  /** Soft disc, dotted ring and sparkles behind the chef (turn off inside the arch) */
  backdrop?: boolean;
  /** Show the speech bubble and react to taps */
  interactive?: boolean;
}

export const ChefBowl = ({ className = "", interactive = true, backdrop = true }: ChefBowlProps) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [jumping, setJumping] = useState(false);
  const [tipIndex, setTipIndex] = useState<number | null>(null);

  // Eyes follow the pointer (written straight to CSS variables, no re-render)
  useEffect(() => {
    let raf = 0;
    const onMove = (e: PointerEvent) => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const svg = svgRef.current;
        if (!svg) return;
        const r = svg.getBoundingClientRect();
        const cx = r.left + r.width / 2;
        const cy = r.top + r.height * 0.45;
        const dx = Math.max(-1, Math.min(1, (e.clientX - cx) / 400));
        const dy = Math.max(-1, Math.min(1, (e.clientY - cy) / 400));
        svg.style.setProperty("--px", String(dx * 3.2));
        svg.style.setProperty("--py", String(dy * 2.4));
      });
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      window.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  // Greet once, then rotate tips gently
  useEffect(() => {
    if (!interactive) return;
    const first = window.setTimeout(() => setTipIndex(0), 1400);
    return () => window.clearTimeout(first);
  }, [interactive]);

  useEffect(() => {
    if (!interactive || tipIndex === null) return;
    const t = window.setTimeout(() => setTipIndex((i) => (i === null ? 0 : (i + 1) % TIPS.length)), 9000);
    return () => window.clearTimeout(t);
  }, [interactive, tipIndex]);

  const poke = () => {
    if (!interactive) return;
    setJumping(true);
    setTipIndex((i) => (i === null ? 0 : (i + 1) % TIPS.length));
    window.setTimeout(() => setJumping(false), 750);
  };

  const art = (
        <svg ref={svgRef} viewBox="0 0 400 420" className="w-full h-auto overflow-visible" role="img" aria-label="Весел готвач бърка в въртяща се купа със салата">
          <defs>
            <clipPath id="chef-bowl-clip">
              <path d="M88 338 C92 380 148 404 200 404 C252 404 308 380 312 338 Q200 390 88 338 Z" />
            </clipPath>
          </defs>

          {backdrop && (
            <>
            {/* Backdrop */}
            <circle cx="200" cy="215" r="165" style={{ fill: "hsl(var(--primary) / 0.1)" }} />
            <circle className="chef-ring" cx="200" cy="215" r="182" fill="none" strokeWidth="3" strokeLinecap="round" strokeDasharray="1 14" style={{ stroke: "hsl(var(--primary) / 0.35)" }} />

            {/* Sparkles */}
            {[
              { x: 66, y: 150, d: 0 },
              { x: 338, y: 128, d: 0.7 },
              { x: 332, y: 262, d: 1.4 },
              { x: 74, y: 262, d: 2.1 },
            ].map((s) => (
              <path
                key={s.x}
                className="chef-sparkle"
                d={`M${s.x} ${s.y - 10} L${s.x + 3} ${s.y - 3} L${s.x + 10} ${s.y} L${s.x + 3} ${s.y + 3} L${s.x} ${s.y + 10} L${s.x - 3} ${s.y + 3} L${s.x - 10} ${s.y} L${s.x - 3} ${s.y - 3} Z`}
                fill={HONEY}
                style={{ animationDelay: `${s.d}s` }}
              />
            ))}
            </>
          )}

          {/* ───── Chef ───── */}
          <g className={jumping ? "chef-jump" : ""}>
            <g className="chef-bob">
              {/* torso */}
              <path d="M122 345 C122 270 152 238 200 238 C248 238 278 270 278 345 Z" fill="#fff" stroke={INK} strokeWidth="4" strokeLinejoin="round" />
              <circle cx="200" cy="292" r="4.5" fill={INK} />
              <circle cx="200" cy="316" r="4.5" fill={INK} />
              {/* scarf */}
              <path d="M170 234 L230 234 L200 266 Z" fill={HONEY} stroke={INK} strokeWidth="3.5" strokeLinejoin="round" />
              <circle cx="200" cy="238" r="9" fill={HONEY} stroke={INK} strokeWidth="3.5" />

              {/* left arm resting on the bowl */}
              <path d="M138 266 Q110 302 150 328" fill="none" stroke={INK} strokeWidth="32" strokeLinecap="round" />
              <path d="M138 266 Q110 302 150 328" fill="none" stroke="#fff" strokeWidth="25" strokeLinecap="round" />
              <circle cx="152" cy="329" r="13" fill={SKIN} stroke={INK} strokeWidth="3.5" />

              {/* head */}
              <circle cx="154" cy="182" r="8" fill={SKIN} stroke={INK} strokeWidth="3.5" />
              <circle cx="246" cy="182" r="8" fill={SKIN} stroke={INK} strokeWidth="3.5" />
              <circle cx="200" cy="178" r="47" fill={SKIN} stroke={INK} strokeWidth="4" />
              {/* face */}
              <path d="M174 162 Q184 156 194 162" fill="none" stroke={INK} strokeWidth="3.5" strokeLinecap="round" />
              <path d="M206 162 Q216 156 226 162" fill="none" stroke={INK} strokeWidth="3.5" strokeLinecap="round" />
              {[184, 216].map((x) => (
                <g key={x} className="chef-blink">
                  <circle cx={x} cy="177" r="9.5" fill="#fff" stroke={INK} strokeWidth="2.5" />
                  <g className="chef-pupil">
                    <circle cx={x} cy="177" r="5" fill={INK} />
                    <circle cx={x + 1.8} cy="175" r="1.6" fill="#fff" />
                  </g>
                </g>
              ))}
              <circle cx="170" cy="194" r="7" fill={TOMATO} opacity="0.3" />
              <circle cx="230" cy="194" r="7" fill={TOMATO} opacity="0.3" />
              <path d="M184 198 Q200 216 216 198" fill="#fff" stroke={INK} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
              {/* moustache */}
              <path d="M182 194 Q191 188 200 194 Q209 188 218 194 Q209 199 200 196 Q191 199 182 194 Z" fill={INK} />

              {/* hat */}
              <g className="chef-hat">
                {/* outline: fat dark shapes, then white shapes on top */}
                <g fill={INK} stroke={INK} strokeWidth={8} strokeLinejoin="round">
                  <circle cx="166" cy="110" r="27" />
                  <circle cx="200" cy="92" r="33" />
                  <circle cx="234" cy="110" r="27" />
                  <rect x="150" y="118" width="100" height="30" rx="9" />
                </g>
                <g fill="#fff">
                  <circle cx="166" cy="110" r="27" />
                  <circle cx="200" cy="92" r="33" />
                  <circle cx="234" cy="110" r="27" />
                  <rect x="150" y="118" width="100" height="30" rx="9" />
                </g>
                <path d="M158 134 L242 134" stroke={INK} strokeWidth="2.5" strokeLinecap="round" opacity="0.25" />
              </g>

              {/* right arm, stirring */}
              <g className="chef-arm">
                <path d="M262 266 Q294 298 238 324" fill="none" stroke={INK} strokeWidth="32" strokeLinecap="round" />
                <path d="M262 266 Q294 298 238 324" fill="none" stroke="#fff" strokeWidth="25" strokeLinecap="round" />
                <g className="chef-spoon">
                  <path d="M238 324 L212 352" stroke={INK} strokeWidth="11" strokeLinecap="round" />
                  <path d="M238 324 L212 352" stroke={WOOD} strokeWidth="6" strokeLinecap="round" />
                  <ellipse cx="208" cy="357" rx="13" ry="8.5" transform="rotate(-40 208 357)" fill={WOOD} stroke={INK} strokeWidth="3" />
                </g>
                <circle cx="238" cy="325" r="13" fill={SKIN} stroke={INK} strokeWidth="3.5" />
              </g>
            </g>
          </g>

          {/* ───── Bowl ───── */}
          <ellipse cx="200" cy="410" rx="124" ry="9" fill={INK} opacity="0.12" />
          {/* back rim + interior */}
          <ellipse cx="200" cy="338" rx="112" ry="27" fill="#5a1428" stroke={BOWL_RIM} strokeWidth="6" />
          {/* food */}
          <g stroke={INK} strokeWidth="3" strokeLinejoin="round">
            <ellipse cx="148" cy="326" rx="26" ry="12" transform="rotate(-18 148 326)" fill={LEAF} />
            <ellipse cx="252" cy="324" rx="26" ry="12" transform="rotate(16 252 324)" fill={LEAF} />
            <ellipse cx="200" cy="318" rx="30" ry="13" fill={LEAF_LIGHT} />
            <ellipse cx="176" cy="330" rx="22" ry="10" transform="rotate(10 176 330)" fill={LEAF_LIGHT} />
            <circle cx="170" cy="316" r="12" fill={TOMATO} />
            <circle cx="232" cy="314" r="12" fill={TOMATO} />
            <circle cx="206" cy="308" r="10" fill={HONEY} />
            <ellipse cx="136" cy="318" rx="9" ry="6" transform="rotate(-30 136 318)" fill={CARROT} />
            <ellipse cx="264" cy="318" rx="9" ry="6" transform="rotate(30 264 318)" fill={CARROT} />
            <ellipse cx="190" cy="334" rx="11" ry="8" fill="#fff" />
          </g>
          <circle cx="190" cy="334" r="4" fill={HONEY} />

          {/* tossed ingredients */}
          <g transform="translate(150 316)">
            <g className="chef-toss" style={{ "--dx": "-30px", animationDelay: "0s" } as CSSProperties}>
              <circle r="11" fill={TOMATO} stroke={INK} strokeWidth="3" />
              <path d="M-5 -10 Q0 -17 5 -10" fill="none" stroke={LEAF} strokeWidth="3.5" strokeLinecap="round" />
            </g>
          </g>
          <g transform="translate(182 314)">
            <g className="chef-toss" style={{ "--dx": "-12px", animationDelay: "0.7s" } as CSSProperties}>
              <path d="M0 -15 C13 -8 13 9 0 15 C-13 9 -13 -8 0 -15Z" fill={LEAF_LIGHT} stroke={INK} strokeWidth="3" strokeLinejoin="round" />
              <path d="M0 -10 L0 11" stroke={INK} strokeWidth="2" strokeLinecap="round" />
            </g>
          </g>
          <g transform="translate(216 314)">
            <g className="chef-toss" style={{ "--dx": "14px", animationDelay: "1.4s" } as CSSProperties}>
              <path d="M-5 -13 L5 -13 L0 15 Z" fill={CARROT} stroke={INK} strokeWidth="3" strokeLinejoin="round" />
              <path d="M-3 -14 L0 -20 L3 -14" fill="none" stroke={LEAF} strokeWidth="3" strokeLinecap="round" />
            </g>
          </g>
          <g transform="translate(250 316)">
            <g className="chef-toss" style={{ "--dx": "32px", animationDelay: "2.1s" } as CSSProperties}>
              <ellipse rx="10" ry="13" fill="#fff" stroke={INK} strokeWidth="3" />
              <circle r="5" cy="2" fill={HONEY} />
            </g>
          </g>
          <g transform="translate(200 312)">
            <g className="chef-toss" style={{ "--dx": "4px", animationDelay: "2.8s" } as CSSProperties}>
              <ellipse rx="14" ry="9" fill={HONEY} stroke={INK} strokeWidth="3" />
              <path d="M-6 0 L6 0" stroke={INK} strokeWidth="2" strokeLinecap="round" opacity="0.5" />
            </g>
          </g>

          {/* bowl body with spinning pattern */}
          <path d="M88 338 C92 380 148 404 200 404 C252 404 308 380 312 338 Q200 390 88 338 Z" fill={BOWL} />
          <g clipPath="url(#chef-bowl-clip)">
            <g className="chef-spin">
              {Array.from({ length: 9 }).map((_, i) => (
                <g key={i} transform={`translate(${24 + i * 64} 0)`}>
                  <path d="M0 366 L11 378 L0 390 L-11 378 Z" fill={CREAM} />
                  <circle cx="32" cy="384" r="4" fill={HONEY} />
                  <circle cx="32" cy="370" r="2.5" fill={CREAM} opacity="0.7" />
                </g>
              ))}
            </g>
          </g>
          <path d="M88 338 C92 380 148 404 200 404 C252 404 308 380 312 338 Q200 390 88 338 Z" fill="none" stroke={INK} strokeWidth="4" strokeLinejoin="round" />
          <path d="M88 338 Q200 390 312 338" fill="none" stroke={BOWL_RIM} strokeWidth="7" strokeLinecap="round" />
          <path d="M104 356 Q118 384 150 396" fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" opacity="0.28" />
        </svg>
  );

  return (
    <div className={`relative ${className}`}>
      {interactive ? (
        <button type="button" onClick={poke} aria-label="Шеф-готвачът: натисни за съвет" className="block w-full cursor-pointer focus-visible:outline-offset-4">
          {art}
        </button>
      ) : (
        <div aria-hidden="true" className="block w-full">{art}</div>
      )}

      {/* speech bubble */}
      {interactive && (
        <div className="absolute -top-2 right-0 sm:right-[-4%] max-w-[210px] pointer-events-none" role="status" aria-live="polite">
          <AnimatePresence mode="wait">
            {tipIndex !== null && (
              <motion.p
                key={tipIndex}
                initial={{ opacity: 0, scale: 0.85, y: 8 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ type: "spring", stiffness: 380, damping: 24 }}
                style={{ transformOrigin: "bottom left" }}
                className="relative rounded-2xl rounded-bl-md bg-card border border-border shadow-md px-3.5 py-2.5 text-[13px] leading-snug text-foreground"
              >
                {TIPS[tipIndex]}
              </motion.p>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};

export default ChefBowl;

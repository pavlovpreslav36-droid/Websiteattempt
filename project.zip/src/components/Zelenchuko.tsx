import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Sparkles } from "lucide-react";

/**
 * "Зеленчуко" — interactive mascot.
 * Friendly avocado-shaped character with state-driven facial expressions,
 * eyes that follow the mouse, idle blink/bob, and a chat-style Bulgarian Q&A
 * that switches emotions based on keywords.
 */

type Emotion =
  | "idle" | "happy" | "excited" | "thinking" | "love"
  | "wink" | "shy" | "sad" | "wow" | "cool";

type Reply = { emotion: Emotion; text: string };

const KEYWORD_RULES: { match: RegExp; reply: () => Reply }[] = [
  {
    match: /(име|казваш|кой си|какво си)/i,
    reply: () => ({ emotion: "happy", text: "Аз съм Зеленчуко! Твоят приятел от градината 🥑" }),
  },
  {
    match: /(здрав|добре ли си|как си)/i,
    reply: () => ({ emotion: "excited", text: "Свеж съм като току-що откъсната салата! А ти?" }),
  },
  {
    match: /(обич|любим|сърц)/i,
    reply: () => ({ emotion: "love", text: "Обичам броколи, авокадо и теб най-много! 💚" }),
  },
  {
    match: /(тъжен|тъга|зле|болен|умор)/i,
    reply: () => ({ emotion: "sad", text: "Поеми дъх дълбоко… после хапни нещо зелено. Помага, обещавам." }),
  },
  {
    match: /(глад|храна|ям|рецеп)/i,
    reply: () => ({ emotion: "happy", text: "Рецептите ме изпълват с радост! Пробвай боул с киноа и авокадо 🥗" }),
  },
  {
    match: /(спорт|тренир|фитнес|упражн)/i,
    reply: () => ({ emotion: "cool", text: "Десет клекa сега, после ела пак. Чакам те 💪" }),
  },
  {
    match: /(вода|пия|жажд)/i,
    reply: () => ({ emotion: "wow", text: "Пий водичка! Поне 8 чаши на ден — клетките ти ще ти благодарят." }),
  },
  {
    match: /(сън|спя|спи|умор)/i,
    reply: () => ({ emotion: "thinking", text: "Сънят е суперхрана. Заспи преди полунощ — ще се събудиш като нов човек." }),
  },
  {
    match: /(шега|майтап|смях)/i,
    reply: () => ({ emotion: "wink", text: "Защо домата се изчерви? Защото видя салатата да се съблича! 😉" }),
  },
  {
    match: /(красив|сладък|готин)/i,
    reply: () => ({ emotion: "shy", text: "Спри, ще се изчервя… макар че съм зелен 🙈" }),
  },
];

const QUICK_PROMPTS = [
  "Как се казваш?",
  "Как си днес?",
  "Кажи ми шега",
  "Какво да ям?",
];

function answer(q: string): Reply {
  for (const rule of KEYWORD_RULES) if (rule.match.test(q)) return rule.reply();
  return { emotion: "thinking", text: "Хмм… не знам отговора, но мога да ти направя компания 🌱" };
}

export function Zelenchuko() {
  const [emotion, setEmotion] = useState<Emotion>("idle");
  const [message, setMessage] = useState<string>("Здравей! Аз съм Зеленчуко. Питай ме нещо!");
  const [input, setInput] = useState("");
  const [blink, setBlink] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [eye, setEye] = useState({ x: 0, y: 0 });

  // Blink loop
  useEffect(() => {
    const t = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 140);
    }, 3200 + Math.random() * 1500);
    return () => clearInterval(t);
  }, []);

  // Eyes follow mouse
  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      const el = containerRef.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const dx = (e.clientX - cx) / r.width;
      const dy = (e.clientY - cy) / r.height;
      const max = 2.2;
      setEye({
        x: Math.max(-max, Math.min(max, dx * 6)),
        y: Math.max(-max, Math.min(max, dy * 6)),
      });
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  function ask(q: string) {
    const trimmed = q.trim();
    if (!trimmed) return;
    setEmotion("thinking");
    setMessage("…мисля 🌿");
    setTimeout(() => {
      const r = answer(trimmed);
      setEmotion(r.emotion);
      setMessage(r.text);
    }, 650);
    setInput("");
  }

  // Subtle bob
  const bob = useMemo(
    () => ({ y: [0, -6, 0], rotate: [0, -1.5, 0, 1.5, 0] }),
    [],
  );

  return (
    <section className="relative py-16 md:py-24 px-5">
      <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-10 md:gap-14 items-center">
        {/* MASCOT */}
        <div ref={containerRef} className="relative flex items-center justify-center min-h-[360px]">
          {/* Aura */}
          <motion.div
            aria-hidden
            className="absolute inset-0 -m-10 rounded-full blur-3xl"
            style={{ background: "radial-gradient(circle, hsl(152 70% 45% / 0.35), transparent 65%)" }}
            animate={{ scale: [1, 1.08, 1], opacity: [0.7, 1, 0.7] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          />

          <motion.div
            animate={bob}
            transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut" }}
            className="relative will-change-transform"
          >
            <Mascot emotion={emotion} blink={blink} eye={eye} />
          </motion.div>

          {/* Speech bubble */}
          <AnimatePresence mode="wait">
            <motion.div
              key={message}
              initial={{ opacity: 0, y: 10, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.96 }}
              transition={{ duration: 0.25 }}
              className="absolute -top-2 right-0 md:-right-6 max-w-[220px] rounded-2xl bg-muted backdrop-blur-xl border border-border px-4 py-3 text-sm text-foreground shadow-[0_12px_40px_-12px_hsl(160_70%_30%/0.5)]"
            >
              {message}
              <span className="absolute -bottom-2 left-6 w-3 h-3 rotate-45 bg-muted border-r border-b border-border backdrop-blur-xl" />
            </motion.div>
          </AnimatePresence>
        </div>

        {/* CHAT PANEL */}
        <div className="space-y-5">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-medium">
              <Sparkles className="w-3.5 h-3.5" /> Запознай се с Зеленчуко
            </div>
            <h2 className="text-3xl md:text-5xl font-display font-bold mt-4 text-foreground leading-[1.05]">
              Поговори с <span className="gradient-text">Зеленчуко</span>
            </h2>
            <p className="text-muted-foreground mt-3 leading-relaxed">
              Твоят зелен приятел има изражение за всеки въпрос. Питай го как се казва, как е днес или му поискай шега.
            </p>
          </div>

          <form
            onSubmit={(e) => { e.preventDefault(); ask(input); }}
            className="flex items-center gap-2 rounded-2xl bg-muted backdrop-blur-xl border border-border p-1.5 shadow-[0_8px_32px_-12px_hsl(180_60%_30%/0.4)]"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Питай Зеленчуко…"
              className="flex-1 bg-transparent px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 outline-none"
            />
            <button
              type="submit"
              className="h-10 w-10 grid place-items-center rounded-xl bg-primary text-primary-foreground hover:scale-105 active:scale-95 transition-transform shadow-md"
              aria-label="Изпрати"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          <div className="flex flex-wrap gap-2">
            {QUICK_PROMPTS.map((p) => (
              <button
                key={p}
                onClick={() => ask(p)}
                className="px-3.5 py-2 text-xs md:text-sm rounded-full bg-muted backdrop-blur-md border border-border text-foreground/85 hover:bg-secondary hover:scale-[1.04] hover:border-primary/40 transition-all"
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────────────  SVG MASCOT  ───────────────── */

type MouthShape = "smile" | "bigSmile" | "open" | "flat" | "frown" | "smirk" | "kiss";
type BrowShape = "neutral" | "up" | "down" | "tilt";

const EMO_MAP: Record<Emotion, { mouth: MouthShape; brow: BrowShape; cheek: number; wink?: "left" | "right"; accent?: "heart" | "star" | "drop" | "zzz" }> = {
  idle:     { mouth: "smile",    brow: "neutral", cheek: 0.4 },
  happy:    { mouth: "bigSmile", brow: "up",      cheek: 0.8 },
  excited:  { mouth: "open",     brow: "up",      cheek: 0.9, accent: "star" },
  thinking: { mouth: "smirk",    brow: "tilt",    cheek: 0.3 },
  love:     { mouth: "kiss",     brow: "up",      cheek: 1.0, accent: "heart" },
  wink:     { mouth: "smirk",    brow: "up",      cheek: 0.7, wink: "right" },
  shy:      { mouth: "smile",    brow: "tilt",    cheek: 1.0 },
  sad:      { mouth: "frown",    brow: "down",    cheek: 0.2, accent: "drop" },
  wow:      { mouth: "open",     brow: "up",      cheek: 0.6 },
  cool:     { mouth: "smirk",    brow: "neutral", cheek: 0.5 },
};

function Mascot({ emotion, blink, eye }: { emotion: Emotion; blink: boolean; eye: { x: number; y: number } }) {
  const cfg = EMO_MAP[emotion];

  return (
    <svg viewBox="0 0 220 260" className="w-[240px] h-[280px] md:w-[300px] md:h-[340px]" aria-label="Зеленчуко">
      <defs>
        <radialGradient id="zBody" cx="40%" cy="35%" r="75%">
          <stop offset="0%"  stopColor="hsl(95 65% 65%)" />
          <stop offset="55%" stopColor="hsl(120 55% 42%)" />
          <stop offset="100%" stopColor="hsl(140 60% 28%)" />
        </radialGradient>
        <radialGradient id="zPit" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="hsl(32 65% 58%)" />
          <stop offset="100%" stopColor="hsl(22 60% 38%)" />
        </radialGradient>
        <radialGradient id="zHL" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="hsl(0 0% 100% / 0.55)" />
          <stop offset="100%" stopColor="hsl(0 0% 100% / 0)" />
        </radialGradient>
        <filter id="zShadow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur in="SourceAlpha" stdDeviation="6" />
          <feOffset dx="0" dy="8" result="off" />
          <feComponentTransfer><feFuncA type="linear" slope="0.35" /></feComponentTransfer>
          <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>

      {/* Body (avocado) */}
      <g filter="url(#zShadow)">
        <path
          d="M110 18 C 62 18, 28 70, 28 132 C 28 198, 62 246, 110 246 C 158 246, 192 198, 192 132 C 192 70, 158 18, 110 18 Z"
          fill="url(#zBody)"
        />
        {/* inner flesh */}
        <ellipse cx="110" cy="138" rx="58" ry="86" fill="hsl(60 70% 88%)" />
        {/* pit */}
        <circle cx="110" cy="150" r="34" fill="url(#zPit)" />
        {/* body highlight */}
        <ellipse cx="78" cy="72" rx="36" ry="22" fill="url(#zHL)" />
      </g>

      {/* Leaf on top */}
      <motion.g
        animate={{ rotate: [-4, 6, -4] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        style={{ transformOrigin: "110px 20px" }}
      >
        <path d="M110 24 C 120 6, 142 4, 150 14 C 142 30, 124 34, 110 24 Z" fill="hsl(140 65% 38%)" />
        <path d="M110 24 C 120 14, 138 12, 148 16" stroke="hsl(140 70% 28%)" strokeWidth="1.5" fill="none" />
      </motion.g>

      {/* Cheeks */}
      <circle cx="78"  cy="158" r="9" fill="hsl(350 80% 70%)" opacity={cfg.cheek * 0.55} />
      <circle cx="142" cy="158" r="9" fill="hsl(350 80% 70%)" opacity={cfg.cheek * 0.55} />

      {/* Eyes */}
      <Eye x={86}  y={132} blink={blink} closed={cfg.wink === "left"}  pupil={eye} />
      <Eye x={134} y={132} blink={blink} closed={cfg.wink === "right"} pupil={eye} />

      {/* Brows */}
      <Brow x={86}  y={114} shape={cfg.brow} side="left" />
      <Brow x={134} y={114} shape={cfg.brow} side="right" />

      {/* Mouth */}
      <Mouth shape={cfg.mouth} />

      {/* Floating accent */}
      <AnimatePresence>
        {cfg.accent && <Accent kind={cfg.accent} />}
      </AnimatePresence>
    </svg>
  );
}

function Eye({ x, y, blink, closed, pupil }: { x: number; y: number; blink: boolean; closed?: boolean; pupil: { x: number; y: number } }) {
  const shut = blink || closed;
  return (
    <g>
      {shut ? (
        <path d={`M ${x - 8} ${y} Q ${x} ${y + 5}, ${x + 8} ${y}`} stroke="hsl(120 30% 18%)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
      ) : (
        <>
          <ellipse cx={x} cy={y} rx="8" ry="9" fill="white" />
          <circle cx={x + pupil.x} cy={y + pupil.y + 1} r="4.2" fill="hsl(160 40% 12%)" />
          <circle cx={x + pupil.x - 1.4} cy={y + pupil.y - 0.6} r="1.4" fill="white" />
        </>
      )}
    </g>
  );
}

function Brow({ x, y, shape, side }: { x: number; y: number; shape: BrowShape; side: "left" | "right" }) {
  const flip = side === "right" ? -1 : 1;
  let d = `M ${x - 9} ${y} Q ${x} ${y - 2}, ${x + 9} ${y}`;
  if (shape === "up")   d = `M ${x - 9} ${y + 2} Q ${x} ${y - 6}, ${x + 9} ${y + 2}`;
  if (shape === "down") d = `M ${x - 9} ${y - 2} Q ${x} ${y + 4}, ${x + 9} ${y - 2}`;
  if (shape === "tilt") d = side === "left"
    ? `M ${x - 9} ${y + 2} Q ${x} ${y - 4}, ${x + 9} ${y - 2}`
    : `M ${x - 9} ${y - 2} Q ${x} ${y - 4}, ${x + 9} ${y + 2}`;
  void flip;
  return (
    <motion.path
      d={d}
      stroke="hsl(120 35% 16%)"
      strokeWidth="3"
      strokeLinecap="round"
      fill="none"
      initial={false}
      animate={{ d }}
      transition={{ duration: 0.25 }}
    />
  );
}

function Mouth({ shape }: { shape: MouthShape }) {
  const paths: Record<MouthShape, string> = {
    smile:    "M 92 178 Q 110 192, 128 178",
    bigSmile: "M 86 176 Q 110 204, 134 176",
    open:     "", // rendered separately
    flat:     "M 94 182 L 126 182",
    frown:    "M 92 188 Q 110 174, 128 188",
    smirk:    "M 96 182 Q 110 192, 130 180",
    kiss:     "", // rendered separately
  };

  if (shape === "open") {
    return (
      <motion.g initial={{ scaleY: 0.5 }} animate={{ scaleY: [0.6, 1, 0.6] }} transition={{ duration: 1.2, repeat: Infinity }} style={{ transformOrigin: "110px 184px" }}>
        <ellipse cx="110" cy="184" rx="13" ry="11" fill="hsl(350 50% 22%)" />
        <ellipse cx="110" cy="190" rx="8" ry="4" fill="hsl(350 70% 50%)" />
      </motion.g>
    );
  }
  if (shape === "kiss") {
    return <ellipse cx="110" cy="184" rx="6" ry="7" fill="hsl(350 70% 55%)" />;
  }

  return (
    <motion.path
      d={paths[shape]}
      stroke="hsl(120 35% 16%)"
      strokeWidth="3.5"
      strokeLinecap="round"
      fill="none"
      initial={false}
      animate={{ d: paths[shape] }}
      transition={{ duration: 0.3 }}
    />
  );
}

function Accent({ kind }: { kind: "heart" | "star" | "drop" | "zzz" }) {
  const common = {
    initial: { opacity: 0, y: 0, scale: 0.5 },
    animate: { opacity: [0, 1, 1, 0], y: -34, scale: 1 },
    exit:    { opacity: 0 },
    transition: { duration: 1.8, repeat: Infinity, ease: "easeOut" as const },
  };
  if (kind === "heart") return (
    <motion.path {...common} d="M178 60 c -6 -10 -22 -4 -16 8 c 4 8 16 12 16 12 c 0 0 12 -4 16 -12 c 6 -12 -10 -18 -16 -8 z" fill="hsl(350 80% 60%)" />
  );
  if (kind === "star") return (
    <motion.path {...common} d="M180 50 l 4 10 l 10 2 l -8 7 l 2 11 l -8 -5 l -8 5 l 2 -11 l -8 -7 l 10 -2 z" fill="hsl(48 95% 60%)" />
  );
  if (kind === "drop") return (
    <motion.path {...common} transition={{ ...common.transition, duration: 1.5 }} d="M150 174 c 0 -8 8 -14 8 -14 s 8 6 8 14 a 8 8 0 0 1 -16 0 z" fill="hsl(200 85% 60%)" />
  );
  return null;
}
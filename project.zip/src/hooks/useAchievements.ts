import { useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { toast } from 'sonner';
import { useLanguage } from '@/contexts/LanguageContext';

export const useAchievements = () => {
  const { user } = useAuth();
  const { language } = useLanguage();

  const checkAndAwardAchievement = useCallback(async (requirementType: string, currentValue: number) => {
    if (!user) return;

    try {
      // Get all achievements for this requirement type
      const { data: achievements, error: achievementsError } = await supabase
        .from('achievements')
        .select('*')
        .eq('requirement_type', requirementType)
        .lte('requirement_value', currentValue);

      if (achievementsError) throw achievementsError;
      if (!achievements || achievements.length === 0) return;

      // Get user's existing achievements
      const { data: existingAchievements, error: existingError } = await supabase
        .from('user_achievements')
        .select('achievement_id')
        .eq('user_id', user.id);

      if (existingError) throw existingError;

      const existingIds = new Set(existingAchievements?.map(a => a.achievement_id) || []);

      // Award new achievements
      for (const achievement of achievements) {
        if (!existingIds.has(achievement.id)) {
          const { error: insertError } = await supabase
            .from('user_achievements')
            .insert({
              user_id: user.id,
              achievement_id: achievement.id
            });

          if (!insertError) {
            // Show celebration toast
            toast.success(
              `🏆 ${language === 'bg' ? 'Ново постижение!' : 'New Achievement!'} ${achievement.icon} ${language === 'bg' ? achievement.name_bg : achievement.name}`,
              {
                description: language === 'bg' ? achievement.description_bg : achievement.description,
                duration: 5000,
              }
            );
          }
        }
      }
    } catch (error) {
      console.error('Error checking achievements:', error);
    }
  }, [user, language]);

  const trackProgress = useCallback((type: string, value: number = 1) => {
    // Store progress in localStorage for non-logged users
    const key = `achievement_progress_${type}`;
    const current = parseInt(localStorage.getItem(key) || '0', 10);
    const newValue = current + value;
    localStorage.setItem(key, newValue.toString());
    
    // If logged in, check for achievements
    if (user) {
      checkAndAwardAchievement(type, newValue);
    }

    return newValue;
  }, [user, checkAndAwardAchievement]);

  const getProgress = useCallback((type: string): number => {
    const key = `achievement_progress_${type}`;
    return parseInt(localStorage.getItem(key) || '0', 10);
  }, []);

  const checkTimeBasedAchievements = useCallback(() => {
    const hour = new Date().getHours();
    
    if (hour < 7) {
      trackProgress('early_login', 1);
    }
    
    if (hour >= 23) {
      trackProgress('late_login', 1);
    }
  }, [trackProgress]);

  return {
    trackProgress,
    getProgress,
    checkAndAwardAchievement,
    checkTimeBasedAchievements
  };
};

import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter } from "react-router-dom";
import Navigation from "./components/Navigation";
import { LanguageProvider } from "./contexts/LanguageContext";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AuthProvider } from "./hooks/useAuth";
import { UserProfileProvider } from "./contexts/UserProfileContext";
import { GlobalAIChatButton } from "./components/GlobalAIChatButton";
import { AnimatedRoutes } from "./components/AnimatedRoutes";
import { ScrollProgress } from "./components/ScrollProgress";
import { ClickBurst } from "./components/ClickBurst";

const queryClient = new QueryClient();

const AppContent = () => (
  <>
    <Navigation />
    <ScrollProgress />
    <ClickBurst />
    <GlobalAIChatButton />
    <AnimatedRoutes />
  </>
);

const App = () => (
  <BrowserRouter>
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <ThemeProvider>
          <UserProfileProvider>
            <AuthProvider>
              <TooltipProvider>
                <Toaster />
                <Sonner />
                <AppContent />
              </TooltipProvider>
            </AuthProvider>
          </UserProfileProvider>
        </ThemeProvider>
      </LanguageProvider>
    </QueryClientProvider>
  </BrowserRouter>
);

export default App;

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface UserProfile {
  username: string;
  createdAt: string;
}

interface UserProfileContextType {
  profile: UserProfile | null;
  setUsername: (username: string) => void;
  clearProfile: () => void;
  isProfileSet: boolean;
}

const UserProfileContext = createContext<UserProfileContextType | undefined>(undefined);

export const UserProfileProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [profile, setProfile] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('user_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    return null;
  });

  useEffect(() => {
    if (profile) {
      localStorage.setItem('user_profile', JSON.stringify(profile));
      // Also set cookie for persistence
      document.cookie = `username=${encodeURIComponent(profile.username)}; path=/; max-age=31536000`;
    } else {
      localStorage.removeItem('user_profile');
      document.cookie = 'username=; path=/; max-age=0';
    }
  }, [profile]);

  const setUsername = (username: string) => {
    setProfile({
      username: username.trim(),
      createdAt: new Date().toISOString()
    });
  };

  const clearProfile = () => {
    setProfile(null);
  };

  return (
    <UserProfileContext.Provider value={{
      profile,
      setUsername,
      clearProfile,
      isProfileSet: !!profile?.username
    }}>
      {children}
    </UserProfileContext.Provider>
  );
};

export const useUserProfile = () => {
  const context = useContext(UserProfileContext);
  if (!context) {
    throw new Error('useUserProfile must be used within UserProfileProvider');
  }
  return context;
};

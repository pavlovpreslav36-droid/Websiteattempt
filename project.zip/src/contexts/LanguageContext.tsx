import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'bg' | 'en';

interface Translations {
  nav: {
    home: string;
    quiz: string;
    recipes: string;
    funFacts: string;
    productScanner: string;
    settings: string;
  };
  home: {
    title: string;
    subtitle: string;
    startQuiz: string;
    viewRecipes: string;
    learnFacts: string;
    heroTitle: string;
    heroSubtitle: string;
  };
  settings: {
    title: string;
    languageSection: string;
    themeSection: string;
    aiHelperSection: string;
    selectLanguage: string;
    selectTheme: string;
    darkTheme: string;
    lightTheme: string;
    customTheme: string;
    openAIHelper: string;
  };
}

const translations: Record<Language, Translations> = {
  bg: {
    nav: {
      home: 'Начало',
      quiz: 'Викторина',
      recipes: 'Рецепти',
      funFacts: 'Интересни факти',
      productScanner: 'Скенер',
      settings: 'Настройки'
    },
    home: {
      title: 'Пътят към здравословен живот',
      subtitle: 'Научете, тренирайте и живейте здравословно',
      startQuiz: 'Започни викторината',
      viewRecipes: 'Виж рецепти',
      learnFacts: 'Научи нови факти',
      heroTitle: 'Здравето е вашето богатство',
      heroSubtitle: 'Открийте пътя към по-здравословен и щастлив живот'
    },
    settings: {
      title: 'Настройки',
      languageSection: 'Език',
      themeSection: 'Тема',
      aiHelperSection: 'AI Помощник',
      selectLanguage: 'Изберете език',
      selectTheme: 'Изберете тема',
      darkTheme: 'Тъмна',
      lightTheme: 'Светла',
      customTheme: 'Персонализирана',
      openAIHelper: 'Отворете AI помощника'
    }
  },
  en: {
    nav: {
      home: 'Home',
      quiz: 'Quiz',
      recipes: 'Recipes',
      funFacts: 'Fun Facts',
      productScanner: 'Scanner',
      settings: 'Settings'
    },
    home: {
      title: 'Steps to a Healthy Life',
      subtitle: 'Learn, Train and Live Healthy',
      startQuiz: 'Start Quiz',
      viewRecipes: 'View Recipes',
      learnFacts: 'Learn New Facts',
      heroTitle: 'Your Health is Your Wealth',
      heroSubtitle: 'Discover the path to a healthier and happier life'
    },
    settings: {
      title: 'Settings',
      languageSection: 'Language',
      themeSection: 'Theme',
      aiHelperSection: 'AI Helper',
      selectLanguage: 'Select Language',
      selectTheme: 'Select Theme',
      darkTheme: 'Dark',
      lightTheme: 'Light',
      customTheme: 'Custom',
      openAIHelper: 'Open AI Helper'
    }
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translations;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('language');
    return (saved as Language) || 'bg';
  });

  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  const value = {
    language,
    setLanguage,
    t: translations[language]
  };

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
};

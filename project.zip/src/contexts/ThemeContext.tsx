import React, { createContext, useContext, useState, useEffect } from 'react';

type ThemeMode = 'dark' | 'light' | 'custom';

interface CustomTheme {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  foreground: string;
}

interface ThemeContextType {
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
  customTheme: CustomTheme;
  setCustomTheme: (theme: CustomTheme) => void;
  applyTheme: () => void;
}

// Starting point for the "custom" theme (HSL triplets, same format as the CSS tokens)
const defaultCustomTheme: CustomTheme = {
  primary: '10 80% 43%',
  secondary: '22 65% 90%',
  accent: '36 96% 50%',
  background: '24 78% 95%',
  foreground: '345 73% 13%',
};

const CUSTOM_PROPS: (keyof CustomTheme)[] = ['primary', 'secondary', 'accent', 'background', 'foreground'];

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [mode, setMode] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('themeMode');
    // New visitors get the light theme
    return (saved as ThemeMode) || 'light';
  });

  const [customTheme, setCustomTheme] = useState<CustomTheme>(() => {
    try {
      const saved = localStorage.getItem('customTheme');
      return saved ? { ...defaultCustomTheme, ...JSON.parse(saved) } : defaultCustomTheme;
    } catch {
      return defaultCustomTheme;
    }
  });

  const applyTheme = () => {
    const root = document.documentElement;

    // Light and dark live entirely in index.css (:root and .dark).
    // Only the custom theme writes inline values, so clear them otherwise.
    CUSTOM_PROPS.forEach((key) => root.style.removeProperty(`--${key}`));
    root.style.removeProperty('--tomato');
    root.style.removeProperty('--ring');

    root.classList.toggle('dark', mode === 'dark');

    if (mode === 'custom') {
      CUSTOM_PROPS.forEach((key) => root.style.setProperty(`--${key}`, customTheme[key]));
      root.style.setProperty('--tomato', customTheme.accent);
      root.style.setProperty('--ring', customTheme.primary);
    }
  };

  useEffect(() => {
    localStorage.setItem('themeMode', mode);
    applyTheme();
  }, [mode]);

  useEffect(() => {
    localStorage.setItem('customTheme', JSON.stringify(customTheme));
    if (mode === 'custom') {
      applyTheme();
    }
  }, [customTheme]);

  const value = {
    mode,
    setMode,
    customTheme,
    setCustomTheme,
    applyTheme,
  };

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
};

// "Folders" shown on the home page and the recipes page.
// `name` must match the `category` field of the recipes.
export const recipeFolders = [
  { name: "Български", image: "/images/food/bulgarian.jpg" },
  { name: "Закуска", image: "/images/food/breakfast.jpg" },
  { name: "Супа", image: "/images/food/soup.jpg" },
  { name: "Салата", image: "/images/food/salad.jpg" },
  { name: "Италианско", image: "/images/food/italian.jpg" },
  { name: "Гръцко", image: "/images/food/greek.jpg" },
  { name: "Японско", image: "/images/food/japanese.jpg" },
  { name: "Мексиканско", image: "/images/food/mexican.jpg" },
  { name: "Индийско", image: "/images/food/indian.jpg" },
  { name: "Тайландско", image: "/images/food/thai.jpg" },
  { name: "Корейско", image: "/images/food/korean.jpg" },
  { name: "Испанско", image: "/images/food/spanish.jpg" },
  { name: "Френско", image: "/images/food/french.jpg" },
];

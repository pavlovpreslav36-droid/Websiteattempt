import { dietRecipes, type DietRecipe, type DietTag } from "@/data/dietRecipes";
import { drinks, type Drink } from "@/data/drinks";

export type Restriction = "gluten-free" | "lactose-free" | "vegan";

export interface DayPlan {
  breakfast?: DietRecipe;
  snack?: DietRecipe;
  lunch?: DietRecipe;
  dinner?: DietRecipe;
  drinks: Drink[];
}

const pick = <T,>(list: T[], i: number): T | undefined => (list.length ? list[((i % list.length) + list.length) % list.length] : undefined);

/** Seven-day menu for the first week without cigarettes, built from the recipe and drink libraries. */
export function buildPlan(restr: Restriction[]): DayPlan[] {
  const okRecipe = (r: DietRecipe) => restr.every((t) => r.tags.includes(t as DietTag));
  const okDrink = (d: Drink) => restr.every((t) => d.tags.includes(t as never));
  const quitFirst = (list: DietRecipe[]) => [...list.filter((x) => x.tags.includes("quit")), ...list.filter((x) => !x.tags.includes("quit"))];

  const breakfasts = quitFirst(dietRecipes.filter((r) => r.meal === "Закуска" && okRecipe(r)));
  const snacks = dietRecipes.filter((r) => r.meal === "Снакс" && r.tags.includes("quit") && okRecipe(r));
  const mains = dietRecipes.filter((r) => ["Основно", "Салата", "Супа"].includes(r.meal) && okRecipe(r));
  const warm = drinks.filter((d) => d.serve === "hot" && d.tags.includes("quit") && okDrink(d));
  const water = drinks.filter((d) => d.type === "water" && okDrink(d));
  const evening = drinks.filter((d) => d.serve === "hot" && d.tags.includes("caffeine-free") && okDrink(d));

  return Array.from({ length: 7 }, (_, d) => {
    const lunch = pick(mains, d * 3);
    let dinner = pick(mains, d * 3 + 7);
    if (dinner && lunch && dinner.id === lunch.id) dinner = pick(mains, d * 3 + 8);
    return {
      breakfast: pick(breakfasts, d),
      snack: pick(snacks, d * 2),
      lunch,
      dinner,
      drinks: [pick(warm, d), pick(water, d * 2), pick(evening, d + 1)].filter((x): x is Drink => !!x),
    };
  });
}

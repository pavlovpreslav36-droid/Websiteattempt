import { useSyncExternalStore } from "react";

export interface ShoppingItem {
  id: string;
  text: string;
  source: string;
  done: boolean;
}

const KEY = "shopping-list-v1";
const listeners = new Set<() => void>();
let cache: ShoppingItem[] | null = null;

const valid = (x: unknown): x is ShoppingItem => {
  const o = x as ShoppingItem;
  return !!o && typeof o.id === "string" && typeof o.text === "string" && typeof o.source === "string" && typeof o.done === "boolean";
};

function read(): ShoppingItem[] {
  if (cache) return cache;
  try {
    const raw = localStorage.getItem(KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    cache = Array.isArray(parsed) ? parsed.filter(valid) : [];
  } catch {
    cache = [];
  }
  return cache;
}

function write(next: ShoppingItem[]) {
  cache = next;
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* private mode: the list still works until the tab closes */
  }
  listeners.forEach((l) => l());
}

if (typeof window !== "undefined") {
  window.addEventListener("storage", (e) => {
    if (e.key === KEY) {
      cache = null;
      listeners.forEach((l) => l());
    }
  });
}

const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
};

const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

/** Adds items that are not already on the list. Returns how many were added. */
export function addItems(texts: string[], source: string): number {
  const current = read();
  const have = new Set(current.filter((i) => !i.done).map((i) => i.text.trim().toLowerCase()));
  const added: ShoppingItem[] = [];
  for (const raw of texts) {
    const text = raw.trim();
    if (!text) continue;
    const key = text.toLowerCase();
    if (have.has(key)) continue;
    have.add(key);
    added.push({ id: uid(), text, source, done: false });
  }
  if (added.length) write([...current, ...added]);
  return added.length;
}

export const toggleItem = (id: string) => write(read().map((i) => (i.id === id ? { ...i, done: !i.done } : i)));
export const removeItem = (id: string) => write(read().filter((i) => i.id !== id));
export const clearDone = () => write(read().filter((i) => !i.done));
export const clearAll = () => write([]);

export function useShoppingList(): ShoppingItem[] {
  return useSyncExternalStore(subscribe, read, () => []);
}

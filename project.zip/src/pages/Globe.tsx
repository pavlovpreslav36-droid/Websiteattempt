import { useEffect, useRef, useState, useCallback, lazy, Suspense } from "react";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";

// Lazy load heavy decorative components
const StarField = lazy(() => import("@/components/globe/StarField"));
const SolarSystem = lazy(() => import("@/components/globe/SolarSystem"));
const StreetViewPanel = lazy(() => import("@/components/globe/StreetViewPanel"));

const MAPBOX_TOKEN = "pk.eyJ1IjoiY3JlYXRpdmVwaWdlb24iLCJhIjoiY21sb2RpMTgzMTAzNzNrczlhNHl4anFmaiJ9.rHMjeFeyzyuFheXdS1SZLw";
const GOOGLE_MAPS_KEY = "AIzaSyDc8BgB31_ouvCHk5T9avzi9nYDA7iPLu0";

const quickFlyLocations = [
  { name: "🇧🇬 София", lng: 23.3219, lat: 42.6977, zoom: 16 },
  { name: "🗼 Париж", lng: 2.2945, lat: 48.8584, zoom: 16 },
  { name: "🗽 Ню Йорк", lng: -74.006, lat: 40.7128, zoom: 15 },
  { name: "🏯 Токио", lng: 139.6917, lat: 35.6895, zoom: 15 },
  { name: "🌉 Сан Франциско", lng: -122.4194, lat: 37.7749, zoom: 14 },
];

const Globe = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const spinningRef = useRef(true);
  const [zoom, setZoom] = useState(1.5);
  const [viewMode, setViewMode] = useState<"globe" | "map">("globe");
  const [lng, setLng] = useState(25.48);
  const [lat, setLat] = useState(42.73);
  const [showStreetView, setShowStreetView] = useState(false);
  const [streetViewExpanded, setStreetViewExpanded] = useState(false);
  const [googleLoaded, setGoogleLoaded] = useState(false);
  const [mapReady, setMapReady] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);

  // Load Google Maps script
  useEffect(() => {
    try {
      if (document.getElementById("google-maps-script")) {
        if ((window as any).google?.maps) setGoogleLoaded(true);
        return;
      }
      const script = document.createElement("script");
      script.id = "google-maps-script";
      script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_KEY}&libraries=places`;
      script.async = true;
      script.defer = true;
      script.onload = () => setGoogleLoaded(true);
      script.onerror = () => console.warn("Google Maps failed to load");
      document.head.appendChild(script);
    } catch (e) {
      console.warn("Google Maps script error:", e);
    }
  }, []);

  // Initialize Mapbox
  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    try {
      mapboxgl.accessToken = MAPBOX_TOKEN;

      const m = new mapboxgl.Map({
        container: mapContainer.current,
        style: "mapbox://styles/mapbox/satellite-streets-v12",
        center: [lng, lat],
        zoom: zoom,
        projection: "globe",
        antialias: false, // Disable for better perf on weak GPUs
        pitch: 30,
        fadeDuration: 0,
        trackResize: true,
        maxTileCacheSize: 50, // Limit memory usage
      });

      map.current = m;

      m.on("style.load", () => {
        try {
          m.setFog({
            color: "rgb(8, 10, 28)",
            "high-color": "rgb(30, 40, 100)",
            "horizon-blend": 0.06,
            "space-color": "rgb(3, 3, 12)",
            "star-intensity": 0.0,
          });

          // Only add terrain if not a low-end device
          if (window.devicePixelRatio <= 2) {
            m.addSource("mapbox-dem", {
              type: "raster-dem",
              url: "mapbox://mapbox.mapbox-terrain-dem-v1",
              tileSize: 512,
              maxzoom: 12,
            });
            m.setTerrain({ source: "mapbox-dem", exaggeration: 1.0 });
          }

          // 3D buildings — only at high zoom
          const layers = m.getStyle().layers;
          const labelLayerId = layers?.find(
            (layer) => layer.type === "symbol" && layer.layout?.["text-field"]
          )?.id;

          if (!m.getLayer("3d-buildings")) {
            m.addLayer(
              {
                id: "3d-buildings",
                source: "composite",
                "source-layer": "building",
                filter: ["==", "extrude", "true"],
                type: "fill-extrusion",
                minzoom: 14,
                paint: {
                  "fill-extrusion-color": "hsl(220, 25%, 25%)",
                  "fill-extrusion-height": ["get", "height"],
                  "fill-extrusion-base": ["get", "min_height"],
                  "fill-extrusion-opacity": 0.8,
                },
              },
              labelLayerId
            );
          }

          setMapReady(true);
        } catch (e) {
          console.error("Map style setup error:", e);
        }
      });

      m.on("error", (e) => {
        console.error("Mapbox error:", e.error);
      });

      // Navigation controls
      m.addControl(new mapboxgl.NavigationControl(), "top-right");

      // Track zoom (throttled)
      let zoomTimer: ReturnType<typeof setTimeout>;
      m.on("zoom", () => {
        clearTimeout(zoomTimer);
        zoomTimer = setTimeout(() => {
          const z = m.getZoom();
          setZoom(z);
          setViewMode(z > 5 ? "map" : "globe");
        }, 100);
      });

      let moveTimer: ReturnType<typeof setTimeout>;
      m.on("move", () => {
        clearTimeout(moveTimer);
        moveTimer = setTimeout(() => {
          const center = m.getCenter();
          setLng(parseFloat(center.lng.toFixed(4)));
          setLat(parseFloat(center.lat.toFixed(4)));
        }, 100);
      });

      // Smooth auto-rotate
      const spinGlobe = () => {
        if (!m || !spinningRef.current) return;
        if (m.getZoom() < 4) {
          const center = m.getCenter();
          center.lng += 0.06;
          m.easeTo({ center, duration: 150, easing: (t) => t });
        }
      };

      const spinInterval = setInterval(spinGlobe, 150);

      m.on("mousedown", () => { spinningRef.current = false; });
      m.on("touchstart", () => { spinningRef.current = false; });
      m.on("mouseup", () => { if (m.getZoom() < 4) spinningRef.current = true; });
      m.on("touchend", () => { if (m.getZoom() < 4) spinningRef.current = true; });
      m.on("zoom", () => { if (m.getZoom() >= 4) spinningRef.current = false; });

      // Double-click for Street View
      m.on("dblclick", (e) => {
        e.preventDefault();
        setLng(parseFloat(e.lngLat.lng.toFixed(4)));
        setLat(parseFloat(e.lngLat.lat.toFixed(4)));
        setShowStreetView(true);
      });

      return () => {
        clearInterval(spinInterval);
        clearTimeout(zoomTimer);
        clearTimeout(moveTimer);
        m.remove();
        map.current = null;
      };
    } catch (e) {
      console.error("Map init error:", e);
      setMapError("Failed to load the map. Please refresh the page.");
    }
  }, []);

  const flyTo = useCallback((targetLng: number, targetLat: number, targetZoom: number) => {
    if (!map.current) return;
    spinningRef.current = false;
    map.current.flyTo({
      center: [targetLng, targetLat],
      zoom: targetZoom,
      pitch: targetZoom > 14 ? 50 : 30,
      bearing: 0,
      duration: 2500,
      essential: true,
    });
  }, []);

  if (mapError) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center pt-16">
        <div className="text-center p-8">
          <p className="text-destructive text-lg">{mapError}</p>
          <Button className="mt-4" onClick={() => window.location.reload()}>
            Reload
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[rgb(3,3,12)] pt-16 relative overflow-hidden">
      {/* Space background — lazy loaded */}
      <Suspense fallback={null}>
        <StarField />
        <SolarSystem />
      </Suspense>

      {/* Info overlay */}
      <div className="absolute top-20 left-4 z-10 bg-background/60 backdrop-blur-xl rounded-xl border border-white/10 px-4 py-3 shadow-2xl">
        <p className="text-xs text-muted-foreground font-mono">
          Lng: {lng} | Lat: {lat}
        </p>
        <p className="text-xs text-muted-foreground font-mono">
          Zoom: {zoom.toFixed(1)}
        </p>
        <div className="flex items-center gap-2 mt-1">
          <span
            className={`inline-block w-2 h-2 rounded-full ${
              viewMode === "globe" ? "bg-blue-400" : "bg-green-400"
            }`}
          />
          <span className="text-xs font-medium text-foreground">
            {viewMode === "globe" ? "🌍 Глобус" : "🗺️ 3D Карта"}
          </span>
        </div>
      </div>

      {/* Quick fly-to buttons */}
      <div className="absolute top-44 left-4 z-10 flex flex-col gap-2">
        {quickFlyLocations.map((loc) => (
          <Button
            key={loc.name}
            variant="outline"
            size="sm"
            onClick={() => flyTo(loc.lng, loc.lat, loc.zoom)}
            className="bg-background/50 backdrop-blur-xl border-white/10 text-xs hover:bg-primary/20 hover:border-primary/30 transition-colors shadow-lg"
          >
            {loc.name}
          </Button>
        ))}
      </div>

      {/* Street View toggle */}
      <div className="absolute top-20 right-16 z-10">
        <Button
          onClick={() => setShowStreetView(!showStreetView)}
          variant={showStreetView ? "default" : "outline"}
          className="bg-background/60 backdrop-blur-xl border-white/10 gap-2 hover:bg-primary/20 shadow-lg"
        >
          <MapPin className="w-4 h-4" />
          Street View
        </Button>
      </div>

      {/* Bottom hint */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 bg-background/50 backdrop-blur-xl rounded-full border border-white/10 px-5 py-2 shadow-2xl">
        <p className="text-sm text-muted-foreground text-center">
          🖱️ Scroll за zoom • Drag за завъртане • Double-click за Street View
        </p>
      </div>

      {/* Map + Street View */}
      <div className="flex w-full h-[calc(100vh-4rem)] relative" style={{ zIndex: 2 }}>
        <div
          ref={mapContainer}
          className={`h-full transition-all duration-500 ease-in-out ${
            showStreetView && !streetViewExpanded ? "w-1/2" : showStreetView && streetViewExpanded ? "w-0 overflow-hidden" : "w-full"
          }`}
          style={{ minWidth: showStreetView && streetViewExpanded ? 0 : undefined }}
        />

        <AnimatePresence>
          {showStreetView && (
            <Suspense fallback={<div className="w-1/2 h-full bg-background/90 flex items-center justify-center text-muted-foreground">Loading...</div>}>
              <StreetViewPanel
                lat={lat}
                lng={lng}
                expanded={streetViewExpanded}
                googleLoaded={googleLoaded}
                onToggleExpand={() => setStreetViewExpanded(!streetViewExpanded)}
                onClose={() => {
                  setShowStreetView(false);
                  setStreetViewExpanded(false);
                }}
              />
            </Suspense>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Globe;

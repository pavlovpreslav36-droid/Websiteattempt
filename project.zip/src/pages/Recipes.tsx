import { useState, useCallback, useEffect } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Flame, Beef, Loader2, Sparkles, Wheat, Droplets, Leaf, Clock, ChefHat, Play, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import Footer from "@/components/Footer";
import { Reveal } from "@/components/Reveal";
import { ChefBowl } from "@/components/ChefBowl";
import { recipeFolders } from "@/lib/recipeFolders";
import { diets } from "@/data/diets";
import { Link, useSearchParams } from "react-router-dom";

interface NutritionDetails {
  carbs: number;
  fiber: number;
  fat: number;
  saturatedFat: number;
  sugar: number;
  sodium: number;
  carbSources: string;
}

interface Recipe {
  id: number;
  name: string;
  image: string;
  calories: number;
  protein: number;
  prepTime?: number;
  difficulty?: "лесно" | "средно" | "трудно";
  nutrition?: NutritionDetails;
  category: string;
  cookingMethod: {
    temperature: string;
    oil: string;
    healthierOil: string;
    steps: string[];
  };
}

const recipes: Recipe[] = [
  // Български национални ястия (1-15)
  { id: 1, name: "Шопска салата с пиле", image: "🥗", calories: 680, protein: 48, prepTime: 35, difficulty: "лесно", nutrition: { carbs: 28, fiber: 6, fat: 38, saturatedFat: 12, sugar: 8, sodium: 890, carbSources: "домати, краставици, чушки, сирене" }, category: "Български", cookingMethod: { temperature: "200°C за 20-25 мин", oil: "Зехтин", healthierOil: "Лимонов сок", steps: ["Нарежете 400г домати, 200г краставици, 150г чушки на кубчета", "Печете 250г пилешки гърди при 200°C за 20-25 мин и нарежете", "Смесете зеленчуците с пилето", "Настържете 100г сирене отгоре", "Поръсете с 2 с.л. зехтин и оцет"] }},
  { id: 2, name: "Таратор с ядки и яйца", image: "🥣", calories: 620, protein: 32, prepTime: 75, difficulty: "лесно", nutrition: { carbs: 24, fiber: 4, fat: 42, saturatedFat: 8, sugar: 12, sodium: 680, carbSources: "кисело мляко, орехи, краставици" }, category: "Български", cookingMethod: { temperature: "Студено", oil: "Зехтин", healthierOil: "Без масло", steps: ["Обелете и нарежете 300г краставици", "Смесете 500мл кисело мляко с 200мл вода", "Добавете краставици, 80г орехи, 4 скилидки чесън", "Добавете 3 сварени яйца нарязани", "Поръсете с копър и охладете 1 час"] }},
  { id: 3, name: "Боб чорба с наденица", image: "🍲", calories: 780, protein: 42, prepTime: 150, difficulty: "средно", nutrition: { carbs: 68, fiber: 18, fat: 32, saturatedFat: 10, sugar: 6, sodium: 1250, carbSources: "бял боб, морков, лук, домати" }, category: "Български", cookingMethod: { temperature: "Средна за 2 часа", oil: "Слънчогледово", healthierOil: "Намалено", steps: ["Накиснете 400г боб вечерта за 8-10 часа", "Сварете до омекване около 1.5 часа", "Добавете 150г лук, 100г моркови, 200г домати и 200г наденица", "Варете още 30 мин и овкусете с чубрица и червен пипер"] }},
  { id: 4, name: "Пълнени чушки с месо", image: "🫑", calories: 820, protein: 52, prepTime: 60, difficulty: "средно", nutrition: { carbs: 48, fiber: 8, fat: 46, saturatedFat: 16, sugar: 12, sodium: 980, carbSources: "ориз, чушки, домати, лук" }, category: "Български", cookingMethod: { temperature: "180°C за 40-45 мин", oil: "Слънчогледово", healthierOil: "Минимално", steps: ["Очистете 8 чушки от семената", "Смесете 500г кайма, 150г ориз, 100г лук, 200г домати", "Напълнете чушките и подредете в тава с 200мл вода", "Печете при 180°C за 40-45 мин до златисто"] }},
  { id: 5, name: "Агнешко печено с картофи", image: "🍖", calories: 980, protein: 68, prepTime: 120, difficulty: "средно", nutrition: { carbs: 52, fiber: 6, fat: 54, saturatedFat: 22, sugar: 4, sodium: 890, carbSources: "картофи" }, category: "Български", cookingMethod: { temperature: "200°C за 1.5-2 часа", oil: "Зехтин", healthierOil: "Минимално", steps: ["Овкусете 800г агнешко бут с розмарин, мащерка и 6 скилидки чесън", "Добавете 600г картофи нарязани на едро", "Залейте с 100мл вода и 3 с.л. зехтин", "Печете при 200°C за 1.5-2 часа, поливайте със сок на всеки 30 мин"] }},
  { id: 6, name: "Мусака с кайма", image: "🍆", calories: 920, protein: 56, prepTime: 75, difficulty: "средно", nutrition: { carbs: 42, fiber: 8, fat: 58, saturatedFat: 22, sugar: 10, sodium: 1180, carbSources: "патладжани, картофи, яйца, мляко" }, category: "Български", cookingMethod: { temperature: "180°C за 45-50 мин", oil: "Слънчогледово", healthierOil: "Печене вместо пържене", steps: ["Нарежете 600г патладжани и 400г картофи на резени 1см", "Запържете 500г кайма с 150г лук и 200г домати", "Редете пластове в тава, залейте с 4 яйца разбити с 300мл мляко", "Печете при 180°C за 45-50 мин до златисто"] }},
  { id: 7, name: "Зеленчукова яхния с телешко", image: "🥘", calories: 720, protein: 52, prepTime: 70, difficulty: "средно", nutrition: { carbs: 38, fiber: 10, fat: 38, saturatedFat: 12, sugar: 14, sodium: 780, carbSources: "картофи, моркови, домати, чушки, лук" }, category: "Български", cookingMethod: { temperature: "Средна за 1 час", oil: "Зехтин", healthierOil: "Намалено", steps: ["Нарежете 400г телешко на кубчета", "Запържете с 150г лук до зачервяване", "Добавете 200г картофи, 150г моркови, 200г чушки, 300г домати", "Задушете на среден огън 45-60 мин с 200мл вода"] }},
  { id: 8, name: "Печена риба с картофи", image: "🐟", calories: 680, protein: 58, prepTime: 45, difficulty: "лесно", nutrition: { carbs: 42, fiber: 5, fat: 28, saturatedFat: 6, sugar: 3, sodium: 720, carbSources: "картофи, лимон" }, category: "Български", cookingMethod: { temperature: "200°C за 30-35 мин", oil: "Зехтин", healthierOil: "Лимонов сок", steps: ["Очистете 600г риба (ципура/лаврак) и направете надрези", "Добавете 500г картофи нарязани на кръгчета", "Овкусете с сол, пипер, 2 лимона и 3 с.л. зехтин", "Печете при 200°C за 30-35 мин"] }},
  { id: 9, name: "Кашкавал пане с гарнитура", image: "🧀", calories: 880, protein: 42, prepTime: 30, difficulty: "лесно", nutrition: { carbs: 68, fiber: 4, fat: 52, saturatedFat: 26, sugar: 4, sodium: 1420, carbSources: "галета, ориз, брашно" }, category: "Български", cookingMethod: { temperature: "180°C за 15-20 мин", oil: "Слънчогледово", healthierOil: "Печен във фурна", steps: ["Нарежете 400г кашкавал на резени 1.5см", "Овалете в брашно, 2 яйца и галета", "Печете при 180°C за 15-20 мин или пържете", "Сервирайте с 200г варен ориз и салата"] }},
  { id: 10, name: "Баница със сирене и яйца", image: "🥧", calories: 780, protein: 38, prepTime: 55, difficulty: "средно", nutrition: { carbs: 52, fiber: 2, fat: 48, saturatedFat: 18, sugar: 4, sodium: 1680, carbSources: "кори за баница, сирене" }, category: "Български", cookingMethod: { temperature: "180°C за 35-40 мин", oil: "Олио", healthierOil: "Намазан слой", steps: ["Разбийте 6 яйца с 500г сирене и 200мл кисело мляко", "Намажете 500г кори с олио", "Навийте с плънката и подредете в тава", "Печете при 180°C за 35-40 мин до златисто"] }},
  { id: 11, name: "Пилешка супа с фиде", image: "🍲", calories: 580, protein: 48, prepTime: 100, difficulty: "лесно", nutrition: { carbs: 42, fiber: 3, fat: 22, saturatedFat: 6, sugar: 4, sodium: 1280, carbSources: "фиде, моркови, картофи" }, category: "Български", cookingMethod: { temperature: "Средна за 1.5 часа", oil: "Без", healthierOil: "Без", steps: ["Сварете 1 цяло пиле (1.5кг) в 3л вода за 1 час", "Извадете месото и добавете 150г моркови, 200г картофи", "Добавете 150г фиде и варете 15 мин", "Овкусете с магданоз и лимонов сок"] }},
  { id: 12, name: "Кюфтета на скара с гарнитура", image: "🍖", calories: 920, protein: 62, prepTime: 35, difficulty: "лесно", nutrition: { carbs: 48, fiber: 4, fat: 52, saturatedFat: 20, sugar: 4, sodium: 1120, carbSources: "картофи, хляб" }, category: "Български", cookingMethod: { temperature: "Скара 220°C за 8-10 мин", oil: "Без", healthierOil: "Без (на скара)", steps: ["Смесете 600г кайма с 100г лук, 2 яйца, 50г галета и чубрица", "Оформете 8 големи кюфтета (около 90г всяко)", "Печете на скара при висока температура 4-5 мин на страна", "Сервирайте с 400г пържени картофи"] }},
  { id: 13, name: "Капама", image: "🍲", calories: 1050, protein: 68, prepTime: 240, difficulty: "трудно", nutrition: { carbs: 62, fiber: 12, fat: 58, saturatedFat: 22, sugar: 8, sodium: 1580, carbSources: "ориз, кисело зеле" }, category: "Български", cookingMethod: { temperature: "160°C за 3-4 часа", oil: "Зехтин", healthierOil: "Намалено", steps: ["Редете 500г кисело зеле, 600г свинско/телешко и 500г пилешко на слоеве", "Добавете 200г ориз и 2 с.л. червен пипер между слоевете", "Залейте с 500мл вода и 4 с.л. зехтин", "Печете в глинен съд при 160°C за 3-4 часа с капак"] }},
  { id: 14, name: "Гювеч с месо", image: "🥘", calories: 780, protein: 48, prepTime: 105, difficulty: "средно", nutrition: { carbs: 52, fiber: 10, fat: 42, saturatedFat: 14, sugar: 16, sodium: 920, carbSources: "картофи, домати, чушки, патладжани" }, category: "Български", cookingMethod: { temperature: "180°C за 1.5 часа", oil: "Зехтин", healthierOil: "Минимално", steps: ["Нарежете 400г месо, 300г картофи, 200г патладжани, 200г чушки", "Добавете 300г домати, 150г лук и 3 с.л. зехтин", "Подредете в глинен съд и залейте с 200мл вода", "Печете при 180°C за 1.5 часа без разбъркване"] }},
  { id: 15, name: "Дроб сарма", image: "🍲", calories: 720, protein: 52, prepTime: 60, difficulty: "трудно", nutrition: { carbs: 32, fiber: 2, fat: 42, saturatedFat: 14, sugar: 4, sodium: 980, carbSources: "ориз, лук" }, category: "Български", cookingMethod: { temperature: "180°C за 40-45 мин", oil: "Масло", healthierOil: "Зехтин", steps: ["Нарежете 400г агнешки дроб на парчета", "Задушете 200г лук и смесете с 150г ориз и дроба", "Добавете 4 яйца, магданоз, копър и чубрица", "Увийте в агнешка мрежа и печете при 180°C за 40-45 мин"] }},
  
  // Азиатски кухни (16-35)
  { id: 16, name: "Пиле Терияки с ориз", image: "🍗", calories: 850, protein: 58, prepTime: 150, difficulty: "средно", nutrition: { carbs: 78, fiber: 3, fat: 28, saturatedFat: 6, sugar: 22, sodium: 1680, carbSources: "бял ориз, терияки сос (захар), мед" }, category: "Японско", cookingMethod: { temperature: "180°C за 25-30 мин", oil: "Сусамово", healthierOil: "На пара", steps: ["Мариновайте 400г пиле 2 часа в соев сос, мед и джинджифил", "Пригответе терияки сос от соев сос, мирин, захар", "Печете при 180°C за 25-30 мин, сервирайте с 250г ориз"] }},
  { id: 17, name: "Суши роли комплект", image: "🍣", calories: 720, protein: 38, prepTime: 60, difficulty: "трудно", nutrition: { carbs: 92, fiber: 4, fat: 22, saturatedFat: 4, sugar: 8, sodium: 1420, carbSources: "суши ориз, оризов оцет" }, category: "Японско", cookingMethod: { temperature: "Без", oil: "Без", healthierOil: "Без", steps: ["Сварете 300г суши ориз и овкусете с оризов оцет", "Подгответе 150г сьомга, 100г тунец и зеленчуци", "Навийте 12 парчета маки и нигири с нори"] }},
  { id: 18, name: "Рамен с месо", image: "🍜", calories: 880, protein: 52, prepTime: 240, difficulty: "трудно", nutrition: { carbs: 72, fiber: 4, fat: 42, saturatedFat: 14, sugar: 6, sodium: 2180, carbSources: "рамен нудли (пшеница), зеленчуци" }, category: "Японско", cookingMethod: { temperature: "Средна за 3-4 часа", oil: "Сусамово", healthierOil: "Намалено", steps: ["Сварете костен бульон от свински кости 3-4 часа", "Добавете 200г рамен нудли и 150г свинско чашу", "Добавете меко яйце, нори и пресен лук"] }},
  { id: 19, name: "Донбури с пиле", image: "🍚", calories: 780, protein: 48, prepTime: 25, difficulty: "лесно", nutrition: { carbs: 82, fiber: 3, fat: 26, saturatedFat: 6, sugar: 12, sodium: 1380, carbSources: "бял ориз, лук, яйце" }, category: "Японско", cookingMethod: { temperature: "Средна за 15 мин", oil: "Минимално", healthierOil: "Без", steps: ["Сварете 250г ориз", "Запържете 300г пиле с 100г лук в даши бульон", "Добавете 2 разбити яйца и сервирайте върху ориза"] }},
  { id: 20, name: "Пад Тай с пиле", image: "🍜", calories: 920, protein: 48, prepTime: 45, difficulty: "средно", nutrition: { carbs: 86, fiber: 5, fat: 42, saturatedFat: 8, sugar: 18, sodium: 1680, carbSources: "оризови нудли, фъстъци, тамаринд сос" }, category: "Тайландско", cookingMethod: { temperature: "Висока за 8-10 мин", oil: "Фъстъчено", healthierOil: "Намалено", steps: ["Накиснете 250г оризови нудли 30 мин", "Запържете 300г пиле с 2 яйца на висок огън", "Добавете нудли, 50г фъстъци и пад тай сос"] }},
  { id: 21, name: "Том Ям с морски дарове", image: "🍲", calories: 520, protein: 48, prepTime: 35, difficulty: "средно", nutrition: { carbs: 28, fiber: 4, fat: 24, saturatedFat: 12, sugar: 6, sodium: 1820, carbSources: "гъби, домати, кокосово мляко" }, category: "Тайландско", cookingMethod: { temperature: "Средна за 25 мин", oil: "Без", healthierOil: "Без", steps: ["Сварете 1л бульон с лемонграс, галангал и кафяво листо", "Добавете 200г скариди, 150г миди и гъби", "Овкусете с лайм, рибен сос и кокосово мляко"] }},
  { id: 22, name: "Зелено къри с пиле", image: "🍛", calories: 780, protein: 52, prepTime: 35, difficulty: "средно", nutrition: { carbs: 42, fiber: 6, fat: 48, saturatedFat: 32, sugar: 8, sodium: 1420, carbSources: "кокосово мляко, зеленчуци, басмати ориз" }, category: "Тайландско", cookingMethod: { temperature: "Средна за 25 мин", oil: "Кокосово", healthierOil: "Намалено", steps: ["Запържете 3 с.л. зелена къри паста", "Добавете 400мл кокосово мляко и 400г пиле", "Гответе 20 мин със зеленчуци, сервирайте с ориз"] }},
  { id: 23, name: "Кунг Пао пиле с ориз", image: "🍗", calories: 880, protein: 56, prepTime: 25, difficulty: "средно", nutrition: { carbs: 74, fiber: 5, fat: 38, saturatedFat: 6, sugar: 14, sodium: 1580, carbSources: "бял ориз, фъстъци, сос" }, category: "Китайско", cookingMethod: { temperature: "Висока (уок) за 8-10 мин", oil: "Растително", healthierOil: "Намалено", steps: ["Нарежете 500г пиле на кубчета", "Запържете в уок с 150г чушки и 3 сушени чили", "Добавете 80г фъстъци и кунг пао сос, сервирайте с 200г ориз"] }},
  { id: 24, name: "Дим сум асортимент", image: "🥟", calories: 680, protein: 38, prepTime: 90, difficulty: "трудно", nutrition: { carbs: 62, fiber: 4, fat: 32, saturatedFat: 10, sugar: 6, sodium: 1280, carbSources: "пшенично тесто, скорбяла" }, category: "Китайско", cookingMethod: { temperature: "На пара 100°C за 12-15 мин", oil: "Без", healthierOil: "Без", steps: ["Пригответе плънки: свинска, скаридена, зеленчукова", "Увийте в дим сум тесто (12-15 броя)", "Гответе на пара 12-15 мин"] }},
  { id: 25, name: "Фо с говеждо", image: "🍜", calories: 720, protein: 52, prepTime: 300, difficulty: "трудно", nutrition: { carbs: 68, fiber: 3, fat: 26, saturatedFat: 8, sugar: 4, sodium: 1980, carbSources: "оризови нудли, боб кълнове" }, category: "Виетнамско", cookingMethod: { temperature: "Ниска за 4-6 часа", oil: "Без", healthierOil: "Без", steps: ["Сварете бульон от говежди кости 4-6 часа с канела и звездовиден анасон", "Добавете 200г оризови нудли и 200г тънко нарязано говеждо", "Гарнирайте с боб кълнове, босилек и лайм"] }},
  { id: 26, name: "Бан Ми сандвич голям", image: "🥖", calories: 820, protein: 48, prepTime: 30, difficulty: "лесно", nutrition: { carbs: 72, fiber: 5, fat: 38, saturatedFat: 10, sugar: 12, sodium: 1680, carbSources: "френска багета, морков, репичка" }, category: "Виетнамско", cookingMethod: { temperature: "200°C за 8 мин", oil: "Малко", healthierOil: "Минимално", steps: ["Запечете 1 голяма багета при 200°C за 5-8 мин", "Добавете 250г мариновано свинско месо и пате", "Гарнирайте с кисели моркови, репички, кориандър и халапеньо"] }},
  { id: 27, name: "Бибимбап с говеждо", image: "🍚", calories: 880, protein: 52, prepTime: 40, difficulty: "средно", nutrition: { carbs: 86, fiber: 8, fat: 36, saturatedFat: 10, sugar: 10, sodium: 1420, carbSources: "бял ориз, зеленчуци, гочуджанг" }, category: "Корейско", cookingMethod: { temperature: "Висока за 15 мин", oil: "Сусамово", healthierOil: "Спрей", steps: ["Сварете 250г ориз в каменна купа (долсот)", "Подгответе намул (спанак, боб кълнове, морков, тиквичка) и 200г говеждо булгоги", "Добавете пържено яйце и 2 с.л. гочуджанг, разбъркайте"] }},
  { id: 28, name: "Корейско BBQ плато", image: "🥩", calories: 1050, protein: 78, prepTime: 300, difficulty: "средно", nutrition: { carbs: 42, fiber: 6, fat: 62, saturatedFat: 24, sugar: 18, sodium: 1880, carbSources: "ориз, маринати (захар, круша), кимчи" }, category: "Корейско", cookingMethod: { temperature: "Грил 220-250°C за 3-4 мин на страна", oil: "Без", healthierOil: "Без (на скара)", steps: ["Мариновайте 600г говеждо (галби/булгоги) 4-6 часа в соев сос, круша и чесън", "Печете на грил при 220-250°C за 3-4 мин на страна", "Сервирайте с кимчи, ссам и 150г ориз"] }},
  { id: 29, name: "Корейска оризова купа", image: "🍚", calories: 680, protein: 38, prepTime: 25, difficulty: "лесно", nutrition: { carbs: 72, fiber: 6, fat: 28, saturatedFat: 6, sugar: 8, sodium: 1280, carbSources: "бял ориз, кимчи, тофу" }, category: "Корейско", cookingMethod: { temperature: "Средна за 15 мин", oil: "Сусамово", healthierOil: "Минимално", steps: ["Сварете 250г ориз", "Добавете 150г кимчи и 200г твърдо тофу нарязано", "Запържете яйце отгоре и поръсете със сусам"] }},
  { id: 30, name: "Бирияни с пиле голямо", image: "🍛", calories: 1020, protein: 62, prepTime: 300, difficulty: "трудно", nutrition: { carbs: 98, fiber: 4, fat: 42, saturatedFat: 16, sugar: 6, sodium: 1420, carbSources: "басмати ориз, лук, кисело мляко" }, category: "Индийско", cookingMethod: { temperature: "180°C за 45-50 мин", oil: "Гхи", healthierOil: "Зехтин", steps: ["Мариновайте 500г пиле 3-4 часа в кисело мляко и бирияни подправки", "Сварете 300г басмати ориз с канела, кардамом и дафинов лист", "Редете слоеве в тава, залейте с шафранено мляко, печете при 180°C за 45-50 мин"] }},
  { id: 31, name: "Далл с леща и хляб", image: "🍲", calories: 780, protein: 42, prepTime: 45, difficulty: "лесно", nutrition: { carbs: 88, fiber: 22, fat: 28, saturatedFat: 12, sugar: 8, sodium: 980, carbSources: "червена/жълта леща, наан хляб, лук" }, category: "Индийско", cookingMethod: { temperature: "Средна за 35 мин", oil: "Гхи", healthierOil: "Минимално", steps: ["Сварете 300г леща до мека консистенция (25-30 мин)", "Направете тадка с 2 с.л. гхи, кимион, чесън и домати", "Смесете и сервирайте с 2 наан хляба"] }},
  { id: 32, name: "Тандури пиле с ориз", image: "🍗", calories: 780, protein: 62, prepTime: 280, difficulty: "средно", nutrition: { carbs: 58, fiber: 3, fat: 32, saturatedFat: 10, sugar: 6, sodium: 1180, carbSources: "басмати ориз, кисело мляко маринат" }, category: "Индийско", cookingMethod: { temperature: "220°C за 30-35 мин", oil: "Без", healthierOil: "Без", steps: ["Мариновайте 500г пилешки бутчета в 200г кисело мляко с тандури подправки минимум 4 часа", "Печете при 220°C за 30-35 мин до златисто и леко овъглено", "Сервирайте с 200г басмати ориз, лимон и мента раита"] }},
  { id: 33, name: "Палак панир с ориз", image: "🧀", calories: 820, protein: 42, prepTime: 35, difficulty: "средно", nutrition: { carbs: 62, fiber: 8, fat: 48, saturatedFat: 26, sugar: 8, sodium: 980, carbSources: "ориз, спанак, сметана" }, category: "Индийско", cookingMethod: { temperature: "Средна за 25 мин", oil: "Гхи", healthierOil: "Кокосово", steps: ["Бланширайте 500г спанак и пюрирайте", "Запържете 300г панир до златисто", "Смесете с подправки и 100мл сметана, сервирайте с 200г ориз"] }},
  { id: 34, name: "Чана масала с наан", image: "🫓", calories: 780, protein: 32, prepTime: 40, difficulty: "лесно", nutrition: { carbs: 98, fiber: 18, fat: 28, saturatedFat: 8, sugar: 12, sodium: 1180, carbSources: "нахут, наан хляб, домати" }, category: "Индийско", cookingMethod: { temperature: "Средна за 30 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Сварете 400г нахут или използвайте консервиран", "Направете масала сос с домати, лук и гарам масала", "Смесете и сервирайте с 2 наан хляба"] }},
  { id: 35, name: "Самоса с къри", image: "🥟", calories: 720, protein: 28, prepTime: 60, difficulty: "трудно", nutrition: { carbs: 78, fiber: 8, fat: 36, saturatedFat: 12, sugar: 6, sodium: 1080, carbSources: "пшенично тесто, картофи, грах" }, category: "Индийско", cookingMethod: { temperature: "180°C за 25-30 мин", oil: "Растително", healthierOil: "Печени", steps: ["Пригответе плънка с 400г картофи, 100г грах и гарам масала", "Увийте в тънко разточено тесто (10-12 самоси)", "Печете при 180°C за 25-30 мин, сервирайте с мента чътни"] }},
  
  // Средиземноморски кухни (36-55)
  { id: 36, name: "Гръцка салата с пиле", image: "🥗", calories: 680, protein: 52, nutrition: { carbs: 28, fiber: 6, fat: 38, saturatedFat: 14, sugar: 8, sodium: 1120, carbSources: "домати, краставици, маслини, фета сирене" }, category: "Гръцко", cookingMethod: { temperature: "200°C за 20-25 мин", oil: "Зехтин", healthierOil: "Умерено", steps: ["Нарежете 400г домати, 200г краставици, 150г чушки", "Печете 300г пилешки гърди при 200°C за 20-25 мин", "Добавете 150г фета, 80г маслини и нарязаното месо"] }},
  { id: 37, name: "Мусака гръцка голяма", image: "🍆", calories: 920, protein: 58, nutrition: { carbs: 48, fiber: 10, fat: 56, saturatedFat: 24, sugar: 12, sodium: 1380, carbSources: "патладжани, картофи, бешамел (брашно, мляко)" }, category: "Гръцко", cookingMethod: { temperature: "180°C за 50-55 мин", oil: "Зехтин", healthierOil: "Спрей", steps: ["Печете 600г патладжани при 200°C за 20 мин", "Редете с 500г кайма и 300г картофи", "Залейте с бешамел от 400мл мляко, печете при 180°C за 50-55 мин"] }},
  { id: 38, name: "Сувлаки плато", image: "🍢", calories: 780, protein: 62, nutrition: { carbs: 52, fiber: 4, fat: 38, saturatedFat: 12, sugar: 6, sodium: 1280, carbSources: "питка, дзадзики (кисело мляко), домати" }, category: "Гръцко", cookingMethod: { temperature: "Скара 220°C за 10-12 мин", oil: "Зехтин", healthierOil: "Намалено", steps: ["Мариновайте 500г свинско/пиле 2-3 часа в зехтин, лимон и орегано", "Нанижете на шишове с чушки и лук", "Печете на скара при 220°C за 10-12 мин, сервирайте с 2 питки и 150г дзадзики"] }},
  { id: 39, name: "Гирос с пиле", image: "🥙", calories: 720, protein: 52, nutrition: { carbs: 58, fiber: 5, fat: 32, saturatedFat: 10, sugar: 8, sodium: 1420, carbSources: "питка, картофи, дзадзики" }, category: "Гръцко", cookingMethod: { temperature: "Скара 200°C за 8-10 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Мариновайте 400г пиле 2-4 часа с орегано, чесън и лимон", "Печете на скара при 200°C за 8-10 мин", "Увийте в питка с 100г картофи, салата и 80г дзадзики"] }},
  { id: 40, name: "Шакшука с хляб", image: "🍳", calories: 680, protein: 38, nutrition: { carbs: 52, fiber: 8, fat: 36, saturatedFat: 10, sugar: 14, sodium: 1180, carbSources: "домати, пълнозърнест хляб, лук, чушки" }, category: "Израелско", cookingMethod: { temperature: "Средна за 20-25 мин", oil: "Зехтин", healthierOil: "Умерено", steps: ["Задушете 500г домати с 150г лук и 100г чушки 15 мин", "Счупете 4 яйца и гответе покрито 5-8 мин", "Сервирайте с 2 филии пълнозърнест хляб"] }},
  { id: 41, name: "Фалафел плато", image: "🧆", calories: 780, protein: 35, nutrition: { carbs: 82, fiber: 18, fat: 36, saturatedFat: 4, sugar: 8, sodium: 1320, carbSources: "нахут, питка, хумус, тахан" }, category: "Израелско", cookingMethod: { temperature: "180°C за 20-25 мин", oil: "Растително", healthierOil: "Печени", steps: ["Смелете 400г накиснат нахут с магданоз, кориандър и кимион", "Оформете 15-18 топчета", "Печете при 180°C за 20-25 мин, сервирайте с 200г хумус и питки"] }},
  { id: 42, name: "Хумус с пиле", image: "🫘", calories: 720, protein: 52, nutrition: { carbs: 58, fiber: 14, fat: 32, saturatedFat: 6, sugar: 4, sodium: 980, carbSources: "нахут, тахан, питка" }, category: "Израелско", cookingMethod: { temperature: "200°C за 20-25 мин", oil: "Зехтин", healthierOil: "Умерено", steps: ["Сварете 300г нахут и смелете с 60г тахан, лимон и чесън", "Печете 300г пилешки гърди при 200°C за 20-25 мин", "Добавете нарязаното пиле отгоре с 2 с.л. зехтин"] }},
  { id: 43, name: "Табуле с риба тон", image: "🥗", calories: 680, protein: 48, nutrition: { carbs: 52, fiber: 10, fat: 32, saturatedFat: 6, sugar: 6, sodium: 1080, carbSources: "булгур, магданоз, домати, лимон" }, category: "Ливанско", cookingMethod: { temperature: "Без", oil: "Зехтин", healthierOil: "Умерено", steps: ["Накиснете 150г булгур 30 мин в гореща вода", "Нарежете 200г магданоз, 150г домати, 50г мента", "Смесете с 250г риба тон, лимон и 3 с.л. зехтин"] }},
  { id: 44, name: "Фатуш с пиле", image: "🥗", calories: 720, protein: 48, nutrition: { carbs: 58, fiber: 8, fat: 34, saturatedFat: 8, sugar: 10, sodium: 1280, carbSources: "питка, зеленчуци, сумак дресинг" }, category: "Ливанско", cookingMethod: { temperature: "200°C за 20-25 мин", oil: "Зехтин", healthierOil: "Умерено", steps: ["Нарежете 200г домати, 150г краставици, 100г репички", "Печете 300г пиле при 200°C за 20-25 мин и нарежете", "Добавете 2 печени питки и полейте със сумак дресинг"] }},
  { id: 45, name: "Паста с пилешко", image: "🍝", calories: 820, protein: 56, nutrition: { carbs: 78, fiber: 4, fat: 32, saturatedFat: 12, sugar: 6, sodium: 980, carbSources: "паста (пшеница), пармезан, чесън" }, category: "Италианско", cookingMethod: { temperature: "Средна за 20 мин", oil: "Зехтин", healthierOil: "Умерено", steps: ["Сварете 250г паста ал денте 10-12 мин", "Запържете 350г пиле с 4 скилидки чесън в 2 с.л. зехтин", "Смесете с 50г пармезан и свежи билки"] }},
  { id: 46, name: "Ризото с морски дарове", image: "🍚", calories: 780, protein: 48, nutrition: { carbs: 72, fiber: 2, fat: 32, saturatedFat: 14, sugar: 4, sodium: 1420, carbSources: "арборио ориз, бяло вино, пармезан" }, category: "Италианско", cookingMethod: { temperature: "Средна за 25-30 мин", oil: "Зехтин", healthierOil: "Намалено", steps: ["Задушете 250г ориз арборио с 100мл бяло вино", "Добавяйте 800мл бульон постепенно на порции 15-20 мин", "Добавете 200г скариди, 150г миди и 50г пармезан"] }},
  { id: 47, name: "Минестроне с хляб", image: "🍲", calories: 680, protein: 28, nutrition: { carbs: 82, fiber: 16, fat: 24, saturatedFat: 8, sugar: 12, sodium: 1380, carbSources: "паста, боб, картофи, зеленчуци, хляб" }, category: "Италианско", cookingMethod: { temperature: "Средна за 45-50 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Задушете 150г морков, 150г целина, 100г лук 10 мин", "Добавете 1л бульон, 200г боб, 150г паста и картофи", "Варете 30-35 мин, сервирайте с пармезан и 2 филии хляб"] }},
  { id: 48, name: "Лазаня", image: "🍝", calories: 920, protein: 52, nutrition: { carbs: 68, fiber: 6, fat: 52, saturatedFat: 26, sugar: 10, sodium: 1580, carbSources: "лазаня кори, бешамел (мляко, брашно), домати" }, category: "Италианско", cookingMethod: { temperature: "180°C за 45-50 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Пригответе болонезе сос с 400г кайма и 300г домати 30 мин", "Редете 12 кори с месото и бешамел от 500мл мляко", "Печете при 180°C за 45-50 мин до златисто"] }},
  { id: 49, name: "Рататуй с месо", image: "🍆", calories: 680, protein: 42, nutrition: { carbs: 38, fiber: 12, fat: 36, saturatedFat: 10, sugar: 16, sodium: 820, carbSources: "патладжани, тиквички, домати, чушки" }, category: "Френско", cookingMethod: { temperature: "180°C за 45-50 мин", oil: "Зехтин", healthierOil: "Спрей", steps: ["Нарежете 200г патладжани, 200г тиквички, 200г домати на тънки кръгове", "Добавете 250г свинско филе нарязано", "Подредете в тава със сос от домати, печете при 180°C за 45-50 мин"] }},
  { id: 50, name: "Салата Нисоаз", image: "🥗", calories: 720, protein: 52, nutrition: { carbs: 42, fiber: 8, fat: 42, saturatedFat: 8, sugar: 8, sodium: 1280, carbSources: "картофи, зелен боб, домати, яйца" }, category: "Френско", cookingMethod: { temperature: "Без", oil: "Зехтин", healthierOil: "Умерено", steps: ["Подредете 250г тунец и 4 яйца нарязани", "Добавете 200г зелен боб, 200г картофи и 150г домати", "Полейте с дижонски дресинг от 3 с.л. зехтин"] }},
  { id: 51, name: "Киш с бекон", image: "🥧", calories: 780, protein: 38, nutrition: { carbs: 48, fiber: 2, fat: 52, saturatedFat: 24, sugar: 4, sodium: 1420, carbSources: "тесто (брашно, масло), яйца, сметана" }, category: "Френско", cookingMethod: { temperature: "180°C за 40-45 мин", oil: "Масло", healthierOil: "Зехтин", steps: ["Подгответе крехко тесто и предпечете 15 мин", "Пригответе плънка с 200г бекон, 4 яйца и 200мл сметана", "Печете при 180°C за 35-40 мин до златисто"] }},
  { id: 52, name: "Паеля с морски дарове", image: "🥘", calories: 880, protein: 58, nutrition: { carbs: 78, fiber: 4, fat: 36, saturatedFat: 10, sugar: 6, sodium: 1680, carbSources: "ориз бомба, грах, чушки, шафран" }, category: "Испанско", cookingMethod: { temperature: "Средна за 35-40 мин", oil: "Зехтин", healthierOil: "Умерено", steps: ["Задушете 300г ориз бомба с шафран и 700мл бульон", "Добавете 200г пиле, 150г скариди и 150г миди", "Гответе без разбъркване 25-30 мин до сокарат"] }},
  { id: 53, name: "Тапас плато", image: "🍢", calories: 780, protein: 45, nutrition: { carbs: 52, fiber: 6, fat: 48, saturatedFat: 16, sugar: 4, sodium: 1880, carbSources: "хляб, картофи, маслини, хамон" }, category: "Испанско", cookingMethod: { temperature: "Различни", oil: "Зехтин", healthierOil: "Минимално", steps: ["Пригответе патас бравас с 300г картофи и пикантен сос", "Добавете 100г хамон, 80г маслини и 100г манчего", "Сервирайте с 2 филии хляб и айоли"] }},
  { id: 54, name: "Испанска тортиля с хамон", image: "🥚", calories: 720, protein: 42, nutrition: { carbs: 48, fiber: 4, fat: 42, saturatedFat: 12, sugar: 6, sodium: 1320, carbSources: "картофи, лук, яйца" }, category: "Испанско", cookingMethod: { temperature: "Средна за 25-30 мин", oil: "Зехтин", healthierOil: "Намалено", steps: ["Нарежете 400г картофи и 150г лук тънко", "Запържете бавно 15-20 мин с 100г хамон", "Добавете 6 разбити яйца, обърнете и допечете от двете страни"] }},
  { id: 55, name: "Чурос с шоколад", image: "🍩", calories: 680, protein: 18, nutrition: { carbs: 82, fiber: 3, fat: 32, saturatedFat: 14, sugar: 38, sodium: 420, carbSources: "брашно, захар, шоколад, масло" }, category: "Испанско", cookingMethod: { temperature: "180°C за 15-18 мин", oil: "Растително", healthierOil: "Печени", steps: ["Пригответе тесто от 250г брашно, вода и масло", "Изформете 12-15 чурос", "Печете при 180°C за 15-18 мин, сервирайте с топъл шоколад"] }},
  
  // Латиноамерикански кухни (56-70)
  { id: 56, name: "Буритос боул", image: "🌯", calories: 880, protein: 58, nutrition: { carbs: 82, fiber: 18, fat: 38, saturatedFat: 14, sugar: 6, sodium: 1420, carbSources: "ориз, черен боб, царевица, тортиля чипс" }, category: "Мексиканско", cookingMethod: { temperature: "180°C за 20-25 мин", oil: "Зехтин", healthierOil: "Без", steps: ["Сварете 200г ориз и 200г черен боб", "Печете 350г пиле при 180°C за 20-25 мин", "Подредете в купа с 1 авокадо, 100г царевица и салса"] }},
  { id: 57, name: "Тако плато", image: "🌮", calories: 820, protein: 52, nutrition: { carbs: 62, fiber: 10, fat: 44, saturatedFat: 18, sugar: 8, sodium: 1380, carbSources: "царевични тортиля, боб, сирене, сметана" }, category: "Мексиканско", cookingMethod: { temperature: "Средна за 15 мин", oil: "Без", healthierOil: "Без", steps: ["Запържете 400г кайма с тако подправки 10-12 мин", "Подгответе 8 тортиля и напълнете", "Гарнирайте с 1 авокадо, 100г сметана и 100г сирене"] }},
  { id: 58, name: "Начос с месо", image: "🧀", calories: 780, protein: 42, nutrition: { carbs: 68, fiber: 8, fat: 42, saturatedFat: 18, sugar: 6, sodium: 1580, carbSources: "царевични чипс, боб, сирене чедър" }, category: "Мексиканско", cookingMethod: { temperature: "180°C за 12-15 мин", oil: "Минимално", healthierOil: "Без", steps: ["Подредете 250г царевични чипс в тава", "Добавете 300г кайма, 150г боб и 150г сирене", "Печете при 180°C за 12-15 мин, добавете гуакамоле"] }},
  { id: 59, name: "Кесадия с пиле", image: "🫓", calories: 720, protein: 52, nutrition: { carbs: 52, fiber: 4, fat: 38, saturatedFat: 18, sugar: 4, sodium: 1280, carbSources: "пшеничени тортиля, сирене, чушки" }, category: "Мексиканско", cookingMethod: { temperature: "Средна за 8-10 мин", oil: "Минимално", healthierOil: "Без", steps: ["Напълнете 2 големи тортиля с 300г пиле и 150г сирене", "Добавете 100г чушки и халапеньо", "Печете от двете страни 4-5 мин, сервирайте със салса"] }},
  { id: 60, name: "Енчиладас плато", image: "🌯", calories: 820, protein: 52, nutrition: { carbs: 62, fiber: 8, fat: 44, saturatedFat: 20, sugar: 10, sodium: 1480, carbSources: "царевични тортиля, доматен сос, сирене" }, category: "Мексиканско", cookingMethod: { temperature: "180°C за 25-30 мин", oil: "Малко", healthierOil: "Спрей", steps: ["Напълнете 6 тортиля с 400г пиле и навийте", "Залейте с 400г доматен сос и 150г сирене", "Печете при 180°C за 25-30 мин"] }},
  { id: 61, name: "Фейжоада голяма", image: "🍲", calories: 920, protein: 62, nutrition: { carbs: 72, fiber: 22, fat: 42, saturatedFat: 16, sugar: 4, sodium: 1680, carbSources: "черен боб, ориз, фариня (маниока)" }, category: "Бразилско", cookingMethod: { temperature: "Ниска за 3-4 часа", oil: "Минимално", healthierOil: "Без", steps: ["Накиснете 400г черен боб 8 часа", "Добавете 300г свинско, 200г наденица и 100г бекон", "Варете бавно 3-4 часа, сервирайте с 200г ориз"] }},
  { id: 62, name: "Асай боул протеинов", image: "🫐", calories: 680, protein: 35, nutrition: { carbs: 82, fiber: 12, fat: 28, saturatedFat: 4, sugar: 42, sodium: 180, carbSources: "асай, банан, гранола, мед, плодове" }, category: "Бразилско", cookingMethod: { temperature: "Без", oil: "Без", healthierOil: "Без", steps: ["Смесете 200г асай пюре с 1 банан и 30г протеин", "Добавете 100г смесени плодове и 50г ядки", "Поръсете с 60г гранола и 2 с.л. мед"] }},
  { id: 63, name: "Севиче голямо", image: "🦐", calories: 520, protein: 52, nutrition: { carbs: 28, fiber: 4, fat: 18, saturatedFat: 3, sugar: 8, sodium: 1180, carbSources: "лайм сок, лук, царевица, чушки" }, category: "Перуанско", cookingMethod: { temperature: "Студено мариноване 20-30 мин", oil: "Без", healthierOil: "Без", steps: ["Нарежете 400г бяла риба и 150г скариди на кубчета", "Мариновайте в сок от 8-10 лайма 20-30 мин до непрозрачност", "Добавете 100г лук, 50г чушки, кориандър и царевица"] }},
  { id: 64, name: "Ломо салтадо", image: "🥩", calories: 820, protein: 58, nutrition: { carbs: 62, fiber: 6, fat: 38, saturatedFat: 12, sugar: 8, sodium: 1420, carbSources: "картофи пържени, ориз, домати, лук" }, category: "Перуанско", cookingMethod: { temperature: "Висока за 10-12 мин", oil: "Растително", healthierOil: "Намалено", steps: ["Запържете 400г говежди филенца на висок огън 3-4 мин", "Добавете 150г лук, 200г домати и соев сос", "Сервирайте с 200г пържени картофи и 150г ориз"] }},
  { id: 65, name: "Емпанадас плато", image: "🥟", calories: 780, protein: 42, nutrition: { carbs: 68, fiber: 4, fat: 42, saturatedFat: 16, sugar: 4, sodium: 1280, carbSources: "пшенично тесто, лук, картофи" }, category: "Аржентинско", cookingMethod: { temperature: "180°C за 25-30 мин", oil: "Без", healthierOil: "Печени", steps: ["Пригответе тесто от 300г брашно и масло", "Напълнете 10-12 емпанади с 400г кайма, лук и маслини", "Печете при 180°C за 25-30 мин, сервирайте със салата"] }},
  { id: 66, name: "Чимичури стейк", image: "🥩", calories: 920, protein: 68, nutrition: { carbs: 42, fiber: 4, fat: 56, saturatedFat: 22, sugar: 4, sodium: 980, carbSources: "картофи, магданоз, чесън" }, category: "Аржентинско", cookingMethod: { temperature: "Грил 250°C за 8-12 мин", oil: "Зехтин", healthierOil: "Умерено", steps: ["Пригответе чимичури сос от магданоз, чесън, зехтин и оцет", "Печете 400г стейк рибай на грил 4-6 мин на страна", "Сервирайте с 250г печени картофи и чимичури"] }},
  { id: 67, name: "Арепас с месо", image: "🫓", calories: 720, protein: 45, nutrition: { carbs: 62, fiber: 4, fat: 34, saturatedFat: 14, sugar: 4, sodium: 1080, carbSources: "царевично брашно, сирене, авокадо" }, category: "Венецуелско", cookingMethod: { temperature: "Средна за 15-18 мин", oil: "Минимално", healthierOil: "Печени", steps: ["Замесете тесто от 300г царевично брашно и вода", "Оформете 6 питки и печете 6-8 мин на страна", "Напълнете с 250г говеждо, 100г сирене и авокадо"] }},
  { id: 68, name: "Моле с пиле", image: "🍗", calories: 820, protein: 58, nutrition: { carbs: 58, fiber: 8, fat: 42, saturatedFat: 10, sugar: 18, sodium: 1380, carbSources: "ориз, шоколад, чушки, бадеми" }, category: "Мексиканско", cookingMethod: { temperature: "Ниска за 45-50 мин", oil: "Малко", healthierOil: "Намалено", steps: ["Пригответе моле сос от сушени чушки, шоколад и бадеми", "Сварете 500г пилешки бутчета 30 мин", "Залейте със соса и варете още 15 мин, сервирайте с 200г ориз"] }},
  { id: 69, name: "Чили кон карне голям", image: "🌶️", calories: 820, protein: 58, nutrition: { carbs: 62, fiber: 18, fat: 38, saturatedFat: 14, sugar: 12, sodium: 1480, carbSources: "боб червен, домати, царевица, ориз" }, category: "Мексиканско", cookingMethod: { temperature: "Ниска за 2-2.5 часа", oil: "Минимално", healthierOil: "Без", steps: ["Запържете 500г кайма с лук и чесън", "Добавете 300г боб, 400г домати и чили подправки", "Варете бавно 2-2.5 часа, сервирайте с ориз и сметана"] }},
  { id: 70, name: "Посоле", image: "🍲", calories: 780, protein: 55, nutrition: { carbs: 68, fiber: 10, fat: 32, saturatedFat: 10, sugar: 6, sodium: 1580, carbSources: "царевица хомини, зеле, репички, тортиля" }, category: "Мексиканско", cookingMethod: { temperature: "Ниска за 3 часа", oil: "Без", healthierOil: "Без", steps: ["Сварете 400г царевица хомини 2 часа", "Добавете 400г свинско рамо и гответе още 1 час", "Гарнирайте с зеле, репички, кълнове, лайм и тортиля чипс"] }},
  
  // Здравословни закуски (71-85)
  { id: 71, name: "Овесена каша с протеин", image: "🥣", calories: 680, protein: 42, nutrition: { carbs: 78, fiber: 12, fat: 24, saturatedFat: 4, sugar: 28, sodium: 220, carbSources: "овесени ядки, банан, мед, гранола" }, category: "Закуска", cookingMethod: { temperature: "Средна за 8-10 мин", oil: "Без", healthierOil: "Без", steps: ["Сварете 100г овесени ядки в 300мл мляко 8-10 мин", "Добавете 30г протеин на прах и 1 банан", "Поръсете с 50г ядки, 30г гранола и 2 с.л. мед"] }},
  { id: 72, name: "Авокадо тост с яйца", image: "🥑", calories: 720, protein: 38, nutrition: { carbs: 52, fiber: 14, fat: 42, saturatedFat: 10, sugar: 4, sodium: 680, carbSources: "пълнозърнест хляб, авокадо" }, category: "Закуска", cookingMethod: { temperature: "Средна за 10 мин", oil: "Без", healthierOil: "Без", steps: ["Препечете 2 филии пълнозърнест хляб", "Смачкайте 1.5 авокадо и разстелете", "Добавете 2 поширани яйца и 60г пушена сьомга"] }},
  { id: 73, name: "Смути боул с протеин", image: "🫐", calories: 680, protein: 42, nutrition: { carbs: 82, fiber: 10, fat: 22, saturatedFat: 4, sugar: 48, sodium: 180, carbSources: "банан, боровинки, гранола, мед" }, category: "Закуска", cookingMethod: { temperature: "Без", oil: "Без", healthierOil: "Без", steps: ["Смесете 150г замразени боровинки, 1 банан и 40г протеин", "Излейте в купа (дебела консистенция)", "Гарнирайте с 60г гранола, 40г ядки и пресни плодове"] }},
  { id: 74, name: "Яйца Бенедикт", image: "🥚", calories: 780, protein: 42, nutrition: { carbs: 42, fiber: 2, fat: 52, saturatedFat: 22, sugar: 4, sodium: 1280, carbSources: "английска мъфина, холандез (масло, яйца)" }, category: "Закуска", cookingMethod: { temperature: "Средна за 15 мин", oil: "Минимално", healthierOil: "Гръцко кисело мляко", steps: ["Поширайте 4 яйца в оцетна вода 3-4 мин", "Пригответе холандез от 3 жълтъка, лимон и 100г масло", "Сервирайте на 2 английски мъфини с 120г шунка"] }},
  { id: 75, name: "Чиа пудинг с протеин", image: "🥛", calories: 620, protein: 38, nutrition: { carbs: 58, fiber: 18, fat: 28, saturatedFat: 6, sugar: 24, sodium: 180, carbSources: "чиа семена, кокосово мляко, плодове, мед" }, category: "Закуска", cookingMethod: { temperature: "Без (престояване 4-8 часа)", oil: "Без", healthierOil: "Без", steps: ["Смесете 60г чиа с 300мл кокосово мляко и 30г протеин", "Охладете в хладилник нощем или минимум 4 часа", "Добавете 150г пресни плодове и 40г ядки"] }},
  { id: 76, name: "Протеинови палачинки", image: "🥞", calories: 720, protein: 52, nutrition: { carbs: 62, fiber: 8, fat: 32, saturatedFat: 8, sugar: 22, sodium: 480, carbSources: "овесени ядки, банан, мед, плодове" }, category: "Закуска", cookingMethod: { temperature: "Средна за 15 мин", oil: "Спрей", healthierOil: "Тефлон", steps: ["Смесете 100г овесени ядки, 4 яйца, 1 банан и 40г протеин", "Печете 6 големи палачинки по 2-3 мин на страна", "Сервирайте с 150г плодове и 3 с.л. мед"] }},
  { id: 77, name: "Гръцко кисело мляко боул", image: "🍯", calories: 680, protein: 48, nutrition: { carbs: 68, fiber: 6, fat: 28, saturatedFat: 8, sugar: 42, sodium: 180, carbSources: "гръцко кисело мляко, мед, гранола, плодове" }, category: "Закуска", cookingMethod: { temperature: "Без", oil: "Без", healthierOil: "Без", steps: ["Сложете 400г гръцко кисело мляко 10% в купа", "Добавете 3 с.л. мед и 150г смесени плодове", "Поръсете с 80г гранола и 50г ядки"] }},
  { id: 78, name: "Голям омлет с пълнеж", image: "🍳", calories: 720, protein: 52, nutrition: { carbs: 18, fiber: 4, fat: 48, saturatedFat: 18, sugar: 6, sodium: 1180, carbSources: "зеленчуци (чушки, домати, лук)" }, category: "Закуска", cookingMethod: { temperature: "Средна за 10-12 мин", oil: "Спрей", healthierOil: "Без", steps: ["Разбийте 5 яйца с 50мл мляко", "Добавете 100г сирене, 80г шунка и 100г зеленчуци", "Печете в тефлон тиган 10-12 мин, сгънете наполовина"] }},
  { id: 79, name: "Гранола боул", image: "🥣", calories: 720, protein: 32, nutrition: { carbs: 88, fiber: 12, fat: 32, saturatedFat: 8, sugar: 38, sodium: 120, carbSources: "овесени ядки, мед, ядки, сушени плодове" }, category: "Закуска", cookingMethod: { temperature: "150°C за 25-30 мин", oil: "Кокосово", healthierOil: "Намалено", steps: ["Смесете 200г овесени ядки с 3 с.л. мед и 2 с.л. кокосово масло", "Добавете 100г ядки и печете при 150°C за 25-30 мин", "Сервирайте 120г с 250мл мляко и пресни плодове"] }},
  { id: 80, name: "Тост с рикота и сьомга", image: "🍞", calories: 680, protein: 42, nutrition: { carbs: 48, fiber: 6, fat: 38, saturatedFat: 12, sugar: 4, sodium: 980, carbSources: "пълнозърнест хляб, рикота" }, category: "Закуска", cookingMethod: { temperature: "Без", oil: "Без", healthierOil: "Без", steps: ["Препечете 2 филии пълнозърнест хляб", "Намажете с 150г рикота и лимонов сок", "Добавете 120г пушена сьомга и половин авокадо"] }},
  { id: 81, name: "Плодова салата с протеин", image: "🍓", calories: 620, protein: 35, nutrition: { carbs: 78, fiber: 10, fat: 18, saturatedFat: 6, sugar: 58, sodium: 120, carbSources: "плодове (ягоди, банан, манго), гръцко кисело мляко" }, category: "Закуска", cookingMethod: { temperature: "Без", oil: "Без", healthierOil: "Без", steps: ["Нарежете 400г различни плодове (ягоди, банан, манго, киви)", "Добавете 200г гръцко кисело мляко и 25г протеин", "Поръсете с 50г ядки и 2 с.л. мед"] }},
  { id: 82, name: "Шакшука с хляб закуска", image: "🍳", calories: 720, protein: 42, nutrition: { carbs: 58, fiber: 10, fat: 38, saturatedFat: 12, sugar: 16, sodium: 1280, carbSources: "домати, чушки, пълнозърнест хляб, сирене" }, category: "Закуска", cookingMethod: { temperature: "Средна за 20-25 мин", oil: "Спрей", healthierOil: "Минимално", steps: ["Задушете 500г домати с 150г чушки и харисса 15 мин", "Счупете 5 яйца и добавете 80г фета", "Гответе покрито 6-8 мин, сервирайте с 2 филии хляб"] }},
  { id: 83, name: "Бананов смути протеинов", image: "🍌", calories: 680, protein: 45, nutrition: { carbs: 72, fiber: 8, fat: 28, saturatedFat: 8, sugar: 42, sodium: 280, carbSources: "банани, овесени ядки, мед, фъстъчено масло" }, category: "Закуска", cookingMethod: { temperature: "Без", oil: "Без", healthierOil: "Без", steps: ["Смесете 2 банана с 300мл мляко и 40г протеин", "Добавете 2 с.л. фъстъчено масло и 30г овесени ядки", "Миксирайте до гладко, поръсете с канела"] }},
  { id: 84, name: "Кефир смути с ядки", image: "🥛", calories: 620, protein: 35, nutrition: { carbs: 62, fiber: 8, fat: 28, saturatedFat: 6, sugar: 38, sodium: 320, carbSources: "кефир, банан, ядки, мед, овесени ядки" }, category: "Закуска", cookingMethod: { temperature: "Без", oil: "Без", healthierOil: "Без", steps: ["Смесете 400мл кефир с 1 банан и 100г плодове", "Добавете 50г ядки, 30г овесени ядки и 2 с.л. мед", "Миксирайте до гладко"] }},
  { id: 85, name: "Тофу скрамбъл голям", image: "🥗", calories: 680, protein: 45, nutrition: { carbs: 38, fiber: 12, fat: 42, saturatedFat: 8, sugar: 8, sodium: 880, carbSources: "тофу, зеленчуци, авокадо, хляб" }, category: "Закуска", cookingMethod: { temperature: "Средна за 12-15 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Нарошете 400г твърдо тофу на едри парчета", "Запържете с 2 ч.л. куркума, 150г чушки и 100г спанак", "Добавете 1 авокадо, сервирайте с 2 филии хляб"] }},
  
  // Супи и чорби (86-100)
  { id: 86, name: "Леща супа с хляб", image: "🍲", calories: 680, protein: 38, nutrition: { carbs: 82, fiber: 24, fat: 18, saturatedFat: 3, sugar: 8, sodium: 980, carbSources: "червена леща, морков, лук, пълнозърнест хляб" }, category: "Супа", cookingMethod: { temperature: "Средна за 35-40 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Сварете 300г червена леща с 150г морков и 100г лук 30 мин", "Добавете кимион, куркума и лимонов сок", "Сервирайте с 2 филии пълнозърнест хляб"] }},
  { id: 87, name: "Пилешки бульон с месо", image: "🍵", calories: 680, protein: 52, nutrition: { carbs: 48, fiber: 4, fat: 28, saturatedFat: 8, sugar: 4, sodium: 1480, carbSources: "фиде, морков, картофи, целина" }, category: "Супа", cookingMethod: { temperature: "Ниска за 1.5-2 часа", oil: "Без", healthierOil: "Без", steps: ["Сварете 1 цяло пиле (1.5кг) в 3л вода 1.5 часа", "Извадете месото, добавете 150г морков, 200г картофи и 150г фиде", "Варете още 15 мин, сервирайте с нарязаното месо"] }},
  { id: 88, name: "Крем супа от тиква с месо", image: "🎃", calories: 680, protein: 42, nutrition: { carbs: 52, fiber: 8, fat: 32, saturatedFat: 12, sugar: 18, sodium: 880, carbSources: "тиква, сметана, хляб" }, category: "Супа", cookingMethod: { temperature: "200°C за 35-40 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Печете 800г тиква при 200°C за 35-40 мин", "Смесете с 500мл бульон и 100мл сметана", "Добавете 200г печени пилешки гърди нарязани"] }},
  { id: 89, name: "Крем супа от броколи с пиле", image: "🥦", calories: 680, protein: 48, nutrition: { carbs: 38, fiber: 10, fat: 36, saturatedFat: 14, sugar: 8, sodium: 1080, carbSources: "броколи, мляко, картофи, сметана" }, category: "Супа", cookingMethod: { temperature: "Средна за 25-30 мин", oil: "Без", healthierOil: "Без", steps: ["Сварете 600г броколи и 150г картофи 20 мин", "Добавете 500мл бульон, 200мл мляко и пюрирайте", "Добавете 250г нарязано пиле и 50мл сметана"] }},
  { id: 90, name: "Зеленчуков бульон с месо", image: "🥕", calories: 680, protein: 45, nutrition: { carbs: 42, fiber: 10, fat: 28, saturatedFat: 10, sugar: 12, sodium: 1280, carbSources: "морков, картофи, целина, грах, фасул" }, category: "Супа", cookingMethod: { temperature: "Ниска за 2-2.5 часа", oil: "Без", healthierOil: "Без", steps: ["Сварете 400г говеждо в 2л вода 1.5 часа", "Добавете 200г морков, 200г картофи, 100г целина, 100г грах", "Варете още 30-40 мин, сервирайте с месото нарязано"] }},
  { id: 91, name: "Гъбена супа със сметана", image: "🍄", calories: 680, protein: 32, nutrition: { carbs: 48, fiber: 6, fat: 42, saturatedFat: 22, sugar: 8, sodium: 1180, carbSources: "гъби, картофи, сметана, крутони, хляб" }, category: "Супа", cookingMethod: { temperature: "Средна за 30-35 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Задушете 500г смесени гъби с 100г лук 15 мин", "Добавете 800мл бульон, 150г картофи и 150мл сметана", "Сервирайте с крутони и 2 филии хляб"] }},
  { id: 92, name: "Супа от грах със шунка", image: "🟢", calories: 720, protein: 42, nutrition: { carbs: 72, fiber: 22, fat: 28, saturatedFat: 8, sugar: 10, sodium: 1480, carbSources: "сух грах, морков, картофи, шунка" }, category: "Супа", cookingMethod: { temperature: "Средна за 1.5 часа", oil: "Без", healthierOil: "Без", steps: ["Сварете 300г сух грах 1 час до омекване", "Добавете 200г шунка, 100г морков и 150г картофи", "Пюрирайте наполовина, сервирайте с чесново масло"] }},
  { id: 93, name: "Рибена чорба голяма", image: "🐟", calories: 720, protein: 58, nutrition: { carbs: 42, fiber: 4, fat: 32, saturatedFat: 8, sugar: 8, sodium: 1380, carbSources: "картофи, домати, морков, хляб" }, category: "Супа", cookingMethod: { temperature: "Средна за 45-50 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Сварете рибен бульон от 400г рибни глави и кости 30 мин", "Добавете 500г риба (шаран/сом), 200г картофи и 200г домати", "Сервирайте с лимон и 2 филии хляб"] }},
  { id: 94, name: "Царевична супа с пиле", image: "🌽", calories: 680, protein: 45, nutrition: { carbs: 62, fiber: 6, fat: 28, saturatedFat: 10, sugar: 12, sodium: 1180, carbSources: "царевица, картофи, мляко, сметана" }, category: "Супа", cookingMethod: { temperature: "Средна за 30-35 мин", oil: "Масло", healthierOil: "Без", steps: ["Сварете 400г царевица и 150г картофи 20 мин", "Добавете 300мл мляко, 100мл сметана и 250г нарязано пиле", "Пюрирайте наполовина за кремообразна текстура"] }},
  { id: 95, name: "Доматена супа с риба", image: "🍅", calories: 680, protein: 48, nutrition: { carbs: 42, fiber: 8, fat: 32, saturatedFat: 8, sugar: 18, sodium: 1280, carbSources: "домати, хляб, чесън" }, category: "Супа", cookingMethod: { temperature: "200°C за 30 мин + средна", oil: "Зехтин", healthierOil: "Минимално", steps: ["Печете 800г домати с чесън при 200°C за 30 мин", "Добавете 500мл бульон и пюрирайте", "Добавете 300г печена риба, сервирайте с крутони"] }},
  { id: 96, name: "Картофена супа с бекон", image: "🥔", calories: 720, protein: 35, nutrition: { carbs: 58, fiber: 6, fat: 42, saturatedFat: 18, sugar: 8, sodium: 1480, carbSources: "картофи, мляко, сметана, лук" }, category: "Супа", cookingMethod: { temperature: "Средна за 35-40 мин", oil: "Без", healthierOil: "Без", steps: ["Сварете 600г картофи с 150г лук и 100г целина 25 мин", "Добавете 600мл бульон, 200мл мляко и 100мл сметана", "Добавете 150г печен бекон и пресен лук"] }},
  { id: 97, name: "Супа от спанак с яйца", image: "🥬", calories: 620, protein: 38, nutrition: { carbs: 38, fiber: 8, fat: 36, saturatedFat: 12, sugar: 6, sodium: 1080, carbSources: "спанак, ориз, кисело мляко" }, category: "Супа", cookingMethod: { temperature: "Средна за 25-30 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Задушете 500г спанак с 100г лук 10 мин", "Добавете 800мл бульон и 80г ориз, варете 15 мин", "Добавете 4 поширани яйца и 100мл кисело мляко"] }},
  { id: 98, name: "Френска лучена супа", image: "🧅", calories: 680, protein: 28, nutrition: { carbs: 58, fiber: 6, fat: 36, saturatedFat: 18, sugar: 18, sodium: 1680, carbSources: "лук карамелизиран, хляб, грюер сирене" }, category: "Супа", cookingMethod: { temperature: "Ниска за 1 час + 200°C за 10 мин", oil: "Масло", healthierOil: "Зехтин", steps: ["Карамелизирайте 800г лук в 50г масло на нисък огън 45-60 мин", "Добавете 1л говежди бульон и 100мл бяло вино", "Сервирайте с хляб и 150г грюер, запечете при 200°C за 10 мин"] }},
  { id: 99, name: "Харчо супа", image: "🍲", calories: 720, protein: 48, nutrition: { carbs: 52, fiber: 4, fat: 34, saturatedFat: 12, sugar: 8, sodium: 1380, carbSources: "ориз, орехи, домати, ткемали сос" }, category: "Супа", cookingMethod: { temperature: "Средна за 1.5 часа", oil: "Зехтин", healthierOil: "Минимално", steps: ["Сварете 400г говеждо в 1.5л вода 1 час", "Добавете 100г ориз, 200г домати и 80г орехи", "Овкусете с кориандър, чесън и ткемали сос"] }},
  { id: 100, name: "Том Кха Гай голям", image: "🥥", calories: 720, protein: 52, nutrition: { carbs: 38, fiber: 4, fat: 46, saturatedFat: 32, sugar: 10, sodium: 1580, carbSources: "кокосово мляко, гъби, галангал" }, category: "Супа", cookingMethod: { temperature: "Средна за 25-30 мин", oil: "Без", healthierOil: "Без", steps: ["Сварете 500мл кокосово мляко с галангал, лемонграс и кафяво листо", "Добавете 400г пиле нарязано и 150г гъби", "Овкусете с рибен сос, лайм и кориандър, добавете чили"] }},
  
  // Салати (101-115)
  { id: 101, name: "Цезар салата с пиле", image: "🥗", calories: 720, protein: 52, nutrition: { carbs: 32, fiber: 6, fat: 46, saturatedFat: 12, sugar: 4, sodium: 1280, carbSources: "крутони, пармезан, цезар дресинг" }, category: "Салата", cookingMethod: { temperature: "200°C за 20-25 мин", oil: "Зехтин", healthierOil: "Кисело мляко дресинг", steps: ["Накъсайте 400г ромейн салата", "Печете 300г пилешки гърди при 200°C за 20-25 мин и нарежете", "Добавете 80г крутони, 50г пармезан и цезар дресинг"] }},
  { id: 102, name: "Салата с киноа и пиле", image: "🥗", calories: 720, protein: 48, nutrition: { carbs: 62, fiber: 10, fat: 32, saturatedFat: 6, sugar: 8, sodium: 680, carbSources: "киноа, нахут, зеленчуци" }, category: "Салата", cookingMethod: { temperature: "200°C за 20 мин", oil: "Зехтин", healthierOil: "Лимонов сок", steps: ["Сварете 150г киноа 15 мин и охладете", "Печете 250г пиле при 200°C за 20 мин", "Добавете 100г нахут, краставици, домати и лимонов дресинг"] }},
  { id: 103, name: "Азиатска салата с говеждо", image: "🥗", calories: 680, protein: 48, nutrition: { carbs: 42, fiber: 8, fat: 38, saturatedFat: 10, sugar: 18, sodium: 1480, carbSources: "оризови нудли, зеле, морков, едамаме" }, category: "Салата", cookingMethod: { temperature: "Висока за 5-6 мин", oil: "Сусамово", healthierOil: "Минимално", steps: ["Нарежете 200г зеле, 150г морков и 100г краставици", "Запържете 300г говежди филенца 5-6 мин", "Добавете 100г едамаме и полейте със соев-сусамов дресинг"] }},
  { id: 104, name: "Салата с нахут и фета", image: "🥗", calories: 680, protein: 32, nutrition: { carbs: 62, fiber: 16, fat: 36, saturatedFat: 12, sugar: 10, sodium: 1180, carbSources: "нахут, краставици, домати, питка" }, category: "Салата", cookingMethod: { temperature: "Без", oil: "Зехтин", healthierOil: "Лимонов сок", steps: ["Отцедете 400г нахут (консервиран или сварен)", "Нарежете 200г краставици, 200г домати, 100г чушки", "Добавете 150г фета, маслини и 3 с.л. зехтин дресинг"] }},
  { id: 105, name: "Салата с авокадо и яйца", image: "🥑", calories: 720, protein: 38, nutrition: { carbs: 32, fiber: 16, fat: 52, saturatedFat: 12, sugar: 6, sodium: 680, carbSources: "авокадо, хляб крутони, зеленчуци" }, category: "Салата", cookingMethod: { temperature: "Средна за 10 мин", oil: "Зехтин", healthierOil: "Умерено", steps: ["Сварете 4 яйца за 8 мин (меки) и нарежете", "Нарежете 2 авокадо, 150г чери домати и 100г ракета", "Добавете 80г крутони и полейте с лимоново-зехтинов дресинг"] }},
  { id: 106, name: "Салата с риба тон протеинова", image: "🐟", calories: 680, protein: 52, nutrition: { carbs: 28, fiber: 6, fat: 42, saturatedFat: 8, sugar: 6, sodium: 1080, carbSources: "боб зелен, картофи, маслини, яйца" }, category: "Салата", cookingMethod: { temperature: "Без", oil: "Зехтин", healthierOil: "Минимално", steps: ["Отцедете 350г риба тон", "Добавете 200г зелен боб, 150г чери домати и 3 яйца", "Смесете с 80г маслини и лимоново-зехтинов дресинг"] }},
  { id: 107, name: "Кобб салата", image: "🥗", calories: 780, protein: 52, nutrition: { carbs: 28, fiber: 8, fat: 56, saturatedFat: 18, sugar: 8, sodium: 1380, carbSources: "авокадо, домати, синьо сирене, бекон" }, category: "Салата", cookingMethod: { temperature: "200°C за 20 мин + средна", oil: "Зехтин", healthierOil: "Намален дресинг", steps: ["Нарежете 300г печено пиле, 2 яйца, 1 авокадо на редове", "Добавете 150г чери домати, 100г бекон и 80г синьо сирене", "Подредете в купа и полейте с ранч дресинг"] }},
  { id: 108, name: "Уолдорф салата с пиле", image: "🍎", calories: 680, protein: 42, nutrition: { carbs: 42, fiber: 8, fat: 42, saturatedFat: 8, sugar: 28, sodium: 580, carbSources: "ябълки, грозде, орехи, целина" }, category: "Салата", cookingMethod: { temperature: "200°C за 20 мин", oil: "Без", healthierOil: "Гръцко кисело мляко", steps: ["Нарежете 2 ябълки, 150г целина и 100г грозде", "Добавете 250г печено пиле и 80г орехи", "Смесете с дресинг от 150г гръцко кисело мляко и майонеза"] }},
  { id: 109, name: "Салата с цвекло и козе сирене", image: "🥗", calories: 680, protein: 32, nutrition: { carbs: 48, fiber: 10, fat: 42, saturatedFat: 14, sugar: 32, sodium: 780, carbSources: "цвекло, орехи, мед, зеленина" }, category: "Салата", cookingMethod: { temperature: "200°C за 45-50 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Печете 500г цвекло при 200°C за 45-50 мин, охладете и нарежете", "Подредете върху 200г ракета или спанак", "Добавете 150г козе сирене, 80г орехи и медено-балсамов дресинг"] }},
  { id: 110, name: "Салата с грилирано пиле и манго", image: "🥗", calories: 680, protein: 45, nutrition: { carbs: 48, fiber: 6, fat: 32, saturatedFat: 8, sugar: 32, sodium: 580, carbSources: "манго, авокадо, ядки, лайм" }, category: "Салата", cookingMethod: { temperature: "Скара 200°C за 8-10 мин", oil: "Зехтин", healthierOil: "Лимонов сок", steps: ["Грилирайте 300г пиле при 200°C за 8-10 мин", "Нарежете 1 манго, 1 авокадо и 100г чери домати", "Добавете 50г ядки и полейте с лаймов дресинг"] }},
  { id: 111, name: "Капрезе с моцарела", image: "🍅", calories: 680, protein: 38, nutrition: { carbs: 18, fiber: 4, fat: 52, saturatedFat: 22, sugar: 8, sodium: 980, carbSources: "домати, моцарела, босилек" }, category: "Салата", cookingMethod: { temperature: "Без", oil: "Зехтин", healthierOil: "Умерено", steps: ["Нарежете 400г домати и 300г моцарела на резени", "Подредете с пресен босилек", "Полейте с 3 с.л. зехтин и балсамов оцет, добавете 200г печено пиле"] }},
  { id: 112, name: "Тайска салата с говеждо", image: "🥗", calories: 720, protein: 48, nutrition: { carbs: 42, fiber: 6, fat: 42, saturatedFat: 12, sugar: 22, sodium: 1580, carbSources: "оризови нудли, лайм, фъстъци, чили" }, category: "Салата", cookingMethod: { temperature: "Висока за 5-6 мин", oil: "Сусамово", healthierOil: "Минимално", steps: ["Запържете 300г говежди филенца 5-6 мин и нарежете тънко", "Смесете с 150г зеле, 100г морков, мента и кориандър", "Полейте с дресинг от лайм, рибен сос и чили, поръсете с 50г фъстъци"] }},
  { id: 113, name: "Детокс зелена салата", image: "🥬", calories: 620, protein: 35, nutrition: { carbs: 42, fiber: 14, fat: 38, saturatedFat: 6, sugar: 12, sodium: 480, carbSources: "авокадо, краставици, спанак, зелена ябълка, семена" }, category: "Салата", cookingMethod: { temperature: "Без", oil: "Зехтин", healthierOil: "Лимонов сок", steps: ["Накъсайте 200г спанак и 100г кейл", "Добавете 1 авокадо, 150г краставици и 1 зелена ябълка", "Добавете 200г печено пиле и полейте с лимонов дресинг"] }},
  { id: 114, name: "Мексиканска салата с царевица", image: "🌽", calories: 720, protein: 42, nutrition: { carbs: 62, fiber: 14, fat: 36, saturatedFat: 12, sugar: 10, sodium: 1180, carbSources: "царевица, черен боб, чедър, тортиля чипс" }, category: "Салата", cookingMethod: { temperature: "200°C за 20 мин", oil: "Зехтин", healthierOil: "Минимално", steps: ["Грилирайте 200г царевица и 200г чушки", "Добавете 200г черен боб, 200г домати и 100г сирене", "Печете 250г пиле при 200°C за 20 мин, добавете с тортиля чипс и ранч дресинг"] }},
  { id: 115, name: "Средиземноморска салата с паста", image: "🍝", calories: 720, protein: 38, nutrition: { carbs: 72, fiber: 8, fat: 32, saturatedFat: 10, sugar: 10, sodium: 1080, carbSources: "паста, сушени домати, маслини, артишок" }, category: "Салата", cookingMethod: { temperature: "Средна за 15 мин", oil: "Зехтин", healthierOil: "Умерено", steps: ["Сварете 200г фузили ал денте и охладете", "Добавете 100г сушени домати, 80г маслини и 100г артишок", "Смесете с 200г печено пиле, фета и 3 с.л. зехтин дресинг"] }},
];

// Helper: get unique image per recipe – dish-specific generated photos first
const getRecipeImage = (recipe: Recipe): string => {
  const n = recipe.name.toLowerCase();

  // ═══ PER-DISH exact matches (realistic generated photos) ═══
  if (n.includes("шопска салата")) return "/images/food/shopska-salata.jpg";
  if (n.includes("таратор")) return "/images/food/tarator.jpg";
  if (n.includes("боб чорба")) return "/images/food/bob-chorba.jpg";
  if (n.includes("пълнени чушки")) return "/images/food/palneni-chushki.jpg";
  if (n.includes("агнешко")) return "/images/food/agneshko.jpg";
  if (n.includes("мусака")) return "/images/food/musaka.jpg";
  if (n.includes("кюфтета")) return "/images/food/kyufteta.jpg";
  if (n.includes("кашкавал пане")) return "/images/food/kashkaval-pane.jpg";
  if (n.includes("баница")) return "/images/food/banitsa.jpg";
  if (n.includes("капама")) return "/images/food/kapama.jpg";
  if (n.includes("яхния")) return "/images/food/yahnia.jpg";
  if (n.includes("пилешка супа") || n.includes("супа с фиде")) return "/images/food/pileshka-supa.jpg";
  if (n.includes("гювеч")) return "/images/food/gyuvech.jpg";
  if (n.includes("дроб сарма")) return "/images/food/drob-sarma.jpg";
  if (n.includes("печена риба")) return "/images/food/pechena-riba.jpg";
  if (n.includes("терияки")) return "/images/food/teriyaki.jpg";
  if (n.includes("суши")) return "/images/food/sushi-plate.jpg";
  if (n.includes("рамен")) return "/images/food/ramen.jpg";
  if (n.includes("донбури")) return "/images/food/donburi.jpg";
  if (n.includes("пад тай")) return "/images/food/pad-thai.jpg";
  if (n.includes("цезар салата")) return "/images/food/caesar-salad.jpg";

  // ═══ DISH TYPE matches ═══
  if (n.includes("фо бо") || n.includes("фо ")) return "/images/food/noodle-bowl.jpg";
  if (n.includes("шакшука")) return "/images/food/shakshuka.jpg";
  if (n.includes("пълнен") || n.includes("чушки с месо")) return "/images/food/palneni-chushki.jpg";
  if (n.includes("сувлаки") || n.includes("кебаб") || n.includes("шиш") || n.includes("адана")) return "/images/food/kebab-skewer.jpg";
  if (n.includes("паста") || n.includes("лазаня") || n.includes("ризото") || n.includes("карбонара") || n.includes("болонезе")) return "/images/food/pasta-plate.jpg";
  if (n.includes("тако") || n.includes("начос") || n.includes("буритос") || n.includes("енчилада")) return "/images/food/tacos-plate.jpg";
  if (n.includes("дим сум") || n.includes("самоса") || n.includes("емпанад") || n.includes("гьоза")) return "/images/food/dumplings-plate.jpg";
  if (n.includes("гирос") || n.includes("фалафел") || n.includes("арепас") || n.includes("шаурма") || n.includes("дюнер")) return "/images/food/wrap-pita.jpg";
  if (n.includes("киш") || n.includes("чурос") || n.includes("тиропита") || n.includes("бурек")) return "/images/food/pastry-pie.jpg";
  if (n.includes("стейк") || n.includes("bbq") || n.includes("свинско печено") || n.includes("телешко печено")) return "/images/food/roast-meat.jpg";
  if (n.includes("скара") || n.includes("грил") || n.includes("кебапче")) return "/images/food/kyufteta.jpg";
  if (n.includes("къри") || n.includes("масала") || n.includes("далл") || n.includes("бирияни") || n.includes("тандури") || n.includes("тикка")) return "/images/food/curry-dish.jpg";
  if (n.includes("риба") || n.includes("сьомга") || n.includes("тунец") || n.includes("ципура") || n.includes("лаврак")) return "/images/food/pechena-riba.jpg";
  if (n.includes("морски") || n.includes("скариди") || n.includes("миди") || n.includes("севиче") || n.includes("паеля")) return "/images/food/seafood-plate.jpg";
  if (n.includes("бибимбап") || n.includes("оризова купа") || n.includes("поке")) return "/images/food/rice-bowl.jpg";
  if (n.includes("смути") || n.includes("протеинов шейк")) return "/images/food/smoothie.jpg";
  if (n.includes("салата")) return "/images/food/salad.jpg";
  if (n.includes("супа") || n.includes("бульон") || n.includes("чорба") || n.includes("крем супа") || n.includes("том ям") || n.includes("том кха")) return "/images/food/soup.jpg";
  if (n.includes("нудли") || n.includes("якисоба") || n.includes("удон")) return "/images/food/noodle-bowl.jpg";
  if (n.includes("ориз") || n.includes("пилаф")) return "/images/food/rice-bowl.jpg";
  if (n.includes("пане")) return "/images/food/kashkaval-pane.jpg";
  if (n.includes("пиле") || n.includes("пилешк")) return "/images/food/teriyaki.jpg";
  if (n.includes("говежд") || n.includes("телешк") || n.includes("свинск")) return "/images/food/roast-meat.jpg";
  if (n.includes("моле")) return "/images/food/curry-dish.jpg";
  if (n.includes("десерт") || n.includes("торта") || n.includes("панакота") || n.includes("крем брюле")) return "/images/food/dessert.jpg";
  if (n.includes("закуска") || n.includes("омлет") || n.includes("гранола") || n.includes("палачинки")) return "/images/food/breakfast.jpg";

  // ═══ CATEGORY fallback ═══
  const categoryMap: Record<string, string> = {
    "Български": "/images/food/bulgarian.jpg",
    "Японско": "/images/food/japanese.jpg",
    "Тайландско": "/images/food/thai.jpg",
    "Китайско": "/images/food/chinese.jpg",
    "Индийско": "/images/food/indian.jpg",
    "Гръцко": "/images/food/greek.jpg",
    "Италианско": "/images/food/italian.jpg",
    "Мексиканско": "/images/food/mexican.jpg",
    "Корейско": "/images/food/korean.jpg",
    "Виетнамско": "/images/food/vietnamese.jpg",
    "Израелско": "/images/food/israeli.jpg",
    "Ливанско": "/images/food/lebanese.jpg",
    "Френско": "/images/food/french.jpg",
    "Испанско": "/images/food/spanish.jpg",
    "Закуска": "/images/food/breakfast.jpg",
    "Супа": "/images/food/soup.jpg",
    "Бразилско": "/images/food/brazilian.jpg",
    "Перуанско": "/images/food/seafood-plate.jpg",
    "Аржентинско": "/images/food/grilled-meat.jpg",
    "Венецуелско": "/images/food/wrap-pita.jpg",
    "Американско": "/images/food/american.jpg",
    "Десерт": "/images/food/dessert.jpg",
    "Салата": "/images/food/salad.jpg",
  };
  return categoryMap[recipe.category] || "/images/food/mediterranean.jpg";
};

// YouTube search URL (opens in new tab or modal)
const getYoutubeSearchUrl = (recipeName: string): string => {
  const query = encodeURIComponent(`${recipeName} рецепта как се прави`);
  return `https://www.youtube.com/results?search_query=${query}`;
};

// Map of dish names to real YouTube video IDs
const youtubeVideoMap: Record<string, string> = {
  "баница": "qKGiB1fJyKE",
  "таратор": "T7TJoGmHCuI",
  "шопска салата": "5GRr1MiYFgI",
  "мусака": "JCbSQH8GwOc",
  "кюфтета": "pVxJhBFBGW8",
  "пълнени чушки": "tYy6HFnMs6c",
  "боб чорба": "RHNdB2nJz1g",
  "агнешко": "dVz_vR15mkA",
  "капама": "4qCbiMxLoko",
  "гювеч": "TuV4Z5uXjhM",
  "кашкавал пане": "YOAVbBnwZbU",
  "яхния": "LZ-Z0cMFT3Q",
  "дроб сарма": "VHwFm-v40bM",
  "печена риба": "Q3pJbBF0TZc",
  "пилешка супа": "V8BBlOaHD8A",
  "ramen": "KUhHJBEFnSk",
  "pad thai": "qH-gDEcMNLY",
  "teriyaki": "0V2CF-9Ao44",
  "caesar salad": "a4Z2x0sPbIc",
  "sushi": "joXfEg2kSJk",
  "pasta": "bJUiWdM__Qw",
  "pizza": "sv3TXMSv6to",
  "tacos": "uxFhSHjOeYI",
  "curry": "w1BnQbSxhWU",
  "steak": "AmC9SmCBUj4",
  "soup": "IxnPIjht61o",
  "salad": "O-cPA3M7ZEE",
  // Verified chef videos (confirmed via YouTube oEmbed)
  "пиле с грах": "glYpHoDHYw8",      // Иван Звездев
  "мехлета": "mqJtU6vVV-0",           // Иван Звездев
  "шкембе": "6abwrpur7Bo",            // Иван Звездев
  "poke": "guXtz64bIlo",              // Joshua Weissman
  "chicken salad": "cSAGdGSdE6k",     // Lisa Bryan (Downshiftology)
};

// Verified recipes with full chef attribution (source links confirmed live)
export interface VerifiedRecipe {
  name: string;
  chef: string;
  chefUrl: string;
  sourceUrl: string;
  youtubeId: string;
  servings: number;
  prepMin: number;
  cookMin: number;
  category: string;
  ingredients: string[];
  steps: string[];
  nutrition: { kcal: number; protein: number; carbs: number; fat: number; fiber: number; sugar: number; sodium: number };
}

export const verifiedRecipes: VerifiedRecipe[] = [
  {
    name: "Пиле с грах",
    chef: "Иван Звездев",
    chefUrl: "https://zvezdev.com",
    sourceUrl: "https://zvezdev.com/рецепта/пиле-с-грах",
    youtubeId: "glYpHoDHYw8",
    servings: 4, prepMin: 15, cookMin: 30, category: "Български",
    ingredients: ["2 пилешки бутчета/бедра", "10 зърна черен пипер", "1 дафинов лист", "1 морков", "1 глава лук", "1 стебло целина", "2 скилидки чесън", "1 с.л. доматено пюре", "1 ч.л. червен пипер", "500 г замразен грах", "1 с.л. брашно", "2-3 с.л. олио", "копър и магданоз", "3-4 консервирани обелени домата", "30 г масло", "сол на вкус"],
    steps: ["Сварете пилето 10 мин с дафинов лист, черен пипер и сол.", "Нарежете ситно целина, морков и лук.", "Запържете зеленчуците в олио 1 мин, добавете целина и сол.", "Добавете брашно и червен пипер, после домати и ½ чаша гореща вода; задушете. Добавете чесън, копър, магданоз и масло; прехвърлете в гювеч.", "Подредете пилето отгоре, залейте с прецеден бульон и печете на 180°C 15 мин; добавете отцедения грах и завършете с червен пипер."],
    nutrition: { kcal: 380, protein: 28, carbs: 16, fat: 22, fiber: 5, sugar: 5, sodium: 520 },
  },
  {
    name: "Мехлета с булгур",
    chef: "Иван Звездев",
    chefUrl: "https://zvezdev.com",
    sourceUrl: "https://zvezdev.com/рецепта/мехлета",
    youtubeId: "mqJtU6vVV-0",
    servings: 4, prepMin: 15, cookMin: 30, category: "Български",
    ingredients: ["1 глава лук", "3 малки моркова (150 г)", "4-5 домата (300 г)", "1 чаша булгур (150 г)", "4-5 с.л. олио", "1 клонка чубрица", "5 стръка магданоз", "сол"],
    steps: ["Нарежете лука на ситно.", "Запържете лука в олио 2 мин.", "Добавете морковите на колелца, запържете 1-2 мин.", "Измийте булгура няколко пъти.", "Нарежете доматите на едри парчета.", "Сложете лук, моркови и булгур в глинен съд, залейте с 3 чаши гореща вода и сол, покрийте с домати.", "Печете покрито на 180°C около 30 мин.", "На 20-ата минута добавете чубрица; гарнирайте с магданоз."],
    nutrition: { kcal: 220, protein: 5, carbs: 34, fat: 8, fiber: 6, sugar: 5, sodium: 380 },
  },
  {
    name: "Агнешка шкембе чорба",
    chef: "Иван Звездев",
    chefUrl: "https://zvezdev.com",
    sourceUrl: "https://zvezdev.com/рецепта/агнешка-шкембе-чорба",
    youtubeId: "6abwrpur7Bo",
    servings: 6, prepMin: 20, cookMin: 40, category: "Български",
    ingredients: ["1 агнешко шкембе", "1 глава лук", "1 морков", "200 мл мляко", "5 стръка мента (или 1 ч.л. сушена)", "2 скилидки чесън", "5 с.л. олио", "2 яйца", "2 с.л. брашно", "10 зърна черен пипер", "25 г масло", "2 ч.л. сол"],
    steps: ["Сварете шкембето под налягане с лук, морков, сол, пипер и мента 30 мин; нарежете на кубчета и прецедете бульона.", "Врийте бульона с кубчетата шкембе и счукан чесън 5 мин.", "Разбийте брашно, мляко и яйца на застройка.", "Темперирайте с няколко черпака горещ бульон.", "Загрейте олио и масло, добавете червен пипер, запържете кратко и добавете към застройката.", "Свалете от огъня, влейте застройката; сервирайте с чесън и оцет."],
    nutrition: { kcal: 210, protein: 18, carbs: 6, fat: 12, fiber: 0.5, sugar: 2, sodium: 640 },
  },
  {
    name: "Поке боул с риба тон",
    chef: "Joshua Weissman",
    chefUrl: "https://www.joshuaweissman.com",
    sourceUrl: "https://www.joshuaweissman.com/recipes/best-homemade-poke-bowl-recipe",
    youtubeId: "guXtz64bIlo",
    servings: 2, prepMin: 5, cookMin: 25, category: "Международно",
    ingredients: ["2 скилидки чесън", "2 с.л. чили крисп", "1.5 с.л. остър сос", "2 с.л. шою", "1 с.л. сок от юзу", "1.5 ч.л. сусамово олио", "1 с.л. мирин", "500 г сашими тон", "2 чаши суши ориз", "4-6 шалота", "олио за пържене", "½ краставица", "авокадо", "тай босилек", "кориандър"],
    steps: ["Разбийте маринатата; мариновайте нарязания тон поне 1 час.", "Сварете ориза.", "Изпържете тънко нарязан шалот до златисто; отцедете и осолете.", "Нарежете краставица и авокадо.", "Сглобете боула: ориз, тон с марината, краставица, билки, пържен шалот."],
    nutrition: { kcal: 520, protein: 34, carbs: 55, fat: 16, fiber: 3, sugar: 4, sodium: 850 },
  },
  {
    name: "Пилешка салата Ultimate",
    chef: "Lisa Bryan (Downshiftology)",
    chefUrl: "https://downshiftology.com",
    sourceUrl: "https://downshiftology.com/recipes/chicken-salad/",
    youtubeId: "cSAGdGSdE6k",
    servings: 6, prepMin: 10, cookMin: 15, category: "Международно",
    ingredients: ["пилешки гърди", "майонеза", "дижонска горчица", "червено грозде", "целина", "пресен лук", "препечени бадеми", "магданоз", "естрагон", "сол и пипер"],
    steps: ["Поаширайте пилето в подсолена вода ~10 мин до 75°C вътрешна температура.", "Оставете да почива, после охладете.", "Препечете бадемите; нарежете охладеното пиле на кубчета.", "Нарежете грозде, целина, магданоз, естрагон и пресен лук.", "Смесете всичко с майонеза и дижон, подправете.", "Охладете поне 30 мин преди сервиране."],
    nutrition: { kcal: 290, protein: 24, carbs: 8, fat: 18, fiber: 1, sugar: 6, sodium: 320 },
  },
];

// Card for a verified chef recipe: full credit, video, ingredients, steps, nutrition
function VerifiedRecipeCard({ recipe, index }: { recipe: VerifiedRecipe; index: number }) {
  const [open, setOpen] = useState(false);
  const [showVideo, setShowVideo] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.08, 0.4), ease: [0.25, 0.46, 0.45, 0.94] }}
    >
      <Card className="overflow-hidden bg-card border border-border rounded-3xl shadow-sm hover:shadow-md transition-shadow duration-300">
        <div className="p-6">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div>
              <h3 className="text-xl font-display font-bold text-foreground">{recipe.name}</h3>
              <p className="text-sm text-muted-foreground mt-1">
                от{" "}
                <a href={recipe.chefUrl} target="_blank" rel="noopener noreferrer" className="text-primary font-medium hover:underline">
                  {recipe.chef}
                </a>
              </p>
            </div>
            <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full font-medium whitespace-nowrap">
              {recipe.category}
            </span>
          </div>

          <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mb-4">
            <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{recipe.prepMin}+{recipe.cookMin} мин</span>
            <span className="flex items-center gap-1"><Flame className="w-3.5 h-3.5" />{recipe.nutrition.kcal} kcal</span>
            <span className="flex items-center gap-1"><Beef className="w-3.5 h-3.5" />{recipe.nutrition.protein}г протеин</span>
            <span>{recipe.servings} порции</span>
          </div>

          <div className="flex gap-2">
            <Button size="sm" variant="outline" className="rounded-full" onClick={() => setOpen(!open)}>
              {open ? "Скрий детайли" : "Виж рецептата"}
            </Button>
            <Button size="sm" className="rounded-full" onClick={() => setShowVideo(!showVideo)}>
              <Play className="w-3.5 h-3.5 mr-1" />
              {showVideo ? "Скрий видео" : "Гледай видео"}
            </Button>
          </div>

          {showVideo && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="mt-4">
              <div className="aspect-video rounded-2xl overflow-hidden">
                <iframe
                  src={`https://www.youtube-nocookie.com/embed/${recipe.youtubeId}?rel=0`}
                  className="w-full h-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  title={`${recipe.name} — ${recipe.chef}`}
                />
              </div>
            </motion.div>
          )}

          {open && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="mt-5 space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-2 text-foreground">Продукти</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  {recipe.ingredients.map((ing, i) => <li key={i}>{ing}</li>)}
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2 text-foreground">Стъпки</h4>
                <ol className="text-sm text-muted-foreground space-y-1.5 list-decimal list-inside">
                  {recipe.steps.map((s, i) => <li key={i}>{s}</li>)}
                </ol>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                {[
                  { l: "kcal", v: recipe.nutrition.kcal },
                  { l: "Протеин", v: `${recipe.nutrition.protein}г` },
                  { l: "Въгл.", v: `${recipe.nutrition.carbs}г` },
                  { l: "Мазн.", v: `${recipe.nutrition.fat}г` },
                ].map((n) => (
                  <div key={n.l} className="bg-muted/50 rounded-xl py-2">
                    <div className="font-bold text-foreground">{n.v}</div>
                    <div className="text-muted-foreground">{n.l}</div>
                  </div>
                ))}
              </div>
              <a
                href={recipe.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
              >
                Оригинална рецепта на {recipe.chef} →
              </a>
            </motion.div>
          )}
        </div>
      </Card>
    </motion.div>
  );
}

const getYoutubeVideoId = (recipeName: string): string | null => {
  const lower = recipeName.toLowerCase();
  for (const [key, id] of Object.entries(youtubeVideoMap)) {
    if (lower.includes(key)) return id;
  }
  return null;
};

const getYoutubeEmbedUrlById = (videoId: string): string => `https://www.youtube-nocookie.com/embed/${videoId}?rel=0`;

const getYoutubeWatchUrl = (recipeName: string): string => {
  const videoId = getYoutubeVideoId(recipeName);
  return videoId
    ? `https://www.youtube.com/watch?v=${videoId}`
    : getYoutubeSearchUrl(recipeName);
};

const isYoutubeVideoAvailable = async (videoId: string): Promise<boolean> => {
  try {
    const watchUrl = encodeURIComponent(`https://www.youtube.com/watch?v=${videoId}`);
    const response = await fetch(`https://www.youtube.com/oembed?url=${watchUrl}&format=json`);
    return response.ok;
  } catch {
    return false;
  }
};

// Прилагане на липсващи данни
const addMissingData = (recipe: Recipe): Recipe => {
  const defaults: Partial<Recipe> = {};

  if (!recipe.prepTime) {
    if (recipe.cookingMethod.steps.length <= 3) {
      defaults.prepTime = 25;
    } else if (recipe.cookingMethod.temperature.includes("часа")) {
      defaults.prepTime = 120;
    } else {
      defaults.prepTime = 40;
    }
  }
  
  if (!recipe.difficulty) {
    if (recipe.cookingMethod.steps.length <= 3 && (recipe.prepTime || defaults.prepTime || 30) <= 30) {
      defaults.difficulty = "лесно";
    } else if ((recipe.prepTime || defaults.prepTime || 30) > 90) {
      defaults.difficulty = "трудно";
    } else {
      defaults.difficulty = "лесно";
    }
  }
  
  return { ...recipe, ...defaults } as Recipe;
};

const getHealthScore = (recipe: Recipe): number => {
  let score = 0;
  score += (recipe.nutrition?.saturatedFat || 10) * 2;
  score += (recipe.nutrition?.sugar || 10) * 1.5;
  score += ((recipe.nutrition?.sodium || 1000) / 100);
  score -= (recipe.nutrition?.fiber || 5) * 2;
  score -= (recipe.protein / 10);
  return score;
};

const allRecipes = recipes.map(addMissingData);

const Recipes = () => {
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [searchParams] = useSearchParams();
  const [filterCategory, setFilterCategory] = useState(searchParams.get("cat") || "all");
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [videoRecipeName, setVideoRecipeName] = useState("");
  const [videoEmbedUrl, setVideoEmbedUrl] = useState<string | null>(null);
  const [isVideoLoading, setIsVideoLoading] = useState(false);
  const [ingredientsInput, setIngredientsInput] = useState("");
  const [generatedRecipes, setGeneratedRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const cat = searchParams.get("cat");
    if (cat) setFilterCategory(cat);
  }, [searchParams]);

  const openVideoModal = useCallback((name: string) => {
    setVideoRecipeName(name);
    setShowVideoModal(true);
  }, []);

  useEffect(() => {
    let isCancelled = false;

    const resolveVideo = async () => {
      if (!showVideoModal || !videoRecipeName) {
        setVideoEmbedUrl(null);
        return;
      }

      setIsVideoLoading(true);
      const videoId = getYoutubeVideoId(videoRecipeName);

      if (!videoId) {
        if (!isCancelled) {
          setVideoEmbedUrl(null);
          setIsVideoLoading(false);
        }
        return;
      }

      const isAvailable = await isYoutubeVideoAvailable(videoId);

      if (!isCancelled) {
        setVideoEmbedUrl(isAvailable ? getYoutubeEmbedUrlById(videoId) : null);
        setIsVideoLoading(false);
      }
    };

    void resolveVideo();

    return () => {
      isCancelled = true;
    };
  }, [showVideoModal, videoRecipeName]);

  const difficultyOrder = { "лесно": 1, "средно": 2, "трудно": 3 };

  const filteredRecipes = allRecipes
    .filter(recipe => 
      recipe.name.toLowerCase().includes(search.toLowerCase()) &&
      (filterCategory === "all" || recipe.category === filterCategory)
    )
    .sort((a, b) => {
      switch (sortBy) {
        case "calories": return a.calories - b.calories;
        case "protein": return b.protein - a.protein;
        case "difficulty": return (difficultyOrder[a.difficulty || "средно"] || 2) - (difficultyOrder[b.difficulty || "средно"] || 2);
        case "healthier": return getHealthScore(a) - getHealthScore(b);
        case "time": return (a.prepTime || 30) - (b.prepTime || 30);
        default: return a.name.localeCompare(b.name, 'bg');
      }
    });

  const categories = ["all", ...Array.from(new Set(allRecipes.map(r => r.category)))];

  const generateRecipes = async () => {
    if (!ingredientsInput.trim()) {
      toast({ title: "Грешка", description: "Моля, въведете продукти", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const ingredients = ingredientsInput.split(',').map(i => i.trim()).filter(i => i.length > 0);
      const { data, error } = await supabase.functions.invoke('generate-recipes', { body: { ingredients } });
      if (error) throw error;
      setGeneratedRecipes(data.recipes);
      toast({ title: "✅ Успешно!", description: `Генерирани са ${data.recipes.length} рецепти` });
    } catch (error) {
      console.error('Error generating recipes:', error);
      toast({ title: "Грешка", description: "Не успяхме да генерираме рецепти. Опитайте отново.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="pt-nav pb-8">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
        >
          <div className="flex items-center justify-between gap-4 pt-6 pb-5 md:pt-10">
            <div className="min-w-0">
              <h1 className="text-3xl md:text-5xl font-bold text-foreground">Рецепти</h1>
              <p className="mt-1.5 text-muted-foreground">{allRecipes.length} ястия с калории, протеин и стъпки за приготвяне.</p>
            </div>
            <ChefBowl interactive={false} className="w-24 sm:w-32 md:w-40 shrink-0" />
          </div>

          <Tabs defaultValue="browse" className="mb-8">
            <TabsList className="grid w-full grid-cols-3 h-12 rounded-full bg-muted p-1">
              <TabsTrigger value="browse" className="rounded-full h-full">Преглед</TabsTrigger>
              <TabsTrigger value="chefs" className="rounded-full h-full">
                <ChefHat className="mr-2 w-4 h-4" />
                От шефовете
              </TabsTrigger>
              <TabsTrigger value="generate" className="rounded-full h-full">
                <Sparkles className="mr-2 w-4 h-4" />
                AI Генератор
              </TabsTrigger>
            </TabsList>

            <TabsContent value="chefs" className="space-y-6">
              <Reveal>
                <p className="text-muted-foreground text-sm md:text-base max-w-2xl">
                  Реални рецепти от признати готвачи — с пълен кредит към автора, линк към оригинала и официално видео.
                </p>
              </Reveal>
              <div className="grid md:grid-cols-2 gap-6">
                {verifiedRecipes.map((r, i) => (
                  <VerifiedRecipeCard key={r.name} recipe={r} index={i} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="browse" className="space-y-7 mt-6">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" aria-hidden="true" />
                <Input
                  placeholder="Търси в рецептите..."
                  aria-label="Търси рецепта"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="h-12 pl-12 pr-12 rounded-full bg-card text-base"
                />
                {search && (
                  <button
                    onClick={() => setSearch("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 grid place-items-center w-7 h-7 rounded-full bg-muted text-foreground"
                    aria-label="Изчисти търсенето"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Diets */}
              <div>
                <div className="flex items-end justify-between gap-3 mb-3">
                  <h2 className="text-lg font-bold text-foreground">Режими на хранене</h2>
                  <Link to="/diets" className="eyebrow text-primary underline underline-offset-4">Всички</Link>
                </div>
                <div className="no-scrollbar -mx-5 md:mx-0 px-5 md:px-0 flex gap-2 overflow-x-auto">
                  {diets.map((d) => (
                    <Link key={d.slug} to={`/diets/${d.slug}`} className="shrink-0 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:border-primary/50">
                      {d.emoji} {d.title}
                    </Link>
                  ))}
                  <Link to="/drinks" className="shrink-0 rounded-full border border-primary/60 px-4 py-2 text-sm font-semibold text-primary transition-colors hover:bg-primary hover:text-primary-foreground">
                    🥤 Напитки
                  </Link>
                </div>
              </div>

              {/* Folders */}
              <div>
                <h2 className="text-lg font-bold text-foreground mb-3">Папки</h2>
                <ul className="no-scrollbar -mx-5 md:-mx-8 px-5 md:px-8 flex gap-3 md:gap-4 overflow-x-auto pb-2 pt-1">
                  <li className="shrink-0 w-[76px] md:w-[92px]">
                    <button onClick={() => setFilterCategory("all")} className="group block w-full" aria-pressed={filterCategory === "all"}>
                      <div className={`aspect-square rounded-2xl grid place-items-center bg-primary text-primary-foreground transition-all active:scale-95 ${filterCategory === "all" ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : ""}`}>
                        <ChefHat className="w-7 h-7" aria-hidden="true" />
                      </div>
                      <span className={`mt-2 block text-xs md:text-sm text-center leading-tight ${filterCategory === "all" ? "font-bold text-primary" : "font-medium text-foreground"}`}>Всички</span>
                    </button>
                  </li>
                  {recipeFolders.map((f) => {
                    const active = filterCategory === f.name;
                    return (
                      <li key={f.name} className="shrink-0 w-[76px] md:w-[92px]">
                        <button onClick={() => setFilterCategory(active ? "all" : f.name)} className="group block w-full" aria-pressed={active}>
                          <div className={`aspect-square overflow-hidden rounded-2xl bg-muted transition-all active:scale-95 ${active ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : "ring-1 ring-border"}`}>
                            <img src={f.image} alt="" loading="lazy" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                          </div>
                          <span className={`mt-2 block text-xs md:text-sm text-center leading-tight ${active ? "font-bold text-primary" : "font-medium text-foreground"}`}>{f.name}</span>
                        </button>
                      </li>
                    );
                  })}
                  {categories
                    .filter((c) => c !== "all" && !recipeFolders.some((f) => f.name === c))
                    .map((c) => {
                      const active = filterCategory === c;
                      return (
                        <li key={c} className="shrink-0 w-[76px] md:w-[92px]">
                          <button onClick={() => setFilterCategory(active ? "all" : c)} className="group block w-full" aria-pressed={active}>
                            <div className={`aspect-square rounded-2xl grid place-items-center bg-secondary text-xl font-bold text-secondary-foreground transition-all active:scale-95 ${active ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : ""}`}>
                              {c.charAt(0)}
                            </div>
                            <span className={`mt-2 block text-xs md:text-sm text-center leading-tight ${active ? "font-bold text-primary" : "font-medium text-foreground"}`}>{c}</span>
                          </button>
                        </li>
                      );
                    })}
                </ul>
              </div>

              {/* Results header */}
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-lg font-bold text-foreground">
                  {filterCategory === "all" ? "Всички рецепти" : filterCategory}{" "}
                  <span className="text-base font-medium text-muted-foreground">{filteredRecipes.length}</span>
                </h2>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[165px] h-10 rounded-full bg-card" aria-label="Сортирай по"><SelectValue placeholder="Сортирай по" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">Азбучен ред</SelectItem>
                    <SelectItem value="difficulty">Трудност</SelectItem>
                    <SelectItem value="calories">Калории</SelectItem>
                    <SelectItem value="protein">Протеин</SelectItem>
                    <SelectItem value="healthier">По-здравословни</SelectItem>
                    <SelectItem value="time">Време</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {filteredRecipes.length === 0 ? (
                <div className="rounded-3xl bg-card border border-border p-10 text-center">
                  <p className="text-lg font-semibold text-foreground">Няма рецепти с тези условия</p>
                  <p className="mt-1 text-muted-foreground">Пробвай друга дума или избери всички папки.</p>
                  <Button className="mt-5 rounded-full" onClick={() => { setSearch(""); setFilterCategory("all"); }}>
                    Покажи всички рецепти
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-3 gap-y-5 md:gap-x-5 md:gap-y-7">
                  {filteredRecipes.map((recipe, index) => (
                    <motion.div
                      key={recipe.id}
                      initial={{ opacity: 0, y: 14 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: Math.min(index * 0.025, 0.3), duration: 0.35, ease: [0.25, 0.46, 0.45, 0.94] }}
                      whileTap={{ scale: 0.97 }}
                    >
                      <div
                        role="button"
                        tabIndex={0}
                        onClick={() => setSelectedRecipe(recipe)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            setSelectedRecipe(recipe);
                          }
                        }}
                        className="group cursor-pointer"
                      >
                        <div className="relative aspect-[5/4] overflow-hidden rounded-3xl bg-muted">
                          <img
                            src={getRecipeImage(recipe)}
                            alt={recipe.name}
                            loading="lazy"
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                          {recipe.image && !recipe.image.startsWith("/") && (
                            <span className="absolute left-2.5 bottom-2.5 grid place-items-center w-9 h-9 rounded-full bg-card text-lg ring-2 ring-card shadow-md" aria-hidden="true">
                              {recipe.image}
                            </span>
                          )}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              openVideoModal(recipe.name);
                            }}
                            className="absolute top-2.5 right-2.5 grid place-items-center w-8 h-8 rounded-full bg-black/55 text-white backdrop-blur-sm transition-transform hover:scale-110"
                            aria-label={`Гледай видео: ${recipe.name}`}
                          >
                            <Play className="w-3.5 h-3.5 ml-0.5" />
                          </button>
                        </div>
                        <h3 className="mt-2.5 text-sm md:text-base font-semibold leading-snug text-foreground line-clamp-2 group-hover:text-primary transition-colors">{recipe.name}</h3>
                        <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1"><Flame className="w-3.5 h-3.5 text-tomato" aria-hidden="true" />{recipe.calories} kcal</span>
                          <span className="flex items-center gap-1"><Beef className="w-3.5 h-3.5" aria-hidden="true" />{recipe.protein} г</span>
                          {recipe.prepTime && (
                            <span className="flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                              {recipe.prepTime >= 60 ? `${Math.floor(recipe.prepTime / 60)}ч ${recipe.prepTime % 60}м` : `${recipe.prepTime}м`}
                            </span>
                          )}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="generate" className="space-y-8">
              <Card className="p-8 bg-card">
                <h2 className="text-2xl font-bold mb-4">
                  <Sparkles className="inline mr-2" />
                  Генерирай рецепти с AI
                </h2>
                <p className="text-muted-foreground mb-6">
                  Въведете продуктите, които имате (разделени със запетая) и ние ще генерираме над 10 различни здравословни рецепти!
                </p>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="ingredients" className="text-lg">Вашите продукти</Label>
                    <Input
                      id="ingredients"
                      placeholder="Напр: пилешко месо, броколи, ориз, домати, лук..."
                      value={ingredientsInput}
                      onChange={(e) => setIngredientsInput(e.target.value)}
                      className="mt-2"
                    />
                  </div>
                  <Button onClick={generateRecipes} disabled={loading} size="lg" className="w-full">
                    {loading ? "Готвим идеи..." : (<><Sparkles className="mr-2" />Генерирай рецепти</>)}
                  </Button>
                  {loading && (
                    <div className="flex flex-col items-center pt-2" role="status">
                      <ChefBowl interactive={false} className="w-44" />
                      <p className="text-sm text-muted-foreground">Шефът бърка в купата и търси идеи...</p>
                    </div>
                  )}
                </div>
              </Card>

              {generatedRecipes.length > 0 && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                  <h2 className="text-3xl font-bold mb-6">Вашите AI рецепти ({generatedRecipes.length})</h2>
                  <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {generatedRecipes.map((recipe, index) => (
                      <motion.div key={recipe.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }}>
                        <Card
                          className="p-6 bg-gradient-to-br from-primary/20 to-secondary/20 backdrop-blur-sm hover:shadow-glow transition-all cursor-pointer"
                          onClick={() => setSelectedRecipe(recipe)}
                        >
                          <div className="text-6xl mb-4 text-center">{recipe.image}</div>
                          <h3 className="font-bold text-lg mb-3 text-center">{recipe.name}</h3>
                          <div className="flex justify-between text-sm text-muted-foreground">
                            <span className="flex items-center gap-1"><Flame className="w-4 h-4" />{recipe.calories} кал</span>
                            <span className="flex items-center gap-1"><Beef className="w-4 h-4" />{recipe.protein}г протеин</span>
                          </div>
                          <div className="mt-2 text-xs text-center text-primary">{recipe.category}</div>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
      </div>
      <Dialog open={!!selectedRecipe} onOpenChange={() => setSelectedRecipe(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          {selectedRecipe && (
            <>
              {/* Hero image in dialog */}
              <div className="relative -mx-6 -mt-6 mb-4 rounded-t-lg overflow-hidden">
                <img
                  src={getRecipeImage(selectedRecipe)}
                  alt={selectedRecipe.name}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
                <div className="absolute bottom-4 left-6 right-6">
                  <span className="inline-block px-3 py-1 rounded-full bg-primary/90 text-primary-foreground text-xs font-semibold mb-2">
                    {selectedRecipe.category}
                  </span>
                  <h2 className="text-2xl md:text-3xl font-display font-bold text-foreground drop-shadow-lg">
                    {selectedRecipe.name}
                  </h2>
                </div>
              </div>

              {/* YouTube Video Button */}
              <button
                onClick={() => openVideoModal(selectedRecipe.name)}
                className="flex items-center gap-3 p-4 rounded-xl bg-red-500/10 border border-red-500/20 hover:bg-red-500/20 transition-all group mb-4 w-full text-left"
              >
                <div className="w-12 h-12 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <Play className="w-6 h-6 text-white ml-0.5" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-foreground">Гледай видео рецепта</p>
                  <p className="text-xs text-muted-foreground">Гледай видео ръководство директно тук</p>
                </div>
                <Play className="w-4 h-4 text-muted-foreground" />
              </button>

              <div className="space-y-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Card className="p-3 bg-orange-500/10 border-orange-500/20">
                    <div className="flex items-center gap-2 mb-1"><Flame className="w-4 h-4 text-orange-500" /><span className="font-semibold text-sm">Калории</span></div>
                    <p className="text-xl font-bold">{selectedRecipe.calories}</p>
                  </Card>
                  <Card className="p-3 bg-red-500/10 border-red-500/20">
                    <div className="flex items-center gap-2 mb-1"><Beef className="w-4 h-4 text-red-500" /><span className="font-semibold text-sm">Протеин</span></div>
                    <p className="text-xl font-bold">{selectedRecipe.protein}г</p>
                  </Card>
                  <Card className="p-3 bg-amber-500/10 border-amber-500/20">
                    <div className="flex items-center gap-2 mb-1"><Wheat className="w-4 h-4 text-amber-500" /><span className="font-semibold text-sm">Въглехидрати</span></div>
                    <p className="text-xl font-bold">{selectedRecipe.nutrition?.carbs || 0}г</p>
                  </Card>
                  <Card className="p-3 bg-yellow-500/10 border-yellow-500/20">
                    <div className="flex items-center gap-2 mb-1"><Droplets className="w-4 h-4 text-yellow-500" /><span className="font-semibold text-sm">Мазнини</span></div>
                    <p className="text-xl font-bold">{selectedRecipe.nutrition?.fat || 0}г</p>
                  </Card>
                </div>

                {selectedRecipe.nutrition && (
                  <Card className="p-4 bg-muted/30">
                    <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                      <Leaf className="w-5 h-5 text-green-500" />
                      Детайлна хранителна стойност
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                      <div className="flex justify-between"><span className="text-muted-foreground">Фибри:</span><span className="font-semibold">{selectedRecipe.nutrition.fiber}г</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">Наситени мазнини:</span><span className="font-semibold">{selectedRecipe.nutrition.saturatedFat}г</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">Захари:</span><span className="font-semibold">{selectedRecipe.nutrition.sugar}г</span></div>
                      <div className="flex justify-between col-span-2 md:col-span-3"><span className="text-muted-foreground">Натрий:</span><span className="font-semibold">{selectedRecipe.nutrition.sodium}мг</span></div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-border">
                      <p className="text-sm"><span className="text-muted-foreground">Въглехидрати от: </span><span className="font-medium">{selectedRecipe.nutrition.carbSources}</span></p>
                    </div>
                  </Card>
                )}

                <div>
                  <h3 className="text-xl font-bold mb-3 flex items-center gap-2">
                    <ChefHat className="w-5 h-5 text-primary" />
                    Метод на готвене
                  </h3>
                  <div className="space-y-2 text-muted-foreground">
                    <p><strong>Температура:</strong> {selectedRecipe.cookingMethod.temperature}</p>
                    <p><strong>Масло:</strong> {selectedRecipe.cookingMethod.oil}</p>
                    <p className="text-primary"><strong>По-здравословно:</strong> {selectedRecipe.cookingMethod.healthierOil}</p>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold mb-3">Стъпки</h3>
                  <ol className="space-y-2">
                    {selectedRecipe.cookingMethod.steps.map((step, index) => (
                      <li key={index} className="flex gap-3">
                        <span className="font-bold text-primary min-w-[24px]">{index + 1}.</span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Video Modal */}
      <Dialog open={showVideoModal} onOpenChange={setShowVideoModal}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden" aria-describedby="video-modal-desc">
          <DialogHeader className="p-4 pb-0">
            <DialogTitle className="text-lg font-display font-bold text-foreground pr-10">
              🎬 {videoRecipeName}
            </DialogTitle>
            <DialogDescription id="video-modal-desc">Видео рецепта от YouTube</DialogDescription>
          </DialogHeader>
          <div className="relative">
            <div className="absolute top-3 right-3 z-10">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowVideoModal(false)}
                className="rounded-full bg-background/80 backdrop-blur-sm hover:bg-background"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <div className="aspect-video mt-4">
              {isVideoLoading ? (
                <div className="w-full h-full flex flex-col items-center justify-center bg-muted/50 gap-4">
                  <Loader2 className="w-10 h-10 text-muted-foreground animate-spin" />
                  <p className="text-muted-foreground text-center">Проверяваме видеото...</p>
                </div>
              ) : videoEmbedUrl ? (
                <iframe
                  src={videoEmbedUrl}
                  className="w-full h-full"
                  allowFullScreen
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  title={`Видео рецепта: ${videoRecipeName}`}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-muted/50 gap-4">
                  <Play className="w-16 h-16 text-muted-foreground" />
                  <p className="text-muted-foreground text-center">Този видеоклип не е налице за вграждане — отвори го директно в YouTube.</p>
                </div>
              )}
            </div>
            <div className="p-4 pt-2">
              <Button
                asChild
                variant="outline"
                className="w-full gap-2"
              >
                <a
                  href={getYoutubeWatchUrl(videoRecipeName)}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Play className="w-4 h-4" />
                  Отвори в YouTube
                </a>
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default Recipes;

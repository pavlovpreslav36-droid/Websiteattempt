import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Footer from "@/components/Footer";
import { Reveal } from "@/components/Reveal";
import { toast } from "sonner";
import {
  Headphones, Play, ExternalLink, Zap, Flame, Skull, Crown,
  Disc3, Sparkles, RefreshCw, Search, Volume2, Radio
} from "lucide-react";

interface Track {
  title: string;
  artist: string;
  spotify_query: string;
  bpm_estimate?: number;
  energy?: string;
}

interface GeneratedPlaylist {
  playlist_name: string;
  playlist_description: string;
  tracks: Track[];
  spotify_search_url?: string;
}

interface Genre {
  id: string;
  label: string;
  labelBg: string;
  tagline: string;
  taglineBg: string;
  icon: typeof Zap;
  accentClass: string;
  spotifyPlaylistId?: string;
  artists: string;
}

const GENRES: Genre[] = [
  {
    id: "drill",
    label: "Drill / Hoodtap",
    labelBg: "Drill / Hoodtap",
    tagline: "Sdot Go · Kay Flock · DD Osama · Pop Smoke · Central Cee",
    taglineBg: "Sdot Go · Kay Flock · DD Osama · Pop Smoke · Central Cee",
    icon: Skull,
    accentClass: "text-red-500 dark:text-red-400",
    spotifyPlaylistId: "37i9dQZF1DWY4xHQp97fN6",
    artists: "Sdot Go, Kay Flock, DD Osama, Pop Smoke, Central Cee",
  },
  {
    id: "trap",
    label: "Trap / Hip-Hop",
    labelBg: "Трап / Хип-Хоп",
    tagline: "Travis Scott · Future · 21 Savage · Metro Boomin · Lil Baby",
    taglineBg: "Travis Scott · Future · 21 Savage · Metro Boomin · Lil Baby",
    icon: Flame,
    accentClass: "text-orange-500 dark:text-orange-400",
    spotifyPlaylistId: "37i9dQZF1DX0XUsuxWHRQd",
    artists: "Travis Scott, Future, 21 Savage, Metro Boomin, Lil Baby",
  },
  {
    id: "oldschool",
    label: "Old School Hip-Hop",
    labelBg: "Олд Скуул Хип-Хоп",
    tagline: "Eminem · Snoop Dogg · Biggie · DMX · 2Pac · Dr. Dre · Nas",
    taglineBg: "Eminem · Snoop Dogg · Biggie · DMX · 2Pac · Dr. Dre · Nas",
    icon: Crown,
    accentClass: "text-amber-500 dark:text-amber-400",
    spotifyPlaylistId: "37i9dQZF1DX186v583rmzp",
    artists: "Eminem, Snoop Dogg, Biggie, DMX, 2Pac, Dr. Dre, Nas",
  },
  {
    id: "pop_edm",
    label: "Pop / EDM",
    labelBg: "Поп / EDM",
    tagline: "The Weeknd · Dua Lipa · Calvin Harris · Martin Garrix",
    taglineBg: "The Weeknd · Dua Lipa · Calvin Harris · Martin Garrix",
    icon: Disc3,
    accentClass: "text-violet-500 dark:text-violet-400",
    spotifyPlaylistId: "37i9dQZF1DX4dyzvuaRJ0n",
    artists: "The Weeknd, Dua Lipa, Calvin Harris, Martin Garrix",
  },
  {
    id: "rock",
    label: "Rock / Metal",
    labelBg: "Рок / Метъл",
    tagline: "Metallica · Linkin Park · AC/DC · SOAD · RATM",
    taglineBg: "Metallica · Linkin Park · AC/DC · SOAD · RATM",
    icon: Zap,
    accentClass: "text-emerald-500 dark:text-emerald-400",
    spotifyPlaylistId: "37i9dQZF1DWWJOmJ7nRx0C",
    artists: "Metallica, Linkin Park, AC/DC, SOAD, RATM",
  },
];

const WorkoutMusic = () => {
  const { language } = useLanguage();
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const isBg = language === "bg";

  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [generatedPlaylist, setGeneratedPlaylist] = useState<GeneratedPlaylist | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showSpotifyEmbed, setShowSpotifyEmbed] = useState(false);
  const [spotifyTrack, setSpotifyTrack] = useState<Track | null>(null);

  useEffect(() => {
    if (!loading && !user) navigate("/auth");
  }, [user, loading, navigate]);

  const handleGenreSelect = async (genreId: string) => {
    setSelectedGenre(genreId);
    setGeneratedPlaylist(null);
    await generatePlaylist(genreId);
  };

  const generatePlaylist = async (genreId: string) => {
    setIsGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke("generate-playlist", {
        body: { genre: genreId, language },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setGeneratedPlaylist(data);
      toast.success(isBg ? "Плейлистът е готов! 🎵" : "Playlist generated! 🎵");
    } catch (e) {
      console.error("Playlist generation error:", e);
      toast.error(isBg ? "Грешка при генерирането" : "Failed to generate playlist");
    } finally {
      setIsGenerating(false);
    }
  };

  const getSpotifySearchUrl = (query: string) =>
    `https://open.spotify.com/search/${encodeURIComponent(query)}`;

  const getYoutubeUrl = (query: string) =>
    `https://www.youtube.com/results?search_query=${encodeURIComponent(query + " official audio")}`;

  const openSpotifyTrack = (track: Track) => {
    setSpotifyTrack(track);
    setShowSpotifyEmbed(true);
  };

  const genre = selectedGenre ? GENRES.find((g) => g.id === selectedGenre) : null;

  if (loading || !user) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Hero – cinematic, not templated */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] min-h-[30vh] md:min-h-[38vh] flex items-end justify-center overflow-hidden pt-12 pb-8 md:pb-10">
        <div className="absolute inset-0">
          <img src="/images/music-mixer-hero.jpg" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10" />
        </div>
        <div className="relative z-10 px-6 max-w-4xl mx-auto w-full">
          <Reveal>
            <p className="text-sm font-medium tracking-widest uppercase text-white mb-3">
              {isBg ? "Твоят саундтрак" : "Your Soundtrack"}
            </p>
          </Reveal>
          <Reveal delay={0.08}>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold text-white leading-[1.05] mb-4">
              {isBg ? (
                <>Workout<br className="md:hidden" /> Music Mixer</>
              ) : (
                <>Workout<br className="md:hidden" /> Music Mixer</>
              )}
            </h1>
          </Reveal>
          <Reveal delay={0.15}>
            <p className="text-white/85 text-base md:text-lg max-w-lg">
              {isBg
                ? "AI подбира песните. Ти избираш вайба."
                : "AI picks the tracks. You pick the vibe."}
            </p>
          </Reveal>
        </div>
      </section>

      <div className="px-6 pb-16 max-w-4xl mx-auto">
        {/* Genre cards – clean, not rainbow gradients */}
        <section className="mb-12">
          <Reveal>
            <h2 className="text-lg font-semibold text-foreground mb-5 tracking-tight">
              {isBg ? "Избери стил" : "Pick your style"}
            </h2>
          </Reveal>

          <div className="space-y-2">
            {GENRES.map((g, i) => {
              const isActive = selectedGenre === g.id;
              const Icon = g.icon;
              return (
                <Reveal key={g.id} delay={i * 0.04}>
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleGenreSelect(g.id)}
                    className={`w-full flex items-center gap-4 p-4 md:p-5 rounded-2xl border text-left transition-all duration-200 ${
                      isActive
                        ? "bg-card border-primary/40 shadow-md"
                        : "bg-card/50 border-border/40 hover:bg-card hover:border-border"
                    }`}
                  >
                    <Icon className={`w-6 h-6 shrink-0 ${isActive ? g.accentClass : "text-muted-foreground"}`} />
                    <div className="flex-1 min-w-0">
                      <p className={`font-semibold text-sm md:text-base ${isActive ? "text-foreground" : "text-foreground/80"}`}>
                        {isBg ? g.labelBg : g.label}
                      </p>
                      <p className="text-xs text-muted-foreground truncate mt-0.5">
                        {isBg ? g.taglineBg : g.tagline}
                      </p>
                    </div>
                    {isActive && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-2 h-2 rounded-full bg-primary shrink-0"
                      />
                    )}
                  </motion.button>
                </Reveal>
              );
            })}
          </div>
        </section>

        {/* Loading */}
        <AnimatePresence>
          {isGenerating && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="py-16 text-center"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                className="inline-block mb-4"
              >
                <Disc3 className="w-12 h-12 text-primary" />
              </motion.div>
              <p className="text-foreground font-medium">
                {isBg ? "Подбиране на песни..." : "Curating tracks..."}
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Generated Playlist */}
        <AnimatePresence mode="wait">
          {!isGenerating && generatedPlaylist && genre && (
            <motion.div
              key={selectedGenre}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              {/* Playlist header */}
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-2xl md:text-3xl font-display font-bold text-foreground leading-tight">
                    {generatedPlaylist.playlist_name}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {generatedPlaylist.playlist_description}
                  </p>
                  <div className="flex items-center gap-3 mt-3">
                    <span className="text-[11px] px-2.5 py-1 rounded-full bg-primary/10 text-primary font-medium">
                      AI Generated
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {generatedPlaylist.tracks.length} {isBg ? "песни" : "tracks"}
                    </span>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => generatePlaylist(genre.id)}
                  className="shrink-0 gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  {isBg ? "Нов" : "New"}
                </Button>
              </div>

              {/* Track list – clean table-like layout */}
              <div className="rounded-2xl border border-border/60 bg-card/50 overflow-hidden divide-y divide-border/40">
                {generatedPlaylist.tracks.map((track, i) => (
                  <motion.div
                    key={`${track.title}-${i}`}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.03 }}
                    className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30 transition-colors group"
                  >
                    <span className="text-[11px] text-muted-foreground/40 w-5 text-right tabular-nums font-mono">
                      {String(i + 1).padStart(2, "0")}
                    </span>

                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{track.title}</p>
                      <p className="text-xs text-muted-foreground truncate">{track.artist}</p>
                    </div>

                    {track.bpm_estimate && (
                      <span className="text-[10px] text-muted-foreground/50 tabular-nums hidden sm:block">
                        {track.bpm_estimate}
                      </span>
                    )}

                    <div className="flex items-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => openSpotifyTrack(track)}
                        className="w-7 h-7 rounded-full hover:bg-[#1DB954]/15 flex items-center justify-center transition-colors"
                        title="Spotify"
                      >
                        <Volume2 className="w-3.5 h-3.5 text-[#1DB954]" />
                      </button>
                      <a
                        href={getSpotifySearchUrl(track.spotify_query)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-7 h-7 rounded-full hover:bg-[#1DB954]/15 flex items-center justify-center transition-colors"
                        title="Open in Spotify"
                      >
                        <Search className="w-3.5 h-3.5 text-[#1DB954]" />
                      </a>
                      <a
                        href={getYoutubeUrl(track.spotify_query)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-7 h-7 rounded-full hover:bg-red-500/15 flex items-center justify-center transition-colors"
                        title="YouTube"
                      >
                        <Play className="w-3.5 h-3.5 text-red-500 ml-0.5" />
                      </a>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Spotify Embed */}
              {genre.spotifyPlaylistId && (
                <Reveal delay={0.1}>
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Radio className="w-4 h-4 text-[#1DB954]" />
                      <h4 className="text-sm font-semibold text-foreground">
                        {isBg ? "Слушай в Spotify" : "Listen on Spotify"}
                      </h4>
                    </div>
                    <div className="rounded-xl overflow-hidden border border-border/40">
                      <iframe
                        src={`https://open.spotify.com/embed/playlist/${genre.spotifyPlaylistId}?utm_source=generator&theme=0`}
                        width="100%"
                        height="352"
                        frameBorder="0"
                        allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                        loading="lazy"
                      />
                    </div>
                  </div>
                </Reveal>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Empty state */}
        {!selectedGenre && !isGenerating && (
          <Reveal delay={0.2}>
            <div className="py-20 text-center">
              <Headphones className="w-10 h-10 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">
                {isBg
                  ? "Избери стил по-горе, за да започнеш"
                  : "Pick a style above to get started"}
              </p>
            </div>
          </Reveal>
        )}
      </div>

      {/* Spotify Track Modal */}
      <Dialog open={showSpotifyEmbed} onOpenChange={setShowSpotifyEmbed}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">
              {spotifyTrack ? `${spotifyTrack.artist} — ${spotifyTrack.title}` : "Spotify"}
            </DialogTitle>
          </DialogHeader>
          {spotifyTrack && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                {isBg
                  ? "Използвай бутоните по-долу, за да намериш песента:"
                  : "Use the buttons below to find this track:"}
              </p>
              <div className="flex gap-2">
                <Button asChild className="flex-1 bg-[#1DB954] hover:bg-[#1ed760] text-black font-semibold">
                  <a
                    href={getSpotifySearchUrl(spotifyTrack.spotify_query)}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Spotify
                  </a>
                </Button>
                <Button asChild variant="outline" className="flex-1">
                  <a
                    href={getYoutubeUrl(spotifyTrack.spotify_query)}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    YouTube
                  </a>
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default WorkoutMusic;

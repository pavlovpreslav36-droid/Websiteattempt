import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Clock, Droplets, Dumbbell, HeartPulse, Leaf, ShoppingCart, Sparkles, Apple } from "lucide-react";
import { toast } from "sonner";
import Footer from "@/components/Footer";
import { PageBanner, SectionTitle } from "@/components/food/PageBanner";
import { RecipeDialog } from "@/components/food/RecipeDialog";
import { DrinkDialog } from "@/components/food/DrinkDialog";
import { DrinkGlass } from "@/components/food/DrinkGlass";
import { Button } from "@/components/ui/button";
import { dietRecipes, type DietRecipe } from "@/data/dietRecipes";
import { drinks, type Drink } from "@/data/drinks";
import { tagLabels } from "@/data/diets";
import { addItems } from "@/lib/shoppingList";
import { buildPlan, type DayPlan, type Restriction } from "@/lib/quitPlan";

const restrictions: Restriction[] = ["gluten-free", "lactose-free", "vegan"];

const rules = [
  { icon: Droplets, title: "Пий вода през целия ден", text: "Носи бутилка със себе си. Овкусените води и билковите чайове помагат да пиеш повече." },
  { icon: Apple, title: "Дръж хрупкаво под ръка", text: "Моркови, краставици, ябълка или шепа ядки заемат ръцете и устата в моментите на навик." },
  { icon: Clock, title: "Не пропускай хранения", text: "Редовното хранене помага да избегнеш рязък глад, а с него и по-силно желание." },
  { icon: Leaf, title: "Смени навика около кафето", text: "Първите седмици пробвай вода, билков чай или цикория на местата, където обикновено пушиш." },
  { icon: HeartPulse, title: "Говори с лекар", text: "Храната и водата подкрепят, но не заменят професионалната помощ при отказване." },
];

const RecipeRow = ({ label, recipe, onOpen }: { label: string; recipe?: DietRecipe; onOpen: (r: DietRecipe) => void }) =>
  recipe ? (
    <button onClick={() => onOpen(recipe)} className="group w-full flex items-center gap-3 rounded-2xl border border-border bg-background/60 p-2 text-left transition-colors hover:border-primary/50">
      <img src={recipe.photo} alt="" loading="lazy" className="w-16 h-16 rounded-xl object-cover shrink-0" />
      <span className="min-w-0">
        <span className="eyebrow text-primary block">{label}</span>
        <span className="block font-semibold text-foreground leading-snug line-clamp-2">{recipe.name}</span>
        <span className="block text-xs text-muted-foreground">{recipe.minutes} мин, {recipe.kcal} kcal</span>
      </span>
    </button>
  ) : null;

const QuitKitchen = () => {
  const [restr, setRestr] = useState<Restriction[]>([]);
  const [day, setDay] = useState(0);
  const [openRecipe, setOpenRecipe] = useState<DietRecipe | null>(null);
  const [openDrink, setOpenDrink] = useState<Drink | null>(null);
  const [idea, setIdea] = useState<{ kind: "recipe"; item: DietRecipe } | { kind: "drink"; item: Drink } | null>(null);
  const [spin, setSpin] = useState(0);

  const plan = useMemo(() => buildPlan(restr), [restr]);
  const today = plan[day];

  const quickRecipes = useMemo(() => dietRecipes.filter((r) => r.tags.includes("quit") && r.minutes <= 10), []);
  const quickDrinks = useMemo(() => drinks.filter((d) => d.tags.includes("quit") && d.minutes <= 5), []);

  const toggle = (t: Restriction) => setRestr((p) => (p.includes(t) ? p.filter((x) => x !== t) : [...p, t]));

  const ingredientsOf = (p: DayPlan) => [
    ...[p.breakfast, p.snack, p.lunch, p.dinner].flatMap((r) => r?.ingredients ?? []),
    ...p.drinks.flatMap((d) => d.ingredients),
  ];

  const addDay = () => {
    const n = addItems(ingredientsOf(today), `Кухня за отказване: ден ${day + 1}`);
    toast.success(n ? `Добавени в списъка: ${n}` : "Всичко вече е в списъка");
  };

  const addWeek = () => {
    let n = 0;
    plan.forEach((p, i) => {
      n += addItems(ingredientsOf(p), `Кухня за отказване: ден ${i + 1}`);
    });
    toast.success(n ? `Добавени в списъка: ${n}` : "Всичко вече е в списъка");
  };

  const surprise = () => {
    setSpin((s) => s + 1);
    const all = quickRecipes.length + quickDrinks.length;
    const i = Math.floor(Math.random() * all);
    setIdea(i < quickRecipes.length ? { kind: "recipe", item: quickRecipes[i] } : { kind: "drink", item: quickDrinks[i - quickRecipes.length] });
  };

  return (
    <div className="min-h-screen bg-background">
      <PageBanner
        eyebrow="Седем дни, една цел"
        title="Кухня за отказване"
        text="План за първата седмица без цигара: хрупкави снаксове, редовни хранения и много вода. Храната подкрепя деня, но не замества помощта от лекар."
      >
        <div className="mt-8 flex flex-wrap gap-3">
          <a href="#plan" className="btn-sheen inline-flex items-center h-12 px-7 rounded-full bg-cream text-wine font-semibold">Към плана</a>
          <Link to="/tobacco-free#counter" className="inline-flex items-center h-12 px-7 rounded-full border border-cream/50 text-cream font-semibold hover:bg-cream hover:text-wine transition-colors">
            Брояч „Без дим“
          </Link>
        </div>
      </PageBanner>

      <section className="container py-14 md:py-20">
        <SectionTitle text="Пет прости навика, които правят деня по-лесен.">Правила за седмицата</SectionTitle>
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {rules.map((r) => (
            <div key={r.title} className="rounded-[2rem] bg-card border border-border p-5">
              <span className="grid place-items-center w-11 h-11 rounded-xl bg-primary/10 text-primary mb-3"><r.icon className="w-5 h-5" aria-hidden="true" /></span>
              <h3 className="font-semibold text-foreground">{r.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{r.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="plan" className="px-3 md:px-6 scroll-mt-24">
        <div className="rounded-[2.5rem] bg-wine text-cream px-5 md:px-12 py-12 md:py-16">
          <div className="container px-0">
            <p className="eyebrow text-flame">План</p>
            <h2 className="display mt-3 text-[clamp(1.9rem,5vw,3.4rem)] text-cream">Седемдневно меню</h2>
            <p className="mt-3 text-cream/80 max-w-xl">Избери ограничения и менюто се подрежда наново. Натисни ястие или напитка за пълната рецепта.</p>

            <div className="mt-6 flex flex-wrap gap-2" role="group" aria-label="Ограничения в храненето">
              {restrictions.map((t) => {
                const on = restr.includes(t);
                return (
                  <button
                    key={t}
                    onClick={() => toggle(t)}
                    aria-pressed={on}
                    className={`rounded-full px-4 py-2 text-sm font-semibold border transition-colors ${on ? "bg-flame text-wine border-flame" : "border-cream/40 text-cream hover:bg-cream/10"}`}
                  >
                    {tagLabels[t]}
                  </button>
                );
              })}
            </div>

            <div className="mt-6 no-scrollbar -mx-1 px-1 flex gap-2 overflow-x-auto" role="tablist" aria-label="Дни">
              {plan.map((_, i) => (
                <button
                  key={i}
                  role="tab"
                  aria-selected={day === i}
                  onClick={() => setDay(i)}
                  className={`shrink-0 h-12 px-5 rounded-full text-sm font-bold border transition-colors ${day === i ? "bg-cream text-wine border-cream" : "border-cream/40 text-cream hover:bg-cream/10"}`}
                >
                  Ден {i + 1}
                </button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={`${day}-${restr.join()}`}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="mt-6 grid lg:grid-cols-[1.4fr_1fr] gap-5"
              >
                <div className="rounded-[2rem] bg-cream text-wine p-4 md:p-6 space-y-3">
                  <RecipeRow label="Закуска" recipe={today.breakfast} onOpen={setOpenRecipe} />
                  <RecipeRow label="Хрупкав снакс" recipe={today.snack} onOpen={setOpenRecipe} />
                  <RecipeRow label="Обяд" recipe={today.lunch} onOpen={setOpenRecipe} />
                  <RecipeRow label="Вечеря" recipe={today.dinner} onOpen={setOpenRecipe} />
                  {!today.breakfast && !today.lunch && <p className="p-4 text-sm">Няма достатъчно рецепти с тази комбинация. Махни едно ограничение.</p>}
                </div>

                <div className="rounded-[2rem] bg-wine-2 p-4 md:p-6">
                  <p className="eyebrow text-flame">Напитки за деня</p>
                  <ul className="mt-3 space-y-3">
                    {today.drinks.map((d) => (
                      <li key={d.id}>
                        <button onClick={() => setOpenDrink(d)} className="w-full flex items-center gap-3 rounded-2xl bg-cream/10 p-2 text-left transition-colors hover:bg-cream/20">
                          <span className="grid place-items-center w-16 h-16 rounded-xl shrink-0" style={{ background: `${d.color}55` }}>
                            <DrinkGlass drink={d} label="" className="h-14 w-auto" />
                          </span>
                          <span className="min-w-0">
                            <span className="block font-semibold text-cream leading-snug">{d.name}</span>
                            <span className="block text-xs text-cream/70">{d.minutes} мин, {d.kcal} kcal</span>
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-5 flex flex-wrap gap-2">
                    <Button size="sm" className="bg-cream text-wine hover:bg-cream/90" onClick={addDay}><ShoppingCart className="w-4 h-4 mr-2" aria-hidden="true" />Добави деня</Button>
                    <Button size="sm" variant="outline" className="border-cream/50 bg-transparent text-cream hover:bg-cream hover:text-wine" onClick={addWeek}>Цялата седмица</Button>
                  </div>
                  <Link to="/shopping-list" className="mt-3 inline-block text-sm font-semibold text-flame underline underline-offset-4">Отвори списъка за пазаруване</Link>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </section>

      <section className="container py-14 md:py-20">
        <SectionTitle text="Натисни бутона и получи бърза идея, която отнема до 10 минути.">Когато ти се прияде цигара</SectionTitle>
        <div className="grid lg:grid-cols-[auto_1fr] gap-6 items-stretch">
          <div className="rounded-[2rem] bg-flame text-wine p-8 md:p-10 flex flex-col items-start justify-between gap-6 lg:w-[22rem]">
            <motion.span animate={{ rotate: spin * 360 }} transition={{ duration: 0.7, ease: "easeInOut" }} className="grid place-items-center w-14 h-14 rounded-2xl bg-wine text-cream">
              <Sparkles className="w-7 h-7" aria-hidden="true" />
            </motion.span>
            <div>
              <h3 className="display text-[clamp(1.6rem,3vw,2.3rem)]">Изненада ме</h3>
              <p className="mt-2 font-medium">Чаша вода, хрупкав снакс или топъл чай: избираме ти нещо за ръцете и устата.</p>
            </div>
            <Button size="lg" className="bg-wine text-cream hover:bg-wine/90" onClick={surprise}>Дай ми идея</Button>
          </div>

          <div className="rounded-[2rem] bg-card border border-border p-5 md:p-6 min-h-[16rem] grid place-items-center">
            <AnimatePresence mode="wait">
              {idea ? (
                <motion.button
                  key={idea.item.id}
                  initial={{ opacity: 0, scale: 0.92, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 300, damping: 24 }}
                  onClick={() => (idea.kind === "recipe" ? setOpenRecipe(idea.item) : setOpenDrink(idea.item))}
                  className="w-full max-w-md flex items-center gap-5 text-left"
                >
                  {idea.kind === "recipe" ? (
                    <img src={idea.item.photo} alt="" className="w-28 h-28 rounded-3xl object-cover shrink-0" />
                  ) : (
                    <span className="grid place-items-center w-28 h-28 rounded-3xl shrink-0" style={{ background: `${idea.item.color}55` }}>
                      <DrinkGlass drink={idea.item} label="" className="h-24 w-auto" />
                    </span>
                  )}
                  <span>
                    <span className="eyebrow text-primary block">{idea.kind === "recipe" ? idea.item.meal : "Напитка"}</span>
                    <span className="block font-brand text-2xl leading-snug text-foreground">{idea.item.name}</span>
                    <span className="mt-1 block text-sm text-muted-foreground">{idea.item.minutes} мин. Натисни за рецептата.</span>
                  </span>
                </motion.button>
              ) : (
                <motion.p key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center text-muted-foreground max-w-xs">
                  Натисни „Дай ми идея“ и тук ще се появи бърз снакс или напитка.
                </motion.p>
              )}
            </AnimatePresence>
          </div>
        </div>
      </section>

      <section className="container pb-16 md:pb-24">
        <div className="grid md:grid-cols-3 gap-4">
          <Link to="/diets/quit" className="rounded-[2rem] bg-card border border-border p-6 transition-all hover:-translate-y-1 hover:border-primary/40">
            <p className="eyebrow text-primary">{dietRecipes.filter((r) => r.tags.includes("quit")).length} рецепти</p>
            <h3 className="mt-2 font-brand text-xl">Всички рецепти за подкрепа</h3>
            <p className="mt-2 text-sm text-muted-foreground">Филтрирай по ястие, време и режим.</p>
          </Link>
          <Link to="/drinks" className="rounded-[2rem] bg-card border border-border p-6 transition-all hover:-translate-y-1 hover:border-primary/40">
            <p className="eyebrow text-primary">{drinks.filter((d) => d.tags.includes("quit")).length} напитки</p>
            <h3 className="mt-2 font-brand text-xl">Напитки и брояч за водата</h3>
            <p className="mt-2 text-sm text-muted-foreground">Овкусени води, чайове и смутита.</p>
          </Link>
          <Link to="/exercises" className="rounded-[2rem] bg-card border border-border p-6 transition-all hover:-translate-y-1 hover:border-primary/40">
            <span className="grid place-items-center w-10 h-10 rounded-xl bg-primary/10 text-primary"><Dumbbell className="w-5 h-5" aria-hidden="true" /></span>
            <h3 className="mt-3 font-brand text-xl">Раздвижи се</h3>
            <p className="mt-2 text-sm text-muted-foreground">Кратка разходка или тренировка също помага да издържиш желанието.</p>
          </Link>
        </div>
      </section>

      <RecipeDialog recipe={openRecipe} onClose={() => setOpenRecipe(null)} />
      <DrinkDialog drink={openDrink} onClose={() => setOpenDrink(null)} />
      <Footer />
    </div>
  );
};

export default QuitKitchen;

import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Heart, Star, Droplets, Brain, Apple, Moon, Sun, Flame, Wind, Mountain, Waves } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ZodiacSign {
  id: string;
  name: string;
  nameBg: string;
  symbol: string;
  dates: string;
  datesBg: string;
  element: string;
  elementBg: string;
  icon: React.ReactNode;
  color: string;
  image: string;
}

const zodiacSigns: ZodiacSign[] = [
  { id: "aries", name: "Aries", nameBg: "Овен", symbol: "♈", dates: "Mar 21 - Apr 19", datesBg: "21 март - 19 април", element: "Fire", elementBg: "Огън", icon: <Flame className="w-4 h-4" />, color: "from-red-500 to-orange-500", image: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=400&h=300&fit=crop" },
  { id: "taurus", name: "Taurus", nameBg: "Телец", symbol: "♉", dates: "Apr 20 - May 20", datesBg: "20 април - 20 май", element: "Earth", elementBg: "Земя", icon: <Mountain className="w-4 h-4" />, color: "from-green-600 to-emerald-500", image: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=400&h=300&fit=crop" },
  { id: "gemini", name: "Gemini", nameBg: "Близнаци", symbol: "♊", dates: "May 21 - Jun 20", datesBg: "21 май - 20 юни", element: "Air", elementBg: "Въздух", icon: <Wind className="w-4 h-4" />, color: "from-yellow-400 to-amber-500", image: "https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=400&h=300&fit=crop" },
  { id: "cancer", name: "Cancer", nameBg: "Рак", symbol: "♋", dates: "Jun 21 - Jul 22", datesBg: "21 юни - 22 юли", element: "Water", elementBg: "Вода", icon: <Waves className="w-4 h-4" />, color: "from-blue-400 to-cyan-500", image: "https://images.unsplash.com/photo-1505506874110-6a7a69069a08?w=400&h=300&fit=crop" },
  { id: "leo", name: "Leo", nameBg: "Лъв", symbol: "♌", dates: "Jul 23 - Aug 22", datesBg: "23 юли - 22 август", element: "Fire", elementBg: "Огън", icon: <Sun className="w-4 h-4" />, color: "from-amber-500 to-yellow-400", image: "https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?w=400&h=300&fit=crop" },
  { id: "virgo", name: "Virgo", nameBg: "Дева", symbol: "♍", dates: "Aug 23 - Sep 22", datesBg: "23 август - 22 септември", element: "Earth", elementBg: "Земя", icon: <Apple className="w-4 h-4" />, color: "from-lime-500 to-green-600", image: "https://images.unsplash.com/photo-1464802686167-b939a6910659?w=400&h=300&fit=crop" },
  { id: "libra", name: "Libra", nameBg: "Везни", symbol: "♎", dates: "Sep 23 - Oct 22", datesBg: "23 септември - 22 октомври", element: "Air", elementBg: "Въздух", icon: <Wind className="w-4 h-4" />, color: "from-pink-400 to-rose-500", image: "https://images.unsplash.com/photo-1507400492013-162706c8c05e?w=400&h=300&fit=crop" },
  { id: "scorpio", name: "Scorpio", nameBg: "Скорпион", symbol: "♏", dates: "Oct 23 - Nov 21", datesBg: "23 октомври - 21 ноември", element: "Water", elementBg: "Вода", icon: <Droplets className="w-4 h-4" />, color: "from-purple-600 to-indigo-600", image: "https://images.unsplash.com/photo-1520034475321-cbe63696469a?w=400&h=300&fit=crop" },
  { id: "sagittarius", name: "Sagittarius", nameBg: "Стрелец", symbol: "♐", dates: "Nov 22 - Dec 21", datesBg: "22 ноември - 21 декември", element: "Fire", elementBg: "Огън", icon: <Flame className="w-4 h-4" />, color: "from-violet-500 to-purple-500", image: "https://images.unsplash.com/photo-1543722530-d2c3201371e7?w=400&h=300&fit=crop" },
  { id: "capricorn", name: "Capricorn", nameBg: "Козирог", symbol: "♑", dates: "Dec 22 - Jan 19", datesBg: "22 декември - 19 януари", element: "Earth", elementBg: "Земя", icon: <Mountain className="w-4 h-4" />, color: "from-stone-500 to-zinc-600", image: "https://images.unsplash.com/photo-1465101162946-4377e57745c3?w=400&h=300&fit=crop" },
  { id: "aquarius", name: "Aquarius", nameBg: "Водолей", symbol: "♒", dates: "Jan 20 - Feb 18", datesBg: "20 януари - 18 февруари", element: "Air", elementBg: "Въздух", icon: <Brain className="w-4 h-4" />, color: "from-sky-400 to-blue-500", image: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=400&h=300&fit=crop" },
  { id: "pisces", name: "Pisces", nameBg: "Риби", symbol: "♓", dates: "Feb 19 - Mar 20", datesBg: "19 февруари - 20 март", element: "Water", elementBg: "Вода", icon: <Moon className="w-4 h-4" />, color: "from-teal-400 to-cyan-600", image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&h=300&fit=crop" },
];

const HealthHoroscope = () => {
  const { language } = useLanguage();
  const [selectedSign, setSelectedSign] = useState<ZodiacSign | null>(null);
  const [horoscope, setHoroscope] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [healthScore, setHealthScore] = useState<number>(0);

  const generateHoroscope = useCallback(async (sign: ZodiacSign) => {
    setSelectedSign(sign);
    setLoading(true);
    setHoroscope("");
    setHealthScore(0);

    try {
      const today = new Date().toLocaleDateString('bg-BG', { day: 'numeric', month: 'long', year: 'numeric' });
      const prompt = language === 'bg'
        ? `Ти си здравен астролог. Генерирай кратък, забавен и полезен здравен хороскоп за зодия ${sign.nameBg} за днес (${today}). Включи: 1) Обща здравна енергия (1-10), 2) Съвет за хранене, 3) Съвет за упражнения, 4) Емоционално здраве, 5) Щастливо число за здравето. Бъди креативен и позитивен! Пиши на български. Форматирай с емоджи.`
        : `You are a health astrologer. Generate a short, fun, and useful health horoscope for ${sign.name} for today (${today}). Include: 1) Overall health energy (1-10), 2) Nutrition tip, 3) Exercise tip, 4) Emotional wellness, 5) Lucky health number. Be creative and positive! Format with emojis.`;

      const { data, error } = await supabase.functions.invoke('ai-chat', {
        body: { messages: [{ role: 'user', content: prompt }], language },
      });

      if (error) throw error;

      const text = data?.reply || data?.message || '';
      setHoroscope(text);
      const scoreMatch = text.match(/(\d+)\s*\/\s*10/);
      setHealthScore(scoreMatch ? parseInt(scoreMatch[1]) : Math.floor(Math.random() * 4) + 6);
    } catch (error) {
      console.error('Error generating horoscope:', error);
      toast.error(language === 'bg' ? 'Грешка при генериране на хороскопа' : 'Error generating horoscope');
      setHoroscope(language === 'bg'
        ? `🌟 Днес ${sign.nameBg} има силна здравна енергия! Опитайте нещо ново в храненето — добавете повече зеленчуци. Разходка на чист въздух ще ви зареди. Емоциите ви са балансирани. Щастливо число: 7.`
        : `🌟 Today ${sign.name} has strong health energy! Try something new in your diet — add more vegetables. A walk in fresh air will energize you. Your emotions are balanced. Lucky number: 7.`
      );
      setHealthScore(7);
    } finally {
      setLoading(false);
    }
  }, [language]);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] overflow-hidden min-h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0">
          <img
            src="/images/horoscope-hero.jpg"
            alt="Cosmic zodiac sky"
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/30" />
        </div>

        <div className="relative z-10 text-center px-4 max-w-3xl mx-auto">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl md:text-6xl font-display font-bold text-white mb-4 drop-shadow-lg"
          >
            {language === 'bg' ? 'Здравен Хороскоп' : 'Health Horoscope'}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg md:text-xl text-white/80 font-light"
          >
            {language === 'bg'
              ? 'Открийте какво казват звездите за вашето здраве днес'
              : 'Discover what the stars say about your health today'}
          </motion.p>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Zodiac Wheel Image */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="flex justify-center mb-10"
        >
          <img
            src="/images/zodiac-wheel.jpg"
            alt="Zodiac wheel"
            className="w-48 h-48 md:w-56 md:h-56 rounded-full object-cover shadow-xl border-4 border-primary/20"
          />
        </motion.div>

        {/* Zodiac Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-12">
          {zodiacSigns.map((sign, index) => (
            <motion.div
              key={sign.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05, duration: 0.4 }}
            >
              <button
                onClick={() => generateHoroscope(sign)}
                disabled={loading}
                className={`group relative w-full rounded-xl overflow-hidden transition-all duration-300 ${
                  selectedSign?.id === sign.id
                    ? 'ring-2 ring-primary scale-[1.03] shadow-xl'
                    : 'hover:scale-[1.03] hover:shadow-lg'
                }`}
              >
                {/* Sign Image */}
                <div className="aspect-[3/4] relative">
                  <img
                    src={sign.image}
                    alt={sign.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${sign.color} opacity-60 mix-blend-multiply`} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                  {/* Content overlay */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-2">
                    <span className="text-4xl md:text-5xl mb-1 drop-shadow-lg">{sign.symbol}</span>
                    <span className="text-sm font-display font-bold drop-shadow-md">
                      {language === 'bg' ? sign.nameBg : sign.name}
                    </span>
                    <span className="text-[10px] text-white/70 mt-0.5">
                      {language === 'bg' ? sign.datesBg : sign.dates}
                    </span>
                  </div>

                  {/* Element badge */}
                  <div className="absolute top-2 right-2">
                    <span className="flex items-center gap-1 bg-black/40 backdrop-blur-sm text-white text-[10px] px-1.5 py-0.5 rounded-full">
                      {sign.icon}
                    </span>
                  </div>
                </div>
              </button>
            </motion.div>
          ))}
        </div>

        {/* Result Section */}
        <AnimatePresence mode="wait">
          {loading && (
            <motion.div
              key="loading"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col items-center gap-4 py-16"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                className="text-7xl"
              >
                {selectedSign?.symbol}
              </motion.div>
              <p className="text-muted-foreground animate-pulse text-lg">
                {language === 'bg' ? 'Четем звездите...' : 'Reading the stars...'}
              </p>
            </motion.div>
          )}

          {!loading && horoscope && selectedSign && (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="overflow-hidden border border-border shadow-xl">
                {/* Card Hero with sign image */}
                <div className="relative h-48 md:h-56">
                  <img
                    src={selectedSign.image}
                    alt={selectedSign.name}
                    className="w-full h-full object-cover"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-r ${selectedSign.color} opacity-70 mix-blend-multiply`} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />

                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <div className="flex items-end justify-between">
                      <div className="flex items-center gap-4">
                        <span className="text-6xl drop-shadow-lg">{selectedSign.symbol}</span>
                        <div>
                          <CardTitle className="text-3xl font-display text-white drop-shadow-md">
                            {language === 'bg' ? selectedSign.nameBg : selectedSign.name}
                          </CardTitle>
                          <p className="text-white/80 text-sm">
                            {language === 'bg' ? selectedSign.datesBg : selectedSign.dates}
                          </p>
                        </div>
                      </div>
                      <Badge className="bg-white/20 text-white border-white/30 backdrop-blur-sm">
                        {selectedSign.icon}
                        <span className="ml-1">{language === 'bg' ? selectedSign.elementBg : selectedSign.element}</span>
                      </Badge>
                    </div>

                    {/* Health Score Bar */}
                    <div className="mt-4">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-white/90 flex items-center gap-1">
                          <Heart className="w-4 h-4" />
                          {language === 'bg' ? 'Здравна енергия' : 'Health Energy'}
                        </span>
                        <span className="text-sm font-bold">{healthScore}/10</span>
                      </div>
                      <div className="w-full h-2 bg-white/20 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${healthScore * 10}%` }}
                          transition={{ duration: 1, delay: 0.3 }}
                          className="h-full bg-white/80 rounded-full"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <CardContent className="p-6 md:p-8">
                  <ScrollArea className="max-h-[400px]">
                    <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap leading-relaxed text-foreground">
                      {horoscope}
                    </div>
                  </ScrollArea>

                  <div className="mt-6 flex items-center justify-between border-t border-border pt-4">
                    <p className="text-xs text-muted-foreground">
                      {language === 'bg'
                        ? `${new Date().toLocaleDateString('bg-BG', { day: 'numeric', month: 'long', year: 'numeric' })}`
                        : `${new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })}`}
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => generateHoroscope(selectedSign)}
                      className="gap-2"
                    >
                      <Star className="w-4 h-4" />
                      {language === 'bg' ? 'Ново четене' : 'New reading'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {!loading && !horoscope && (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <p className="text-muted-foreground text-lg">
                {language === 'bg' ? 'Изберете вашата зодия, за да разберете какво ви очаква днес' : 'Select your zodiac sign to discover what awaits you today'}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default HealthHoroscope;

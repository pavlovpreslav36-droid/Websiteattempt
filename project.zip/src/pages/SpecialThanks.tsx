import { motion } from "framer-motion";
import { Heart, Instagram, Star, Sparkles, Users } from "lucide-react";
import { Reveal } from "@/components/Reveal";

interface TeamMember {
  name: string;
  instagram: string;
  role: string;
  appreciation: string;
  quote: string;
  gradient: string;
  icon: React.ReactNode;
}

const team: TeamMember[] = [
  {
    name: "Христова",
    instagram: "khristova235",
    role: "Учител и наставник",
    appreciation:
      "Огромна благодарност към г-жа Христова за безценното ръководство и напътствия. Без нейната визия и професионална подкрепа този проект нямаше да бъде същият. Тя беше искрата, която запали всичко. Нейната креативност и ентусиазъм бяха заразителни — винаги знаеше как да насочи обикновената идея към нещо магическо. Истински вдъхновяващ учител.",
    quote: "\u201EИстинската сила е в хората, които вярват в теб.\u201C",
    gradient: "from-rose-500/20 via-pink-500/10 to-fuchsia-500/20",
    icon: <Heart className="w-6 h-6 sm:w-8 sm:h-8" />,
  },
  {
    name: "Тошко",
    instagram: "_toshko_7",
    role: "Мотивация и морална подкрепа",
    appreciation:
      "Огромно благодаря на Тошко за несломимата вяра в този проект и за това, че винаги беше до мен в трудните моменти. Неговият оптимизъм и положителна енергия ме караха да продължавам напред, дори когато нещата изглеждаха невъзможни. Той е истински приятел — от тези, които са рядкост.",
    quote: "\u201EИстинската сила идва от хората до теб.\u201C",
    gradient: "from-blue-500/20 via-cyan-500/10 to-teal-500/20",
    icon: <Star className="w-6 h-6 sm:w-8 sm:h-8" />,
  },
  {
    name: "Коцето",
    instagram: "koce_naidenov777",
    role: "Готин човек с полезни съвети",
    appreciation:
      "Коцето е просто страхотен човек. Винаги е имал готови съвети и полезни идеи, които правеха нещата по-добри. Неговите подсказки бяха точно навреме и винаги на място. Благодаря му, че е такъв какъвто е — един наистина як човек, на когото винаги можеш да разчиташ.",
    quote: "\u201EНай-добрите съвети идват от най-готините хора.\u201C",
    gradient: "from-amber-500/20 via-orange-500/10 to-yellow-500/20",
    icon: <Sparkles className="w-6 h-6 sm:w-8 sm:h-8" />,
  },
];

const FloatingHearts = () => (
  <div className="absolute inset-0 overflow-hidden pointer-events-none">
    {Array.from({ length: 12 }).map((_, i) => (
      <motion.div
        key={i}
        className="absolute text-primary/10"
        initial={{
          x: Math.random() * 100 + "%",
          y: "110%",
          scale: Math.random() * 0.5 + 0.5,
          rotate: Math.random() * 360,
        }}
        animate={{ y: "-10%", rotate: Math.random() * 360 + 180 }}
        transition={{
          duration: Math.random() * 8 + 10,
          repeat: Infinity,
          delay: Math.random() * 10,
          ease: "linear",
        }}
      >
        <Heart className="w-4 h-4 sm:w-6 sm:h-6 fill-current" />
      </motion.div>
    ))}
  </div>
);

const PersonCard = ({ member, index }: { member: TeamMember; index: number }) => {
  const isEven = index % 2 === 0;

  return (
    <Reveal direction={isEven ? "left" : "right"} delay={0.1} duration={0.9}>
      <div className="relative group">
        <div
          className={`absolute inset-0 bg-gradient-to-br ${member.gradient} rounded-2xl sm:rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700`}
        />

        <div className="relative bg-card/80 backdrop-blur-xl border border-border/50 rounded-2xl sm:rounded-3xl p-5 sm:p-8 md:p-12 overflow-hidden">
          {/* Decorative corners */}
          <div className="absolute top-0 left-0 w-16 sm:w-24 h-16 sm:h-24 bg-gradient-to-br from-primary/10 to-transparent rounded-br-full" />
          <div className="absolute bottom-0 right-0 w-20 sm:w-32 h-20 sm:h-32 bg-gradient-to-tl from-primary/5 to-transparent rounded-tl-full" />

          <div
            className={`flex flex-col ${isEven ? "md:flex-row" : "md:flex-row-reverse"} gap-5 sm:gap-8 md:gap-12 items-center`}
          >
            {/* Avatar */}
            <div className="flex-shrink-0">
              <div
                className={`w-28 h-28 sm:w-40 sm:h-40 md:w-52 md:h-52 rounded-2xl sm:rounded-3xl bg-gradient-to-br ${member.gradient} flex items-center justify-center relative overflow-hidden`}
              >
                <div className="absolute inset-0 bg-background/30 backdrop-blur-sm" />
                <div className="relative z-10 flex flex-col items-center gap-2 sm:gap-3">
                  <div className="text-primary">{member.icon}</div>
                  <span className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-foreground">
                    {member.name.charAt(0)}
                  </span>
                </div>
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
                  animate={{ x: ["-100%", "200%"] }}
                  transition={{ duration: 3, repeat: Infinity, repeatDelay: 4 }}
                />
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 text-center md:text-left space-y-3 sm:space-y-5">
              <div>
                <h3 className="text-2xl sm:text-3xl md:text-4xl font-display font-bold text-foreground mb-1 sm:mb-2">
                  {member.name}
                </h3>
                <a
                  href={`https://instagram.com/${member.instagram}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors text-base sm:text-lg"
                >
                  <Instagram className="w-4 h-4 sm:w-5 sm:h-5" />
                  @{member.instagram}
                </a>
              </div>

              <div className="inline-block px-3 sm:px-4 py-1 sm:py-1.5 rounded-full bg-primary/10 text-primary text-xs sm:text-sm font-medium">
                {member.role}
              </div>

              <p className="text-muted-foreground text-base sm:text-lg leading-relaxed">
                {member.appreciation}
              </p>

              <blockquote className="border-l-4 border-primary/50 pl-4 sm:pl-5 italic text-foreground/80 text-base sm:text-lg font-display">
                {member.quote}
              </blockquote>
            </div>
          </div>
        </div>
      </div>
    </Reveal>
  );
};

const SpecialThanks = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] overflow-hidden min-h-[56vh] flex items-center justify-center py-12">
        <div className="absolute inset-0">
          <img
            src="/images/thanks-hero.jpg"
            alt="Специални благодарности"
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/45 to-black/25" />
        </div>

        <FloatingHearts />

        <div className="relative z-10 text-center px-4 sm:px-6 max-w-4xl mx-auto">
          <Reveal direction="scale" delay={0}>
            <div className="inline-flex items-center justify-center w-14 h-14 sm:w-20 sm:h-20 rounded-full bg-primary/20 backdrop-blur-xl mb-4 sm:mb-6">
              <Heart className="w-7 h-7 sm:w-10 sm:h-10 text-white fill-primary" />
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.15}>
            <h1 className="text-3xl sm:text-5xl md:text-7xl lg:text-8xl font-display font-bold text-white mb-4 sm:mb-6">
              Специални{" "}
              <span className="bg-gradient-to-r from-primary via-pink-400 to-rose-400 bg-clip-text text-transparent">
                Благодарности
              </span>
            </h1>
          </Reveal>

          <Reveal direction="up" delay={0.3}>
            <p className="text-base sm:text-xl md:text-2xl text-white/85 max-w-2xl mx-auto leading-relaxed">
              На хората, които вярваха в мен и ми помогнаха да превърна една мечта в реалност.
              Без вас нищо от това нямаше да е възможно.
            </p>
          </Reveal>

          <Reveal direction="up" delay={0.45}>
            <div className="flex items-center justify-center gap-2 mt-6 sm:mt-8 text-white/60">
              <Users className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-xs sm:text-sm font-medium tracking-widest uppercase">
                Моят отбор
              </span>
              <Users className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
          </Reveal>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-6 sm:bottom-10 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-5 h-8 sm:w-6 sm:h-10 rounded-full border-2 border-foreground/20 flex items-start justify-center pt-1.5 sm:pt-2">
            <motion.div
              className="w-1 h-1 sm:w-1.5 sm:h-1.5 rounded-full bg-primary"
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </div>
        </motion.div>
      </section>

      {/* Team Cards */}
      <section className="relative py-12 sm:py-20 md:py-32 px-4 sm:px-6">
        <div className="max-w-5xl mx-auto space-y-10 sm:space-y-16 md:space-y-24">
          {team.map((member, i) => (
            <PersonCard key={member.instagram} member={member} index={i} />
          ))}
        </div>
      </section>

      {/* Outro Section */}
      <section className="relative py-16 sm:py-24 md:py-40 px-4 sm:px-6 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-primary/5 via-transparent to-transparent" />
        <FloatingHearts />

        <div className="relative z-10 max-w-3xl mx-auto text-center space-y-6 sm:space-y-8">
          <Reveal direction="scale">
            <div className="flex justify-center gap-2 sm:gap-3">
              {["❤️", "🙏", "⭐", "💪"].map((emoji, i) => (
                <motion.span
                  key={i}
                  className="text-3xl sm:text-4xl md:text-5xl"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
                >
                  {emoji}
                </motion.span>
              ))}
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.15}>
            <h2 className="text-3xl sm:text-4xl md:text-6xl font-display font-bold text-foreground">
              Благодаря ви,{" "}
              <span className="bg-gradient-to-r from-primary via-rose-400 to-amber-400 bg-clip-text text-transparent">
                че сте до мен
              </span>
            </h2>
          </Reveal>

          <Reveal direction="up" delay={0.3}>
            <p className="text-base sm:text-lg md:text-xl text-muted-foreground leading-relaxed">
              Всеки от вас остави отпечатък върху този проект и върху мен като човек.
              Тази страница е малък жест на признателност за голямата ви подкрепа.
              Вие не сте просто помощници — вие сте моето вдъхновение и моята сила.
            </p>
          </Reveal>

          <Reveal direction="up" delay={0.45}>
            <p className="text-muted-foreground/60 text-xs sm:text-sm tracking-widest uppercase pt-4 sm:pt-8">
              Направено с ❤️ и безкрайна благодарност
            </p>
          </Reveal>
        </div>
      </section>
    </div>
  );
};

export default SpecialThanks;

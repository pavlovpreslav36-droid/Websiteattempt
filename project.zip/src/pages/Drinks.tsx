import { useMemo, useState } from "react";
import { Search, X } from "lucide-react";
import Footer from "@/components/Footer";
import { PageBanner, SectionTitle } from "@/components/food/PageBanner";
import { HydrationTracker } from "@/components/food/HydrationTracker";
import { DrinkCard } from "@/components/food/DrinkCard";
import { DrinkDialog } from "@/components/food/DrinkDialog";
import { DrinkGlass } from "@/components/food/DrinkGlass";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { drinks, drinkTypes, getDrinkById, type Drink, type DrinkTag, type DrinkType } from "@/data/drinks";
import { tagLabels } from "@/data/diets";

const flagOptions: DrinkTag[] = ["quit", "vegan", "sugar-free", "caffeine-free", "quick"];

const Drinks = () => {
  const [open, setOpen] = useState<Drink | null>(null);
  const [type, setType] = useState<"all" | DrinkType>("all");
  const [flags, setFlags] = useState<DrinkTag[]>([]);
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return drinks.filter(
      (d) =>
        (type === "all" || d.type === type) &&
        flags.every((f) => d.tags.includes(f)) &&
        (!q || d.name.toLowerCase().includes(q) || d.ingredients.some((i) => i.toLowerCase().includes(q))),
    );
  }, [type, flags, query]);

  const toggleFlag = (f: DrinkTag) => setFlags((prev) => (prev.includes(f) ? prev.filter((x) => x !== f) : [...prev, f]));
  const reset = () => {
    setType("all");
    setFlags([]);
    setQuery("");
  };

  const heroDrinks = ["cucumber-mint-water", "berry-basil-water", "ginger-lemon-tea"].map(getDrinkById).filter((d): d is Drink => !!d);

  return (
    <div className="min-h-screen bg-background">
      <PageBanner
        eyebrow="Вода, чай и смутита"
        title="Напитки"
        text={`${drinks.length} напитки: овкусени води, билкови чайове, смутита и топли напитки. Пиенето на вода и чай дава на ръцете и устата занимание и помага деня да върви по-леко, особено когато се отказваш от никотин.`}
        art={
          <div className="flex items-end gap-1">
            {heroDrinks.map((d, i) => (
              <div key={d.id} className={i % 2 ? "float-slower" : "float-slow"}>
                <DrinkGlass drink={d} label={d.name} className="h-44 w-auto" />
              </div>
            ))}
          </div>
        }
      />

      <section className="container py-10 md:py-14">
        <HydrationTracker />
      </section>

      <section className="container pb-16 md:pb-24">
        <SectionTitle text="Избери вид и филтри. Натисни напитка за съставки и приготвяне.">Всички напитки</SectionTitle>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" aria-hidden="true" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Търси напитка или съставка..."
            aria-label="Търси напитка"
            className="h-12 pl-12 pr-12 rounded-full bg-card text-base"
          />
          {query && (
            <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 grid place-items-center w-7 h-7 rounded-full bg-muted" aria-label="Изчисти търсенето">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="mt-5 no-scrollbar -mx-5 md:mx-0 px-5 md:px-0 flex gap-2 overflow-x-auto">
          {([{ id: "all", label: "Всички" }, ...drinkTypes] as { id: "all" | DrinkType; label: string }[]).map((t) => (
            <button
              key={t.id}
              onClick={() => setType(t.id)}
              aria-pressed={type === t.id}
              className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold border transition-colors ${type === t.id ? "bg-wine text-cream border-wine" : "bg-card text-foreground border-border hover:border-wine/50"}`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          {flagOptions.map((f) => {
            const on = flags.includes(f);
            return (
              <button
                key={f}
                onClick={() => toggleFlag(f)}
                aria-pressed={on}
                className={`rounded-full px-4 py-2 text-sm font-semibold border transition-colors ${on ? "bg-primary text-primary-foreground border-primary" : "bg-card text-foreground border-border hover:border-primary/50"}`}
              >
                {tagLabels[f]}
              </button>
            );
          })}
          <p className="ml-auto text-sm font-semibold text-foreground" aria-live="polite">{results.length} {results.length === 1 ? "напитка" : "напитки"}</p>
        </div>

        {results.length === 0 ? (
          <div className="mt-10 rounded-[2rem] bg-card border border-border p-10 text-center">
            <p className="font-brand text-2xl">Няма напитки с тези условия</p>
            <p className="mt-2 text-muted-foreground">Махни някой филтър или изтрий търсенето.</p>
            <Button className="mt-5" onClick={reset}>Покажи всички</Button>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
            {results.map((d) => (
              <DrinkCard key={d.id} drink={d} onOpen={setOpen} />
            ))}
          </div>
        )}
      </section>

      <DrinkDialog drink={open} onClose={() => setOpen(null)} />
      <Footer />
    </div>
  );
};

export default Drinks;

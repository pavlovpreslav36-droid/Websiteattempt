import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Scan, Search, Loader2, ScanBarcode, Leaf, Flame, Award, BookOpen, Scale } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import Footer from "@/components/Footer";
import { AllergenHighlighter } from "@/components/AllergenHighlighter";
import { BarcodeScanner } from "@/components/BarcodeScanner";
import { useAchievements } from "@/hooks/useAchievements";
import { ProductCatalog, CatalogProduct } from "@/components/ProductCatalog";
import { ProductComparison } from "@/components/ProductComparison";
import { Reveal } from "@/components/Reveal";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface ProductInfo {
  name: string;
  calories: number;
  carbs: number;
  protein: number;
  fats: number;
  sugars?: number;
  fiber?: number;
  saturatedFat?: number;
  salt?: number;
  isHealthy: boolean;
  healthScore: number;
  nutriScore?: string | null;
  novaGroup?: number | null;
  recommendation: string;
  ingredients?: string | null;
  richIn?: string[];
  healthBenefits?: string[];
  category?: string | null;
  origin?: string | null;
  labels?: string | null;
  source?: string;
}

const ProductScanner = () => {
  const [productName, setProductName] = useState("");
  const [manufacturer, setManufacturer] = useState("");
  const [loading, setLoading] = useState(false);
  const [productInfo, setProductInfo] = useState<ProductInfo | null>(null);
  const [showScanner, setShowScanner] = useState(false);
  const [scannedCode, setScannedCode] = useState("");
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [scanCount, setScanCount] = useState(0);
  const [compareList, setCompareList] = useState<CatalogProduct[]>([]);
  const [activeTab, setActiveTab] = useState("scanner");
  const { toast } = useToast();
  const { trackProgress, getProgress } = useAchievements();

  const handleAddToCompare = (product: CatalogProduct) => {
    if (compareList.length >= 3) {
      toast({ title: "Максимум 3 продукта", description: "Премахнете продукт преди да добавите нов", variant: "destructive" });
      return;
    }
    if (!compareList.some(p => p.id === product.id)) {
      setCompareList(prev => [...prev, product]);
      toast({ title: "✅ Добавен за сравнение", description: product.name });
    }
  };

  const handleRemoveFromCompare = (id: string) => {
    setCompareList(prev => prev.filter(p => p.id !== id));
  };

  useEffect(() => {
    setScanCount(getProgress('product_scans'));
  }, [getProgress]);

  const handleBarcodeScan = (code: string) => {
    setScannedCode(code);
    setShowScanner(false);
    setShowConfirmDialog(true);
  };

  const confirmScannedProduct = () => {
    setProductName(scannedCode);
    setShowConfirmDialog(false);
    analyzeProductWithCode(scannedCode);
  };

  const rejectScannedProduct = () => {
    setShowConfirmDialog(false);
    setScannedCode("");
  };

  const analyzeProductWithCode = async (code: string) => {
    if (!code.trim()) return;
    
    setLoading(true);
    try {
      const barcodePattern = /^\d{8,13}$/;
      const isBarcode = barcodePattern.test(code.trim());
      
      const { data, error } = await supabase.functions.invoke('analyze-product', {
        body: { 
          productName: code.trim(),
          manufacturer: manufacturer.trim(),
          barcode: isBarcode ? code.trim() : null
        }
      });

      if (error) throw error;

      setProductInfo(data);
      
      const newCount = trackProgress('product_scans', 1);
      setScanCount(newCount);
      
      toast({
        title: "✅ Успешно!",
        description: isBarcode ? "Баркодът е сканиран и анализиран" : "Продуктът е анализиран",
      });
    } catch (error) {
      console.error('Error analyzing product:', error);
      toast({
        title: "Грешка",
        description: "Не успяхме да анализираме продукта. Опитайте отново.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const analyzeProduct = async () => {
    if (!productName.trim()) {
      toast({
        title: "Грешка",
        description: "Моля, въведете име на продукт",
        variant: "destructive",
      });
      return;
    }
    await analyzeProductWithCode(productName);
  };

  const getNutriScoreColor = (grade: string) => {
    const colors: Record<string, string> = {
      'A': 'bg-green-500',
      'B': 'bg-lime-500',
      'C': 'bg-yellow-500',
      'D': 'bg-orange-500',
      'E': 'bg-red-500',
    };
    return colors[grade] || 'bg-muted';
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero with image */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] min-h-[30vh] md:min-h-[38vh] flex items-end justify-center overflow-hidden pt-12 pb-8 md:pb-10">
        <div className="absolute inset-0 z-0">
          <img src="/images/scanner-hero.jpg" alt="Скенер на продукти" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10" />
        </div>
        <div className="relative z-10 text-center px-6 max-w-3xl mx-auto">
          <Reveal>
            <div className="flex items-center justify-center gap-3 mb-3">
              <Scan className="w-10 h-10 text-white" />
              <h1 className="text-4xl md:text-6xl font-display font-bold text-white">
                Скенер на продукти
              </h1>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="text-lg text-white/85">
              Сканирайте баркод или въведете име на продукт за подробен анализ
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="flex items-center justify-center gap-2 mt-4 bg-primary/10 rounded-full px-4 py-2 w-fit mx-auto">
              <Award className="w-5 h-5 text-white" />
              <span className="font-bold text-white">{scanCount}</span>
              <span className="text-sm text-white/85">сканирания</span>
            </div>
          </Reveal>
        </div>
      </section>

      <div className="px-6 pb-8">
        <div className="max-w-4xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="scanner" className="gap-2"><Scan className="w-4 h-4" />Скенер</TabsTrigger>
              <TabsTrigger value="catalog" className="gap-2"><BookOpen className="w-4 h-4" />Каталог</TabsTrigger>
              <TabsTrigger value="compare" className="gap-2">
                <Scale className="w-4 h-4" />Сравнение
                {compareList.length > 0 && (
                  <Badge variant="secondary" className="ml-1 h-5 w-5 p-0 flex items-center justify-center text-[10px]">{compareList.length}</Badge>
                )}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="scanner" className="mt-6">
              <Reveal>
                <Card className="p-8 bg-card mb-8">
                  <div className="space-y-6">
                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button
                        onClick={() => setShowScanner(true)}
                        size="lg"
                        className="w-full h-20 text-lg gap-3 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg"
                      >
                        <ScanBarcode className="w-8 h-8" />
                        <div className="flex flex-col items-start">
                          <span className="font-bold">Сканирай с камера</span>
                          <span className="text-xs opacity-80">Бързо сканиране на баркод</span>
                        </div>
                      </Button>
                    </motion.div>

                    <div className="relative flex items-center gap-4">
                      <div className="flex-1 h-px bg-border" />
                      <span className="text-sm text-muted-foreground px-2">или</span>
                      <div className="flex-1 h-px bg-border" />
                    </div>

                    <div>
                      <Label htmlFor="product" className="text-lg">Име на продукт / Баркод</Label>
                      <Input
                        id="product"
                        placeholder="Напр: Кока-Кола, 5901234123457..."
                        value={productName}
                        onChange={(e) => setProductName(e.target.value)}
                        className="mt-2"
                        onKeyDown={(e) => e.key === 'Enter' && analyzeProduct()}
                      />
                    </div>

                    <div>
                      <Label htmlFor="manufacturer" className="text-lg">Производител (незадължително)</Label>
                      <Input
                        id="manufacturer"
                        placeholder="Напр: Nestle, Danone..."
                        value={manufacturer}
                        onChange={(e) => setManufacturer(e.target.value)}
                        className="mt-2"
                      />
                    </div>

                    <Button onClick={analyzeProduct} disabled={loading} size="lg" variant="secondary" className="w-full">
                      {loading ? (
                        <><Loader2 className="mr-2 animate-spin" />Анализира се...</>
                      ) : (
                        <><Search className="mr-2" />Анализирай продукт</>
                      )}
                    </Button>
                  </div>
                </Card>
              </Reveal>

              <AnimatePresence>
                {productInfo && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, y: -20 }}
                    transition={{ type: "spring", duration: 0.5 }}
                    className="space-y-6"
                  >
                    <Card className={`p-8 ${productInfo.isHealthy ? 'bg-green-500/10 border-green-500' : 'bg-red-500/10 border-red-500'}`}>
                      <div className="text-center mb-6">
                        <div className="flex items-center justify-center gap-3 mb-2 flex-wrap">
                          {productInfo.category && (
                            <Badge variant="outline" className="text-xs">{productInfo.category}</Badge>
                          )}
                          {productInfo.nutriScore && (
                            <Badge className={`${getNutriScoreColor(productInfo.nutriScore)} text-white font-bold`}>
                              Nutri-Score {productInfo.nutriScore}
                            </Badge>
                          )}
                          {productInfo.novaGroup && (
                            <Badge variant="secondary">NOVA {productInfo.novaGroup}</Badge>
                          )}
                        </div>
                        <h2 className="text-3xl font-bold mb-2">{productInfo.name}</h2>
                        {productInfo.origin && (
                          <p className="text-sm text-muted-foreground mb-2">📍 {productInfo.origin}</p>
                        )}
                        <motion.div className="text-6xl mb-4" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.2 }}>
                          {productInfo.isHealthy ? '✅' : '⚠️'}
                        </motion.div>
                        <p className="text-2xl font-bold">Здравословен рейтинг: {productInfo.healthScore}/10</p>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                        {[
                          { label: 'Калории', value: productInfo.calories, unit: 'kcal', icon: <Flame className="w-4 h-4" /> },
                          { label: 'Въглехидрати', value: productInfo.carbs, unit: 'г' },
                          { label: 'Протеин', value: productInfo.protein, unit: 'г' },
                          { label: 'Мазнини', value: productInfo.fats, unit: 'г' },
                          { label: 'Захар', value: productInfo.sugars, unit: 'г' },
                          { label: 'Фибри', value: productInfo.fiber, unit: 'г', icon: <Leaf className="w-4 h-4" /> },
                          { label: 'Насит. мазнини', value: productInfo.saturatedFat, unit: 'г' },
                          { label: 'Сол', value: productInfo.salt, unit: 'г' },
                        ].filter(item => item.value !== undefined).map((item, i) => (
                          <motion.div
                            key={item.label}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.05 * i }}
                          >
                            <Card className="p-3 bg-card">
                              <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                                {item.icon}
                                <span>{item.label}</span>
                              </div>
                              <p className="text-xl font-bold">{item.value}{item.unit}</p>
                            </Card>
                          </motion.div>
                        ))}
                      </div>

                      {productInfo.richIn && productInfo.richIn.length > 0 && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
                          <Card className="p-4 bg-card mb-4">
                            <h3 className="text-lg font-bold mb-2">💎 Богат на</h3>
                            <div className="flex flex-wrap gap-2">
                              {productInfo.richIn.map((nutrient, i) => (
                                <Badge key={i} variant="secondary" className="text-sm">{nutrient}</Badge>
                              ))}
                            </div>
                          </Card>
                        </motion.div>
                      )}

                      {productInfo.healthBenefits && productInfo.healthBenefits.length > 0 && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
                          <Card className="p-4 bg-card mb-4">
                            <h3 className="text-lg font-bold mb-3">🏥 Здравословни ползи</h3>
                            <div className="space-y-2">
                              {productInfo.healthBenefits.map((benefit, i) => (
                                <motion.div
                                  key={i}
                                  initial={{ opacity: 0, x: -20 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: 0.5 + i * 0.1 }}
                                  className="p-3 bg-primary/5 rounded-lg text-sm"
                                >
                                  {benefit}
                                </motion.div>
                              ))}
                            </div>
                          </Card>
                        </motion.div>
                      )}

                      {productInfo.ingredients && (
                        <Card className="p-6 bg-card mb-4">
                          <h3 className="text-xl font-bold mb-3">🧪 Съставки</h3>
                          <AllergenHighlighter ingredients={productInfo.ingredients} />
                        </Card>
                      )}

                      <Card className="p-6 bg-card">
                        <h3 className="text-xl font-bold mb-3">💡 Препоръка</h3>
                        <p className="text-lg">{productInfo.recommendation}</p>
                        {productInfo.source && (
                          <p className="text-xs text-muted-foreground mt-3">Източник: {productInfo.source}</p>
                        )}
                      </Card>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>
            </TabsContent>

            <TabsContent value="catalog" className="mt-6">
              <ProductCatalog onAddToCompare={handleAddToCompare} compareList={compareList} />
            </TabsContent>

            <TabsContent value="compare" className="mt-6">
              <ProductComparison products={compareList} onRemove={handleRemoveFromCompare} />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Barcode Scanner Modal */}
      <AnimatePresence>
        {showScanner && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <div className="w-full max-w-md">
              <BarcodeScanner onScan={handleBarcodeScan} onClose={() => setShowScanner(false)} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ScanBarcode className="w-5 h-5" />
              Баркод сканиран
            </DialogTitle>
            <DialogDescription className="pt-2">
              Сканиран код: <strong className="text-foreground">{scannedCode}</strong>
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={rejectScannedProduct}>Отказ</Button>
            <Button onClick={confirmScannedProduct}>Анализирай</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default ProductScanner;

import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Check, Search, X, AlertCircle } from "lucide-react";
import Footer from "@/components/Footer";
import { PageBanner } from "@/components/food/PageBanner";
import { RecipeCard } from "@/components/food/RecipeCard";
import { RecipeDialog } from "@/components/food/RecipeDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { dietRecipes, mealOrder, type DietRecipe, type DietTag, type Meal } from "@/data/dietRecipes";
import { diets, getDiet, tagLabels } from "@/data/diets";

const PAGE = 24;
const combinable: DietTag[] = ["gluten-free", "lactose-free", "vegan", "vegetarian", "high-protein", "low-carb", "sugar-free", "quit", "quick"];

const DietPage = () => {
  const { slug } = useParams();
  const diet = getDiet(slug);

  const [tags, setTags] = useState<DietTag[]>(() => (diet && diet.slug !== "healthy" ? [diet.slug] : []));
  const [meal, setMeal] = useState<"all" | Meal>("all");
  const [maxTime, setMaxTime] = useState("all");
  const [sort, setSort] = useState("default");
  const [query, setQuery] = useState("");
  const [visible, setVisible] = useState(PAGE);
  const [open, setOpen] = useState<DietRecipe | null>(null);

  useEffect(() => {
    setTags(diet && diet.slug !== "healthy" ? [diet.slug] : []);
    setMeal("all");
    setMaxTime("all");
    setSort("default");
    setQuery("");
    setVisible(PAGE);
    window.scrollTo({ top: 0 });
  }, [slug]); // eslint-disable-line react-hooks/exhaustive-deps

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = dietRecipes.filter((r) => tags.every((t) => r.tags.includes(t)));
    if (meal !== "all") list = list.filter((r) => r.meal === meal);
    if (maxTime !== "all") list = list.filter((r) => r.minutes <= Number(maxTime));
    if (q) list = list.filter((r) => r.name.toLowerCase().includes(q) || r.ingredients.some((i) => i.toLowerCase().includes(q)));
    const sorted = [...list];
    if (sort === "time") sorted.sort((a, b) => a.minutes - b.minutes);
    if (sort === "kcal") sorted.sort((a, b) => a.kcal - b.kcal);
    if (sort === "protein") sorted.sort((a, b) => b.protein - a.protein);
    return sorted;
  }, [tags, meal, maxTime, sort, query]);

  if (!diet) {
    return (
      <div className="min-h-screen bg-background pt-nav">
        <div className="container py-24 text-center">
          <h1 className="display text-primary text-4xl">Няма такъв режим</h1>
          <p className="mt-4 text-muted-foreground">Избери един от списъка с режими.</p>
          <Button asChild className="mt-6"><Link to="/diets">Към режимите</Link></Button>
        </div>
      </div>
    );
  }

  const toggle = (t: DietTag) => {
    setTags((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
    setVisible(PAGE);
  };

  const reset = () => {
    setTags(diet.slug !== "healthy" ? [diet.slug] : []);
    setMeal("all");
    setMaxTime("all");
    setQuery("");
    setVisible(PAGE);
  };

  return (
    <div className="min-h-screen bg-background">
      <PageBanner eyebrow={`${diet.emoji} Режим`} title={diet.title} text={diet.intro}>
        <Link to="/diets" className="mt-7 inline-block eyebrow border border-cream/50 text-cream rounded-full px-5 py-3 hover:bg-cream hover:text-wine transition-colors">
          Всички режими
        </Link>
      </PageBanner>

      <section className="container pt-10 md:pt-14">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="rounded-[2rem] bg-card border border-border p-6">
            <h2 className="font-brand text-xl flex items-center gap-2"><Check className="w-5 h-5 text-primary" aria-hidden="true" />Подходящо</h2>
            <ul className="mt-3 space-y-2">
              {diet.good.map((g) => (<li key={g} className="flex gap-3 text-foreground"><span className="mt-2 w-1.5 h-1.5 rounded-full bg-primary shrink-0" aria-hidden="true" />{g}</li>))}
            </ul>
          </div>
          <div className="rounded-[2rem] bg-secondary p-6">
            <h2 className="font-brand text-xl flex items-center gap-2 text-secondary-foreground"><AlertCircle className="w-5 h-5 text-primary" aria-hidden="true" />Внимавай</h2>
            <ul className="mt-3 space-y-2">
              {diet.watch.map((w) => (<li key={w} className="flex gap-3 text-secondary-foreground"><span className="mt-2 w-1.5 h-1.5 rounded-full bg-primary shrink-0" aria-hidden="true" />{w}</li>))}
            </ul>
          </div>
        </div>
      </section>

      <section className="container py-10 md:py-14">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" aria-hidden="true" />
          <Input
            value={query}
            onChange={(e) => { setQuery(e.target.value); setVisible(PAGE); }}
            placeholder="Търси по име или съставка..."
            aria-label="Търси рецепта"
            className="h-12 pl-12 pr-12 rounded-full bg-card text-base"
          />
          {query && (
            <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 grid place-items-center w-7 h-7 rounded-full bg-muted" aria-label="Изчисти търсенето">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="mt-5">
          <p className="eyebrow text-muted-foreground mb-2">Комбинирай режими</p>
          <div className="flex flex-wrap gap-2">
            {combinable.map((t) => {
              const on = tags.includes(t);
              return (
                <button
                  key={t}
                  onClick={() => toggle(t)}
                  aria-pressed={on}
                  className={`rounded-full px-4 py-2 text-sm font-semibold border transition-colors ${on ? "bg-primary text-primary-foreground border-primary" : "bg-card text-foreground border-border hover:border-primary/50"}`}
                >
                  {tagLabels[t]}
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-5 no-scrollbar -mx-5 md:mx-0 px-5 md:px-0 flex gap-2 overflow-x-auto">
          {(["all", ...mealOrder] as const).map((m) => (
            <button
              key={m}
              onClick={() => { setMeal(m); setVisible(PAGE); }}
              aria-pressed={meal === m}
              className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold border transition-colors ${meal === m ? "bg-wine text-cream border-wine" : "bg-card text-foreground border-border hover:border-wine/50"}`}
            >
              {m === "all" ? "Всички ястия" : m}
            </button>
          ))}
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <Select value={maxTime} onValueChange={(v) => { setMaxTime(v); setVisible(PAGE); }}>
            <SelectTrigger className="w-[170px] h-11 rounded-full bg-card" aria-label="Време за приготвяне"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Всяко време</SelectItem>
              <SelectItem value="15">До 15 минути</SelectItem>
              <SelectItem value="30">До 30 минути</SelectItem>
              <SelectItem value="60">До 60 минути</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="w-[210px] h-11 rounded-full bg-card" aria-label="Подреди по"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="default">Подредба по ястие</SelectItem>
              <SelectItem value="time">Най-бързи първо</SelectItem>
              <SelectItem value="kcal">Най-малко калории</SelectItem>
              <SelectItem value="protein">Най-много протеин</SelectItem>
            </SelectContent>
          </Select>
          <p className="ml-auto text-sm font-semibold text-foreground" aria-live="polite">{results.length} {results.length === 1 ? "рецепта" : "рецепти"}</p>
        </div>

        {results.length === 0 ? (
          <div className="mt-10 rounded-[2rem] bg-card border border-border p-10 text-center">
            <p className="font-brand text-2xl">Няма рецепти с тази комбинация</p>
            <p className="mt-2 text-muted-foreground">Махни някой филтър или изтрий търсенето.</p>
            <Button className="mt-5" onClick={reset}>Върни филтрите</Button>
          </div>
        ) : (
          <>
            <div className="mt-8 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
              {results.slice(0, visible).map((r) => (
                <RecipeCard key={r.id} recipe={r} onOpen={setOpen} />
              ))}
            </div>
            {visible < results.length && (
              <div className="mt-10 text-center">
                <Button variant="outline" size="lg" onClick={() => setVisible((v) => v + PAGE)}>
                  Покажи още ({results.length - visible})
                </Button>
              </div>
            )}
          </>
        )}
      </section>

      <section className="container pb-16">
        <p className="eyebrow text-muted-foreground mb-3">Други режими</p>
        <div className="flex flex-wrap gap-2">
          {diets.filter((d) => d.slug !== diet.slug).map((d) => (
            <Link key={d.slug} to={`/diets/${d.slug}`} className="rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold text-foreground hover:border-primary/50 transition-colors">
              {d.emoji} {d.title}
            </Link>
          ))}
        </div>
      </section>

      <RecipeDialog recipe={open} onClose={() => setOpen(null)} />
      <Footer />
    </div>
  );
};

export default DietPage;

import { motion } from "framer-motion";
import { Reveal } from "@/components/Reveal";
import Footer from "@/components/Footer";
import {
  Apple, Droplets, Dumbbell, Brain,
  Award, Globe2, Clock, Ban, Sparkles, Shield, Wind, Salad,
} from "lucide-react";
import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { QuitFoodIdeas } from "@/components/QuitFoodIdeas";
import { QuitCounter } from "@/components/QuitCounter";

/**
 * TobaccoFree — „Без тютюн" секция.
 * Създадена в контекста на инициативата „Посланици на здравето" на
 * РЗИ – Враца и Световния ден без тютюн на СЗО (31 май).
 */

const cravingFighters = [
  {
    icon: Apple,
    title: "Плодове и зеленчуци",
    text: "Ябълки, моркови и целина заемат ръцете и устата — а свежият им вкус прави цигарите по-малко привлекателни.",
  },
  {
    icon: Droplets,
    title: "Вода — много вода",
    text: "Глътка вода при първия признак на желание заема устата и ръцете. Често пориви отшумяват само за няколко минути.",
  },
  {
    icon: Salad,
    title: "Млечни продукти",
    text: "Според някои малки проучвания млечните продукти променят вкуса на цигарата, но доказателствата са ограничени. Затова ги приеми като помощ, не като лек.",
  },
  {
    icon: Dumbbell,
    title: "Движение вместо цигара",
    text: "10 бързи клякания или кратка разходка освобождават ендорфини — същото наградно чувство, без дима.",
  },
  {
    icon: Wind,
    title: "Дълбоко дишане",
    text: "4 секунди вдишване, 4 задържане, 4 издишване. Желанието за цигара трае средно 3–5 минути — издишай го.",
  },
  {
    icon: Brain,
    title: "Заеми ръцете си",
    text: "Дъвка без захар, орехи, стрес-топка или молив — ритуалът „ръка → уста“ е половината навик.",
  },
];

const quitTimeline = [
  { time: "20 минути", text: "Кръвното налягане и пулсът се нормализират." },
  { time: "12 часа", text: "Въглеродният оксид в кръвта пада до нормални нива." },
  { time: "2 седмици", text: "Кръвообращението и белодробната функция се подобряват." },
  { time: "1 година", text: "Рискът от сърдечно-съдови заболявания намалява наполовина." },
  { time: "10 години", text: "Рискът от рак на белия дроб пада с около 50%." },
];

const facts = [
  { value: "8 млн.", label: "смъртни случая годишно в света от тютюн" },
  { value: "7000+", label: "химикала в цигарения дим, 70 от тях канцерогенни" },
  { value: "№1", label: "предотвратима причина за смърт в света" },
  { value: "31 май", label: "Световен ден без тютюн на СЗО" },
];

const TobaccoFree = () => {
  const navigate = useNavigate();
  const { hash } = useLocation();

  useEffect(() => {
    if (!hash) return;
    const t = window.setTimeout(() => document.getElementById(hash.slice(1))?.scrollIntoView({ behavior: "smooth", block: "start" }), 300);
    return () => window.clearTimeout(t);
  }, [hash]);

  return (
    <div className="min-h-screen bg-background">
      {/* ═══ HERO ═══ */}
      <section className="relative min-h-[56vh] flex items-center justify-center overflow-hidden pt-24 pb-10">
        <motion.div
          className="absolute w-[55vmax] h-[55vmax] rounded-full blur-3xl opacity-25"
          style={{
            background:
              "radial-gradient(circle, hsl(var(--primary) / 0.45), hsl(var(--accent) / 0.2), transparent 70%)",
          }}
          animate={{ scale: [1, 1.15, 1], opacity: [0.2, 0.32, 0.2] }}
          transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
        />
        <div className="relative z-10 text-center px-6 max-w-3xl mx-auto">
          <Reveal>
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-1.5 rounded-full text-sm font-medium mb-6">
              <Ban className="w-4 h-4" />
              Инициатива „Посланици на здравето"
            </div>
          </Reveal>
          <Reveal delay={0.08}>
            <h1 className="text-4xl md:text-7xl font-display font-bold text-foreground leading-[1.05] tracking-tight mb-6">
              Живот <span className="gradient-text">без дим</span>
            </h1>
          </Reveal>
          <Reveal delay={0.15}>
            <p className="text-muted-foreground text-base md:text-xl max-w-xl mx-auto leading-relaxed">
              Всеки ден без цигара е победа. Научи как храната, движението и дишането
              ти помагат да надвиеш желанието — завинаги.
            </p>
          </Reveal>
        </div>
      </section>

      {/* ═══ FACTS STRIP ═══ */}
      <section className="py-14 px-6">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-y-10 gap-x-6">
          {facts.map((f, i) => (
            <Reveal key={f.label} delay={i * 0.08} direction="up">
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-display font-bold text-primary">{f.value}</div>
                <div className="text-xs md:text-sm text-muted-foreground mt-1.5 leading-snug">{f.label}</div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ═══ QUIT COUNTER ═══ */}
      <section id="counter" className="pb-14 px-6 scroll-mt-24">
        <div className="max-w-3xl mx-auto">
          <Reveal>
            <QuitCounter />
          </Reveal>
        </div>
      </section>

      {/* ═══ CRAVING FIGHTERS ═══ */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <Reveal>
            <h2 className="text-3xl md:text-5xl font-display font-bold text-center mb-4 text-foreground">
              Храни и навици <span className="gradient-text">срещу желанието</span>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="text-center text-muted-foreground text-base md:text-lg mb-14 max-w-xl mx-auto">
              Когато поривът дойде — а той ще дойде — имай план. Ето го.
            </p>
          </Reveal>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cravingFighters.map((c, i) => (
              <Reveal key={c.title} delay={i * 0.06} direction="up">
                <motion.div
                  whileHover={{ y: -6 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  className="h-full p-6 rounded-3xl bg-card shadow-sm hover:shadow-md transition-shadow duration-300"
                >
                  <c.icon className="w-8 h-8 text-primary mb-4" />
                  <h3 className="text-lg font-display font-semibold text-foreground mb-2">{c.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{c.text}</p>
                </motion.div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ QUIT TIMELINE ═══ */}
      <section className="py-20 px-6 bg-card/30">
        <div className="max-w-3xl mx-auto">
          <Reveal>
            <h2 className="text-3xl md:text-5xl font-display font-bold text-center mb-4 text-foreground">
              Тялото ти <span className="gradient-text">се възстановява</span>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="text-center text-muted-foreground text-base md:text-lg mb-14">
              От първите минути след последната цигара
            </p>
          </Reveal>
          <div className="relative">
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-primary/25 md:-translate-x-1/2" />
            <div className="space-y-10">
              {quitTimeline.map((t, i) => (
                <Reveal key={t.time} delay={i * 0.08} direction={i % 2 === 0 ? "left" : "right"}>
                  <div className={`relative flex items-start gap-6 md:w-1/2 ${i % 2 === 0 ? "md:pr-10" : "md:ml-auto md:pl-10"}`}>
                    <div className="absolute left-4 md:left-auto md:right-0 md:translate-x-1/2 -translate-x-1/2 md:translate-x-1/2 top-1 w-3 h-3 rounded-full bg-primary shadow-[0_0_12px_hsl(var(--primary)/0.6)]" style={i % 2 === 0 ? {} : { left: 0, right: "auto", transform: "translateX(-50%)" }} />
                    <div className="pl-10 md:pl-0">
                      <div className="text-primary font-display font-bold text-lg flex items-center gap-2">
                        <Clock className="w-4 h-4" /> {t.time}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{t.text}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══ FOOD & PRODUCTS ═══ */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <Reveal>
            <h2 className="text-3xl md:text-5xl font-display font-bold mb-4 text-foreground">
              На масата: <span className="gradient-text">какво да хапнеш</span>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="text-muted-foreground text-base md:text-lg mb-10 max-w-xl">
              Ястия от рецептите ни и малки навици за първите седмици без цигара.
            </p>
          </Reveal>
          <QuitFoodIdeas />
        </div>
      </section>

      {/* ═══ ПОСЛАНИЦИ НА ЗДРАВЕТО ═══ */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <Reveal>
            <div className="p-8 md:p-12 rounded-3xl bg-card border border-border shadow-card text-center">
              <Award className="w-12 h-12 text-primary mx-auto mb-6" />
              <h2 className="text-2xl md:text-4xl font-display font-bold text-foreground mb-4">
                „Посланици на здравето"
              </h2>
              <p className="text-muted-foreground text-sm md:text-base leading-relaxed max-w-2xl mx-auto mb-4">
                Тази секция е част от ученическа инициатива за превенция на тютюнопушенето,
                в духа на националния конкурс „Посланици на здравето", организиран с подкрепата
                на Регионалната здравна инспекция – Враца и Министерството на здравеопазването.
              </p>
              <p className="text-muted-foreground text-sm md:text-base leading-relaxed max-w-2xl mx-auto mb-8">
                <Globe2 className="w-4 h-4 inline mr-1 text-primary" />
                Всяка година на <strong className="text-foreground">31 май</strong> Световната здравна
                организация отбелязва Световния ден без тютюн — напомняне, че здравето е избор,
                който правим всеки ден.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <button
                  onClick={() => navigate("/breathing")}
                  className="px-7 h-11 rounded-full bg-primary text-primary-foreground text-sm font-medium shadow-lg hover:scale-[1.04] transition-transform duration-300 flex items-center gap-2"
                >
                  <Wind className="w-4 h-4" /> Опитай дихателно упражнение
                </button>
                <button
                  onClick={() => navigate("/ambassadors")}
                  className="px-7 h-11 rounded-full bg-card border border-border text-foreground text-sm font-medium hover:border-primary/50 hover:scale-[1.04] transition-transform flex items-center gap-2"
                >
                  <Award className="w-4 h-4" /> Играй „Мит или факт“
                </button>
                <button
                  onClick={() => navigate("/quiz")}
                  className="px-7 h-11 rounded-full border border-primary/40 text-foreground text-sm font-medium hover:bg-primary/10 hover:scale-[1.04] transition-all duration-300 flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" /> Тествай знанията си
                </button>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ═══ SUPPORT NOTE ═══ */}
      <section className="py-16 px-6">
        <div className="max-w-2xl mx-auto text-center">
          <Reveal>
            <Shield className="w-8 h-8 text-primary mx-auto mb-4" />
            <p className="text-sm text-muted-foreground leading-relaxed">
              Ако ти или близък човек искате да откажете цигарите, потърсете безплатната
              национална телефонна линия за отказване от тютюнопушене или се консултирайте
              с личния си лекар. Не си сам в това.
            </p>
          </Reveal>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default TobaccoFree;

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Reveal, StaggerContainer, staggerItem } from "@/components/Reveal";
import { CalendarDays, Plus, X, ShoppingCart, Flame, Beef, Trash2, ChefHat, Sparkles, Search } from "lucide-react";
import Footer from "@/components/Footer";

const DAYS = ["Понеделник", "Вторник", "Сряда", "Четвъртък", "Петък", "Събота", "Неделя"];
const MEALS = ["Закуска", "Обяд", "Вечеря"];

interface SimpleRecipe {
  id: number;
  name: string;
  calories: number;
  protein: number;
  category: string;
}

const availableRecipes: SimpleRecipe[] = [
  { id: 1, name: "Шопска салата с пиле", calories: 680, protein: 48, category: "Български" },
  { id: 2, name: "Таратор с ядки и яйца", calories: 620, protein: 32, category: "Български" },
  { id: 5, name: "Агнешко печено с картофи", calories: 980, protein: 68, category: "Български" },
  { id: 8, name: "Печена риба с картофи", calories: 680, protein: 58, category: "Български" },
  { id: 10, name: "Баница със сирене и яйца", calories: 780, protein: 38, category: "Български" },
  { id: 16, name: "Пиле терияки с ориз", calories: 850, protein: 58, category: "Японско" },
  { id: 20, name: "Пад тай с пиле", calories: 920, protein: 48, category: "Тайландско" },
  { id: 22, name: "Зелено къри с пиле", calories: 780, protein: 52, category: "Тайландско" },
  { id: 27, name: "Бибимбап с говеждо", calories: 880, protein: 52, category: "Корейско" },
  { id: 30, name: "Бирияни с пиле", calories: 1020, protein: 62, category: "Индийско" },
  { id: 36, name: "Гръцка салата с пиле", calories: 680, protein: 52, category: "Гръцко" },
  { id: 45, name: "Паста с пилешко месо", calories: 820, protein: 56, category: "Италианско" },
  { id: 52, name: "Паеля с морски дарове", calories: 880, protein: 58, category: "Испанско" },
  { id: 56, name: "Буритос боул", calories: 880, protein: 58, category: "Мексиканско" },
  { id: 71, name: "Овесена каша с протеин", calories: 680, protein: 42, category: "Закуска" },
  { id: 72, name: "Авокадо тост с яйца", calories: 720, protein: 38, category: "Закуска" },
  { id: 73, name: "Смути боул с протеин", calories: 680, protein: 42, category: "Закуска" },
  { id: 76, name: "Протеинови палачинки", calories: 720, protein: 52, category: "Закуска" },
  { id: 78, name: "Омлет с пълнеж", calories: 720, protein: 52, category: "Закуска" },
  { id: 86, name: "Леща супа с хляб", calories: 680, protein: 38, category: "Супа" },
  { id: 89, name: "Крем супа от броколи с пиле", calories: 680, protein: 48, category: "Супа" },
  { id: 101, name: "Цезар салата с пиле", calories: 720, protein: 52, category: "Салата" },
  { id: 102, name: "Салата с киноа и пиле", calories: 720, protein: 48, category: "Салата" },
  { id: 110, name: "Салата с грилирано пиле и манго", calories: 680, protein: 45, category: "Салата" },
];

type MealPlan = Record<string, Record<string, SimpleRecipe | null>>;

const MealPlanner = () => {
  const [plan, setPlan] = useState<MealPlan>(() => {
    const saved = localStorage.getItem("mealPlan");
    if (saved) return JSON.parse(saved);
    const initial: MealPlan = {};
    DAYS.forEach(day => {
      initial[day] = {};
      MEALS.forEach(meal => { initial[day][meal] = null; });
    });
    return initial;
  });

  const [dialogOpen, setDialogOpen] = useState(false);
  const [shoppingOpen, setShoppingOpen] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<{ day: string; meal: string } | null>(null);
  const [search, setSearch] = useState("");

  const savePlan = (newPlan: MealPlan) => {
    setPlan(newPlan);
    localStorage.setItem("mealPlan", JSON.stringify(newPlan));
  };

  const addRecipe = (recipe: SimpleRecipe) => {
    if (!selectedSlot) return;
    const newPlan = { ...plan };
    newPlan[selectedSlot.day] = { ...newPlan[selectedSlot.day], [selectedSlot.meal]: recipe };
    savePlan(newPlan);
    setDialogOpen(false);
  };

  const removeRecipe = (day: string, meal: string) => {
    const newPlan = { ...plan };
    newPlan[day] = { ...newPlan[day], [meal]: null };
    savePlan(newPlan);
  };

  const getDayTotals = (day: string) => {
    let calories = 0, protein = 0;
    MEALS.forEach(meal => {
      const r = plan[day]?.[meal];
      if (r) { calories += r.calories; protein += r.protein; }
    });
    return { calories, protein };
  };

  const getWeekTotals = () => {
    let calories = 0, protein = 0, meals = 0;
    DAYS.forEach(day => {
      MEALS.forEach(meal => {
        const r = plan[day]?.[meal];
        if (r) { calories += r.calories; protein += r.protein; meals++; }
      });
    });
    return { calories, protein, meals };
  };

  const getShoppingIngredients = () => {
    const recipes = new Map<string, number>();
    DAYS.forEach(day => {
      MEALS.forEach(meal => {
        const r = plan[day]?.[meal];
        if (r) recipes.set(r.name, (recipes.get(r.name) || 0) + 1);
      });
    });
    return Array.from(recipes.entries());
  };

  const weekTotals = getWeekTotals();
  const filteredRecipes = availableRecipes.filter(r =>
    r.name.toLowerCase().includes(search.toLowerCase()) ||
    r.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Hero with image */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] min-h-[30vh] md:min-h-[38vh] flex items-end justify-center overflow-hidden pt-12 pb-8 md:pb-10">
        <div className="absolute inset-0 z-0">
          <img src="/images/meal-planner-hero.jpg" alt="Седмичен план за хранене" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10" />
        </div>
        <div className="relative z-10 text-center px-6 max-w-3xl mx-auto">
          <Reveal>
            <h1 className="text-4xl md:text-6xl font-display font-bold text-white flex items-center justify-center gap-3">
              <CalendarDays className="w-10 h-10 text-white" />
              Седмичен план
            </h1>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="text-lg text-white/85 mt-2">
              Планирайте здравословното си хранене за цялата седмица
            </p>
          </Reveal>
        </div>
      </section>

      <div className="px-6 pb-8">
        <div className="max-w-7xl mx-auto">
          {/* Weekly Summary */}
          <Reveal delay={0.1}>
            <Card className="p-6 mb-8 bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-sm text-muted-foreground">Общо ястия</p>
                  <p className="text-3xl font-bold text-foreground">{weekTotals.meals}</p>
                  <p className="text-xs text-muted-foreground">от 21</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Ср. калории/ден</p>
                  <p className="text-3xl font-bold text-primary">
                    {weekTotals.meals > 0 ? Math.round(weekTotals.calories / 7) : 0}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Ср. протеин/ден</p>
                  <p className="text-3xl font-bold text-accent-foreground">
                    {weekTotals.meals > 0 ? Math.round(weekTotals.protein / 7) : 0}г
                  </p>
                </div>
              </div>
            </Card>
          </Reveal>

          <div className="flex gap-4 mb-6">
            <Button
              variant="outline"
              onClick={() => setShoppingOpen(true)}
              className="flex items-center gap-2"
            >
              <ShoppingCart className="w-4 h-4" />
              Списък за пазар
            </Button>
          </div>

          {/* Weekly Grid */}
          <StaggerContainer className="space-y-4">
            {DAYS.map((day) => {
              const totals = getDayTotals(day);
              return (
                <motion.div key={day} variants={staggerItem}>
                  <Card className="p-4 md:p-6 bg-card border border-border">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-bold text-foreground">{day}</h3>
                      {totals.calories > 0 && (
                        <div className="flex gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Flame className="w-3 h-3" /> {totals.calories} кал
                          </span>
                          <span className="flex items-center gap-1">
                            <Beef className="w-3 h-3" /> {totals.protein}г
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {MEALS.map((meal) => {
                        const recipe = plan[day]?.[meal];
                        return (
                          <div
                            key={meal}
                            className={`rounded-lg border p-3 transition-all ${
                              recipe
                                ? "bg-primary/5 border-primary/20"
                                : "bg-muted/30 border-dashed border-border hover:border-primary/40 cursor-pointer"
                            }`}
                            onClick={() => {
                              if (!recipe) {
                                setSelectedSlot({ day, meal });
                                setDialogOpen(true);
                              }
                            }}
                          >
                            <p className="text-xs font-semibold text-muted-foreground mb-1">{meal}</p>
                            {recipe ? (
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <p className="text-sm font-medium text-foreground line-clamp-1">{recipe.name}</p>
                                  <p className="text-xs text-muted-foreground">{recipe.calories} кал · {recipe.protein}г</p>
                                </div>
                                <button
                                  onClick={(e) => { e.stopPropagation(); removeRecipe(day, meal); }}
                                  className="text-muted-foreground hover:text-destructive transition-colors mt-0.5"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Plus className="w-3 h-3" /> Добави
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </StaggerContainer>

          {/* Clear Plan */}
          <Reveal delay={0.3}>
            <div className="mt-8 text-center">
              <Button
                variant="ghost"
                onClick={() => {
                  const initial: MealPlan = {};
                  DAYS.forEach(day => {
                    initial[day] = {};
                    MEALS.forEach(meal => { initial[day][meal] = null; });
                  });
                  savePlan(initial);
                }}
                className="text-muted-foreground hover:text-destructive"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Изчисти плана
              </Button>
            </div>
          </Reveal>
        </div>
      </div>

      {/* Add Recipe Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ChefHat className="w-5 h-5 text-primary" />
              Избери ястие за {selectedSlot?.meal} — {selectedSlot?.day}
            </DialogTitle>
          </DialogHeader>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Търси рецепта..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="space-y-2">
            {filteredRecipes.map(recipe => (
              <Card
                key={recipe.id}
                className="p-3 cursor-pointer hover:bg-primary/5 hover:border-primary/30 transition-all"
                onClick={() => addRecipe(recipe)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-sm text-foreground">{recipe.name}</p>
                    <p className="text-xs text-muted-foreground">{recipe.category}</p>
                  </div>
                  <div className="text-right text-xs text-muted-foreground">
                    <p>{recipe.calories} кал</p>
                    <p>{recipe.protein}г протеин</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Shopping List Dialog */}
      <Dialog open={shoppingOpen} onOpenChange={setShoppingOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5 text-primary" />
              Списък за пазаруване
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {getShoppingIngredients().length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Добавете ястия към плана, за да видите списъка
              </p>
            ) : (
              getShoppingIngredients().map(([name, count]) => (
                <div key={name} className="flex items-center justify-between border-b border-border pb-2">
                  <span className="text-sm text-foreground">{name}</span>
                  <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                    ×{count}
                  </span>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default MealPlanner;

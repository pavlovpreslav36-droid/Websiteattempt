import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Footer from "@/components/Footer";
import { Reveal } from "@/components/Reveal";
import { toast } from "@/hooks/use-toast";
import {
  Camera, Plus, Trash2, Loader2, Sparkles, UtensilsCrossed, Apple, Flame, Beef, X, Image as ImageIcon, Video, AlertTriangle, Heart, Scale
} from "lucide-react";

interface MealEntry {
  id: string;
  meal_name: string;
  description: string | null;
  photo_url: string | null;
  calories: number | null;
  protein: number | null;
  carbs: number | null;
  fat: number | null;
  fiber: number | null;
  sugar: number | null;
  sodium: number | null;
  portion_size: string | null;
  ingredients: Array<{ name: string; estimated_grams?: number }> | null;
  allergens: string[] | null;
  health_score: number | null;
  warnings: string[] | null;
  media_type: string | null;
  meal_type: string;
  ai_analysis: string | null;
  created_at: string;
}

const MEAL_TYPES = [
  { id: "breakfast", labelBg: "Закуска", labelEn: "Breakfast", emoji: "🌅" },
  { id: "lunch", labelBg: "Обяд", labelEn: "Lunch", emoji: "☀️" },
  { id: "dinner", labelBg: "Вечеря", labelEn: "Dinner", emoji: "🌙" },
  { id: "snack", labelBg: "Снакс", labelEn: "Snack", emoji: "🍎" },
];

const MealJournal = () => {
  const { language } = useLanguage();
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const isBg = language === "bg";
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const [meals, setMeals] = useState<MealEntry[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newMeal, setNewMeal] = useState({ name: "", type: "lunch", description: "" });
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaType, setMediaType] = useState<"image" | "video" | null>(null);
  const [extractedFrames, setExtractedFrames] = useState<string[]>([]);
  const [extracting, setExtracting] = useState(false);
  const [analysisStep, setAnalysisStep] = useState<string>("");
  const [analyzing, setAnalyzing] = useState(false);
  const [loadingMeals, setLoadingMeals] = useState(true);
  const [expandedMealId, setExpandedMealId] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && !user) navigate("/auth");
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) fetchMeals();
  }, [user]);

  const fetchMeals = async () => {
    const { data } = await supabase
      .from("meal_journal")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);
    if (data) setMeals(data as unknown as MealEntry[]);
    setLoadingMeals(false);
  };

  const downscaleImage = (dataUrl: string, maxDim = 1280, quality = 0.85): Promise<string> =>
    new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });

  const extractVideoFrames = (file: File, count = 4): Promise<string[]> =>
    new Promise((resolve, reject) => {
      const video = document.createElement("video");
      video.preload = "metadata";
      video.muted = true;
      video.playsInline = true;
      video.src = URL.createObjectURL(file);
      const frames: string[] = [];

      video.onloadedmetadata = async () => {
        const duration = video.duration;
        if (!isFinite(duration) || duration <= 0) {
          URL.revokeObjectURL(video.src);
          return reject(new Error("Invalid video"));
        }
        const step = duration / (count + 1);
        const canvas = document.createElement("canvas");
        const targetMax = 1280;
        const scale = Math.min(1, targetMax / Math.max(video.videoWidth || targetMax, video.videoHeight || targetMax));
        canvas.width = Math.round((video.videoWidth || targetMax) * scale);
        canvas.height = Math.round((video.videoHeight || targetMax) * scale);
        const ctx = canvas.getContext("2d")!;

        const captureAt = (t: number) => new Promise<void>((res) => {
          const onSeeked = () => {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            frames.push(canvas.toDataURL("image/jpeg", 0.82));
            video.removeEventListener("seeked", onSeeked);
            res();
          };
          video.addEventListener("seeked", onSeeked);
          video.currentTime = Math.min(Math.max(0.1, t), Math.max(0.1, duration - 0.1));
        });

        try {
          for (let i = 1; i <= count; i++) await captureAt(step * i);
          URL.revokeObjectURL(video.src);
          resolve(frames);
        } catch (e) {
          URL.revokeObjectURL(video.src);
          reject(e);
        }
      };
      video.onerror = () => {
        URL.revokeObjectURL(video.src);
        reject(new Error("Could not load video"));
      };
    });

  const handleMediaSelect = async (e: React.ChangeEvent<HTMLInputElement>, kind: "image" | "video") => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = "";

    const maxBytes = kind === "video" ? 50 * 1024 * 1024 : 10 * 1024 * 1024;
    if (file.size > maxBytes) {
      toast({
        title: isBg
          ? `Файлът е твърде голям (макс ${kind === "video" ? "50MB" : "10MB"})`
          : `File too large (max ${kind === "video" ? "50MB" : "10MB"})`,
        variant: "destructive",
      });
      return;
    }

    setMediaFile(file);
    setMediaType(kind);
    setExtractedFrames([]);

    if (kind === "image") {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const raw = ev.target?.result as string;
        setMediaPreview(raw);
        const small = await downscaleImage(raw);
        setExtractedFrames([small]);
      };
      reader.readAsDataURL(file);
    } else {
      setMediaPreview(URL.createObjectURL(file));
      setExtracting(true);
      try {
        const frames = await extractVideoFrames(file, 4);
        setExtractedFrames(frames);
        toast({
          title: isBg ? `Извлечени ${frames.length} кадъра от видеото` : `Extracted ${frames.length} frames from video`,
        });
      } catch (err) {
        console.error(err);
        toast({
          title: isBg ? "Не успях да обработя видеото" : "Could not process video",
          variant: "destructive",
        });
        clearMedia();
      } finally {
        setExtracting(false);
      }
    }
  };

  const clearMedia = () => {
    if (mediaPreview && mediaType === "video") URL.revokeObjectURL(mediaPreview);
    setMediaPreview(null);
    setMediaFile(null);
    setMediaType(null);
    setExtractedFrames([]);
  };

  const analyzeAndSave = async () => {
    if (!newMeal.name.trim() && extractedFrames.length === 0) {
      toast({
        title: isBg ? "Добави име или снимка/видео" : "Add a name or photo/video",
        variant: "destructive",
      });
      return;
    }
    setAnalyzing(true);
    setAnalysisStep(isBg ? "Качвам файла…" : "Uploading file…");

    try {
      let photoUrl: string | null = null;

      // Upload original media if exists
      if (mediaFile && user) {
        const ext = (mediaFile.name.split(".").pop() || (mediaType === "video" ? "mp4" : "jpg")).toLowerCase();
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error: uploadErr } = await supabase.storage
          .from("meal-photos")
          .upload(path, mediaFile, { contentType: mediaFile.type });
        if (!uploadErr) {
          const { data: urlData } = supabase.storage.from("meal-photos").getPublicUrl(path);
          photoUrl = urlData.publicUrl;
        }
      }

      // Structured AI analysis with frames
      let aiResult: any = null;
      if (extractedFrames.length > 0) {
        setAnalysisStep(isBg ? "AI разпознава храната…" : "AI is identifying the food…");
        const { data: aiData, error: aiErr } = await supabase.functions.invoke("analyze-meal", {
          body: {
            frames: extractedFrames,
            mealName: newMeal.name || undefined,
            description: newMeal.description || undefined,
            mealType: newMeal.type,
            language,
          },
        });
        if (aiErr) {
          console.error("analyze-meal error", aiErr);
          toast({
            title: isBg ? "AI анализът е неуспешен — записвам без него" : "AI analysis failed — saving without it",
            variant: "destructive",
          });
        } else {
          aiResult = aiData?.analysis;
        }
      }

      const np = aiResult?.nutrition_per_portion ?? {};
      setAnalysisStep(isBg ? "Записвам в дневника…" : "Saving to journal…");

      const { error } = await supabase.from("meal_journal").insert({
        user_id: user!.id,
        meal_name: aiResult?.meal_name || newMeal.name || (isBg ? "Ястие" : "Meal"),
        description: newMeal.description || null,
        photo_url: photoUrl,
        meal_type: newMeal.type,
        media_type: mediaType ?? "image",
        calories: np.calories != null ? Math.round(np.calories) : null,
        protein: np.protein_g ?? null,
        carbs: np.carbs_g ?? null,
        fat: np.fat_g ?? null,
        fiber: np.fiber_g ?? null,
        sugar: np.sugar_g ?? null,
        sodium: np.sodium_mg ?? null,
        portion_size: aiResult?.portion_size ?? null,
        ingredients: aiResult?.ingredients ?? null,
        allergens: aiResult?.allergens ?? null,
        health_score: aiResult?.health_score != null ? Math.round(aiResult.health_score) : null,
        warnings: aiResult?.warnings ?? null,
        ai_analysis: aiResult?.analysis ?? null,
      });

      if (error) throw error;

      toast({ title: isBg ? "Ястието е добавено!" : "Meal added!" });
      setShowAdd(false);
      setNewMeal({ name: "", type: "lunch", description: "" });
      clearMedia();
      fetchMeals();
    } catch (err) {
      console.error(err);
      toast({ title: isBg ? "Грешка" : "Error", variant: "destructive" });
    }
    setAnalyzing(false);
    setAnalysisStep("");
  };

  const deleteMeal = async (id: string) => {
    await supabase.from("meal_journal").delete().eq("id", id);
    setMeals(prev => prev.filter(m => m.id !== id));
  };

  const todayCalories = meals
    .filter(m => new Date(m.created_at).toDateString() === new Date().toDateString())
    .reduce((s, m) => s + (m.calories || 0), 0);

  if (loading || !user) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] min-h-[30vh] md:min-h-[38vh] flex items-end justify-center overflow-hidden pt-12 pb-8 md:pb-10">
        <div className="absolute inset-0 z-0">
          <img src="/images/meal-journal-hero.jpg" alt="Meal Journal" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10" />
        </div>
        <div className="relative z-10 text-center px-4">
          <Reveal><UtensilsCrossed className="w-10 h-10 md:w-12 md:h-12 mx-auto mb-3 text-white" /></Reveal>
          <Reveal delay={0.1}>
            <h1 className="text-3xl md:text-6xl font-display font-bold text-white mb-2">
              {isBg ? "Хранителен дневник" : "Meal Journal"}
            </h1>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="text-base md:text-lg text-white/85 max-w-md mx-auto">
              {isBg ? "Снимайте храната си и AI ще анализира калориите" : "Snap your meals and AI will analyze the calories"}
            </p>
          </Reveal>
        </div>
      </section>

      <div className="px-4 md:px-6 pb-12 max-w-4xl mx-auto space-y-6">
        {/* Today's summary */}
        <Reveal>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">{isBg ? "Днес" : "Today"}</p>
              <p className="text-2xl font-bold text-foreground">{todayCalories} <span className="text-sm font-normal text-muted-foreground">kcal</span></p>
            </div>
            <Button onClick={() => setShowAdd(true)} className="rounded-full" size="lg">
              <Plus className="w-5 h-5 mr-2" />
              {isBg ? "Добави" : "Add Meal"}
            </Button>
          </div>
        </Reveal>

        {/* Add meal modal */}
        <AnimatePresence>
          {showAdd && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Card className="p-5 glass-card space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-foreground">{isBg ? "Ново ястие" : "New Meal"}</h3>
                  <button onClick={() => setShowAdd(false)}><X className="w-5 h-5 text-muted-foreground" /></button>
                </div>

                {/* Meal type */}
                <div className="flex gap-2">
                  {MEAL_TYPES.map(t => (
                    <button
                      key={t.id}
                      onClick={() => setNewMeal(p => ({ ...p, type: t.id }))}
                      className={`flex-1 p-2 rounded-xl text-xs font-medium border transition-all ${
                        newMeal.type === t.id ? "bg-primary/15 border-primary/40" : "bg-card border-border/50 hover:border-primary/20"
                      }`}
                    >
                      <span className="block text-lg">{t.emoji}</span>
                      {isBg ? t.labelBg : t.labelEn}
                    </button>
                  ))}
                </div>

                <Input
                  placeholder={isBg ? "Име на ястието" : "Meal name"}
                  value={newMeal.name}
                  onChange={e => setNewMeal(p => ({ ...p, name: e.target.value }))}
                />
                <Input
                  placeholder={isBg ? "Описание (по избор)" : "Description (optional)"}
                  value={newMeal.description}
                  onChange={e => setNewMeal(p => ({ ...p, description: e.target.value }))}
                />

                {/* Photo */}
                <div>
                  <input ref={fileInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => handleMediaSelect(e, "image")} />
                  <input ref={videoInputRef} type="file" accept="video/*" capture="environment" className="hidden" onChange={(e) => handleMediaSelect(e, "video")} />

                  {mediaPreview ? (
                    <div className="relative">
                      {mediaType === "video" ? (
                        <video src={mediaPreview} controls playsInline className="w-full h-48 object-cover rounded-xl bg-black" />
                      ) : (
                        <img src={mediaPreview} alt="Preview" className="w-full h-48 object-cover rounded-xl" />
                      )}
                      <button
                        onClick={clearMedia}
                        className="absolute top-2 right-2 bg-background/80 rounded-full p-1.5"
                        aria-label={isBg ? "Премахни" : "Remove"}
                      >
                        <X className="w-4 h-4" />
                      </button>
                      {extracting && (
                        <div className="absolute inset-0 bg-background/70 backdrop-blur-sm rounded-xl flex flex-col items-center justify-center gap-2">
                          <Loader2 className="w-6 h-6 animate-spin text-primary" />
                          <span className="text-xs text-foreground">{isBg ? "Извличам кадри…" : "Extracting frames…"}</span>
                        </div>
                      )}
                      {!extracting && extractedFrames.length > 1 && (
                        <div className="absolute bottom-2 left-2 right-2 flex gap-1.5 overflow-x-auto">
                          {extractedFrames.map((f, i) => (
                            <img key={i} src={f} alt={`frame ${i + 1}`} className="h-12 w-12 rounded-md object-cover ring-2 ring-primary/40 flex-shrink-0" />
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="h-32 border-2 border-dashed border-border/50 rounded-xl flex flex-col items-center justify-center gap-2 text-muted-foreground hover:border-primary/40 hover:text-primary transition-colors"
                      >
                        <Camera className="w-7 h-7" />
                        <span className="text-xs font-medium">{isBg ? "Снимка" : "Photo"}</span>
                        <span className="text-[10px] opacity-70">{isBg ? "до 10MB" : "up to 10MB"}</span>
                      </button>
                      <button
                        onClick={() => videoInputRef.current?.click()}
                        className="h-32 border-2 border-dashed border-border/50 rounded-xl flex flex-col items-center justify-center gap-2 text-muted-foreground hover:border-accent/40 hover:text-accent transition-colors"
                      >
                        <Video className="w-7 h-7" />
                        <span className="text-xs font-medium">{isBg ? "Видео" : "Video"}</span>
                        <span className="text-[10px] opacity-70">{isBg ? "до 50MB" : "up to 50MB"}</span>
                      </button>
                    </div>
                  )}
                  <p className="text-[10px] text-muted-foreground mt-2 text-center">
                    {isBg
                      ? "AI ще разпознае съставките, порцията и пълните хранителни стойности."
                      : "AI will detect ingredients, portion size and full nutrition."}
                  </p>
                </div>

                <Button
                  onClick={analyzeAndSave}
                  disabled={analyzing || extracting || (!newMeal.name.trim() && extractedFrames.length === 0)}
                  className="w-full rounded-xl"
                  size="lg"
                >
                  {analyzing ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" />{analysisStep || (isBg ? "AI анализира..." : "AI analyzing...")}</>
                  ) : (
                    <><Sparkles className="w-4 h-4 mr-2" />{isBg ? "Анализирай и запази" : "Analyze & Save"}</>
                  )}
                </Button>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Meals list */}
        {loadingMeals ? (
          <div className="text-center py-12"><Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" /></div>
        ) : meals.length === 0 ? (
          <Reveal>
            <Card className="p-8 glass-card text-center">
              <ImageIcon className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">{isBg ? "Все още нямате записи. Добавете първото си ястие!" : "No entries yet. Add your first meal!"}</p>
            </Card>
          </Reveal>
        ) : (
          <div className="space-y-3">
            {meals.map((meal, i) => (
              <Reveal key={meal.id} delay={i * 0.03}>
                <motion.div whileHover={{ scale: 1.01, y: -2 }} transition={{ type: "spring", stiffness: 300 }}>
                  <Card className="p-4 glass-card overflow-hidden cursor-pointer" onClick={() => setExpandedMealId(expandedMealId === meal.id ? null : meal.id)}>
                    <div className="flex gap-4">
                      {meal.photo_url && (
                        meal.media_type === "video" ? (
                          <div className="relative w-20 h-20 md:w-24 md:h-24 rounded-xl overflow-hidden flex-shrink-0 bg-black">
                            <video src={meal.photo_url} className="w-full h-full object-cover" muted playsInline />
                            <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                              <Video className="w-5 h-5 text-white" />
                            </div>
                          </div>
                        ) : (
                          <img src={meal.photo_url} alt={meal.meal_name} className="w-20 h-20 md:w-24 md:h-24 rounded-xl object-cover flex-shrink-0" />
                        )
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-semibold text-foreground truncate">{meal.meal_name}</h4>
                            <p className="text-xs text-muted-foreground">
                              {MEAL_TYPES.find(t => t.id === meal.meal_type)?.emoji}{" "}
                              {new Date(meal.created_at).toLocaleDateString(isBg ? "bg" : "en", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                              {meal.portion_size && <> · {meal.portion_size}</>}
                            </p>
                          </div>
                          <button
                            onClick={(e) => { e.stopPropagation(); deleteMeal(meal.id); }}
                            className="text-muted-foreground hover:text-destructive transition-colors"
                            aria-label={isBg ? "Изтрий" : "Delete"}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        {(meal.calories || meal.protein) && (
                          <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2 text-xs">
                            {meal.calories != null && <span className="flex items-center gap-1"><Flame className="w-3 h-3 text-orange-400" />{meal.calories} kcal</span>}
                            {meal.protein != null && <span className="flex items-center gap-1"><Beef className="w-3 h-3 text-red-400" />{meal.protein}g {isBg ? "белтък" : "protein"}</span>}
                            {meal.carbs != null && <span className="flex items-center gap-1"><Apple className="w-3 h-3 text-green-400" />{meal.carbs}g {isBg ? "въгл." : "carbs"}</span>}
                            {meal.fat != null && <span className="flex items-center gap-1">🧈 {meal.fat}g {isBg ? "мазн." : "fat"}</span>}
                            {meal.health_score != null && (
                              <span className={`flex items-center gap-1 font-medium ${meal.health_score >= 70 ? "text-emerald-500" : meal.health_score >= 40 ? "text-amber-500" : "text-rose-500"}`}>
                                <Heart className="w-3 h-3" />{meal.health_score}/100
                              </span>
                            )}
                          </div>
                        )}
                        {meal.warnings && meal.warnings.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {meal.warnings.slice(0, 3).map((w, idx) => (
                              <span key={idx} className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                                <AlertTriangle className="w-2.5 h-2.5" />{w}
                              </span>
                            ))}
                          </div>
                        )}
                        {meal.ai_analysis && (
                          <p className={`text-xs text-muted-foreground mt-2 ${expandedMealId === meal.id ? "" : "line-clamp-2"}`}>
                            {meal.ai_analysis}
                          </p>
                        )}
                        {expandedMealId === meal.id && (
                          <div className="mt-3 space-y-2 text-xs">
                            {(meal.fiber != null || meal.sugar != null || meal.sodium != null) && (
                              <div className="flex flex-wrap gap-x-3 gap-y-1 text-muted-foreground">
                                {meal.fiber != null && <span>{isBg ? "Фибри" : "Fiber"}: {meal.fiber}g</span>}
                                {meal.sugar != null && <span>{isBg ? "Захар" : "Sugar"}: {meal.sugar}g</span>}
                                {meal.sodium != null && <span>{isBg ? "Натрий" : "Sodium"}: {meal.sodium}mg</span>}
                              </div>
                            )}
                            {meal.ingredients && meal.ingredients.length > 0 && (
                              <div>
                                <p className="font-medium text-foreground mb-1 flex items-center gap-1"><Scale className="w-3 h-3" />{isBg ? "Съставки" : "Ingredients"}</p>
                                <div className="flex flex-wrap gap-1">
                                  {meal.ingredients.map((ing, idx) => (
                                    <span key={idx} className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[10px]">
                                      {ing.name}{ing.estimated_grams ? ` · ${Math.round(ing.estimated_grams)}g` : ""}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                            {meal.allergens && meal.allergens.length > 0 && (
                              <div>
                                <p className="font-medium text-foreground mb-1">{isBg ? "Алергени" : "Allergens"}</p>
                                <div className="flex flex-wrap gap-1">
                                  {meal.allergens.map((a, idx) => (
                                    <span key={idx} className="px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 text-[10px]">{a}</span>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                </motion.div>
              </Reveal>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default MealJournal;

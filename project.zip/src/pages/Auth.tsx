import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, EyeOff, Mail, Lock, User, ArrowLeft, Loader2, CheckCircle2, Sparkles } from "lucide-react";

const getAuthErrorMessage = (error: any, isSignUp: boolean): string => {
  const msg = (error?.message || '').toLowerCase();
  if (msg.includes('invalid login credentials')) return 'Невалиден имейл или парола.';
  if (msg.includes('email not confirmed')) return 'Моля, потвърдете имейла си първо.';
  if (msg.includes('already registered') || msg.includes('user already registered')) return isSignUp ? 'Вече съществува акаунт с този имейл.' : 'Невалиден имейл или парола.';
  if (msg.includes('too many requests') || msg.includes('rate limit')) return 'Твърде много опити. Опитайте по-късно.';
  if (msg.includes('signup is disabled')) return 'Регистрацията е временно деактивирана.';
  return isSignUp ? 'Грешка при регистрация. Опитайте отново.' : 'Грешка при вход. Опитайте отново.';
};

const emailSchema = z.string().email("Невалиден имейл адрес");
const passwordSchema = z.string().min(6, "Паролата трябва да е поне 6 символа");

const Auth = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState("signin");
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotSuccess, setForgotSuccess] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const tab = searchParams.get("tab");
    if (tab === "signup" || tab === "signin") setActiveTab(tab);
  }, [searchParams]);

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    try {
      const { error } = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin,
      });
      if (error) throw error;
    } catch {
      toast({ title: "Грешка", description: "Грешка при вход с Google.", variant: "destructive" });
    } finally {
      setGoogleLoading(false);
    }
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) navigate("/");
    });
  }, [navigate]);

  const validateInputs = (isSignUp: boolean) => {
    try {
      emailSchema.parse(email);
      passwordSchema.parse(password);
      if (isSignUp && !fullName.trim()) throw new Error("Моля, въведете вашето име");
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({ title: "Грешка", description: error.errors[0].message, variant: "destructive" });
      } else if (error instanceof Error) {
        toast({ title: "Грешка", description: error.message, variant: "destructive" });
      }
      return false;
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateInputs(true)) return;
    setLoading(true);
    try {
      const { error } = await supabase.auth.signUp({
        email, password,
        options: { emailRedirectTo: `${window.location.origin}/`, data: { full_name: fullName } },
      });
      if (error) throw error;
      toast({ title: "🎉 Успешно!", description: "Акаунтът е създаден. Моля, влезте." });
      setActiveTab("signin");
    } catch (error: any) {
      toast({ title: "Грешка", description: getAuthErrorMessage(error, true), variant: "destructive" });
    } finally { setLoading(false); }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateInputs(false)) return;
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      toast({ title: "👋 Добре дошли!", description: "Успешно влязохте в профила си." });
      navigate("/");
    } catch (error: any) {
      toast({ title: "Грешка", description: getAuthErrorMessage(error, false), variant: "destructive" });
    } finally { setLoading(false); }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      emailSchema.parse(forgotEmail);
    } catch {
      toast({ title: "Грешка", description: "Невалиден имейл адрес", variant: "destructive" });
      return;
    }
    setForgotLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(forgotEmail, {
        redirectTo: `${window.location.origin}/reset-password`
      });
      if (error) throw error;
      setForgotSuccess(true);
    } catch {
      toast({ title: "Грешка", description: "Грешка при изпращане. Опитайте отново.", variant: "destructive" });
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4 sm:p-6">
      {/* Animated background */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <img src="/images/auth-hero.jpg" alt="Здравословен живот" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-br from-background/90 via-background/80 to-primary/20 backdrop-blur-sm" />
        <motion.div
          className="absolute top-1/4 -left-20 w-72 h-72 bg-primary/10 rounded-full blur-3xl"
          animate={{ x: [0, 30, 0], y: [0, -20, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute bottom-1/4 -right-20 w-80 h-80 bg-accent/10 rounded-full blur-3xl"
          animate={{ x: [0, -20, 0], y: [0, 30, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
        className="w-full max-w-md relative z-10"
      >
        <AnimatePresence mode="wait">
          {showForgotPassword ? (
            <motion.div
              key="forgot"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="border-border/50 bg-card/90 backdrop-blur-xl shadow-2xl overflow-hidden">
                <CardHeader className="text-center pb-2 pt-6">
                  {forgotSuccess ? (
                    <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }}>
                      <CheckCircle2 className="w-16 h-16 text-primary mx-auto mb-3" />
                      <CardTitle className="text-2xl font-display">Имейлът е изпратен!</CardTitle>
                      <CardDescription className="mt-2">
                        Проверете {forgotEmail} за линк за възстановяване на паролата.
                      </CardDescription>
                    </motion.div>
                  ) : (
                    <>
                      <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
                        <Lock className="w-7 h-7 text-primary" />
                      </div>
                      <CardTitle className="text-2xl font-display">Забравена парола</CardTitle>
                      <CardDescription>Въведете имейла си за възстановяване</CardDescription>
                    </>
                  )}
                </CardHeader>
                <CardContent className="pb-6">
                  {forgotSuccess ? (
                    <Button className="w-full rounded-xl h-11 mt-4" onClick={() => { setShowForgotPassword(false); setForgotSuccess(false); }}>
                      <ArrowLeft className="w-4 h-4 mr-2" /> Обратно към вход
                    </Button>
                  ) : (
                    <form onSubmit={handleForgotPassword} className="space-y-4 mt-2">
                      <div className="space-y-2">
                        <Label htmlFor="forgot-email">Имейл</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input id="forgot-email" type="email" placeholder="your@email.com"
                            value={forgotEmail} onChange={(e) => setForgotEmail(e.target.value)} required
                            className="pl-10 rounded-xl h-11" />
                        </div>
                      </div>
                      <Button type="submit" className="w-full rounded-xl h-11" disabled={forgotLoading}>
                        {forgotLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Mail className="w-4 h-4 mr-2" />}
                        Изпрати линк
                      </Button>
                      <Button type="button" variant="ghost" className="w-full" onClick={() => setShowForgotPassword(false)}>
                        <ArrowLeft className="w-4 h-4 mr-2" /> Обратно
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <motion.div
              key="auth"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="border-border/50 bg-card/90 backdrop-blur-xl shadow-2xl overflow-hidden">
                {/* Top decorative bar */}
                <div className="h-1.5 bg-gradient-to-r from-primary via-accent to-primary" />
                
                <CardHeader className="text-center pb-2 pt-6">
                  <motion.div
                    initial={{ scale: 0.8 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", delay: 0.1 }}
                    className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mx-auto mb-3 border border-primary/20"
                  >
                    <Sparkles className="w-8 h-8 text-primary" />
                  </motion.div>
                  <CardTitle className="text-2xl sm:text-3xl font-display font-bold text-foreground">
                    Добре дошли! 👋
                  </CardTitle>
                  <CardDescription className="text-muted-foreground text-sm">
                    {activeTab === "signin" ? "Влезте в профила си" : "Създайте нов акаунт"}
                  </CardDescription>
                </CardHeader>

                <CardContent className="pb-6">
                  <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                    <TabsList className="grid w-full grid-cols-2 mb-5 rounded-xl h-11">
                      <TabsTrigger value="signin" className="rounded-lg text-sm font-medium">Вход</TabsTrigger>
                      <TabsTrigger value="signup" className="rounded-lg text-sm font-medium">Регистрация</TabsTrigger>
                    </TabsList>

                    {/* Google */}
                    <Button type="button" variant="outline"
                      className="w-full rounded-xl h-11 text-sm flex items-center gap-3 border-border/60 hover:bg-muted/50 transition-all hover:scale-[1.01] active:scale-[0.99]"
                      onClick={handleGoogleSignIn} disabled={googleLoading}>
                      <svg className="w-5 h-5" viewBox="0 0 24 24">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                      </svg>
                      {googleLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Вход с Google"}
                    </Button>

                    <div className="relative my-5">
                      <Separator className="bg-border/40" />
                      <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-card px-3 text-xs text-muted-foreground">
                        или
                      </span>
                    </div>

                    <TabsContent value="signin" className="mt-0 space-y-4">
                      <form onSubmit={handleSignIn} className="space-y-3.5">
                        <div className="space-y-1.5">
                          <Label htmlFor="signin-email" className="text-xs font-medium">Имейл</Label>
                          <div className="relative">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input id="signin-email" type="email" placeholder="your@email.com"
                              value={email} onChange={(e) => setEmail(e.target.value)} required
                              className="pl-10 rounded-xl h-11" />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="signin-password" className="text-xs font-medium">Парола</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input id="signin-password" type={showPassword ? "text" : "password"}
                              placeholder="••••••••" value={password}
                              onChange={(e) => setPassword(e.target.value)} required
                              className="pl-10 pr-10 rounded-xl h-11" />
                            <button type="button" onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                        </div>
                        <div className="flex justify-end">
                          <button type="button" onClick={() => { setShowForgotPassword(true); setForgotEmail(email); }}
                            className="text-xs text-primary hover:text-primary/80 transition-colors font-medium">
                            Забравена парола?
                          </button>
                        </div>
                        <Button type="submit" className="w-full rounded-xl h-11 text-sm font-semibold hover:scale-[1.01] active:scale-[0.99] transition-all" disabled={loading}>
                          {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                          {loading ? "Зареждане..." : "Вход"}
                        </Button>
                      </form>
                    </TabsContent>

                    <TabsContent value="signup" className="mt-0 space-y-4">
                      <form onSubmit={handleSignUp} className="space-y-3.5">
                        <div className="space-y-1.5">
                          <Label htmlFor="signup-name" className="text-xs font-medium">Пълно име</Label>
                          <div className="relative">
                            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input id="signup-name" type="text" placeholder="Иван Иванов"
                              value={fullName} onChange={(e) => setFullName(e.target.value)} required
                              className="pl-10 rounded-xl h-11" />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="signup-email" className="text-xs font-medium">Имейл</Label>
                          <div className="relative">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input id="signup-email" type="email" placeholder="your@email.com"
                              value={email} onChange={(e) => setEmail(e.target.value)} required
                              className="pl-10 rounded-xl h-11" />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="signup-password" className="text-xs font-medium">Парола</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input id="signup-password" type={showPassword ? "text" : "password"}
                              placeholder="••••••••" value={password}
                              onChange={(e) => setPassword(e.target.value)} required
                              className="pl-10 pr-10 rounded-xl h-11" />
                            <button type="button" onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                          <p className="text-[10px] text-muted-foreground">Минимум 6 символа</p>
                        </div>
                        <Button type="submit" className="w-full rounded-xl h-11 text-sm font-semibold hover:scale-[1.01] active:scale-[0.99] transition-all" disabled={loading}>
                          {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                          {loading ? "Зареждане..." : "Създай акаунт"}
                        </Button>
                      </form>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default Auth;

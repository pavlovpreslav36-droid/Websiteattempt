import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Download, Smartphone, CheckCircle, Share, MoreVertical } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import Footer from "@/components/Footer";
import { Reveal } from "@/components/Reveal";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

const Install = () => {
  const { language } = useLanguage();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia("(display-mode: standalone)").matches) {
      setIsInstalled(true);
    }

    // Check if iOS
    const ua = navigator.userAgent;
    setIsIOS(/iPad|iPhone|iPod/.test(ua) && !(window as any).MSStream);

    // Listen for install prompt (Android/Chrome)
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener("beforeinstallprompt", handler);

    window.addEventListener("appinstalled", () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setIsInstalled(true);
    }
    setDeferredPrompt(null);
  };

  const bg = language === "bg";

  return (
    <div className="min-h-screen bg-background pt-20">
      <div className="container mx-auto px-6 py-12 max-w-2xl">
        <Reveal>
          <div className="text-center mb-10">
            <motion.div
              className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-primary/10 mb-6"
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ repeat: Infinity, duration: 3 }}
            >
              <Smartphone className="w-10 h-10 text-primary" />
            </motion.div>
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-3">
              {bg ? "Инсталирай приложението" : "Install the App"}
            </h1>
            <p className="text-muted-foreground text-lg">
              {bg
                ? "Добави Healthy Life на началния екран за бърз достъп и офлайн поддръжка"
                : "Add Healthy Life to your home screen for quick access and offline support"}
            </p>
          </div>
        </Reveal>

        {isInstalled ? (
          <Reveal delay={0.1}>
            <Card className="p-8 glass-card text-center">
              <CheckCircle className="w-16 h-16 text-primary mx-auto mb-4" />
              <h2 className="text-2xl font-semibold text-foreground mb-2">
                {bg ? "Вече е инсталирано! 🎉" : "Already Installed! 🎉"}
              </h2>
              <p className="text-muted-foreground">
                {bg
                  ? "Приложението е на началния ти екран. Отвори го оттам!"
                  : "The app is on your home screen. Open it from there!"}
              </p>
            </Card>
          </Reveal>
        ) : (
          <>
            {/* Android / Chrome install */}
            {deferredPrompt && (
              <Reveal delay={0.1}>
                <Card className="p-6 glass-card mb-6">
                  <Button
                    onClick={handleInstall}
                    className="w-full h-14 text-lg rounded-xl gap-3"
                    size="lg"
                  >
                    <Download className="w-6 h-6" />
                    {bg ? "Инсталирай сега" : "Install Now"}
                  </Button>
                </Card>
              </Reveal>
            )}

            {/* iOS instructions */}
            {isIOS && (
              <Reveal delay={0.1}>
                <Card className="p-6 glass-card mb-6">
                  <h2 className="text-xl font-semibold text-foreground mb-4">
                    {bg ? "Как да инсталираш на iPhone:" : "How to install on iPhone:"}
                  </h2>
                  <div className="space-y-4">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">1</div>
                      <p className="text-muted-foreground pt-1">
                        {bg ? "Натисни бутона" : "Tap the"}{" "}
                        <Share className="w-4 h-4 inline text-primary" />{" "}
                        {bg ? "за споделяне (долу в Safari)" : "Share button (bottom of Safari)"}
                      </p>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">2</div>
                      <p className="text-muted-foreground pt-1">
                        {bg ? 'Избери "Добави към начален екран"' : 'Select "Add to Home Screen"'}
                      </p>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">3</div>
                      <p className="text-muted-foreground pt-1">
                        {bg ? 'Натисни "Добави"' : 'Tap "Add"'}
                      </p>
                    </div>
                  </div>
                </Card>
              </Reveal>
            )}

            {/* Generic / Android Chrome instructions */}
            {!isIOS && !deferredPrompt && (
              <Reveal delay={0.1}>
                <Card className="p-6 glass-card mb-6">
                  <h2 className="text-xl font-semibold text-foreground mb-4">
                    {bg ? "Как да инсталираш:" : "How to install:"}
                  </h2>
                  <div className="space-y-4">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">1</div>
                      <p className="text-muted-foreground pt-1">
                        {bg ? "Отвори менюто на браузъра" : "Open the browser menu"}{" "}
                        <MoreVertical className="w-4 h-4 inline text-primary" />
                      </p>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">2</div>
                      <p className="text-muted-foreground pt-1">
                        {bg ? 'Избери "Инсталирай приложение" или "Добави към началния екран"' : 'Select "Install app" or "Add to Home screen"'}
                      </p>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">3</div>
                      <p className="text-muted-foreground pt-1">
                        {bg ? "Потвърди инсталацията" : "Confirm the installation"}
                      </p>
                    </div>
                  </div>
                </Card>
              </Reveal>
            )}

            {/* Benefits */}
            <Reveal delay={0.2}>
              <Card className="p-6 glass-card">
                <h2 className="text-xl font-semibold text-foreground mb-4">
                  {bg ? "Защо да инсталирам?" : "Why install?"}
                </h2>
                <div className="space-y-3">
                  {[
                    bg ? "⚡ По-бързо зареждане" : "⚡ Faster loading",
                    bg ? "📱 Цял екран без браузър лента" : "📱 Full screen without browser bar",
                    bg ? "🔔 Работи офлайн" : "🔔 Works offline",
                    bg ? "🏠 Икона на началния екран" : "🏠 Home screen icon",
                  ].map((benefit, i) => (
                    <p key={i} className="text-muted-foreground">{benefit}</p>
                  ))}
                </div>
              </Card>
            </Reveal>
          </>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default Install;

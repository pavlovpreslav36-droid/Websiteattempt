import { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Award, Ban, BookOpen, Users, BarChart3, Wind, Brain, ExternalLink, ArrowRight } from "lucide-react";
import { Reveal } from "@/components/Reveal";
import Footer from "@/components/Footer";
import { MythOrFact } from "@/components/MythOrFact";
import { QuitFoodIdeas } from "@/components/QuitFoodIdeas";
import { ambassadorsConfig } from "@/data/ambassadors";

/**
 * „Посланици на здравето“ – ученическа инициатива за превенция на тютюнопушенето
 * и никотиновите продукти и за по-висока здравна грамотност.
 * Данните за екип, дейности, резултати и материали се попълват в src/data/ambassadors.ts
 */

const pillars = [
  {
    icon: Ban,
    title: "Превенция",
    text: "Кухня за отказване със седемдневен план, страница „Без тютюн“ с брояч и игра „Мит или факт“ за цигари, вейпове и никотинови продукти.",
    to: "/quit-kitchen",
    cta: "Към кухнята за отказване",
  },
  {
    icon: BookOpen,
    title: "Здравна грамотност",
    text: "Здравна викторина с 50 въпроса, интересни факти, скенер на продукти, рецепти по режими и напитки.",
    to: "/quiz",
    cta: "Към викторината",
  },
  {
    icon: Users,
    title: "Роля на учениците",
    text: "Направено от ученици от кулинарно училище, затова храната е в центъра: рецепти, хранителни стойности и здравословен избор. Учиш чрез игра, а не чрез лекция.",
    to: "#team",
    cta: "Екипът",
  },
  {
    icon: BarChart3,
    title: "Резултати",
    text: "Показваме само реални числа: какво е създадено в платформата и какви материали има зад него.",
    to: "#results",
    cta: "Резултати",
  },
];

const Ambassadors = () => {
  const { school, team, activities, results, materials } = ambassadorsConfig;
  const { hash } = useLocation();

  useEffect(() => {
    if (!hash) return;
    const t = window.setTimeout(() => document.getElementById(hash.slice(1))?.scrollIntoView({ behavior: "smooth", block: "start" }), 250);
    return () => window.clearTimeout(t);
  }, [hash]);


  return (
    <div className="min-h-screen bg-background">
      {/* ═══ Banner ═══ */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] overflow-hidden bg-wine text-cream">
        <div className="absolute -right-24 -top-24 w-72 h-72 rounded-full bg-flame/20 float-slow" aria-hidden="true" />
        <div className="absolute right-24 -bottom-28 w-64 h-64 rounded-full bg-flame/20 float-slower" aria-hidden="true" />
        <div className="absolute left-[-3rem] bottom-[-3rem] w-40 h-40 rounded-full bg-flame/20 float-slow" aria-hidden="true" />
        <div className="relative container py-12 md:py-20 max-w-4xl mx-0 md:mx-auto">
          <Reveal>
            <span className="inline-grid place-items-center w-14 h-14 rounded-2xl bg-flame/25 mb-5">
              <Award className="w-7 h-7" aria-hidden="true" />
            </span>
          </Reveal>
          <Reveal delay={0.08}>
            <h1 className="display text-[clamp(2.2rem,8vw,5.5rem)] text-cream">Посланици на здравето</h1>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-5 text-lg md:text-xl text-cream/90 max-w-2xl leading-relaxed">
              Ученическа инициатива на ученици от кулинарно училище за превенция на тютюнопушенето и никотиновите продукти и за по-висока здравна грамотност. В духа на националния ученически конкурс на Министерството на здравеопазването.
            </p>
          </Reveal>
          {school && (
            <Reveal delay={0.2}>
              <p className="mt-4 text-sm font-semibold text-cream/80">{school}</p>
            </Reveal>
          )}
          <Reveal delay={0.24}>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/tobacco-free" className="inline-flex items-center gap-2 h-12 px-6 rounded-full bg-cream text-wine font-semibold hover:scale-[1.03] transition-transform">
                <Wind className="w-4 h-4" aria-hidden="true" /> Живот без дим
              </Link>
              <a href="#game" className="inline-flex items-center gap-2 h-12 px-6 rounded-full border border-cream/50 font-semibold hover:bg-cream/10 transition-colors">
                <Brain className="w-4 h-4" aria-hidden="true" /> Играй „Мит или факт“
              </a>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ═══ Pillars ═══ */}
      <section className="container py-14 md:py-20">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2">Какво правим</h2>
        <p className="text-muted-foreground mb-8 max-w-xl">Четири посоки, по които платформата работи за здравето на младите хора.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {pillars.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.06}>
              <div className="h-full flex flex-col rounded-3xl bg-card border border-border shadow-card p-6">
                <span className="grid place-items-center w-12 h-12 rounded-2xl bg-primary/10 text-primary mb-4">
                  <p.icon className="w-6 h-6" aria-hidden="true" />
                </span>
                <h3 className="text-lg font-bold text-foreground">{p.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed flex-1">{p.text}</p>
                {p.to.startsWith("#") ? (
                  <a href={p.to} className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-primary">
                    {p.cta} <ArrowRight className="w-4 h-4" aria-hidden="true" />
                  </a>
                ) : (
                  <Link to={p.to} className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-primary">
                    {p.cta} <ArrowRight className="w-4 h-4" aria-hidden="true" />
                  </Link>
                )}
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ═══ Myth or fact ═══ */}
      <section id="game" className="container pb-14 md:pb-20 scroll-mt-24">
        <div className="max-w-2xl">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2">Мит или факт?</h2>
          <p className="text-muted-foreground mb-8">Шест твърдения за цигари, вейпове и никотинови продукти. Познай кое е вярно.</p>
          <MythOrFact />
        </div>
      </section>

      {/* ═══ Food and products ═══ */}
      <section className="container pb-14 md:pb-20">
        <div className="max-w-xl mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2">На масата: храна, която подкрепя</h2>
          <p className="text-muted-foreground">Редовното хранене и хрупкавите зеленчуци помагат в първите седмици без цигара. Ето ястия от рецептите ни и малки навици, които можеш да пробваш.</p>
        </div>
        <QuitFoodIdeas />
      </section>

      {/* ═══ Team ═══ */}
      {team.length > 0 && (
        <section id="team" className="container pb-14 md:pb-20 scroll-mt-24">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8">Екипът</h2>
          <ul className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {team.map((m) => (
              <li key={m.name} className="rounded-3xl bg-card border border-border p-5">
                <p className="font-semibold text-foreground">{m.name}</p>
                <p className="text-sm text-muted-foreground mt-0.5">{m.role}</p>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* ═══ Activities ═══ */}
      {activities.length > 0 && (
        <section id="activities" className="container pb-14 md:pb-20 scroll-mt-24">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8">Дейности</h2>
          <ol className="space-y-4 max-w-3xl">
            {activities.map((a) => (
              <li key={a.title} className="rounded-3xl bg-card border border-border p-5 md:p-6">
                {a.date && <p className="text-sm font-semibold text-primary mb-1">{a.date}</p>}
                <h3 className="font-bold text-foreground">{a.title}</h3>
                <p className="mt-1 text-muted-foreground leading-relaxed">{a.text}</p>
              </li>
            ))}
          </ol>
        </section>
      )}

      {/* ═══ Results ═══ */}
      {results.length > 0 && (
        <section id="results" className="container pb-14 md:pb-20 scroll-mt-24">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8">Какво създадохме</h2>
          <ul className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {results.map((r) => (
              <li key={r.label} className="rounded-3xl bg-card border border-border p-5 text-center">
                <p className="font-brand text-3xl md:text-4xl font-bold text-primary">{r.value}</p>
                <p className="mt-2 text-sm text-muted-foreground leading-snug">{r.label}</p>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* ═══ Materials ═══ */}
      {materials.length > 0 && (
        <section id="materials" className="container pb-14 md:pb-20 scroll-mt-24">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8">Материали и публикации</h2>
          <ul className="grid md:grid-cols-2 gap-4">
            {materials.map((m) => {
              const inner = (
                <>
                  <span className="min-w-0">
                    <span className="block font-semibold text-foreground">{m.title}</span>
                    {m.text && <span className="block text-sm text-muted-foreground mt-0.5">{m.text}</span>}
                  </span>
                  {m.href && (/^https?:\/\//.test(m.href) ? <ExternalLink className="w-4 h-4 text-primary shrink-0" aria-hidden="true" /> : <ArrowRight className="w-4 h-4 text-primary shrink-0" aria-hidden="true" />)}
                </>
              );
              const cls = "flex items-center justify-between gap-4 rounded-3xl bg-card border border-border p-5 hover:border-primary/40 transition-colors";
              const external = !!m.href && /^https?:\/\//.test(m.href);
              return (
                <li key={m.title}>
                  {!m.href ? (
                    <div className="flex items-center justify-between gap-4 rounded-3xl bg-card border border-border p-5">{inner}</div>
                  ) : external ? (
                    <a href={m.href} target="_blank" rel="noopener noreferrer" className={cls}>{inner}</a>
                  ) : (
                    <Link to={m.href} className={cls}>{inner}</Link>
                  )}
                </li>
              );
            })}
          </ul>
        </section>
      )}

      {/* ═══ World No Tobacco Day ═══ */}
      <section className="container pb-16 md:pb-24">
        <div className="rounded-3xl bg-card border border-border p-6 md:p-10 grid md:grid-cols-[auto_1fr] gap-6 items-center">
          <p className="font-brand text-5xl md:text-6xl font-bold text-primary">31 май</p>
          <div>
            <h2 className="text-xl md:text-2xl font-bold text-foreground">Световен ден без тютюн</h2>
            <p className="mt-1.5 text-muted-foreground leading-relaxed">Всяка година Световната здравна организация отбелязва този ден. Ако ти или близък човек искате да откажете цигарите, говорете с личния лекар.</p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Ambassadors;

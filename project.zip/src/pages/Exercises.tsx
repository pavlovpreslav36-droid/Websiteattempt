import { useState, useRef } from "react";
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";
import { Reveal } from "@/components/Reveal";
import Footer from "@/components/Footer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import {
  Dumbbell, Timer, Flame, Heart, Target, TrendingUp,
  ChevronDown, ChevronUp, Zap, Award, Clock, BarChart3,
  ArrowRight, Play, CheckCircle2, Star
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────
interface Exercise {
  name: string;
  sets: string;
  reps: string;
  description: string;
  muscles: string[];
  difficulty: "Начинаещ" | "Среден" | "Напреднал";
  tips: string[];
}

interface Category {
  id: string;
  name: string;
  emoji: string;
  image: string;
  color: string;
  description: string;
  benefits: string[];
  warmup: string[];
  exercises: Exercise[];
  cooldown: string[];
  funFact: string;
}

// ─── Exercise Data ──────────────────────────────────────────────────
const categories: Category[] = [
  {
    id: "basketball",
    name: "Баскетбол",
    emoji: "🏀",
    image: "/images/exercises/basketball.jpg",
    color: "from-orange-500/20 to-amber-500/20",
    description: "Упражнения за експлозивност, бързина и вертикален скок",
    benefits: ["Подобрена координация", "Експлозивна сила", "Кардио издръжливост", "Бързи рефлекси"],
    warmup: ["Бягане на място – 3 мин", "Динамично разтягане на краката", "Странични придвижвания", "Въртене на глезени и колене"],
    exercises: [
      { name: "Box Jumps (Скокове на кутия)", sets: "4", reps: "8", description: "Застанете пред стабилна кутия (50-60 см). Приклекнете леко и скочете нагоре, кацайки меко с двата крака.", muscles: ["Квадрицепс", "Глутеуси", "Прасци"], difficulty: "Среден", tips: ["Кацайте меко с огънати колене", "Стъпвайте надолу, не скачайте"] },
      { name: "Lateral Shuffle (Странични придвижвания)", sets: "4", reps: "30 сек", description: "В полуприклек се придвижвайте бързо настрани, запазвайки ниска позиция. Сменяйте посока на всеки 5 метра.", muscles: ["Аддуктори", "Квадрицепс", "Глутеуси"], difficulty: "Начинаещ", tips: ["Дръжте гърба прав", "Не кръстосвайте краката"] },
      { name: "Defensive Slides", sets: "3", reps: "45 сек", description: "В защитна стойка се придвижвайте настрани, напред и назад по сигнал, симулирайки защитно движение.", muscles: ["Квадрицепс", "Глутеуси", "Прасци"], difficulty: "Среден", tips: ["Ниска позиция", "Бърза смяна на посоката"] },
      { name: "Depth Jumps (Скокове с дълбочина)", sets: "3", reps: "6", description: "Стъпете от кутия (40 см), и веднага след приземяване скочете максимално високо нагоре.", muscles: ["Квадрицепс", "Прасци", "Глутеуси"], difficulty: "Напреднал", tips: ["Минимално време на контакт със земята", "Приземявайте се на предната част на стъпалото"] },
      { name: "Bulgarian Split Squats", sets: "3", reps: "10/крак", description: "С единия крак назад на пейка, приклекнете с предния крак до 90 градуса в коляното.", muscles: ["Квадрицепс", "Глутеуси", "Хамстринги"], difficulty: "Среден", tips: ["Коляното не трябва да минава пръстите", "Контролирано движение надолу"] },
    ],
    cooldown: ["Разтягане на квадрицепс – 30 сек/крак", "Разтягане на хамстринги", "Дълбоко дишане – 2 мин"],
    funFact: "Майкъл Джордан е правил по 500 скока на ден, за да подобри вертикалния си скок!"
  },
  {
    id: "volleyball",
    name: "Волейбол",
    emoji: "🏐",
    image: "/images/exercises/volleyball.jpg",
    color: "from-blue-500/20 to-cyan-500/20",
    description: "Сила на рамото, скок и реактивна бързина",
    benefits: ["Взривна сила", "Гъвкавост на раменете", "Координация око-ръка", "Силни рамене"],
    warmup: ["Кръгове с ръце – 2 мин", "Леки скокове на място", "Разтягане на рамене", "Странични изпади"],
    exercises: [
      { name: "Spike Approach Jumps", sets: "4", reps: "8", description: "Симулирайте подход за атака: 3 стъпки напред с финален скок нагоре, като размахвате ръката за удар.", muscles: ["Прасци", "Квадрицепс", "Рамене"], difficulty: "Среден", tips: ["Последната стъпка е най-голяма", "Замахвайте и с двете ръце за височина"] },
      { name: "Medicine Ball Overhead Throw", sets: "4", reps: "10", description: "С медицинска топка (3-5 кг) я хвърлете силно от зад главата напред и надолу, симулирайки удар.", muscles: ["Рамене", "Трицепс", "Корем"], difficulty: "Среден", tips: ["Ангажирайте кора", "Бъдете експлозивни"] },
      { name: "Block Jumps (Скокове за блок)", sets: "4", reps: "10", description: "Застанете лицом към мрежата (или стената). Скочете нагоре с вдигнати ръце, симулирайки блокада.", muscles: ["Прасци", "Квадрицепс", "Делтоиди"], difficulty: "Начинаещ", tips: ["Ръцете преминават над главата", "Кацайте на пръсти, после на цяло стъпало"] },
      { name: "Prone Y-T-W Raises", sets: "3", reps: "8 всяка", description: "Легнете по корем. Повдигнете ръцете в позиция Y, после T, после W. Задръжте 2 сек всяка.", muscles: ["Ротаторен маншон", "Трапец", "Задно рамо"], difficulty: "Начинаещ", tips: ["Бавно и контролирано", "Стиснете лопатките"] },
      { name: "Single-Leg Box Jumps", sets: "3", reps: "6/крак", description: "Скочете на кутия с един крак, кацайки на същия крак. Развива баланс и едностранна сила.", muscles: ["Квадрицепс", "Глутеуси", "Стабилизатори"], difficulty: "Напреднал", tips: ["Започнете с ниска кутия", "Приземявайте се меко"] },
    ],
    cooldown: ["Разтягане на рамене – 30 сек/ръка", "Cat-Cow stretch", "Разтягане на прасци"],
    funFact: "Топ волейболистите могат да скочат над 3.5 метра височина!"
  },
  {
    id: "table-tennis",
    name: "Тенис на маса",
    emoji: "🏓",
    image: "/images/exercises/table-tennis.jpg",
    color: "from-red-500/20 to-rose-500/20",
    description: "Бързи рефлекси, координация и издръжливост на китката",
    benefits: ["Светкавични рефлекси", "Координация око-ръка", "Фокус и концентрация", "Издръжливост на предмишницата"],
    warmup: ["Въртене на китки – 1 мин", "Бърза стъпка на място", "Разтягане на предмишници", "Очни упражнения (следене на пръст)"],
    exercises: [
      { name: "Wrist Curls (Свиване на китка)", sets: "3", reps: "15", description: "С лека гира (2-5 кг), предмишницата на коляното, свивайте китката нагоре и надолу.", muscles: ["Предмишница", "Китка"], difficulty: "Начинаещ", tips: ["Бавно и контролирано", "Не използвайте твърде тежка тежест"] },
      { name: "Agility Ladder Drills", sets: "4", reps: "30 сек", description: "Бързи стъпки през координационна стълба: in-in-out-out, iki-шуфъл, бърз бяг.", muscles: ["Прасци", "Квадрицепс", "Координация"], difficulty: "Среден", tips: ["Бързина > точност в началото", "Постепенно увеличавайте темпото"] },
      { name: "Shadow Play (Сенчеста игра)", sets: "4", reps: "60 сек", description: "Без топка, симулирайте удари: форхенд, бекхенд, подрязване. Движете се като в реална игра.", muscles: ["Рамене", "Предмишница", "Крака"], difficulty: "Начинаещ", tips: ["Визуализирайте топката", "Работете върху стъпковата работа"] },
      { name: "Reaction Ball Catches", sets: "3", reps: "20", description: "Хвърлете реакционна топка (с неправилна форма) в стената и хващайте. Развива рефлексите.", muscles: ["Координация", "Предмишница", "Рефлекси"], difficulty: "Среден", tips: ["Стойте на 2-3 метра от стената", "Увеличавайте силата на хвърлянето"] },
      { name: "Forearm Plank with Rotation", sets: "3", reps: "10/страна", description: "От планк позиция, ротирайте тялото и вдигнете едната ръка нагоре. Укрепва кора и стабилност.", muscles: ["Корем", "Облики", "Рамене"], difficulty: "Среден", tips: ["Дръжте таза стабилен", "Контролирана ротация"] },
    ],
    cooldown: ["Разтягане на предмишници", "Разтягане на рамене", "Дълбоко дишане с визуализация"],
    funFact: "Топката при тенис на маса може да достигне скорост от 112 км/ч!"
  },
  {
    id: "football",
    name: "Футбол",
    emoji: "⚽",
    image: "/images/exercises/football.jpg",
    color: "from-green-500/20 to-emerald-500/20",
    description: "Издръжливост, бързина и сила на краката",
    benefits: ["Кардио издръжливост", "Бързина и ловкост", "Силни крака", "Командна работа"],
    warmup: ["Лек бяг – 5 мин", "Динамични изпади", "High knees", "Butt kicks"],
    exercises: [
      { name: "Cone Dribbling (Дрибъл между конуси)", sets: "4", reps: "45 сек", description: "Поставете 6-8 конуса на 1.5 м разстояние. Водете топката между тях с вътрешната и външната страна на крака.", muscles: ["Квадрицепс", "Прасци", "Координация"], difficulty: "Среден", tips: ["Дребни докосвания", "Главата горе, не гледайте топката постоянно"] },
      { name: "Sprint Intervals", sets: "8", reps: "30 м", description: "Спринтирайте 30 метра на максимална скорост, после се връщайте с бягане назад. Почивка 30 сек между спринтовете.", muscles: ["Хамстринги", "Квадрицепс", "Прасци"], difficulty: "Среден", tips: ["Пълен спринт", "Добро възстановяване между повторенията"] },
      { name: "Nordic Hamstring Curls", sets: "3", reps: "6", description: "Коленичете, партньор държи глезените ви. Бавно се спускайте напред, като задържате с хамстрингите.", muscles: ["Хамстринги"], difficulty: "Напреднал", tips: ["Много бавно ексцентрично движение", "Помогнете си с ръцете при нужда"] },
      { name: "Single-Leg Romanian Deadlift", sets: "3", reps: "8/крак", description: "На един крак, наведете се напред с прав гръб, докато другият крак отива назад. Развива баланс.", muscles: ["Хамстринги", "Глутеуси", "Стабилизатори"], difficulty: "Среден", tips: ["Прав гръб", "Контролирано движение"] },
      { name: "Plyometric Lunges", sets: "3", reps: "12", description: "Направете изпад и скочете нагоре, като смените краката във въздуха. Кацнете в обратен изпад.", muscles: ["Квадрицепс", "Глутеуси", "Прасци"], difficulty: "Напреднал", tips: ["Меко приземяване", "Коляното не минава пръстите"] },
    ],
    cooldown: ["Разтягане на хамстринги – 30 сек/крак", "Разтягане на хипсовете", "Пяна ролер за краката"],
    funFact: "Футболист изминава средно 10-12 км за един мач!"
  },
  {
    id: "tennis",
    name: "Тенис",
    emoji: "🎾",
    image: "/images/exercises/tennis.jpg",
    color: "from-yellow-500/20 to-lime-500/20",
    description: "Сила на удара, странични движения и издръжливост",
    benefits: ["Сила на раменете", "Ловкост", "Кардио", "Координация"],
    warmup: ["Леки подскоци – 2 мин", "Кръгове с ракета", "Странични придвижвания", "Разтягане на рамене"],
    exercises: [
      { name: "Medicine Ball Rotational Throw", sets: "4", reps: "8/страна", description: "С медицинска топка, ротирайте тялото и хвърлете в стената, симулирайки форхенд или бекхенд.", muscles: ["Облики", "Рамене", "Хипсове"], difficulty: "Среден", tips: ["Ротация от хипсовете", "Експлозивно движение"] },
      { name: "Side-to-Side Shuffles с ракета", sets: "4", reps: "45 сек", description: "С ракета в ръка, придвижвайте се бързо странично, симулирайки позициониране за удар.", muscles: ["Аддуктори", "Квадрицепс", "Прасци"], difficulty: "Начинаещ", tips: ["Ниска позиция", "Бърза смяна на посоката"] },
      { name: "Resistance Band External Rotation", sets: "3", reps: "12/ръка", description: "С ластик, лакътът на 90°, ротирайте предмишницата навън. Критично за здравето на рамото.", muscles: ["Ротаторен маншон", "Инфраспинатус"], difficulty: "Начинаещ", tips: ["Лакътът прилепнал до тялото", "Бавно и контролирано"] },
      { name: "Split Squat Jumps", sets: "3", reps: "10", description: "От позиция изпад, скочете нагоре максимално и кацнете в същата позиция.", muscles: ["Квадрицепс", "Глутеуси", "Прасци"], difficulty: "Напреднал", tips: ["Дълбок изпад", "Меко приземяване"] },
      { name: "Plank with Shoulder Tap", sets: "3", reps: "16", description: "От планк, докоснете лявото рамо с дясната ръка и обратно. Без ротация на таза.", muscles: ["Корем", "Рамене", "Стабилизатори"], difficulty: "Среден", tips: ["Широка стъпка за стабилност", "Без люлеене на хипсовете"] },
    ],
    cooldown: ["Разтягане на рамене и гръб", "Разтягане на предмишници", "Медитативно дишане"],
    funFact: "Сервисът на Джон Изнер е измерен на 253 км/ч – най-бързият в историята!"
  },
  {
    id: "swimming",
    name: "Плуване",
    emoji: "🏊",
    image: "/images/exercises/swimming.jpg",
    color: "from-sky-500/20 to-blue-500/20",
    description: "Горна и долна част на тялото, дишане и гъвкавост",
    benefits: ["Пълно тяло тренировка", "Нисък стрес за ставите", "Подобрено дишане", "Гъвкавост"],
    warmup: ["Кръгове с ръце – 2 мин", "Arm swings", "Разтягане на рамене", "Дихателни упражнения"],
    exercises: [
      { name: "Streamline Pull-Ups (Подтягвания)", sets: "3", reps: "8", description: "Подтягвания с широк хват, имитиращи гребането при кроул. Ключово за сила в гърба.", muscles: ["Широк гръбен", "Бицепс", "Задно рамо"], difficulty: "Напреднал", tips: ["Пълен обхват на движение", "Контролирано спускане"] },
      { name: "Flutter Kicks (Крачета)", sets: "4", reps: "30 сек", description: "Легнете по гръб, повдигнете краката 15 см от земята и ги движете нагоре-надолу бързо.", muscles: ["Долен корем", "Хипсови флексори", "Квадрицепс"], difficulty: "Начинаещ", tips: ["Кръстът прилепнал към пода", "Малки и бързи движения"] },
      { name: "Superman Hold", sets: "3", reps: "20 сек", description: "Легнете по корем, вдигнете едновременно ръцете и краката от земята. Задръжте.", muscles: ["Еректори", "Глутеуси", "Задно рамо"], difficulty: "Начинаещ", tips: ["Не прекалявайте с екстензията", "Дишайте нормално"] },
      { name: "Lat Pulldowns с ластик", sets: "3", reps: "12", description: "С ластик закрепен високо, дърпайте надолу с широк хват, стискайки лопатките.", muscles: ["Широк гръбен", "Бицепс", "Трапец"], difficulty: "Среден", tips: ["Стиснете лопатките долу", "Бавно връщане нагоре"] },
      { name: "Ankle Band Kicks", sets: "3", reps: "20/крак", description: "С ластик на глезените, правете ритници напред, назад и настрани. Укрепва краката за ритане.", muscles: ["Квадрицепс", "Глутеуси", "Аддуктори"], difficulty: "Начинаещ", tips: ["Контролирано движение", "Не люлейте тялото"] },
    ],
    cooldown: ["Разтягане на рамене – 30 сек/ръка", "Child's pose – 30 сек", "Дихателно упражнение 4-7-8"],
    funFact: "Майкъл Фелпс е ял по 12,000 калории на ден по време на тренировъчен период!"
  },
  {
    id: "running",
    name: "Бягане",
    emoji: "🏃",
    image: "/images/exercises/running.jpg",
    color: "from-teal-500/20 to-cyan-500/20",
    description: "Скорост, издръжливост и превенция на контузии",
    benefits: ["Кардио здраве", "Силни крака", "Психично здраве", "Контрол на теглото"],
    warmup: ["Лек бяг – 5 мин", "Динамични разтягания", "A-skip и B-skip", "High knees"],
    exercises: [
      { name: "Tempo Runs", sets: "1", reps: "20 мин", description: "Бягайте с 80-85% от максималното темпо. Трябва да е 'комфортно трудно' – може да говорите, но не лесно.", muscles: ["Сърдечен мускул", "Квадрицепс", "Прасци"], difficulty: "Среден", tips: ["Равномерно темпо", "Не ускорявайте в края"] },
      { name: "Hill Sprints", sets: "8", reps: "15 сек", description: "Намерете хълм с наклон 5-8%. Спринтирайте нагоре 15 сек, ходете надолу за почивка.", muscles: ["Глутеуси", "Прасци", "Квадрицепс"], difficulty: "Напреднал", tips: ["Пълен спринт нагоре", "2 мин почивка между повторенията"] },
      { name: "Calf Raises на стъпало", sets: "3", reps: "15", description: "Застанете с предната част на стъпалото на ръб на стъпало. Вдигнете се максимално нагоре, после спуснете пета надолу.", muscles: ["Прасци", "Солеус"], difficulty: "Начинаещ", tips: ["Пълен обхват на движение", "Задръжте 2 сек горе"] },
      { name: "Glute Bridge", sets: "3", reps: "15", description: "Легнете по гръб, колене огънати. Вдигнете таза максимално нагоре, стискайки глутеусите.", muscles: ["Глутеуси", "Хамстринги", "Долен гръб"], difficulty: "Начинаещ", tips: ["Стиснете горе за 2 сек", "Не прекалявайте с екстензията"] },
      { name: "A-Skip Drill", sets: "4", reps: "30 м", description: "Бяг с високо вдигане на колене, с подскок при всяка стъпка. Подобрява бягащата техника.", muscles: ["Хипсови флексори", "Прасци", "Координация"], difficulty: "Начинаещ", tips: ["Високо коляно", "Активно стъпало"] },
    ],
    cooldown: ["Бавно ходене – 5 мин", "Разтягане на квадрицепс и хамстринги", "Пяна ролер"],
    funFact: "Елиуд Кипчоге пробяга маратон за под 2 часа – 2:01:09 официално!"
  },
  {
    id: "boxing",
    name: "Бокс",
    emoji: "🥊",
    image: "/images/exercises/boxing.jpg",
    color: "from-red-600/20 to-orange-500/20",
    description: "Удърна сила, рефлекси и сърдечна издръжливост",
    benefits: ["Пълно тяло тренировка", "Стрес редукция", "Бързи рефлекси", "Кондиция"],
    warmup: ["Скачане на въже – 3 мин", "Shadow boxing – 2 мин", "Ротации на раменете", "Разтягане на китки"],
    exercises: [
      { name: "Heavy Bag Rounds", sets: "5", reps: "3 мин", description: "3-минутни рунда на тежък чувал. Комбинации: джаб-крос, джаб-джаб-крос-кука. 1 мин почивка.", muscles: ["Рамене", "Трицепс", "Корем", "Крака"], difficulty: "Среден", tips: ["Цялата сила е от краката и хипсовете", "Дишайте при всеки удар"] },
      { name: "Speed Bag Drill", sets: "4", reps: "2 мин", description: "Удряйте бързата топка с ритмични удари, поддържайки постоянен ритъм.", muscles: ["Рамене", "Делтоиди", "Координация"], difficulty: "Среден", tips: ["Малки, бързи кръгови движения", "Дръжте ръцете високо"] },
      { name: "Burpees с удар", sets: "4", reps: "10", description: "Направете бърпи, и при изправяне хвърлете 2 джаба и 1 крос. Убийствено кардио.", muscles: ["Цяло тяло"], difficulty: "Напреднал", tips: ["Бърз преход от бърпи към удари", "Не жертвайте формата за бързина"] },
      { name: "Slip and Counter", sets: "4", reps: "30 сек", description: "Представете си въображаем удар. Наклонете се встрани (slip) и веднага контрирайте с крос.", muscles: ["Облики", "Рамене", "Крака"], difficulty: "Среден", tips: ["Slip с цялото тяло, не само главата", "Експлозивен контра удар"] },
      { name: "Plank Body Saw", sets: "3", reps: "12", description: "В позиция планк на лактите, изтласкайте тялото назад и напред с малки движения.", muscles: ["Корем", "Рамене", "Долен гръб"], difficulty: "Среден", tips: ["Стегнат кор през цялото време", "Малки, контролирани движения"] },
    ],
    cooldown: ["Разтягане на рамене и гърди", "Разтягане на хипсовете", "Медитативно дишане – 3 мин"],
    funFact: "Боксьорът изгаря до 800 калории на час тренировка!"
  },
  {
    id: "cycling",
    name: "Колоездене",
    emoji: "🚴",
    image: "/images/exercises/cycling.jpg",
    color: "from-violet-500/20 to-purple-500/20",
    description: "Сила на краката, кардио и издръжливост",
    benefits: ["Нисък удар за ставите", "Силни крака", "Кардио здраве", "Издръжливост"],
    warmup: ["Леко въртене на педали – 5 мин", "Динамично разтягане на крака", "Кръгове с глезените"],
    exercises: [
      { name: "Leg Press", sets: "4", reps: "12", description: "На машина leg press, бутайте с двата крака. Имитира педалирането под натоварване.", muscles: ["Квадрицепс", "Глутеуси", "Хамстринги"], difficulty: "Среден", tips: ["Не заключвайте коленете", "Пълен обхват на движение"] },
      { name: "Wall Sit (Стена)", sets: "3", reps: "45 сек", description: "Облегнете гърба на стена, коленете на 90°. Задръжте. Изгаря като истинско катерене!", muscles: ["Квадрицепс", "Глутеуси"], difficulty: "Начинаещ", tips: ["Гърбът залепен на стената", "Равномерно дишане"] },
      { name: "Step-Ups с тежест", sets: "3", reps: "10/крак", description: "С гири в ръце, стъпвайте на пейка (40-50 см) и се изправяйте. Сменяйте краката.", muscles: ["Квадрицепс", "Глутеуси", "Прасци"], difficulty: "Среден", tips: ["Цялата сила от предния крак", "Не се отблъсквайте с задния"] },
      { name: "Cadence Intervals на колело", sets: "6", reps: "3 мин", description: "3 мин бързо въртене (100+ RPM), 2 мин бавно. Подобрява ефективността на педалиране.", muscles: ["Квадрицепс", "Прасци", "Кардио"], difficulty: "Среден", tips: ["Гладко, кръгообразно педалиране", "Не скачайте на седалката"] },
      { name: "Hip Flexor Stretch с ластик", sets: "3", reps: "30 сек/страна", description: "Коленичете на едно коляно, другият крак напред. Бутнете хипса напред за разтягане. Критично за колоездачи!", muscles: ["Хипсови флексори", "Квадрицепс"], difficulty: "Начинаещ", tips: ["Стегнете глутеуса на задния крак", "Не прекалявайте"] },
    ],
    cooldown: ["Разтягане на квадрицепс и хамстринги", "Разтягане на хипсови флексори", "Пяна ролер за IT band"],
    funFact: "Тур дьо Франс състезателите изминават около 3,500 км за 21 етапа!"
  },
  {
    id: "weight-loss",
    name: "Отслабване",
    emoji: "🔥",
    image: "/images/exercises/weight-loss.jpg",
    color: "from-orange-500/20 to-red-500/20",
    description: "HIIT тренировки за максимално горене на калории",
    benefits: ["Ускорен метаболизъм", "Горене на мазнини", "Afterburn ефект", "Подобрено сърдечно здраве"],
    warmup: ["Марширане на място – 2 мин", "Jumping jacks – 1 мин", "Динамични разтягания", "Бягане на място"],
    exercises: [
      { name: "Burpees", sets: "4", reps: "12", description: "Клекнете, ритнете краката назад в планк, направете лицева опора, скочете обратно и скочете нагоре.", muscles: ["Цяло тяло"], difficulty: "Среден", tips: ["Гърдите докосват пода", "Експлозивен скок нагоре"] },
      { name: "Mountain Climbers", sets: "4", reps: "30 сек", description: "В позиция за лицева опора, бързо редувайте колене към гърдите, като бягате на място.", muscles: ["Корем", "Рамене", "Квадрицепс"], difficulty: "Начинаещ", tips: ["Бързо темпо", "Хипсовете долу, не нагоре"] },
      { name: "Jump Squats", sets: "4", reps: "15", description: "Приклекнете и скочете максимално нагоре. Кацнете меко и веднага в следващия клек.", muscles: ["Квадрицепс", "Глутеуси", "Прасци"], difficulty: "Среден", tips: ["Дълбок клек", "Меко приземяване"] },
      { name: "High Knees Sprint", sets: "4", reps: "30 сек", description: "Бягане на място с максимално високо вдигане на коленете. Работете с ръцете!", muscles: ["Хипсови флексори", "Корем", "Прасци"], difficulty: "Начинаещ", tips: ["Колене до нивото на хипса", "Бързо темпо"] },
      { name: "Kettlebell Swings", sets: "4", reps: "15", description: "С гира, замахнете я между краката и с движение от хипсовете я изхвърлете до нивото на раменете.", muscles: ["Глутеуси", "Хамстринги", "Корем", "Рамене"], difficulty: "Среден", tips: ["Движението е от хипсовете, не от ръцете", "Стегнат кор"] },
    ],
    cooldown: ["Бавна разходка – 3 мин", "Разтягане на цялото тяло", "Дълбоко дишане"],
    funFact: "HIIT тренировката продължава да гори калории до 48 часа след приключването й!"
  },
  {
    id: "health",
    name: "Здраве & Гъвкавост",
    emoji: "🧘",
    image: "/images/exercises/health.jpg",
    color: "from-emerald-500/20 to-teal-500/20",
    description: "Мобилност, баланс и превенция на болки",
    benefits: ["Намалена болка в гърба", "По-добър сън", "Понижен стрес", "Подобрена стойка"],
    warmup: ["Дълбоко дишане – 2 мин", "Нежни кръгове с врата", "Cat-Cow stretch", "Лек бяг на място"],
    exercises: [
      { name: "Cat-Cow Stretch", sets: "3", reps: "10", description: "На четири крайника, редувайте извиване на гърба нагоре (котка) и надолу (крава) с дишане.", muscles: ["Гръбначен стълб", "Корем", "Гръб"], difficulty: "Начинаещ", tips: ["Синхронизирайте с дишането", "Бавно и плавно"] },
      { name: "Bird Dog", sets: "3", reps: "8/страна", description: "На четири крайника, протегнете едновременно дясна ръка и ляв крак. Задръжте 3 сек. Сменете.", muscles: ["Корем", "Долен гръб", "Глутеуси"], difficulty: "Начинаещ", tips: ["Не ротирайте таза", "Протегнете се максимално"] },
      { name: "World's Greatest Stretch", sets: "3", reps: "5/страна", description: "Направете дълъг изпад, завъртете тялото към предното коляно и протегнете ръка нагоре. Задръжте 5 сек.", muscles: ["Хипсове", "Торакален гръб", "Хамстринги"], difficulty: "Среден", tips: ["Бавно и контролирано", "Дишайте дълбоко при ротацията"] },
      { name: "Dead Hang (Висене на лост)", sets: "3", reps: "30 сек", description: "Увиснете на лост с прав хват. Отпуснете раменете и гръбнака. Декомпресира гръбначния стълб.", muscles: ["Предмишница", "Рамене", "Гръбнак"], difficulty: "Начинаещ", tips: ["Напълно отпуснато тяло", "Дишайте дълбоко"] },
      { name: "90/90 Hip Stretch", sets: "3", reps: "30 сек/страна", description: "Седнете с предния крак на 90° и задния на 90°. Наведете се напред за дълбоко разтягане на хипса.", muscles: ["Хипсови ротатори", "Глутеуси", "Пираформис"], difficulty: "Начинаещ", tips: ["Задържайте стабилен таз", "Постепенно увеличавайте дълбочината"] },
    ],
    cooldown: ["Shavasana (мъртва поза) – 3 мин", "Body scan медитация", "Дълбоко коремно дишане"],
    funFact: "10 минути разтягане на ден може да намали болките в гърба с до 50%!"
  },
];

// ─── Difficulty Colors ──────────────────────────────────────────────
const difficultyConfig = {
  "Начинаещ": { color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30", icon: Star },
  "Среден": { color: "bg-amber-500/20 text-amber-400 border-amber-500/30", icon: TrendingUp },
  "Напреднал": { color: "bg-red-500/20 text-red-400 border-red-500/30", icon: Zap },
};

// ─── Exercise Card Component ────────────────────────────────────────
const ExerciseCard = ({ exercise, index }: { exercise: Exercise; index: number }) => {
  const [expanded, setExpanded] = useState(false);
  const config = difficultyConfig[exercise.difficulty];
  const DiffIcon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: false, margin: "-50px" }}
      transition={{ delay: index * 0.08, duration: 0.4 }}
    >
      <Card
        className="group cursor-pointer border-border/50 bg-card hover:border-primary/30 transition-all duration-300 overflow-hidden"
        onClick={() => setExpanded(!expanded)}
      >
        <CardContent className="p-4 sm:p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-2">
                <span className="text-lg font-semibold text-foreground">{exercise.name}</span>
                <Badge variant="outline" className={`text-xs ${config.color}`}>
                  <DiffIcon className="w-3 h-3 mr-1" />
                  {exercise.difficulty}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground line-clamp-2">{exercise.description}</p>
              <div className="flex items-center gap-4 mt-3">
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <BarChart3 className="w-3.5 h-3.5 text-primary" />
                  {exercise.sets} серии
                </span>
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Target className="w-3.5 h-3.5 text-primary" />
                  {exercise.reps}
                </span>
              </div>
            </div>
            <motion.div animate={{ rotate: expanded ? 180 : 0 }} transition={{ duration: 0.2 }}>
              <ChevronDown className="w-5 h-5 text-muted-foreground" />
            </motion.div>
          </div>

          <AnimatePresence>
            {expanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="mt-4 pt-4 border-t border-border/50 space-y-3">
                  <div>
                    <span className="text-xs font-medium text-primary uppercase tracking-wider">Мускулни групи</span>
                    <div className="flex flex-wrap gap-1.5 mt-1.5">
                      {exercise.muscles.map((m) => (
                        <Badge key={m} variant="secondary" className="text-xs">{m}</Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-xs font-medium text-primary uppercase tracking-wider">Съвети</span>
                    <ul className="mt-1.5 space-y-1">
                      {exercise.tips.map((tip, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <CheckCircle2 className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                          {tip}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
};

// ─── Category Detail Component ──────────────────────────────────────
const CategoryDetail = ({ category }: { category: Category }) => {
  return (
    <div className="space-y-8">
      {/* Category Header */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative rounded-2xl overflow-hidden"
      >
        <div className="absolute inset-0">
          <img src={category.image} alt={category.name} className="w-full h-full object-cover" loading="lazy" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
        </div>
        <div className="relative p-6 sm:p-8 pt-32 sm:pt-40">
          <h2 className="text-3xl sm:text-4xl font-display font-bold text-foreground">
            {category.emoji} {category.name}
          </h2>
          <p className="text-muted-foreground mt-2 max-w-lg">{category.description}</p>
          <div className="flex flex-wrap gap-2 mt-4">
            {category.benefits.map((b) => (
              <Badge key={b} variant="secondary" className="bg-primary/10 text-primary border-primary/20">
                <CheckCircle2 className="w-3 h-3 mr-1" />{b}
              </Badge>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Warmup */}
      <Reveal>
        <Card className="border-border/50 bg-card">
          <CardContent className="p-5">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2 mb-3">
              <Flame className="w-5 h-5 text-accent" /> Загрявка
            </h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {category.warmup.map((w, i) => (
                <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Play className="w-3.5 h-3.5 text-primary shrink-0" /> {w}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </Reveal>

      {/* Exercises */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
          <Dumbbell className="w-5 h-5 text-primary" /> Упражнения ({category.exercises.length})
        </h3>
        {category.exercises.map((ex, i) => (
          <ExerciseCard key={ex.name} exercise={ex} index={i} />
        ))}
      </div>

      {/* Cooldown */}
      <Reveal>
        <Card className="border-border/50 bg-card">
          <CardContent className="p-5">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2 mb-3">
              <Heart className="w-5 h-5 text-primary" /> Охлаждане
            </h3>
            <ul className="space-y-2">
              {category.cooldown.map((c, i) => (
                <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" /> {c}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </Reveal>

      {/* Fun Fact */}
      <Reveal>
        <div className="rounded-xl bg-primary/5 border border-primary/20 p-5">
          <p className="text-sm text-foreground flex items-start gap-2">
            <Award className="w-5 h-5 text-primary shrink-0 mt-0.5" />
            <span><strong>Знаеше ли?</strong> {category.funFact}</span>
          </p>
        </div>
      </Reveal>
    </div>
  );
};

// ─── Stats Section ──────────────────────────────────────────────────
const stats = [
  { label: "Категории", value: categories.length, icon: Target, suffix: "+" },
  { label: "Упражнения", value: categories.reduce((a, c) => a + c.exercises.length, 0), icon: Dumbbell, suffix: "+" },
  { label: "Мускулни групи", value: 25, icon: Zap, suffix: "+" },
  { label: "Съвети", value: categories.reduce((a, c) => a + c.exercises.reduce((b, e) => b + e.tips.length, 0), 0), icon: Star, suffix: "" },
];

// ─── Main Page Component ────────────────────────────────────────────
const Exercises = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>(categories[0].id);
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.5], [1, 1.1]);

  const selectedCat = categories.find((c) => c.id === selectedCategory)!;

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div ref={heroRef} className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] overflow-hidden h-[56vh] sm:h-[60vh]">
        <motion.div style={{ y: heroY, scale: heroScale }} className="absolute inset-0">
          <img
            src="/images/exercises-hero.jpg"
            alt="Тренировки и упражнения"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/40 to-black/15" />
        </motion.div>

        <motion.div
          style={{ opacity: heroOpacity }}
          className="relative h-full flex flex-col items-center justify-center text-center px-6"
        >
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Badge className="mb-4 bg-white/20 text-white border-white/30">
              <Dumbbell className="w-3 h-3 mr-1" /> {categories.length} категории • {categories.reduce((a, c) => a + c.exercises.length, 0)}+ упражнения
            </Badge>
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-display font-bold text-white mb-4 leading-tight">
              Тренировки за<br />
              <span className="text-white">всеки спорт</span>
            </h1>
            <p className="text-lg text-white/85 max-w-xl mx-auto mb-8">
              Реални упражнения за баскетбол, волейбол, тенис, бокс, плуване и много повече.
              Отслабване, здраве и спортна подготовка.
            </p>
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <ChevronDown className="w-8 h-8 text-white mx-auto" />
            </motion.div>
          </motion.div>
        </motion.div>
      </div>

      {/* Stats */}
      <div className="container mx-auto px-4 mt-6 relative z-10">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {stats.map((stat, i) => (
            <Reveal key={stat.label}>
              <motion.div
                whileHover={{ scale: 1.03 }}
                className="rounded-xl bg-card/80 backdrop-blur-xl border border-border/50 p-4 text-center"
              >
                <stat.icon className="w-6 h-6 text-primary mx-auto mb-2" />
                <div className="text-2xl font-bold text-foreground">{stat.value}{stat.suffix}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>

      {/* Category Picker + Content */}
      <div className="container mx-auto px-4 py-12 sm:py-16">
        <Reveal>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-foreground mb-6">
            Избери категория 🎯
          </h2>
        </Reveal>

        {/* Horizontal scrollable category cards */}
        <ScrollArea className="w-full mb-8">
          <div className="flex gap-3 pb-4">
            {categories.map((cat) => (
              <motion.button
                key={cat.id}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setSelectedCategory(cat.id)}
                className={`relative shrink-0 w-28 sm:w-36 rounded-xl overflow-hidden border-2 transition-colors duration-200 ${
                  selectedCategory === cat.id
                    ? "border-primary shadow-lg shadow-primary/20"
                    : "border-border/50 hover:border-border"
                }`}
              >
                <div className="aspect-[3/4] relative">
                  <img src={cat.image} alt={cat.name} className="w-full h-full object-cover" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-2.5 text-left">
                    <div className="text-xl mb-0.5">{cat.emoji}</div>
                    <div className="text-xs font-semibold text-foreground leading-tight">{cat.name}</div>
                  </div>
                  {selectedCategory === cat.id && (
                    <motion.div
                      layoutId="category-indicator"
                      className="absolute top-2 right-2 w-3 h-3 rounded-full bg-primary"
                    />
                  )}
                </div>
              </motion.button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>

        {/* Selected Category Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedCategory}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <CategoryDetail category={selectedCat} />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Quick Tips Section */}
      <div className="container mx-auto px-4 pb-16">
        <Reveal>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-foreground mb-6">
            💡 Бързи съвети за тренировка
          </h2>
        </Reveal>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { icon: Clock, title: "Загрявай винаги", desc: "5-10 минути загрявка намалява риска от контузия с до 50%." },
            { icon: Flame, title: "Прогресивно натоварване", desc: "Увеличавайте тежестта или повторенията с 5-10% на седмица." },
            { icon: Heart, title: "Почивка е ключова", desc: "Мускулите растат при почивка, не при тренировка. Спи 7-9 часа." },
            { icon: Timer, title: "Консистентност > Интензивност", desc: "3 тренировки/седмица за 6 месеца > 6 тренировки за 2 седмици." },
            { icon: TrendingUp, title: "Техника първо", desc: "Научете правилната форма преди да увеличите теглото." },
            { icon: Zap, title: "Хидратация", desc: "Пийте 500 мл вода 2 часа преди тренировка и по 200 мл на всеки 20 мин." },
          ].map((tip, i) => (
            <Reveal key={tip.title}>
              <Card className="border-border/50 bg-card hover:border-primary/30 transition-colors">
                <CardContent className="p-5">
                  <tip.icon className="w-8 h-8 text-primary mb-3" />
                  <h3 className="font-semibold text-foreground mb-1">{tip.title}</h3>
                  <p className="text-sm text-muted-foreground">{tip.desc}</p>
                </CardContent>
              </Card>
            </Reveal>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Exercises;

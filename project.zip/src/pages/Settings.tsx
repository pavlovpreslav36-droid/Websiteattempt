import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { AIChatBot } from "@/components/AIChatBot";
import Footer from "@/components/Footer";
import { Reveal } from "@/components/Reveal";
import { Settings as SettingsIcon } from "lucide-react";

const Settings = () => {
  const { language, setLanguage, t } = useLanguage();
  const { mode, setMode } = useTheme();
  const [showAIChat, setShowAIChat] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero with image */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] min-h-[30vh] md:min-h-[38vh] flex items-end justify-center overflow-hidden pt-12 pb-8 md:pb-10">
        <div className="absolute inset-0 z-0">
          <img src="/images/settings-hero.jpg" alt="Настройки" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10" />
        </div>
        <div className="relative z-10 text-center px-6">
          <Reveal>
            <div className="flex items-center justify-center gap-3 mb-3">
              <SettingsIcon className="w-10 h-10 text-white" />
              <h1 className="text-4xl md:text-6xl font-display font-bold text-white">
                {t.settings.title}
              </h1>
            </div>
          </Reveal>
        </div>
      </section>

      <div className="px-6 pb-8">
        <div className="max-w-4xl mx-auto">
          <div className="space-y-6 mt-4">
            <Reveal delay={0.1}>
              <Card className="p-6 glass-card">
                <h2 className="text-2xl font-semibold mb-4 text-primary">{t.settings.languageSection}</h2>
                <Select value={language} onValueChange={(value) => setLanguage(value as 'bg' | 'en')}>
                  <SelectTrigger className="w-full"><SelectValue placeholder={t.settings.selectLanguage} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bg">Български (Bulgarian)</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                  </SelectContent>
                </Select>
              </Card>
            </Reveal>

            <Reveal delay={0.2}>
              <Card className="p-6 glass-card">
                <h2 className="text-2xl font-semibold mb-4 text-primary">{t.settings.themeSection}</h2>
                <Select value={mode} onValueChange={(value) => setMode(value as 'dark' | 'light' | 'custom')}>
                  <SelectTrigger className="w-full"><SelectValue placeholder={t.settings.selectTheme} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dark">{t.settings.darkTheme}</SelectItem>
                    <SelectItem value="light">{t.settings.lightTheme}</SelectItem>
                    <SelectItem value="custom">{t.settings.customTheme}</SelectItem>
                  </SelectContent>
                </Select>
              </Card>
            </Reveal>

            <Reveal delay={0.3}>
              <Card className="p-6 glass-card">
                <h2 className="text-2xl font-semibold mb-4 text-primary">{t.settings.aiHelperSection}</h2>
                <p className="text-muted-foreground mb-4">
                  {language === 'bg' ? 'Използвайте AI помощника, за да генерирате персонализирана тема или да получите помощ с настройките.' : 'Use the AI helper to generate a custom theme or get help with settings.'}
                </p>
                <Button onClick={() => setShowAIChat(true)} className="w-full rounded-xl">{t.settings.openAIHelper}</Button>
              </Card>
            </Reveal>
          </div>
        </div>
      </div>

      {showAIChat && <AIChatBot onClose={() => setShowAIChat(false)} />}
      <Footer />
    </div>
  );
};

export default Settings;

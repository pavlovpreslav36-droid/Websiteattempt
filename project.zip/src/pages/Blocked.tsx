import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const Blocked = () => {
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    // Play sad trombone sound
    if (audioRef.current) {
      audioRef.current.play().catch(console.error);
    }
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-destructive/20 via-background to-destructive/10 p-4">
      <Card className="w-full max-w-2xl border-destructive shadow-2xl">
        <CardHeader className="text-center">
          <CardTitle className="text-4xl font-bold text-destructive mb-4">
            🚫 ДОСТЪПЪТ ОТКАЗАН 🚫
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <div className="text-6xl animate-bounce">
            😿
          </div>
          <p className="text-2xl font-bold">
            Трябва да се постараеш повече за да хакнеш уебсайта, малко братленце. 😿
          </p>
          <p className="text-muted-foreground">
            Твоят IP адрес е перманентно блокиран за подозрителна активност.
          </p>
          <div className="text-sm text-muted-foreground space-y-1">
            <p>• Всички опити за достъп са записани</p>
            <p>• Твоят IP е добавен в постоянната черна листа</p>
            <p>• Системният администратор е уведомен</p>
          </div>
          <audio ref={audioRef} src="https://www.myinstants.com/media/sounds/sad-trombone.mp3" />
        </CardContent>
      </Card>
    </div>
  );
};

export default Blocked;

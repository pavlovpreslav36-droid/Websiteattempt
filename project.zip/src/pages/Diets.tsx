import { useState } from "react";
import { Link } from "react-router-dom";
import { Droplets, Leaf } from "lucide-react";
import Footer from "@/components/Footer";
import { PageBanner, SectionTitle } from "@/components/food/PageBanner";
import { RecipeCard } from "@/components/food/RecipeCard";
import { RecipeDialog } from "@/components/food/RecipeDialog";
import { Reveal } from "@/components/Reveal";
import { dietRecipes, type DietRecipe } from "@/data/dietRecipes";
import { drinks } from "@/data/drinks";
import { diets } from "@/data/diets";

const Diets = () => {
  const [open, setOpen] = useState<DietRecipe | null>(null);
  const quick = dietRecipes.filter((r) => r.tags.includes("quick") && r.meal !== "Гарнитура").slice(0, 8);

  return (
    <div className="min-h-screen bg-background">
      <PageBanner
        eyebrow="Рецепти по режим"
        title="Диети и режими"
        text={`${dietRecipes.length} рецепти за различни нужди: без глутен, без лактоза, веган, много протеин и още. Всяка има съставки, стъпки и хранителни стойности.`}
      >
        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/drinks" className="btn-sheen inline-flex items-center gap-2 h-12 px-6 rounded-full bg-cream text-wine font-semibold">
            <Droplets className="w-4 h-4" aria-hidden="true" /> {drinks.length} напитки
          </Link>
          <Link to="/quit-kitchen" className="inline-flex items-center gap-2 h-12 px-6 rounded-full border border-cream/50 text-cream font-semibold hover:bg-cream hover:text-wine transition-colors">
            <Leaf className="w-4 h-4" aria-hidden="true" /> Кухня за отказване
          </Link>
        </div>
      </PageBanner>

      <section className="container py-14 md:py-20">
        <SectionTitle text="Избери режим, а вътре можеш да комбинираш: например без глутен и без лактоза едновременно.">Избери режим</SectionTitle>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-5">
          {diets.map((d, i) => {
            const count = d.slug === "healthy" ? dietRecipes.length : dietRecipes.filter((r) => r.tags.includes(d.slug)).length;
            return (
              <Reveal key={d.slug} delay={(i % 4) * 0.05}>
                <Link
                  to={`/diets/${d.slug}`}
                  className="group block h-full rounded-[2rem] bg-card border border-border p-3 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-lg"
                >
                  <div className="relative arch aspect-[5/4] bg-muted">
                    <img src={d.image} alt="" loading="lazy" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                    <span className="absolute left-3 bottom-3 grid place-items-center w-11 h-11 rounded-full bg-card text-xl ring-2 ring-card shadow-md" aria-hidden="true">{d.emoji}</span>
                  </div>
                  <div className="px-2 pt-4 pb-2">
                    <p className="eyebrow text-primary">{count} рецепти</p>
                    <h3 className="mt-1 font-brand text-xl leading-snug text-foreground">{d.title}</h3>
                    <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{d.short}</p>
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </div>
      </section>

      <section className="container pb-14 md:pb-20">
        <SectionTitle text="Готови за 15 минути или по-малко.">Бързи рецепти</SectionTitle>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-5">
          {quick.map((r) => (
            <RecipeCard key={r.id} recipe={r} onOpen={setOpen} />
          ))}
        </div>
        <Link to="/diets/quick" className="mt-8 inline-block eyebrow border border-primary/60 text-primary rounded-full px-5 py-3 hover:bg-primary hover:text-primary-foreground transition-colors">
          Всички бързи рецепти
        </Link>
      </section>

      <section className="px-3 md:px-6 pb-16 md:pb-24">
        <div className="grid md:grid-cols-2 gap-4">
          <Link to="/drinks" className="group block rounded-[2rem] bg-wine text-cream p-8 md:p-10 transition-transform hover:-translate-y-1">
            <p className="eyebrow text-flame">{drinks.length} напитки</p>
            <h3 className="display mt-3 text-[clamp(1.8rem,4vw,3rem)]">Вода, чай и смутита</h3>
            <p className="mt-3 text-cream/80 max-w-sm">Овкусени води, билкови чайове, смутита и топли напитки, плюс брояч за водата.</p>
          </Link>
          <Link to="/quit-kitchen" className="group block rounded-[2rem] bg-flame text-wine p-8 md:p-10 transition-transform hover:-translate-y-1">
            <p className="eyebrow">Седем дни</p>
            <h3 className="display mt-3 text-[clamp(1.8rem,4vw,3rem)]">Кухня за отказване</h3>
            <p className="mt-3 max-w-sm font-medium">План за седмицата с рецепти и напитки, които подкрепят деня без цигара.</p>
          </Link>
        </div>
      </section>

      <RecipeDialog recipe={open} onClose={() => setOpen(null)} />
      <Footer />
    </div>
  );
};

export default Diets;

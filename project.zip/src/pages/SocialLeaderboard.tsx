import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Footer from "@/components/Footer";
import { Reveal } from "@/components/Reveal";
import { toast } from "@/hooks/use-toast";
import {
  Users, Trophy, Swords, Crown, Medal, UserPlus, Loader2, Footprints, Droplets, Flame, Target, ChevronRight
} from "lucide-react";

interface LeaderboardEntry {
  user_id: string;
  username: string;
  score: number;
  total_questions: number;
  best_streak: number;
}

interface Challenge {
  id: string;
  challenge_type: string;
  target_value: number;
  creator_progress: number;
  challenger_progress: number;
  status: string;
  created_at: string;
  ends_at: string;
}

const CHALLENGE_TYPES = [
  { id: "steps", labelBg: "Стъпки", labelEn: "Steps", icon: Footprints, target: 50000, color: "text-green-400" },
  { id: "water", labelBg: "Вода", labelEn: "Water", icon: Droplets, target: 56, color: "text-blue-400" },
  { id: "calories", labelBg: "Калории", labelEn: "Calories", icon: Flame, target: 14000, color: "text-orange-400" },
];

const SocialLeaderboard = () => {
  const { language } = useLanguage();
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const isBg = language === "bg";

  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loadingData, setLoadingData] = useState(true);
  const [activeTab, setActiveTab] = useState<"leaderboard" | "challenges">("leaderboard");
  const [friendEmail, setFriendEmail] = useState("");
  const [addingFriend, setAddingFriend] = useState(false);

  useEffect(() => {
    if (!loading && !user) navigate("/auth");
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) {
      fetchLeaderboard();
      fetchChallenges();
    }
  }, [user]);

  const fetchLeaderboard = async () => {
    const { data } = await supabase
      .from("quiz_scores")
      .select("user_id, username, score, total_questions, best_streak")
      .order("score", { ascending: false })
      .limit(50);
    if (data) setLeaderboard(data);
    setLoadingData(false);
  };

  const fetchChallenges = async () => {
    const { data } = await supabase
      .from("health_challenges")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(20);
    if (data) setChallenges(data as Challenge[]);
  };

  const createChallenge = async (type: typeof CHALLENGE_TYPES[0]) => {
    if (!user) return;
    const { error } = await supabase.from("health_challenges").insert({
      creator_id: user.id,
      challenge_type: type.id,
      target_value: type.target,
    });
    if (error) {
      toast({ title: isBg ? "Грешка" : "Error", variant: "destructive" });
    } else {
      toast({ title: isBg ? "Предизвикателство създадено!" : "Challenge created!" });
      fetchChallenges();
    }
  };

  const sendFriendRequest = async () => {
    if (!friendEmail.trim() || !user) return;
    setAddingFriend(true);
    // Find user by email
    const { data: profile } = await supabase
      .from("profiles")
      .select("id")
      .eq("email", friendEmail.trim())
      .maybeSingle();

    if (!profile) {
      toast({ title: isBg ? "Потребителят не е намерен" : "User not found", variant: "destructive" });
    } else if (profile.id === user.id) {
      toast({ title: isBg ? "Не можете да добавите себе си" : "Can't add yourself", variant: "destructive" });
    } else {
      const { error } = await supabase.from("friendships").insert({
        user_id: user.id,
        friend_id: profile.id,
      });
      if (error?.code === "23505") {
        toast({ title: isBg ? "Вече сте приятели" : "Already friends" });
      } else if (error) {
        toast({ title: isBg ? "Грешка" : "Error", variant: "destructive" });
      } else {
        toast({ title: isBg ? "Заявка изпратена!" : "Request sent!" });
        setFriendEmail("");
      }
    }
    setAddingFriend(false);
  };

  const getRankIcon = (i: number) => {
    if (i === 0) return <Crown className="w-5 h-5 text-yellow-400" />;
    if (i === 1) return <Medal className="w-5 h-5 text-gray-400" />;
    if (i === 2) return <Medal className="w-5 h-5 text-amber-600" />;
    return <span className="w-5 text-center text-sm text-muted-foreground font-mono">{i + 1}</span>;
  };

  if (loading || !user) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] min-h-[30vh] md:min-h-[38vh] flex items-end justify-center overflow-hidden pt-12 pb-8 md:pb-10">
        <div className="absolute inset-0 z-0">
          <img src="/images/social-leaderboard-hero.jpg" alt="Leaderboard" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10" />
        </div>
        <div className="relative z-10 text-center px-4">
          <Reveal><Trophy className="w-10 h-10 md:w-12 md:h-12 mx-auto mb-3 text-white" /></Reveal>
          <Reveal delay={0.1}>
            <h1 className="text-3xl md:text-6xl font-display font-bold text-white mb-2">
              {isBg ? "Класация & Приятели" : "Leaderboard & Friends"}
            </h1>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="text-base md:text-lg text-white/85 max-w-md mx-auto">
              {isBg ? "Състезавайте се с приятели за по-здравословен живот" : "Compete with friends for a healthier life"}
            </p>
          </Reveal>
        </div>
      </section>

      <div className="px-4 md:px-6 pb-12 max-w-4xl mx-auto space-y-6">
        {/* Tabs */}
        <Reveal>
          <div className="flex gap-2 p-1 bg-muted/30 rounded-xl">
            {(["leaderboard", "challenges"] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${
                  activeTab === tab ? "bg-primary text-primary-foreground shadow-md" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab === "leaderboard" ? (isBg ? "🏆 Класация" : "🏆 Leaderboard") : (isBg ? "⚔️ Предизвикателства" : "⚔️ Challenges")}
              </button>
            ))}
          </div>
        </Reveal>

        <AnimatePresence mode="wait">
          {activeTab === "leaderboard" ? (
            <motion.div key="lb" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="space-y-4">
              {/* Add friend */}
              <Reveal>
                <Card className="p-4 glass-card">
                  <div className="flex items-center gap-2">
                    <UserPlus className="w-5 h-5 text-primary flex-shrink-0" />
                    <Input
                      placeholder={isBg ? "Имейл на приятел..." : "Friend's email..."}
                      value={friendEmail}
                      onChange={e => setFriendEmail(e.target.value)}
                      className="flex-1"
                    />
                    <Button onClick={sendFriendRequest} disabled={addingFriend} size="sm" className="rounded-full">
                      {addingFriend ? <Loader2 className="w-4 h-4 animate-spin" /> : <ChevronRight className="w-4 h-4" />}
                    </Button>
                  </div>
                </Card>
              </Reveal>

              {/* Leaderboard */}
              {loadingData ? (
                <div className="text-center py-12"><Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" /></div>
              ) : (
                <div className="space-y-2">
                  {leaderboard.map((entry, i) => (
                    <Reveal key={`${entry.user_id}-${i}`} delay={i * 0.03}>
                      <motion.div
                        whileHover={{ scale: 1.02, x: 4 }}
                        transition={{ type: "spring", stiffness: 400 }}
                      >
                        <Card className={`p-3 md:p-4 border-border/50 ${
                          entry.user_id === user?.id ? "bg-primary/10 border-primary/30" : "glass-card"
                        } ${i < 3 ? "border-l-2 border-l-yellow-400/50" : ""}`}>
                          <div className="flex items-center gap-3">
                            <div className="w-8 flex justify-center">{getRankIcon(i)}</div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-foreground text-sm truncate">
                                {entry.username || (isBg ? "Анонимен" : "Anonymous")}
                                {entry.user_id === user?.id && <span className="text-xs text-primary ml-1">({isBg ? "вие" : "you"})</span>}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {isBg ? "Серия" : "Streak"}: {entry.best_streak} · {entry.score}/{entry.total_questions}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="text-lg font-bold text-foreground">{entry.score}</p>
                              <p className="text-xs text-muted-foreground">{isBg ? "точки" : "pts"}</p>
                            </div>
                          </div>
                        </Card>
                      </motion.div>
                    </Reveal>
                  ))}
                  {leaderboard.length === 0 && (
                    <Card className="p-8 glass-card text-center">
                      <Trophy className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                      <p className="text-muted-foreground">{isBg ? "Все още няма резултати" : "No scores yet"}</p>
                    </Card>
                  )}
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div key="ch" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
              {/* Create challenge */}
              <Reveal>
                <h3 className="text-lg font-semibold text-foreground mb-3">{isBg ? "Ново предизвикателство" : "New Challenge"}</h3>
                <div className="grid grid-cols-3 gap-3">
                  {CHALLENGE_TYPES.map((type, i) => (
                    <motion.button
                      key={type.id}
                      whileHover={{ scale: 1.05, y: -4 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => createChallenge(type)}
                      className="p-4 rounded-2xl border border-border/50 bg-card hover:border-primary/30 transition-all text-center"
                    >
                      <type.icon className={`w-8 h-8 mx-auto mb-2 ${type.color}`} />
                      <p className="text-sm font-medium text-foreground">{isBg ? type.labelBg : type.labelEn}</p>
                      <p className="text-xs text-muted-foreground mt-1">{type.target.toLocaleString()} / {isBg ? "седмица" : "week"}</p>
                    </motion.button>
                  ))}
                </div>
              </Reveal>

              {/* Active challenges */}
              <Reveal delay={0.1}>
                <h3 className="text-lg font-semibold text-foreground mb-3 mt-6">{isBg ? "Активни" : "Active"}</h3>
              </Reveal>
              {challenges.length === 0 ? (
                <Reveal delay={0.15}>
                  <Card className="p-8 glass-card text-center">
                    <Swords className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground">{isBg ? "Няма активни предизвикателства" : "No active challenges"}</p>
                  </Card>
                </Reveal>
              ) : (
                <div className="space-y-3">
                  {challenges.map((ch, i) => {
                    const type = CHALLENGE_TYPES.find(t => t.id === ch.challenge_type);
                    const progress = Math.round((ch.creator_progress / ch.target_value) * 100);
                    return (
                      <Reveal key={ch.id} delay={i * 0.05}>
                        <motion.div whileHover={{ scale: 1.01 }}>
                          <Card className="p-4 glass-card">
                            <div className="flex items-center gap-3 mb-2">
                              {type && <type.icon className={`w-5 h-5 ${type.color}`} />}
                              <p className="font-semibold text-foreground text-sm">{type ? (isBg ? type.labelBg : type.labelEn) : ch.challenge_type}</p>
                              <span className="ml-auto text-xs text-muted-foreground">
                                {new Date(ch.ends_at).toLocaleDateString(isBg ? "bg" : "en", { month: "short", day: "numeric" })}
                              </span>
                            </div>
                            <div className="w-full bg-muted/30 rounded-full h-2">
                              <motion.div
                                className="h-2 rounded-full bg-primary"
                                initial={{ width: 0 }}
                                animate={{ width: `${Math.min(progress, 100)}%` }}
                                transition={{ duration: 1, ease: "easeOut" }}
                              />
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              {ch.creator_progress.toLocaleString()} / {ch.target_value.toLocaleString()} ({progress}%)
                            </p>
                          </Card>
                        </motion.div>
                      </Reveal>
                    );
                  })}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <Footer />
    </div>
  );
};

export default SocialLeaderboard;

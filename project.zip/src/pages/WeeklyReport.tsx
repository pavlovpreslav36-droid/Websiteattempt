import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Footer from "@/components/Footer";
import { Reveal } from "@/components/Reveal";
import {
  BarChart3, TrendingUp, Droplets, Footprints, Apple, Sparkles, Loader2, Calendar, Award, Heart
} from "lucide-react";

interface DailyLog {
  water: number;
  steps: number;
  meals: { name: string; calories: number; protein: number }[];
}

const WeeklyReport = () => {
  const { language } = useLanguage();
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const isBg = language === "bg";

  const [report, setReport] = useState<string | null>(null);
  const [healthScore, setHealthScore] = useState(0);
  const [generating, setGenerating] = useState(false);
  const [weekData, setWeekData] = useState<Record<string, DailyLog>>({});

  useEffect(() => {
    if (!loading && !user) navigate("/auth");
  }, [user, loading, navigate]);

  // Load week data from localStorage
  useEffect(() => {
    const data: Record<string, DailyLog> = {};
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const key = d.toISOString().split("T")[0];
      const saved = localStorage.getItem(`health-log-${key}`);
      if (saved) {
        try { data[key] = JSON.parse(saved); } catch {}
      }
    }
    setWeekData(data);
  }, []);

  const totalWater = Object.values(weekData).reduce((s, d) => s + (d.water || 0), 0);
  const totalSteps = Object.values(weekData).reduce((s, d) => s + (d.steps || 0), 0);
  const totalCalories = Object.values(weekData).reduce((s, d) =>
    s + (d.meals?.reduce((ms, m) => ms + (m.calories || 0), 0) || 0), 0);
  const totalProtein = Object.values(weekData).reduce((s, d) =>
    s + (d.meals?.reduce((ms, m) => ms + (m.protein || 0), 0) || 0), 0);
  const daysTracked = Object.keys(weekData).length;

  const generateReport = async () => {
    setGenerating(true);
    try {
      const prompt = isBg
        ? `Анализирай тези здравни данни за последните 7 дни и дай подробен седмичен доклад на български:
- Дни с данни: ${daysTracked}/7
- Обща вода: ${totalWater} чаши
- Общо стъпки: ${totalSteps}
- Общо калории: ${totalCalories}
- Общ протеин: ${totalProtein}g
Дай оценка от 1-100 за здравословния начин на живот. Формат: първи ред "SCORE:XX" после анализ с препоръки.`
        : `Analyze this health data for the past 7 days and give a detailed weekly report:
- Days tracked: ${daysTracked}/7
- Total water: ${totalWater} glasses
- Total steps: ${totalSteps}
- Total calories: ${totalCalories}
- Total protein: ${totalProtein}g
Give a score 1-100 for health lifestyle. Format: first line "SCORE:XX" then analysis with recommendations.`;

      const { data, error } = await supabase.functions.invoke("ai-chat", {
        body: { messages: [{ role: "user", content: prompt }], language },
      });

      if (error) throw error;

      const text = data.message || "";
      const scoreMatch = text.match(/SCORE:(\d+)/);
      if (scoreMatch) setHealthScore(parseInt(scoreMatch[1]));
      setReport(text.replace(/SCORE:\d+\n?/, "").trim());
    } catch (err) {
      console.error(err);
      setReport(isBg ? "Грешка при генериране. Опитайте отново." : "Error generating report. Try again.");
    }
    setGenerating(false);
  };

  const statCards = [
    { icon: Droplets, label: isBg ? "Вода" : "Water", value: `${totalWater}`, unit: isBg ? "чаши" : "glasses", color: "text-blue-400", bg: "from-blue-500/10 to-cyan-500/10" },
    { icon: Footprints, label: isBg ? "Стъпки" : "Steps", value: totalSteps.toLocaleString(), unit: "", color: "text-green-400", bg: "from-green-500/10 to-emerald-500/10" },
    { icon: Apple, label: isBg ? "Калории" : "Calories", value: totalCalories.toLocaleString(), unit: "kcal", color: "text-orange-400", bg: "from-orange-500/10 to-amber-500/10" },
    { icon: Heart, label: isBg ? "Протеин" : "Protein", value: `${totalProtein}`, unit: "g", color: "text-pink-400", bg: "from-pink-500/10 to-rose-500/10" },
  ];

  if (loading || !user) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] min-h-[30vh] md:min-h-[38vh] flex items-end justify-center overflow-hidden pt-12 pb-8 md:pb-10">
        <div className="absolute inset-0 z-0">
          <img src="/images/weekly-report-hero.jpg" alt="Report" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10" />
        </div>
        <div className="relative z-10 text-center px-4">
          <Reveal><BarChart3 className="w-10 h-10 md:w-12 md:h-12 mx-auto mb-3 text-white" /></Reveal>
          <Reveal delay={0.1}>
            <h1 className="text-3xl md:text-6xl font-display font-bold text-white mb-2">
              {isBg ? "Седмичен доклад" : "Weekly Report"}
            </h1>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="text-base md:text-lg text-white/85 max-w-md mx-auto">
              {isBg ? "AI анализ на вашия здравословен напредък" : "AI analysis of your health progress"}
            </p>
          </Reveal>
        </div>
      </section>

      <div className="px-4 md:px-6 pb-12 max-w-5xl mx-auto space-y-8">
        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {statCards.map((s, i) => (
            <Reveal key={s.label} delay={i * 0.05}>
              <motion.div whileHover={{ scale: 1.04, y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
                <Card className={`p-4 md:p-5 bg-gradient-to-br ${s.bg} border-border/50 backdrop-blur-sm`}>
                  <s.icon className={`w-6 h-6 ${s.color} mb-2`} />
                  <p className="text-2xl md:text-3xl font-bold text-foreground">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label} {s.unit && `(${s.unit})`}</p>
                </Card>
              </motion.div>
            </Reveal>
          ))}
        </div>

        {/* Days tracked */}
        <Reveal delay={0.2}>
          <Card className="p-5 glass-card">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-foreground">{isBg ? "Проследени дни" : "Days Tracked"}</h3>
              </div>
              <span className="text-sm text-muted-foreground">{daysTracked}/7</span>
            </div>
            <div className="flex gap-1.5">
              {Array.from({ length: 7 }).map((_, i) => {
                const d = new Date(); d.setDate(d.getDate() - (6 - i));
                const key = d.toISOString().split("T")[0];
                const hasData = !!weekData[key];
                return (
                  <motion.div
                    key={i}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: i * 0.05, type: "spring" }}
                    className={`flex-1 h-10 rounded-lg flex items-center justify-center text-xs font-medium transition-colors ${
                      hasData ? "bg-primary/20 text-primary border border-primary/30" : "bg-muted/30 text-muted-foreground border border-border/30"
                    }`}
                  >
                    {d.toLocaleDateString(isBg ? "bg" : "en", { weekday: "short" })}
                  </motion.div>
                );
              })}
            </div>
          </Card>
        </Reveal>

        {/* Generate button */}
        <Reveal delay={0.25}>
          <div className="text-center">
            <Button
              onClick={generateReport}
              disabled={generating}
              size="lg"
              className="rounded-full h-14 px-10 text-base shadow-lg hover:shadow-xl transition-all"
            >
              {generating ? (
                <><Loader2 className="w-5 h-5 mr-2 animate-spin" />{isBg ? "Генериране..." : "Generating..."}</>
              ) : (
                <><Sparkles className="w-5 h-5 mr-2" />{isBg ? "Генерирай AI доклад" : "Generate AI Report"}</>
              )}
            </Button>
          </div>
        </Reveal>

        {/* Report */}
        <AnimatePresence>
          {report && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="p-6 md:p-8 glass-card">
                {healthScore > 0 && (
                  <div className="flex items-center justify-center mb-6">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", delay: 0.2 }}
                      className="relative w-28 h-28"
                    >
                      <svg className="w-full h-full -rotate-90">
                        <circle cx="56" cy="56" r="48" fill="none" stroke="hsl(var(--muted) / 0.3)" strokeWidth="6" />
                        <motion.circle
                          cx="56" cy="56" r="48" fill="none"
                          stroke={healthScore >= 70 ? "hsl(var(--primary))" : healthScore >= 40 ? "hsl(40,90%,50%)" : "hsl(0,70%,50%)"}
                          strokeWidth="6" strokeLinecap="round"
                          strokeDasharray={2 * Math.PI * 48}
                          initial={{ strokeDashoffset: 2 * Math.PI * 48 }}
                          animate={{ strokeDashoffset: 2 * Math.PI * 48 * (1 - healthScore / 100) }}
                          transition={{ duration: 1.5, ease: "easeOut" }}
                        />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-2xl font-bold text-foreground">{healthScore}</span>
                        <span className="text-xs text-muted-foreground">/100</span>
                      </div>
                    </motion.div>
                  </div>
                )}
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <h3 className="text-lg font-semibold text-foreground">{isBg ? "AI анализ" : "AI Analysis"}</h3>
                </div>
                <div className="prose prose-sm max-w-none text-muted-foreground whitespace-pre-wrap">
                  {report}
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <Footer />
    </div>
  );
};

export default WeeklyReport;

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Droplets, Footprints, Utensils, Plus, Target, TrendingUp, Calendar, Flame, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUserProfile } from "@/contexts/UserProfileContext";
import { UsernameSetup } from "@/components/UsernameSetup";
import Footer from "@/components/Footer";
import { Reveal } from "@/components/Reveal";

interface DailyLog {
  date: string;
  water: number;
  steps: number;
  meals: Meal[];
}

interface Meal {
  id: string;
  name: string;
  calories: number;
  protein: number;
  time: string;
}

const WATER_GOAL = 8;
const STEPS_GOAL = 10000;
const CALORIES_GOAL = 2000;
const PROTEIN_GOAL = 100;

const encouragingMessages = [
  "Всяка стъпка те приближава към целта!",
  "Ти можеш! Продължавай напред!",
  "Страхотен напредък, не спирай!",
  "Здравето е в твоите ръце!",
  "Малките усилия водят до големи резултати!",
  "Ти си по-силен, отколкото си мислиш!",
  "Всеки ден е нова възможност!",
  "Фокусирай се на напредъка, не на перфектността!"
];

const HealthDashboard = () => {
  const { toast } = useToast();
  const { profile, isProfileSet } = useUserProfile();
  const [showUsernameSetup, setShowUsernameSetup] = useState(false);
  const today = new Date().toISOString().split('T')[0];
  
  const [dailyLog, setDailyLog] = useState<DailyLog>(() => {
    const saved = localStorage.getItem(`health-log-${today}`);
    return saved ? JSON.parse(saved) : { date: today, water: 0, steps: 0, meals: [] };
  });

  const [newMeal, setNewMeal] = useState({ name: "", calories: "", protein: "" });
  const [mealDialogOpen, setMealDialogOpen] = useState(false);
  const [celebrateGoal, setCelebrateGoal] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem(`health-log-${today}`, JSON.stringify(dailyLog));
  }, [dailyLog, today]);

  useEffect(() => {
    const waterProgress = (dailyLog.water / WATER_GOAL) * 100;
    const stepsProgress = (dailyLog.steps / STEPS_GOAL) * 100;
    
    if (waterProgress >= 100 && !localStorage.getItem(`water-goal-${today}`)) {
      localStorage.setItem(`water-goal-${today}`, 'true');
      setCelebrateGoal('water');
      setTimeout(() => setCelebrateGoal(null), 3000);
    }
    
    if (stepsProgress >= 100 && !localStorage.getItem(`steps-goal-${today}`)) {
      localStorage.setItem(`steps-goal-${today}`, 'true');
      setCelebrateGoal('steps');
      setTimeout(() => setCelebrateGoal(null), 3000);
    }
  }, [dailyLog, today]);

  const addWater = () => {
    setDailyLog(prev => ({ ...prev, water: prev.water + 1 }));
    toast({ title: "💧 +1 чаша вода!", description: `Общо: ${dailyLog.water + 1}/${WATER_GOAL} чаши` });
  };

  const updateSteps = (steps: number) => {
    setDailyLog(prev => ({ ...prev, steps }));
  };

  const addMeal = () => {
    if (!newMeal.name || !newMeal.calories || !newMeal.protein) {
      toast({ title: "Грешка", description: "Моля, попълнете всички полета", variant: "destructive" });
      return;
    }
    const meal: Meal = {
      id: Date.now().toString(),
      name: newMeal.name,
      calories: parseInt(newMeal.calories),
      protein: parseInt(newMeal.protein),
      time: new Date().toLocaleTimeString('bg-BG', { hour: '2-digit', minute: '2-digit' })
    };
    setDailyLog(prev => ({ ...prev, meals: [...prev.meals, meal] }));
    setNewMeal({ name: "", calories: "", protein: "" });
    setMealDialogOpen(false);
    toast({ title: "🍽️ Ястие добавено!", description: `${meal.name} - ${meal.calories} kcal` });
  };

  const removeMeal = (id: string) => {
    setDailyLog(prev => ({ ...prev, meals: prev.meals.filter(m => m.id !== id) }));
    toast({ title: "Ястието е премахнато" });
  };

  const totalCalories = dailyLog.meals.reduce((sum, m) => sum + m.calories, 0);
  const totalProtein = dailyLog.meals.reduce((sum, m) => sum + m.protein, 0);
  const waterProgress = (dailyLog.water / WATER_GOAL) * 100;
  const stepsProgress = (dailyLog.steps / STEPS_GOAL) * 100;
  const caloriesProgress = (totalCalories / CALORIES_GOAL) * 100;
  const proteinProgress = (totalProtein / PROTEIN_GOAL) * 100;

  const getEncouragingMessage = () => {
    const username = profile?.username;
    const avgProgress = (waterProgress + stepsProgress) / 2;
    if (waterProgress >= 100 && stepsProgress >= 100) {
      return username ? `Браво, ${username}! Достигна всички цели днес! 🎉` : "Браво! Достигнахте всички цели днес! 🎉";
    }
    if (avgProgress >= 75) return username ? `Страхотно, ${username}! Почти си там! 💪` : "Страхотно! Почти сте там! 💪";
    if (avgProgress >= 50) return username ? `Добър напредък, ${username}! Продължавай! 🌟` : "Добър напредък! Продължавайте! 🌟";
    if (avgProgress >= 25) return username ? `${username}, ${encouragingMessages[Math.floor(Math.random() * encouragingMessages.length)]}` : encouragingMessages[Math.floor(Math.random() * encouragingMessages.length)];
    return username ? `Здравей, ${username}! Всяка малка стъпка е важна!` : "Всяка малка стъпка е важна, започнете с чаша вода!";
  };

  const getStepsEncouragement = () => {
    const username = profile?.username;
    const percent = Math.min(stepsProgress, 100);
    if (percent >= 100) return username ? `🎉 ${username}, ти го направи!` : "🎉 Цел постигната!";
    if (percent >= 75) return username ? `🔥 ${username}, само още малко!` : "🔥 Само още малко!";
    if (percent >= 50) return username ? `💪 ${username}, на половината си!` : "💪 На половината сте!";
    if (percent >= 25) return username ? `🚶 ${username}, добро начало!` : "🚶 Добро начало!";
    return username ? `👟 ${username}, време е да се раздвижиш!` : "👟 Време е да се раздвижите!";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Goal Achievement Celebration */}
      <AnimatePresence>
        {celebrateGoal && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm"
          >
            <motion.div
              animate={{ scale: [1, 1.2, 1], rotate: [0, 5, -5, 0] }}
              transition={{ duration: 0.5, repeat: 2 }}
              className="text-center"
            >
              <div className="text-9xl mb-4">{celebrateGoal === 'water' ? '💧' : '👟'}</div>
              <h2 className="text-4xl font-bold gradient-text mb-2">
                {isProfileSet ? `Браво, ${profile?.username}!` : "Браво!"}
              </h2>
              <p className="text-2xl text-muted-foreground">
                {celebrateGoal === 'water' ? 'Цел за вода постигната!' : 'Цел за стъпки постигната!'}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero with image */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] min-h-[30vh] md:min-h-[38vh] flex items-end justify-center overflow-hidden pt-12 pb-8 md:pb-10">
        <div className="absolute inset-0 z-0">
          <img src="/images/health-dashboard-hero.jpg" alt="Здравен дневник" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10" />
        </div>
        <div className="relative z-10 text-center px-6 max-w-3xl mx-auto">
          <Reveal>
            <div className="flex items-center justify-center gap-4 mb-3">
              <Calendar className="w-10 h-10 text-white" />
              <div>
                <h1 className="text-3xl md:text-5xl font-display font-bold text-white">
                  Здравен дневник
                </h1>
                <p className="text-white/85 text-base">
                  {new Date().toLocaleDateString('bg-BG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                </p>
              </div>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            {isProfileSet ? (
              <div className="flex items-center justify-center gap-2 mt-2 bg-primary/10 rounded-full px-4 py-2 w-fit mx-auto">
                <User className="w-5 h-5 text-white" />
                <span className="font-semibold">{profile?.username}</span>
              </div>
            ) : (
              <Button variant="outline" onClick={() => setShowUsernameSetup(true)} className="mt-2">
                <User className="mr-2 w-4 h-4" />
                Създай профил
              </Button>
            )}
          </Reveal>
        </div>
      </section>

      <div className="px-6 pb-8">
        <div className="max-w-6xl mx-auto">
          {/* Stats Overview */}
          <Reveal>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <Card className="p-6 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border-blue-500/30">
                <div className="flex items-center gap-3 mb-3">
                  <Droplets className="w-8 h-8 text-blue-400" />
                  <span className="text-lg font-semibold">Вода</span>
                </div>
                <div className="text-3xl font-bold mb-2">{dailyLog.water}/{WATER_GOAL}</div>
                <div className="relative">
                  <Progress value={Math.min(waterProgress, 100)} className="h-3" />
                  {waterProgress >= 100 && <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute -right-1 -top-1 text-lg">✅</motion.span>}
                </div>
                <p className="text-sm text-muted-foreground mt-2">{Math.round(waterProgress)}% от целта</p>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-green-500/20 to-emerald-500/20 border-green-500/30">
                <div className="flex items-center gap-3 mb-3">
                  <Footprints className="w-8 h-8 text-green-400" />
                  <span className="text-lg font-semibold">Стъпки</span>
                </div>
                <div className="text-3xl font-bold mb-2">{dailyLog.steps.toLocaleString()}</div>
                <div className="relative">
                  <Progress value={Math.min(stepsProgress, 100)} className="h-3" />
                  {stepsProgress >= 100 && <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute -right-1 -top-1 text-lg">✅</motion.span>}
                </div>
                <p className="text-sm text-muted-foreground mt-2">{Math.round(Math.min(stepsProgress, 100))}% от целта</p>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-orange-500/20 to-amber-500/20 border-orange-500/30">
                <div className="flex items-center gap-3 mb-3">
                  <Flame className="w-8 h-8 text-orange-400" />
                  <span className="text-lg font-semibold">Калории</span>
                </div>
                <div className="text-3xl font-bold mb-2">{totalCalories}</div>
                <Progress value={Math.min(caloriesProgress, 100)} className="h-3" />
                <p className="text-sm text-muted-foreground mt-2">/ {CALORIES_GOAL} kcal</p>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-purple-500/30">
                <div className="flex items-center gap-3 mb-3">
                  <Target className="w-8 h-8 text-purple-400" />
                  <span className="text-lg font-semibold">Протеин</span>
                </div>
                <div className="text-3xl font-bold mb-2">{totalProtein}g</div>
                <Progress value={Math.min(proteinProgress, 100)} className="h-3" />
                <p className="text-sm text-muted-foreground mt-2">/ {PROTEIN_GOAL}g</p>
              </Card>
            </div>
          </Reveal>

          <Tabs defaultValue="water" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="water">💧 Вода</TabsTrigger>
              <TabsTrigger value="steps">👟 Стъпки</TabsTrigger>
              <TabsTrigger value="meals">🍽️ Ястия</TabsTrigger>
            </TabsList>

            <TabsContent value="water">
              <Reveal>
                <Card className="p-8">
                  <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                    <Droplets className="text-blue-400" />
                    Прием на вода
                  </h2>
                  <div className="flex flex-wrap gap-3 mb-6">
                    {Array.from({ length: WATER_GOAL }).map((_, i) => (
                      <motion.div
                        key={i}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: i * 0.05 }}
                        className={`w-16 h-20 rounded-lg flex items-center justify-center text-3xl transition-all ${
                          i < dailyLog.water 
                            ? 'bg-blue-500/30 border-2 border-blue-400' 
                            : 'bg-muted/30 border-2 border-muted'
                        }`}
                      >
                        {i < dailyLog.water ? '💧' : '○'}
                      </motion.div>
                    ))}
                  </div>
                  <div className="flex gap-4">
                    <Button onClick={addWater} size="lg" className="flex-1">
                      <Plus className="mr-2" /> Добави чаша вода
                    </Button>
                    <Button 
                      variant="outline" 
                      size="lg"
                      onClick={() => setDailyLog(prev => ({ ...prev, water: Math.max(0, prev.water - 1) }))}
                    >
                      -1
                    </Button>
                  </div>
                </Card>
              </Reveal>
            </TabsContent>

            <TabsContent value="steps">
              <Reveal>
                <Card className="p-8">
                  <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                    <Footprints className="text-green-400" />
                    Стъпки днес
                  </h2>
                  <div className="space-y-6">
                    <div className="text-center">
                      <motion.div 
                        className="text-6xl font-bold mb-2"
                        key={dailyLog.steps}
                        initial={{ scale: 1.2 }}
                        animate={{ scale: 1 }}
                      >
                        {dailyLog.steps.toLocaleString()}
                      </motion.div>
                      <p className="text-muted-foreground">от {STEPS_GOAL.toLocaleString()} цел</p>
                      <motion.p 
                        className="text-xl font-semibold text-primary mt-2"
                        key={stepsProgress}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                      >
                        {getStepsEncouragement()}
                      </motion.p>
                    </div>
                    
                    <div className="relative w-48 h-48 mx-auto">
                      <svg className="w-full h-full transform -rotate-90">
                        <circle cx="96" cy="96" r="88" stroke="currentColor" strokeWidth="12" fill="none" className="text-muted/30" />
                        <motion.circle
                          cx="96" cy="96" r="88"
                          stroke="currentColor" strokeWidth="12" fill="none"
                          className="text-green-500" strokeLinecap="round"
                          initial={{ pathLength: 0 }}
                          animate={{ pathLength: Math.min(stepsProgress / 100, 1) }}
                          transition={{ duration: 1, ease: "easeOut" }}
                          style={{ strokeDasharray: "553", strokeDashoffset: "0" }}
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-3xl font-bold">{Math.round(Math.min(stepsProgress, 100))}%</span>
                      </div>
                    </div>

                    <div>
                      <Label className="text-lg mb-2 block">Въведете стъпки:</Label>
                      <div className="flex gap-3">
                        <Input
                          type="number"
                          placeholder="Напр: 5000"
                          value={dailyLog.steps || ""}
                          onChange={(e) => updateSteps(parseInt(e.target.value) || 0)}
                          className="flex-1"
                        />
                        <div className="flex gap-2">
                          {[1000, 2000, 5000].map(val => (
                            <Button
                              key={val}
                              variant="outline"
                              size="sm"
                              onClick={() => updateSteps(dailyLog.steps + val)}
                            >
                              +{val / 1000}к
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              </Reveal>
            </TabsContent>

            <TabsContent value="meals">
              <Reveal>
                <Card className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold flex items-center gap-2">
                      <Utensils className="text-orange-400" />
                      Ястия днес
                    </h2>
                    <Dialog open={mealDialogOpen} onOpenChange={setMealDialogOpen}>
                      <DialogTrigger asChild>
                        <Button><Plus className="mr-2" /> Добави ястие</Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Добави ястие</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label>Име на ястието</Label>
                            <Input placeholder="Напр: Овесена каша" value={newMeal.name} onChange={(e) => setNewMeal(prev => ({ ...prev, name: e.target.value }))} />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Калории (kcal)</Label>
                              <Input type="number" placeholder="350" value={newMeal.calories} onChange={(e) => setNewMeal(prev => ({ ...prev, calories: e.target.value }))} />
                            </div>
                            <div>
                              <Label>Протеин (г)</Label>
                              <Input type="number" placeholder="25" value={newMeal.protein} onChange={(e) => setNewMeal(prev => ({ ...prev, protein: e.target.value }))} />
                            </div>
                          </div>
                          <Button onClick={addMeal} className="w-full">Добави</Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <Card className="p-4 bg-orange-500/10 border-orange-500/20">
                      <p className="text-sm text-muted-foreground">Общо калории</p>
                      <p className="text-3xl font-bold">{totalCalories} <span className="text-sm font-normal text-muted-foreground">/ {CALORIES_GOAL}</span></p>
                      <Progress value={Math.min(caloriesProgress, 100)} className="h-2 mt-2" />
                    </Card>
                    <Card className="p-4 bg-purple-500/10 border-purple-500/20">
                      <p className="text-sm text-muted-foreground">Общо протеин</p>
                      <p className="text-3xl font-bold">{totalProtein}г <span className="text-sm font-normal text-muted-foreground">/ {PROTEIN_GOAL}г</span></p>
                      <Progress value={Math.min(proteinProgress, 100)} className="h-2 mt-2" />
                    </Card>
                  </div>

                  {dailyLog.meals.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">
                      Все още няма добавени ястия. Натиснете бутона горе!
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {dailyLog.meals.map((meal) => (
                        <motion.div
                          key={meal.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border"
                        >
                          <div>
                            <p className="font-semibold">{meal.name}</p>
                            <p className="text-sm text-muted-foreground">{meal.time} · {meal.calories} kcal · {meal.protein}г протеин</p>
                          </div>
                          <Button variant="ghost" size="sm" onClick={() => removeMeal(meal.id)} className="text-muted-foreground hover:text-destructive">✕</Button>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </Card>
              </Reveal>
            </TabsContent>
          </Tabs>

          {/* Encouraging Message */}
          <Reveal delay={0.2}>
            <Card className="p-6 mt-8 glass-card text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-3 text-primary" />
              <p className="text-xl font-semibold text-foreground">{getEncouragingMessage()}</p>
            </Card>
          </Reveal>
        </div>
      </div>

      <Footer />
      <UsernameSetup open={showUsernameSetup} onOpenChange={setShowUsernameSetup} />
    </div>
  );
};

export default HealthDashboard;

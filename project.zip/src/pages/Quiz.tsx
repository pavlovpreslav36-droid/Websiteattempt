import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { useUserProfile } from "@/contexts/UserProfileContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Trophy, Heart, AlertCircle, Lightbulb, Clock, User, Zap, Crown, Medal } from "lucide-react";
import Footer from "@/components/Footer";
import { Reveal } from "@/components/Reveal";
import { supabase } from "@/integrations/supabase/client";

/* ─── Types ─── */
interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  emoji: string;
  category: string;
}

interface LeaderboardEntry {
  id: string;
  username: string;
  score: number;
  total_questions: number;
  best_streak: number;
  created_at: string;
}

/* ─── Question images by category ─── */
const categoryImages: Record<string, string> = {
  hydration: "https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=600&q=80",
  sleep: "https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?w=600&q=80",
  nutrition: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&q=80",
  fitness: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&q=80",
  health: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=600&q=80",
  mental: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=600&q=80",
  anatomy: "https://images.unsplash.com/photo-1559757175-5700dde675bc?w=600&q=80",
};

const questionImages: Record<number, string> = {
  1: "https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=600&q=80",
  2: "https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?w=600&q=80",
  3: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=600&q=80",
  4: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=600&q=80",
  5: "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=600&q=80",
  6: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=600&q=80",
  7: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&q=80",
  8: "https://images.unsplash.com/photo-1559757175-5700dde675bc?w=600&q=80",
  9: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=600&q=80",
  10: "https://images.unsplash.com/photo-1532550907401-a500c9a57435?w=600&q=80",
  11: "https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=600&q=80",
  12: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=600&q=80",
  13: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=600&q=80",
  14: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&q=80",
  15: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=600&q=80",
  16: "https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=600&q=80",
  17: "https://images.unsplash.com/photo-1628348068343-c6a848d2b6dd?w=600&q=80",
  18: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&q=80",
  19: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&q=80",
  20: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=600&q=80",
  21: "https://images.unsplash.com/photo-1538805060514-97d9cc17730c?w=600&q=80",
  22: "https://images.unsplash.com/photo-1498837167922-ddd27525d352?w=600&q=80",
  23: "https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=600&q=80",
  24: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=600&q=80",
  25: "https://images.unsplash.com/photo-1552196563-55cd4e45efb3?w=600&q=80",
  26: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=600&q=80",
  27: "https://images.unsplash.com/photo-1610348725531-843dff563e2c?w=600&q=80",
  28: "https://images.unsplash.com/photo-1517963879433-6ad2b056d712?w=600&q=80",
  29: "https://images.unsplash.com/photo-1587560699334-bea93391dcef?w=600&q=80",
  30: "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=600&q=80",
  31: "https://images.unsplash.com/photo-1505576399279-565b52d4ac71?w=600&q=80",
  32: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&q=80",
  33: "https://images.unsplash.com/photo-1550831107-1553da8c8464?w=600&q=80",
  34: "https://images.unsplash.com/photo-1607962837359-5e7e89f86776?w=600&q=80",
  35: "https://images.unsplash.com/photo-1505576399279-565b52d4ac71?w=600&q=80",
  36: "https://images.unsplash.com/photo-1540420828642-fca2c5c18abe?w=600&q=80",
  37: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&q=80",
  38: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&q=80",
  39: "https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=600&q=80",
  40: "https://images.unsplash.com/photo-1494597564530-871f2b93ac55?w=600&q=80",
  41: "https://images.unsplash.com/photo-1559757175-5700dde675bc?w=600&q=80",
  42: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=600&q=80",
  43: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&q=80",
  44: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=600&q=80",
  45: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=600&q=80",
  46: "https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=600&q=80",
  47: "https://images.unsplash.com/photo-1532550907401-a500c9a57435?w=600&q=80",
  48: "https://images.unsplash.com/photo-1498837167922-ddd27525d352?w=600&q=80",
  49: "https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=600&q=80",
  50: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=600&q=80",
};

const getQuestionImage = (q: Question) => questionImages[q.id] || categoryImages[q.category] || categoryImages.health;

/* ─── 50 Questions ─── */
const quizQuestions: Question[] = [
  { id: 1, question: "Колко вода трябва да пиете дневно?", options: ["1-2 литра", "2-3 литра", "3-4 литра", "4-5 литра"], correctAnswer: 1, emoji: "💧", category: "hydration" },
  { id: 2, question: "Колко часа сън са препоръчителни за възрастен?", options: ["4-5 часа", "5-6 часа", "7-9 часа", "10-12 часа"], correctAnswer: 2, emoji: "😴", category: "sleep" },
  { id: 3, question: "Кой витамин получаваме от слънцето?", options: ["Витамин A", "Витамин B", "Витамин C", "Витамин D"], correctAnswer: 3, emoji: "☀️", category: "nutrition" },
  { id: 4, question: "Колко минути физическа активност дневно са препоръчителни?", options: ["10 минути", "20 минути", "30 минути", "60 минути"], correctAnswer: 2, emoji: "🏃", category: "fitness" },
  { id: 5, question: "Кое е най-здравословното масло за готвене?", options: ["Слънчогледово", "Зехтин", "Палмово", "Кокосово"], correctAnswer: 1, emoji: "🫒", category: "nutrition" },
  { id: 6, question: "Каква е нормалната телесна температура?", options: ["35.5°C", "36.6°C", "37.5°C", "38.0°C"], correctAnswer: 1, emoji: "🌡️", category: "health" },
  { id: 7, question: "Колко пъти седмично трябва да тренирате?", options: ["1-2 пъти", "3-5 пъти", "6-7 пъти", "Всеки ден по 2 пъти"], correctAnswer: 1, emoji: "💪", category: "fitness" },
  { id: 8, question: "Кой орган пречиства кръвта ви?", options: ["Сърцето", "Белите дробове", "Черният дроб", "Стомахът"], correctAnswer: 2, emoji: "🫀", category: "anatomy" },
  { id: 9, question: "Колко е нормалното кръвно налягане?", options: ["100/60", "120/80", "140/90", "160/100"], correctAnswer: 1, emoji: "🩺", category: "health" },
  { id: 10, question: "Кое е най-богатото на протеин?", options: ["Ориз", "Картофи", "Пилешко месо", "Ябълки"], correctAnswer: 2, emoji: "🍗", category: "nutrition" },
  { id: 11, question: "Колко стъпки дневно са препоръчителни?", options: ["5,000", "10,000", "15,000", "20,000"], correctAnswer: 1, emoji: "👣", category: "fitness" },
  { id: 12, question: "Кой е най-важният хранителен прием?", options: ["Закуска", "Обяд", "Вечеря", "Всички еднакво"], correctAnswer: 0, emoji: "🍳", category: "nutrition" },
  { id: 13, question: "Колко време трябва да се разтягате преди тренировка?", options: ["2-3 минути", "5-10 минути", "15-20 минути", "30 минути"], correctAnswer: 1, emoji: "🧘", category: "fitness" },
  { id: 14, question: "Какво е BMI?", options: ["Индекс на телесна маса", "Индекс на мускулна маса", "Индекс на костна маса", "Индекс на метаболизъм"], correctAnswer: 0, emoji: "⚖️", category: "health" },
  { id: 15, question: "Колко калории има 1 грам протеин?", options: ["2 калории", "4 калории", "7 калории", "9 калории"], correctAnswer: 1, emoji: "🔥", category: "nutrition" },
  { id: 16, question: "Коя храна е най-богата на желязо?", options: ["Спанак", "Банани", "Мляко", "Ориз"], correctAnswer: 0, emoji: "🥬", category: "nutrition" },
  { id: 17, question: "Колко е нормалният пулс в покой?", options: ["40-50 удара/мин", "60-100 удара/мин", "110-120 удара/мин", "130-140 удара/мин"], correctAnswer: 1, emoji: "❤️", category: "health" },
  { id: 18, question: "Какво означава кардио тренировка?", options: ["Силова тренировка", "Тренировка за гръб", "Тренировка за сърдечно-съдовата система", "Тренировка за крака"], correctAnswer: 2, emoji: "🏋️", category: "fitness" },
  { id: 19, question: "Колко вода съдържа човешкото тяло?", options: ["30-40%", "50-60%", "60-70%", "80-90%"], correctAnswer: 2, emoji: "💦", category: "anatomy" },
  { id: 20, question: "Кой е най-здравословният източник на въглехидрати?", options: ["Бял хляб", "Пълнозърнест хляб", "Торти", "Бисквити"], correctAnswer: 1, emoji: "🍞", category: "nutrition" },
  { id: 21, question: "Колко калории трябва да изгаряте, за да отслабнете с 1 кг?", options: ["3,500 кал", "5,500 кал", "7,700 кал", "10,000 кал"], correctAnswer: 2, emoji: "📉", category: "fitness" },
  { id: 22, question: "Защо е важно да се храним разнообразно?", options: ["За вкус", "За различни хранителни вещества", "За да не се отегчаваме", "Няма значение"], correctAnswer: 1, emoji: "🥗", category: "nutrition" },
  { id: 23, question: "Колко често трябва да посещавате лекар за профилактика?", options: ["Веднъж месечно", "Веднъж на 6 месеца", "Веднъж годишно", "Само когато сме болни"], correctAnswer: 2, emoji: "👨‍⚕️", category: "health" },
  { id: 24, question: "Кое е най-вредно за сърцето?", options: ["Захар", "Сол", "Трансмазнини", "Всички изброени"], correctAnswer: 3, emoji: "⚠️", category: "health" },
  { id: 25, question: "Колко дни почивка са нужни след интензивна тренировка?", options: ["Никакви", "1-2 дни", "3-4 дни", "1 седмица"], correctAnswer: 1, emoji: "😌", category: "fitness" },
  { id: 26, question: "Какво е стрес хормонът?", options: ["Инсулин", "Кортизол", "Адреналин", "Допамин"], correctAnswer: 1, emoji: "😰", category: "mental" },
  { id: 27, question: "Колко плодове и зеленчуци дневно са препоръчителни?", options: ["1-2 порции", "3-4 порции", "5-7 порции", "10+ порции"], correctAnswer: 2, emoji: "🥦", category: "nutrition" },
  { id: 28, question: "Кое е най-важно след тренировка?", options: ["Храна", "Почивка", "Вода", "Всички изброени"], correctAnswer: 3, emoji: "✅", category: "fitness" },
  { id: 29, question: "Защо е вреден седящият начин на живот?", options: ["Влошава стойката", "Забавя метаболизма", "Увеличава риска от болести", "Всички изброени"], correctAnswer: 3, emoji: "🪑", category: "health" },
  { id: 30, question: "Какво е най-важно за дълголетие?", options: ["Генетика", "Здравословен начин на живот", "Късмет", "Богатство"], correctAnswer: 1, emoji: "🎂", category: "health" },
  // ─── New questions ───
  { id: 31, question: "Кой минерал е най-важен за костите?", options: ["Желязо", "Калций", "Цинк", "Магнезий"], correctAnswer: 1, emoji: "🦴", category: "nutrition" },
  { id: 32, question: "Колко мускула има човешкото тяло?", options: ["Около 200", "Около 400", "Около 600", "Около 800"], correctAnswer: 2, emoji: "💪", category: "anatomy" },
  { id: 33, question: "Какъв процент от мозъка е вода?", options: ["50%", "60%", "75%", "90%"], correctAnswer: 2, emoji: "🧠", category: "anatomy" },
  { id: 34, question: "Кое е най-голямото вътрешно органо?", options: ["Белите дробове", "Черният дроб", "Стомахът", "Бъбреците"], correctAnswer: 1, emoji: "🫁", category: "anatomy" },
  { id: 35, question: "Колко литра кръв циркулира в тялото на възрастен?", options: ["2-3 литра", "4-5 литра", "7-8 литра", "10-12 литра"], correctAnswer: 1, emoji: "🩸", category: "anatomy" },
  { id: 36, question: "Кое упражнение е най-добро за корема?", options: ["Коремни преси", "Планка", "Клек", "Бягане"], correctAnswer: 1, emoji: "🏋️", category: "fitness" },
  { id: 37, question: "Колко калории има в 1 грам мазнини?", options: ["4 калории", "7 калории", "9 калории", "12 калории"], correctAnswer: 2, emoji: "🧈", category: "nutrition" },
  { id: 38, question: "Кой витамин помага за имунната система?", options: ["Витамин A", "Витамин B12", "Витамин C", "Витамин K"], correctAnswer: 2, emoji: "🍊", category: "nutrition" },
  { id: 39, question: "Какво е медитацията?", options: ["Спорт", "Практика за ума", "Диета", "Лекарство"], correctAnswer: 1, emoji: "🧘", category: "mental" },
  { id: 40, question: "Колко кости има възрастен човек?", options: ["106", "156", "206", "256"], correctAnswer: 2, emoji: "💀", category: "anatomy" },
  { id: 41, question: "Кой орган произвежда инсулин?", options: ["Черният дроб", "Панкреасът", "Бъбреците", "Стомахът"], correctAnswer: 1, emoji: "🏥", category: "anatomy" },
  { id: 42, question: "Какво е ефектът на стреса върху тялото?", options: ["Повишава кръвното налягане", "Понижава имунитета", "Причинява безсъние", "Всички изброени"], correctAnswer: 3, emoji: "😣", category: "mental" },
  { id: 43, question: "Коя е най-ефективната тренировка за отслабване?", options: ["Ходене", "HIIT (интервална)", "Йога", "Плуване"], correctAnswer: 1, emoji: "🔥", category: "fitness" },
  { id: 44, question: "Колко зъба има възрастен човек?", options: ["24", "28", "32", "36"], correctAnswer: 2, emoji: "🦷", category: "anatomy" },
  { id: 45, question: "Кое е най-бързото човешко движение?", options: ["Бягане", "Кихане", "Мигане", "Удар с юмрук"], correctAnswer: 2, emoji: "👁️", category: "anatomy" },
  { id: 46, question: "Какъв е ефектът на кафето върху организма?", options: ["Повишава енергията", "Подобрява фокуса", "Може да причини безсъние", "Всички изброени"], correctAnswer: 3, emoji: "☕", category: "nutrition" },
  { id: 47, question: "Кой е хормонът на щастието?", options: ["Кортизол", "Серотонин", "Адреналин", "Инсулин"], correctAnswer: 1, emoji: "😊", category: "mental" },
  { id: 48, question: "Какво е ползата от Омега-3 мастните киселини?", options: ["Здраво сърце", "По-добра памет", "По-малко възпаления", "Всички изброени"], correctAnswer: 3, emoji: "🐟", category: "nutrition" },
  { id: 49, question: "Колко време трябва да тичате за добро кардио?", options: ["5 минути", "15-20 минути", "20-30 минути", "60+ минути"], correctAnswer: 2, emoji: "🏃‍♂️", category: "fitness" },
  { id: 50, question: "Кое е най-важното за психичното здраве?", options: ["Социални връзки", "Пари", "Работа", "Храна"], correctAnswer: 0, emoji: "🤗", category: "mental" },
];

/* ─── Millionaire Sound Engine ─── */
class MillionaireAudio {
  private ctx: AudioContext | null = null;

  private getCtx() {
    if (!this.ctx || this.ctx.state === "closed") this.ctx = new AudioContext();
    return this.ctx;
  }

  /** Dramatic "Стани богат" tension/thinking music */
  playThinking() {
    const ctx = this.getCtx();
    const now = ctx.currentTime;
    const notes = [220, 246.94, 261.63, 293.66, 261.63, 246.94, 220, 196];
    const gain = ctx.createGain();
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0.12, now);

    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = freq;
      osc.connect(gain);
      osc.start(now + i * 0.35);
      osc.stop(now + i * 0.35 + 0.3);
    });

    gain.gain.exponentialRampToValueAtTime(0.01, now + notes.length * 0.35);
  }

  /** Classic correct answer fanfare */
  playCorrect() {
    const ctx = this.getCtx();
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 1.2);

    [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = "triangle";
      osc.frequency.value = freq;
      osc.connect(gain);
      osc.start(now + i * 0.15);
      osc.stop(now + i * 0.15 + 0.3);
    });
  }

  /** Wrong answer buzzer */
  playWrong() {
    const ctx = this.getCtx();
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.8);

    const osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(200, now);
    osc.frequency.linearRampToValueAtTime(100, now + 0.8);
    osc.connect(gain);
    osc.start(now);
    osc.stop(now + 0.8);
  }

  /** Timer tick sound — gets faster as time runs out */
  playTick(urgency: number) {
    const ctx = this.getCtx();
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0.08 + urgency * 0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);

    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = 800 + urgency * 400;
    osc.connect(gain);
    osc.start(now);
    osc.stop(now + 0.06);
  }

  /** Final answer lock-in sound */
  playLockIn() {
    const ctx = this.getCtx();
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.6);

    [440, 554.37, 659.25].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = freq;
      osc.connect(gain);
      osc.start(now + i * 0.1);
      osc.stop(now + i * 0.1 + 0.2);
    });
  }

  /** Victory fanfare */
  playVictory() {
    const ctx = this.getCtx();
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 2);

    [392, 440, 523.25, 587.33, 659.25, 783.99, 880, 1046.5].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = "triangle";
      osc.frequency.value = freq;
      osc.connect(gain);
      osc.start(now + i * 0.2);
      osc.stop(now + i * 0.2 + 0.35);
    });
  }

  /** Click/select sound */
  playClick() {
    const ctx = this.getCtx();
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);

    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = 600;
    osc.connect(gain);
    osc.start(now);
    osc.stop(now + 0.1);
  }
}

/* ─── Host Voice (Browser TTS — Bulgarian) ─── */
const hostSpeak = (text: string) => {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "bg-BG";
  utterance.rate = 0.95;
  utterance.pitch = 0.9;
  utterance.volume = 0.9;
  // Try to find a Bulgarian voice
  const voices = window.speechSynthesis.getVoices();
  const bgVoice = voices.find(v => v.lang.startsWith("bg"));
  if (bgVoice) utterance.voice = bgVoice;
  window.speechSynthesis.speak(utterance);
};

const hostLines = {
  welcome: "Добре дошли в Стани Здрав! Готови ли сте?",
  correct: ["Правилно!", "Браво! Точен отговор!", "Отлично! Продължавайте!", "Вярно е!"],
  wrong: ["Грешен отговор, за съжаление.", "Не е вярно, но продължавайте!", "Грешка! Не се отказвайте!"],
  timeWarning: "Времето ви изтича! Побързайте!",
  timeCritical: "Последни секунди! Решавайте се!",
  hint: "Ще ви помогна — елиминирам един грешен отговор.",
  finalAnswer: "Това ли е окончателният ви отговор?",
  streak3: "Три поредни! Невероятно!",
  streak5: "Пет поредни! Вие сте машина!",
  victory: "Поздравления! Вие спечелихте!",
  goodResult: "Браво! Показахте отлични познания!",
  tryAgain: "Не се отказвайте! Опитайте отново!",
};

const audio = new MillionaireAudio();

/* ─── Component ─── */
const Quiz = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const { profile, isProfileSet } = useUserProfile();
  const [started, setStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);
  const [hintsLeft, setHintsLeft] = useState(3);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [isTimedOut, setIsTimedOut] = useState(false);
  const [showAnimation, setShowAnimation] = useState(false);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [showStreakFire, setShowStreakFire] = useState(false);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [answerLocked, setAnswerLocked] = useState(false);
  const [answerResult, setAnswerResult] = useState<"correct" | "wrong" | null>(null);
  const [eliminatedOption, setEliminatedOption] = useState<number | null>(null);
  const startTimeRef = useRef<number>(0);
  const timeWarningSpoken = useRef(false);
  const timeCriticalSpoken = useRef(false);

  // Load leaderboard
  const fetchLeaderboard = async () => {
    const { data } = await supabase
      .from("quiz_scores")
      .select("id, username, score, total_questions, best_streak, created_at")
      .order("score", { ascending: false })
      .order("best_streak", { ascending: false })
      .limit(20);
    if (data) setLeaderboard(data as LeaderboardEntry[]);
  };

  useEffect(() => { fetchLeaderboard(); }, []);

  // Load voices
  useEffect(() => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
    }
  }, []);

  // Anti-cheat
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (started && !showResult && document.hidden) {
        setIsTimedOut(true);
        localStorage.setItem("quiz_timeout", (Date.now() + 3600000).toString());
        toast({ title: "⚠️ Измама детектирана!", description: "Преминахте на друг таб. Блокирани сте за 1 час!", variant: "destructive" });
        audio.playWrong();
      }
    };
    const checkTimeout = () => {
      const timeout = localStorage.getItem("quiz_timeout");
      if (timeout && Date.now() < parseInt(timeout)) setIsTimedOut(true);
    };
    checkTimeout();
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, [started, showResult, toast]);

  // Timer with sound effects
  useEffect(() => {
    if (started && !showResult && !isTimedOut && !answerLocked && timeLeft > 0) {
      const timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1);
        // Tick sounds
        if (timeLeft <= 15) audio.playTick(timeLeft <= 5 ? 1 : 0.4);
        // Host warnings
        if (timeLeft === 15 && !timeWarningSpoken.current) {
          hostSpeak(hostLines.timeWarning);
          timeWarningSpoken.current = true;
        }
        if (timeLeft === 6 && !timeCriticalSpoken.current) {
          hostSpeak(hostLines.timeCritical);
          timeCriticalSpoken.current = true;
        }
      }, 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showResult && !answerLocked) {
      proceedToNext(false);
    }
  }, [timeLeft, started, showResult, isTimedOut, answerLocked]);

  const startQuiz = () => {
    if (isTimedOut) {
      const timeout = localStorage.getItem("quiz_timeout");
      const remaining = timeout ? Math.ceil((parseInt(timeout) - Date.now()) / 60000) : 0;
      toast({ title: "⏳ Все още сте блокирани", description: `Остават ${remaining} минути`, variant: "destructive" });
      return;
    }
    const shuffled = [...quizQuestions].sort(() => Math.random() - 0.5).slice(0, 30);
    setQuestions(shuffled);
    setStarted(true);
    setCurrentQuestion(0);
    setScore(0);
    setTimeLeft(30);
    setHintsLeft(3);
    setStreak(0);
    setBestStreak(0);
    setAnswerLocked(false);
    setAnswerResult(null);
    setEliminatedOption(null);
    startTimeRef.current = Date.now();
    timeWarningSpoken.current = false;
    timeCriticalSpoken.current = false;
    audio.playClick();
    hostSpeak(hostLines.welcome);
    audio.playThinking();
  };

  const useHint = () => {
    if (hintsLeft > 0 && !answerLocked) {
      setHintsLeft(hintsLeft - 1);
      const q = questions[currentQuestion];
      const wrongOpts = q.options
        .map((_, i) => i)
        .filter(i => i !== q.correctAnswer && i !== selectedAnswer && i !== eliminatedOption);
      const removed = wrongOpts[Math.floor(Math.random() * wrongOpts.length)];
      setEliminatedOption(removed);
      audio.playClick();
      hostSpeak(hostLines.hint);
      toast({ title: "💡 Подсказка!", description: `Отговор ${String.fromCharCode(65 + removed)} е елиминиран!` });
    }
  };

  const handleAnswer = (answerIndex: number) => {
    if (answerLocked) return;
    setSelectedAnswer(answerIndex);
    audio.playClick();
  };

  const lockAnswer = () => {
    if (selectedAnswer === null || answerLocked) return;
    setAnswerLocked(true);
    audio.playLockIn();
    hostSpeak(hostLines.finalAnswer);

    // Reveal after dramatic pause
    setTimeout(() => {
      const isCorrect = selectedAnswer === questions[currentQuestion].correctAnswer;
      setAnswerResult(isCorrect ? "correct" : "wrong");

      if (isCorrect) {
        setScore(s => s + 1);
        const newStreak = streak + 1;
        setStreak(newStreak);
        if (newStreak > bestStreak) setBestStreak(newStreak);
        audio.playCorrect();
        const line = hostLines.correct[Math.floor(Math.random() * hostLines.correct.length)];
        setTimeout(() => hostSpeak(line), 400);
        if (newStreak === 3) { setShowStreakFire(true); setTimeout(() => { setShowStreakFire(false); hostSpeak(hostLines.streak3); }, 1500); }
        if (newStreak === 5) { setShowStreakFire(true); setTimeout(() => { setShowStreakFire(false); hostSpeak(hostLines.streak5); }, 1500); }
      } else {
        setStreak(0);
        audio.playWrong();
        const line = hostLines.wrong[Math.floor(Math.random() * hostLines.wrong.length)];
        setTimeout(() => hostSpeak(line), 400);
      }

      // Move to next after showing result
      setTimeout(() => {
        if (currentQuestion < questions.length - 1) {
          setCurrentQuestion(c => c + 1);
          setSelectedAnswer(null);
          setAnswerLocked(false);
          setAnswerResult(null);
          setEliminatedOption(null);
          setTimeLeft(30);
          timeWarningSpoken.current = false;
          timeCriticalSpoken.current = false;
          audio.playThinking();
        } else {
          finishQuiz();
        }
      }, 2000);
    }, 1500);
  };

  const proceedToNext = (isCorrect: boolean) => {
    if (!isCorrect) {
      setStreak(0);
      audio.playWrong();
    }
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(c => c + 1);
      setSelectedAnswer(null);
      setAnswerLocked(false);
      setAnswerResult(null);
      setEliminatedOption(null);
      setTimeLeft(30);
      timeWarningSpoken.current = false;
      timeCriticalSpoken.current = false;
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = async () => {
    setShowResult(true);
    setShowAnimation(true);
    const percentage = ((score + (selectedAnswer === questions[currentQuestion]?.correctAnswer ? 1 : 0)) / questions.length) * 100;
    if (percentage >= 70) {
      audio.playVictory();
      hostSpeak(percentage >= 90 ? hostLines.victory : hostLines.goodResult);
    } else {
      hostSpeak(hostLines.tryAgain);
    }

    // Save to leaderboard if logged in
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const finalScore = score + (selectedAnswer === questions[currentQuestion]?.correctAnswer ? 1 : 0);
      const timeTaken = Math.round((Date.now() - startTimeRef.current) / 1000);
      await supabase.from("quiz_scores").insert({
        user_id: user.id,
        username: profile?.username || user.email?.split("@")[0] || "Играч",
        score: finalScore,
        total_questions: questions.length,
        best_streak: Math.max(bestStreak, streak),
        time_taken_seconds: timeTaken,
      });
      fetchLeaderboard();
    }
  };

  /* ─── Render: Blocked ─── */
  if (isTimedOut && !showResult) {
    const timeout = localStorage.getItem("quiz_timeout");
    const remaining = timeout ? Math.ceil((parseInt(timeout) - Date.now()) / 60000) : 0;
    return (
      <div className="min-h-screen pt-20 px-4 flex items-center justify-center bg-background">
        <Card className="p-8 max-w-md text-center glass-card border-destructive">
          <AlertCircle className="w-16 h-16 mx-auto mb-4 text-destructive" />
          <h2 className="text-2xl font-bold mb-4 text-foreground">Блокирани сте!</h2>
          <p className="text-muted-foreground mb-2">Детектирана е измама</p>
          <p className="text-xl font-bold text-destructive">Остават: {remaining} минути</p>
        </Card>
      </div>
    );
  }

  /* ─── Render: Results ─── */
  if (showResult) {
    const finalScore = score;
    const percentage = (finalScore / questions.length) * 100;
    const username = profile?.username;
    const getResultMessage = () => {
      if (percentage >= 90) return username ? `🏆 Браво, ${username}! Ти си здравен гуру!` : "🏆 Перфектно! Вие сте здравен гуру!";
      if (percentage >= 70) return username ? `🌟 Отлично, ${username}! Много добри познания!` : "🌟 Отлично! Много добри познания!";
      if (percentage >= 50) return username ? `👍 Добре, ${username}! Има какво да научиш още.` : "👍 Добре! Има какво да научите още.";
      return username ? `💪 Продължавай да се учиш, ${username}!` : "💪 Продължавайте да се учите!";
    };

    return (
      <div className="min-h-screen bg-background">
        <section className="relative min-h-[30vh] flex items-end justify-center overflow-hidden pt-16 pb-8">
          <div className="absolute inset-0 z-0">
            <img src="/images/quiz-hero.jpg" alt="Резултати" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/30 to-background" />
          </div>
          <div className="relative z-10 text-center"><Reveal><Trophy className="w-16 h-16 mx-auto mb-2 text-primary animate-bounce" /></Reveal></div>
        </section>

        <div className="px-6 pb-8">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="max-w-2xl mx-auto text-center">
            <Card className="p-8 glass-card mb-6">
              {isProfileSet && (
                <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-center gap-2 mb-4 text-lg text-muted-foreground">
                  <User className="w-5 h-5" /><span>{username}</span>
                </motion.div>
              )}
              <h2 className="text-4xl font-display font-bold mb-4 gradient-text">{isProfileSet ? `Поздравления, ${username}! 🎉` : "Поздравления! 🎉"}</h2>
              <p className="text-6xl font-bold mb-2 text-foreground">{finalScore}/{questions.length}</p>
              <div className="flex items-center justify-center gap-4 mb-4">
                <div className="flex items-center gap-1"><Zap className="w-5 h-5 text-accent" /><span className="text-muted-foreground">Серия: <span className="font-bold text-accent">{bestStreak}</span></span></div>
              </div>
              <motion.p className="text-2xl mb-6 text-foreground" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>{getResultMessage()}</motion.p>
              <AnimatePresence>{showAnimation && percentage >= 70 && (
                <motion.div initial={{ opacity: 0, y: 50, rotate: -10 }} animate={{ opacity: 1, y: 0, rotate: 0 }} exit={{ opacity: 0 }} className="mb-6 text-8xl animate-bounce">{percentage >= 90 ? "🥇" : "🥈"}</motion.div>
              )}</AnimatePresence>
              <div className="flex gap-3 justify-center flex-wrap">
                <Button onClick={() => { setShowResult(false); setStarted(false); setShowAnimation(false); }} size="lg" className="rounded-xl">Опитай отново 🔄</Button>
                <Button onClick={() => setShowLeaderboard(!showLeaderboard)} variant="outline" size="lg" className="rounded-xl"><Crown className="mr-2 w-5 h-5" />Класация</Button>
              </div>
            </Card>

            {/* Leaderboard */}
            <AnimatePresence>
              {showLeaderboard && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}>
                  <Card className="p-6 glass-card">
                    <h3 className="text-2xl font-display font-bold mb-4 text-primary flex items-center justify-center gap-2"><Crown className="w-6 h-6" /> Топ 20 Играчи</h3>
                    {leaderboard.length === 0 ? (
                      <p className="text-muted-foreground">Няма резултати все още. Бъди първият!</p>
                    ) : (
                      <div className="space-y-2">
                        {leaderboard.map((entry, i) => (
                          <motion.div key={entry.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                            className={`flex items-center gap-3 p-3 rounded-xl ${i < 3 ? "bg-primary/10 border border-primary/20" : "bg-secondary/50"}`}
                          >
                            <span className="text-2xl w-8 text-center">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i + 1}.`}</span>
                            <span className="flex-1 font-semibold text-foreground">{entry.username}</span>
                            <span className="font-bold text-primary">{entry.score}/{entry.total_questions}</span>
                            <span className="flex items-center gap-1 text-sm text-accent"><Zap className="w-3 h-3" />{entry.best_streak}</span>
                          </motion.div>
                        ))}
                      </div>
                    )}
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
        <Footer />
      </div>
    );
  }

  /* ─── Render: Start Screen ─── */
  if (!started) {
    return (
      <div className="min-h-screen bg-background">
        <section className="relative min-h-[40vh] flex items-end justify-center overflow-hidden pt-16 pb-10">
          <div className="absolute inset-0 z-0">
            <img src="/images/quiz-hero.jpg" alt="Викторина" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/30 to-background" />
          </div>
          <div className="relative z-10 text-center px-6">
            <Reveal>
              <h1 className="text-4xl md:text-6xl font-display font-bold text-foreground mb-2">🎯 Стани Здрав!</h1>
              <p className="text-lg text-muted-foreground max-w-xl mx-auto">Вдъхновено от „Стани богат" — тествай знанията си!</p>
            </Reveal>
          </div>
        </section>

        <div className="px-6 pb-8">
          <div className="max-w-2xl mx-auto space-y-6">
            <Reveal delay={0.1}>
              <Card className="p-8 glass-card">
                <Heart className="w-16 h-16 mx-auto mb-6 text-primary" />
                <h2 className="text-2xl font-bold mb-4 text-foreground">Правила:</h2>
                <ul className="text-left space-y-3 mb-8 text-lg text-muted-foreground">
                  <li>✅ 30 въпроса от 50 рандомизирани</li>
                  <li>⏱️ 30 секунди за всеки въпрос</li>
                  <li>💡 3 подсказки — елиминират грешен отговор</li>
                  <li>🔒 Заключете отговора си като в „Стани богат"</li>
                  <li>🔊 Драматични звуци и гласов водещ!</li>
                  <li>🔥 Серия от правилни отговори = бонус!</li>
                  <li>⚠️ Без измама! (смяна на таб = 1 час блокиране)</li>
                  <li>🏆 Класация — влезте в акаунт за да участвате!</li>
                </ul>
                <Button onClick={startQuiz} size="lg" className="w-full rounded-xl h-14 text-lg">🎬 Да започваме!</Button>
              </Card>
            </Reveal>

            {/* Leaderboard on start page */}
            <Reveal delay={0.2}>
              <Card className="p-6 glass-card">
                <h3 className="text-xl font-display font-bold mb-4 text-primary flex items-center gap-2"><Crown className="w-5 h-5" /> Класация</h3>
                {leaderboard.length === 0 ? (
                  <p className="text-muted-foreground text-center">Няма резултати. Бъди първият! 🏅</p>
                ) : (
                  <div className="space-y-2">
                    {leaderboard.slice(0, 10).map((entry, i) => (
                      <div key={entry.id} className={`flex items-center gap-3 p-2.5 rounded-xl ${i < 3 ? "bg-primary/10" : "bg-secondary/30"}`}>
                        <span className="text-xl w-7 text-center">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i + 1}.`}</span>
                        <span className="flex-1 font-medium text-foreground truncate">{entry.username}</span>
                        <span className="font-bold text-primary">{entry.score}/{entry.total_questions}</span>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            </Reveal>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  /* ─── Render: Active Quiz ─── */
  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const questionImg = getQuestionImage(question);
  const categoryLabel = { hydration: "Хидратация", sleep: "Сън", nutrition: "Хранене", fitness: "Фитнес", health: "Здраве", mental: "Психика", anatomy: "Анатомия" }[question.category] || question.category;

  return (
    <div className="min-h-screen bg-background pt-20 px-4 pb-8">
      <div className="max-w-3xl mx-auto">
        {/* Stats bar */}
        <div className="mb-4 flex justify-between items-center flex-wrap gap-2">
          <div className="flex gap-4 items-center">
            <span className="text-xl font-bold text-foreground">{currentQuestion + 1}/{questions.length}</span>
            <span className="text-xl font-bold text-primary">🏆 {score}</span>
            {streak >= 2 && (
              <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="flex items-center gap-1 text-accent font-bold text-lg"><Zap className="w-5 h-5" />{streak}x</motion.span>
            )}
          </div>
          <div className="flex gap-3 items-center">
            <div className={`flex items-center gap-2 text-lg font-bold px-3 py-1 rounded-full ${timeLeft <= 10 ? "bg-destructive/15 text-destructive" : timeLeft <= 20 ? "bg-accent/15 text-accent" : "text-foreground"}`}>
              <Clock className={timeLeft <= 10 ? "animate-pulse" : ""} size={20} />
              <span>{timeLeft}s</span>
            </div>
            <Button onClick={useHint} disabled={hintsLeft === 0 || answerLocked} variant="outline" size="sm" className="rounded-xl">
              <Lightbulb className="mr-1" size={16} />{hintsLeft}
            </Button>
          </div>
        </div>

        <Progress value={progress} className="mb-6" />

        {/* Streak fire overlay */}
        <AnimatePresence>
          {showStreakFire && (
            <motion.div initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.5 }} className="fixed inset-0 pointer-events-none flex items-center justify-center z-50">
              <span className="text-[120px]">🔥</span>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          <motion.div key={currentQuestion} initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}>
            {/* Question image */}
            <div className="relative rounded-2xl overflow-hidden mb-6 h-48 md:h-56">
              <img src={questionImg} alt={question.category} className="w-full h-full object-cover" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
              <div className="absolute bottom-3 left-4 flex items-center gap-2">
                <span className="text-3xl">{question.emoji}</span>
                <span className="text-sm font-semibold text-primary-foreground bg-primary/80 px-3 py-1 rounded-full backdrop-blur-sm">{categoryLabel}</span>
              </div>
            </div>

            <Card className="p-6 md:p-8 glass-card mb-6">
              <h2 className="text-xl md:text-2xl font-bold mb-6 text-center text-foreground">{question.question}</h2>
              <div className="grid gap-3">
                {question.options.map((option, index) => {
                  const isEliminated = eliminatedOption === index;
                  const letter = String.fromCharCode(65 + index);
                  let variant: "default" | "outline" | "destructive" = "outline";
                  let extraClass = "";

                  if (answerResult) {
                    if (index === question.correctAnswer) {
                      extraClass = "!bg-primary !text-primary-foreground ring-2 ring-primary";
                    } else if (index === selectedAnswer && answerResult === "wrong") {
                      extraClass = "!bg-destructive !text-destructive-foreground";
                    }
                  } else if (selectedAnswer === index) {
                    variant = "default";
                  }

                  return (
                    <motion.div key={index} whileHover={!answerLocked && !isEliminated ? { scale: 1.02 } : {}} whileTap={!answerLocked && !isEliminated ? { scale: 0.98 } : {}}>
                      <Button
                        onClick={() => handleAnswer(index)}
                        variant={variant}
                        disabled={isEliminated || answerLocked}
                        className={`w-full text-lg py-6 justify-start rounded-xl transition-all duration-300 ${extraClass} ${isEliminated ? "opacity-30 line-through" : ""}`}
                      >
                        <span className="font-bold mr-3 text-primary">{letter}.</span>
                        {option}
                      </Button>
                    </motion.div>
                  );
                })}
              </div>
            </Card>

            {/* Lock-in button (like "Final Answer" in the show) */}
            <Button
              onClick={lockAnswer}
              disabled={selectedAnswer === null || answerLocked}
              size="lg"
              className={`w-full rounded-xl h-14 text-lg transition-all ${answerLocked ? "opacity-60" : "animate-pulse hover:animate-none"}`}
            >
              {answerLocked
                ? (answerResult ? (answerResult === "correct" ? "✅ Правилно!" : "❌ Грешно!") : "⏳ Проверяваме...")
                : currentQuestion === questions.length - 1 ? "🔒 Финален отговор!" : "🔒 Заключи отговора!"
              }
            </Button>
          </motion.div>
        </AnimatePresence>
      </div>
      <Footer />
    </div>
  );
};

export default Quiz;

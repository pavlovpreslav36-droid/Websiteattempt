import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Sparkles } from "lucide-react";
import Footer from "@/components/Footer";
import { Reveal, StaggerContainer, staggerItem } from "@/components/Reveal";

const funFacts = [
  "🧠 Мозъкът използва 20% от кислорода в тялото!",
  "💪 Най-силният мускул в тялото е челюстта!",
  "👃 Човек може да запомни до 50,000 различни аромата!",
  "❤️ Сърцето бие около 100,000 пъти дневно!",
  "🦴 В човешкото тяло има 206 кости!",
  "👁️ Очите ви имат 107 милиона светлочувствителни клетки!",
  "🫁 Белите дробове съдържат 300 милиона алвеоли!",
  "🩸 Кръвта изминава 19,000 км дневно в тялото!",
  "🦷 Емайлът на зъбите е най-твърдото вещество в тялото!",
  "👂 Ухото никога не спира да расте!",
  "💧 70% от тялото е вода!",
  "🏃 Ходенето използва 200 мускула!",
  "😴 По време на сън растем!",
  "🤧 Кихането излиза със скорост 160 км/ч!",
  "👶 Бебетата имат 300 кости, възрастните 206!",
  "🧬 ДНК в едно тяло е дълго 2 метра!",
  "🫀 Сърцето прокарва 7,500 литра кръв дневно!",
  "👀 Мигаме около 15-20 пъти в минута!",
  "🦴 Най-малката кост е в ухото!",
  "💪 Най-голямият мускул е gluteus maximus!",
  "🍎 Ябълките дават повече енергия от кафето!",
  "🥛 Млякото укрепва костите със своя калций!",
  "🥕 Морковите подобряват зрението!",
  "🍌 Бананите са пълни с калий за мускулите!",
  "🥦 Броколито е супер храна с витамини!",
  "🥑 Авокадото съдържа здравословни мазнини!",
  "🍓 Ягодите имат повече витамин C от портокалите!",
  "🥬 Спанакът е богат на желязо!",
  "🥜 Ядките подобряват мозъчната дейност!",
  "🐟 Рибата е богата на омега-3!",
  "🏋️ Силовата тренировка увеличава метаболизма!",
  "🧘 Йогата намалява стреса и подобрява гъвкавостта!",
  "🏃‍♀️ Бягането освобождава ендорфини!",
  "🚴 Колоезденето е отлично кардио!",
  "🏊 Плуването работи всички мускули!",
  "🤸 Стречингът предотвратява контузии!",
  "⛰️ Планинските разходки подобряват издръжливостта!",
  "🎾 Тенисът подобрява координацията!",
  "⚽ Футболът развива командна работа!",
  "🥊 Боксът е чудесна кардио тренировка!",
  "😊 Смехът намалява стреса!",
  "🌞 15 минути слънце дневно са достатъчни за витамин D!",
  "💤 Качественият сън подобрява паметта!",
  "🧘‍♀️ Медитацията намалява кръвното налягане!",
  "🚶 10,000 стъпки дневно подобряват здравето!",
  "🎵 Музиката може да намали болката!",
  "🤗 Прегръдките повишават имунитета!",
  "🌿 Престоят в природата намалява стреса!",
  "📚 Четенето подобрява когнитивните функции!",
  "🎨 Творчеството намалява тревожността!",
  "🫐 Боровинките подобряват паметта!",
  "🍊 Портокалите укрепват имунната система!",
  "🌰 Бадемите са богати на витамин E!",
  "🥒 Краставиците хидратират тялото!",
  "🍅 Доматите съдържат ликопен за здраве!",
  "🥥 Кокосовата вода е естествен изотоник!",
  "🫘 Бобовите храни са отличен източник на протеин!",
  "🧄 Чесънът има антибактериални свойства!",
  "🧅 Лукът помага за имунитета!",
  "🌶️ Лютите чушки ускоряват метаболизма!",
  "🥗 Салатите помагат за храносмилането!",
  "🍵 Зеленият чай е богат на антиоксиданти!",
  "☕ Кафето може да подобри фокуса!",
  "🥤 Газираните напитки съдържат много захар!",
  "🧃 Плодовите сокове трябва да са без захар!",
  "🍯 Медът е естествен подсладител!",
  "🧂 Прекомерната сол повишава налягането!",
  "🍬 Захарта води до кариеси!",
  "🍫 Черният шоколад е по-здравословен!",
  "🥚 Яйцата са пълни с протеин!",
  "🧀 Сиренето е богато на калций!",
  "🥩 Червеното месо съдържа желязо!",
  "🍗 Пилешкото е нискомаслено месо!",
  "🐠 Сьомгата е богата на омега-3!",
  "🦐 Морските дарове са нискокалорични!",
  "🥓 Беконът трябва да се яде умерено!",
  "🌭 Колбасите съдържат много добавки!",
  "🍔 Бургерите са висококалорични!",
  "🍕 Пицата може да бъде нездравословна!",
  "🍟 Пържените картофи са богати на мазнини!",
  "🌮 Такосите могат да бъдат здравословни!",
  "🌯 Буритата са добър избор за обяд!",
  "🥙 Шаурмата може да бъде здравословна!",
  "🍜 Супите са добри за храносмилането!",
  "🍝 Пълнозърнестата паста е по-здравословна!",
  "🍚 Кафявият ориз е по-полезен от белия!",
  "🍞 Пълнозърнестият хляб е богат на фибри!",
  "🥐 Кроасаните са високомаслени!",
  "🥨 Геврекчетата съдържат много сол!",
  "🥯 Бейгълите са плътна храна!",
  "🥞 Палачинките могат да бъдат здравословни!",
  "🧇 Гофретите са сладки и калорични!",
  "🍰 Тортите са за специални случаи!",
  "🎂 Празнични торти съдържат много захар!",
  "🧁 Мъфините могат да бъдат здравословни!",
  "🍪 Бисквитите трябва да са без захар!",
  "🍩 Понички са високозахарни!",
  "🍮 Десертите трябва да се ядат рядко!",
  "🍦 Сладоледът е летен десерт!",
];

const shuffleArray = (array: string[]) => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

const FunFacts = () => {
  const [shuffledFacts, setShuffledFacts] = useState<string[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    setShuffledFacts(shuffleArray(funFacts));
  }, []);

  useEffect(() => {
    if (shuffledFacts.length === 0) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => {
        const next = prev + 1;
        if (next >= shuffledFacts.length) {
          setShuffledFacts(shuffleArray(funFacts));
          return 0;
        }
        return next;
      });
    }, 7000);
    return () => clearInterval(interval);
  }, [shuffledFacts]);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero with image */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] min-h-[30vh] md:min-h-[38vh] flex items-end justify-center overflow-hidden pt-12 pb-8 md:pb-10">
        <div className="absolute inset-0 z-0">
          <img src="/images/funfacts-hero.jpg" alt="Health facts" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10" />
        </div>
        <div className="relative z-10 text-center px-6 max-w-3xl mx-auto">
          <Reveal>
            <h1 className="text-4xl md:text-6xl font-display font-bold mb-3 text-white flex items-center justify-center gap-3">
              <Sparkles className="w-10 h-10 text-white" />
              Интересни факти
            </h1>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="text-lg text-white/85">
              Научете интересни факти за здравето (обновява се на всеки 7 секунди)
            </p>
          </Reveal>
        </div>
      </section>

      <section className="px-6 pb-12">
        <div className="max-w-7xl mx-auto">

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="wait">
            {shuffledFacts.length > 0 && (
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -20 }}
                transition={{ duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
                className="col-span-full"
              >
                <Card className="p-12 text-center glass-card border-primary/20">
                  <p className="text-3xl md:text-4xl font-display font-bold text-foreground">
                    {shuffledFacts[currentIndex]}
                  </p>
                  <div className="mt-6 flex items-center justify-center gap-2">
                    <div className="flex gap-1 max-w-full overflow-hidden">
                      {Array.from({ length: Math.min(shuffledFacts.length, 20) }).map((_, i) => (
                        <div
                          key={i}
                          className={`h-2 rounded-full transition-all duration-300 ${
                            i === currentIndex % 20 ? "w-8 bg-primary" : "w-2 bg-primary/30"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          <StaggerContainer className="col-span-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {shuffledFacts.slice(0, 9).map((fact, index) => (
              <motion.div
                key={`${fact}-${index}`}
                variants={staggerItem}
                whileHover={{ scale: 1.03, y: -4 }}
                className="cursor-pointer"
              >
                <Card className="p-6 h-full glass-card hover:border-primary/30 transition-all duration-300">
                  <p className="text-lg font-medium text-foreground">{fact}</p>
                </Card>
              </motion.div>
            ))}
          </StaggerContainer>
        </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default FunFacts;
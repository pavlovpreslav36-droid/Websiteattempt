import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useUserProfile } from "@/contexts/UserProfileContext";
import { Clock, Flame, User } from "lucide-react";
import Footer from "@/components/Footer";
import WeatherWidget from "@/components/WeatherWidget";
import { QRCodeDisplay } from "@/components/QRCodeDisplay";
import { UsernameSetup } from "@/components/UsernameSetup";
import { MoodWorkoutSuggestion } from "@/components/MoodWorkoutSuggestion";
import { Reveal } from "@/components/Reveal";
import { DailyInspiration } from "@/components/DailyInspiration";
import { RippleCounter } from "@/components/RippleCounter";
import { RippleLeaderboard } from "@/components/RippleLeaderboard";
import { DailyHabitTracker } from "@/components/DailyHabitTracker";
import { DisciplineChallenge } from "@/components/DisciplineChallenge";
import { BoxBreathingWidget } from "@/components/BoxBreathingWidget";
import { Zelenchuko } from "@/components/Zelenchuko";
import { recipeFolders } from "@/lib/recipeFolders";
import { dietRecipes } from "@/data/dietRecipes";
import { drinks, getDrinkById, type Drink } from "@/data/drinks";
import { diets } from "@/data/diets";
import { DrinkGlass } from "@/components/food/DrinkGlass";
import { ProduceIcon, type ProduceName } from "@/components/art/Produce";
import { FloatingDishes, type FloatingDish } from "@/components/art/FloatingDishes";
import { ArchChef } from "@/components/art/ArchChef";
import { Marquee } from "@/components/art/Marquee";
import { Squiggle } from "@/components/art/Squiggle";
import { CountUp } from "@/components/art/CountUp";
import { Morning, Noon, Evening } from "@/components/art/DayArt";

/* ───────── Content ───────── */

const headline = ["Какво ще", "сготвиш", "днес?"];

const heroDishes: FloatingDish[] = [
  { src: "/images/food/shopska-salata.jpg", alt: "Шопска салата с пиле", className: "left-[-6%] top-[58%] w-24 md:left-[5%] md:top-[22%] md:w-44", rotate: -12, depth: 90 },
  { src: "/images/food/tarator.jpg", alt: "Таратор", className: "hidden md:block md:left-[13%] md:top-[60%] md:w-36", rotate: 9, depth: -40, float: "float-slower" },
  { src: "/images/food/gyuvech.jpg", alt: "Гювеч", className: "right-[-6%] top-[52%] w-24 md:right-[5%] md:top-[18%] md:w-44", rotate: 11, depth: 110, float: "float-slower" },
  { src: "/images/food/pechena-riba.jpg", alt: "Печена риба", className: "hidden md:block md:right-[13%] md:top-[58%] md:w-36", rotate: -8, depth: -30 },
];

const heroProduce: { name: ProduceName; className: string; size: number }[] = [
  { name: "tomato", className: "left-[8%] top-[10%] md:left-[24%] md:top-[14%]", size: 46 },
  { name: "leaf", className: "right-[10%] top-[8%] md:right-[26%] md:top-[12%]", size: 44 },
  { name: "lemon", className: "hidden md:block md:left-[30%] md:top-[66%]", size: 50 },
  { name: "garlic", className: "hidden md:block md:right-[31%] md:top-[70%]", size: 44 },
];

// 115 dishes in the recipe book + the diet library
const totalRecipes = 115 + dietRecipes.length;

const stats = [
  { to: totalRecipes, label: "рецепти с калории и протеин" },
  { to: drinks.length, label: "напитки: води, чайове, смутита" },
  { to: diets.length, label: "режима: без глутен, веган и още" },
];

const dietCounts = new Map(diets.map((d) => [d.slug, d.slug === "healthy" ? dietRecipes.length : dietRecipes.filter((r) => r.tags.includes(d.slug)).length]));

const homeDrinks = ["cucumber-mint-water", "berry-basil-water", "orange-rosemary-water", "ginger-lemon-tea", "green-smoothie", "golden-milk"]
  .map(getDrinkById)
  .filter((d): d is Drink => !!d);

const tape = ["Готви", "Хрупкай", "Движи се", "Диша", "Живей"];

const todayRecipes = [
  { name: "Шопска салата с пиле", image: "/images/food/shopska-salata.jpg", kcal: 680, protein: 48, minutes: 35 },
  { name: "Печена риба с картофи", image: "/images/food/pechena-riba.jpg", kcal: 680, protein: 58, minutes: 45 },
  { name: "Таратор с ядки и яйца", image: "/images/food/tarator.jpg", kcal: 620, protein: 32, minutes: 75 },
  { name: "Пълнени чушки с месо", image: "/images/food/palneni-chushki.jpg", kcal: 820, protein: 52, minutes: 60 },
  { name: "Пилешка супа с фиде", image: "/images/food/pileshka-supa.jpg", kcal: 580, protein: 48, minutes: 100 },
  { name: "Гювеч с месо", image: "/images/food/gyuvech.jpg", kcal: 780, protein: 48, minutes: 105 },
  { name: "Мусака с кайма", image: "/images/food/musaka.jpg", kcal: 920, protein: 56, minutes: 75 },
  { name: "Боб чорба с наденица", image: "/images/food/bob-chorba.jpg", kcal: 780, protein: 42, minutes: 150 },
];

const day = [
  { Art: Morning, title: "Сутрин", text: "Избери закуска с протеин и излез на светло.", to: "/recipes?cat=%D0%97%D0%B0%D0%BA%D1%83%D1%81%D0%BA%D0%B0", cta: "Закуски" },
  { Art: Noon, title: "Обед", text: "Сканирай продукта и виж какво има в него.", to: "/product-scanner", cta: "Към скенера" },
  { Art: Evening, title: "Вечер", text: "Подишай спокойно и запиши как мина денят.", to: "/breathing", cta: "Към дишането" },
];

const explore = [
  { to: "/quiz", title: "Здравна викторина", text: "50 въпроса със серии и точки", image: "/images/quiz-hero.jpg", big: true },
  { to: "/fun-facts", title: "Интересни факти", text: "Нов факт на всеки 7 секунди", image: "/images/funfacts-hero.jpg" },
  { to: "/exercises", title: "Упражнения", text: "Тренировки по спорт", image: "/images/exercises-hero.jpg" },
  { to: "/weekly-report", title: "Седмичен доклад", text: "Как мина седмицата", image: "/images/weekly-report-hero.jpg" },
  { to: "/meal-planner", title: "Планер за менюто", text: "Хранене за цялата седмица", image: "/images/meal-planner-hero.jpg" },
];

/* ───────── Small pieces ───────── */

function SectionHeader({ title, text, action, onDark = false }: { title: string; text?: string; action?: { to: string; label: string }; onDark?: boolean }) {
  return (
    <div className="flex items-end justify-between gap-6 mb-8 md:mb-12">
      <div className="max-w-2xl">
        <h2 className={`display text-[clamp(1.9rem,5.4vw,3.6rem)] ${onDark ? "text-cream" : "text-primary"}`}>{title}</h2>
        <Squiggle className={`mt-3 w-28 h-3 ${onDark ? "text-flame" : "text-honey"}`} />
        {text && <p className={`mt-4 text-base md:text-lg ${onDark ? "text-cream/80" : "text-muted-foreground"}`}>{text}</p>}
      </div>
      {action && (
        <Link
          to={action.to}
          className={`shrink-0 eyebrow border rounded-full px-4 py-2.5 transition-colors ${
            onDark ? "border-cream/50 text-cream hover:bg-cream hover:text-wine" : "border-primary/60 text-primary hover:bg-primary hover:text-primary-foreground"
          }`}
        >
          {action.label}
        </Link>
      )}
    </div>
  );
}

const Home = () => {
  const { profile, isProfileSet } = useUserProfile();
  const navigate = useNavigate();
  const [showUsernameSetup, setShowUsernameSetup] = useState(false);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Добро утро";
    if (hour < 18) return "Добър ден";
    return "Добър вечер";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ═══ Hero ═══ */}
      <section className="relative overflow-hidden pt-nav">
        <FloatingDishes dishes={heroDishes} />
        {heroProduce.map((p) => (
          <div key={p.name} className={`absolute pointer-events-none float-slow ${p.className}`} aria-hidden="true">
            <ProduceIcon name={p.name} size={p.size} />
          </div>
        ))}

        <div className="relative z-10 container text-center pt-10 md:pt-16">
          <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="eyebrow text-primary">
            {isProfileSet ? `${getGreeting()}, ${profile?.username}` : "Здравословен живот, стъпка по стъпка"}
          </motion.p>

          <h1 className="display text-primary text-[clamp(2.8rem,11.5vw,8rem)] mt-5">
            {headline.map((line, i) => (
              <span key={line} className="block overflow-hidden pb-[0.05em]">
                <motion.span
                  className="block"
                  initial={{ y: "105%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 0.9, delay: 0.1 + i * 0.12, ease: [0.22, 1, 0.36, 1] }}
                >
                  {line}
                </motion.span>
              </span>
            ))}
          </h1>

          <motion.p initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 }} className="mt-6 mx-auto max-w-md text-base md:text-lg text-muted-foreground">
            {totalRecipes} здравословни рецепти и {drinks.length} напитки с реални хранителни стойности. Към тях – диети, дневник, скенер и тренировки на едно място.
          </motion.p>

          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.65 }} className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button size="lg" className="h-12 px-8 text-base" onClick={() => navigate("/recipes")}>
              Разгледай рецептите
            </Button>
            <Button size="lg" variant="outline" className="h-12 px-8 text-base border-primary/60 text-primary hover:bg-primary hover:text-primary-foreground" onClick={() => navigate("/ambassadors")}>
              Посланици на здравето
            </Button>
            {!isProfileSet && (
              <button
                onClick={() => setShowUsernameSetup(true)}
                className="inline-flex items-center gap-2 px-3 h-12 text-sm font-semibold text-primary underline underline-offset-4 decoration-primary/30 hover:decoration-primary"
              >
                <User className="w-4 h-4" aria-hidden="true" />
                Създай профил
              </button>
            )}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="relative z-10 mt-12 md:mt-16 mx-auto w-full max-w-[600px] px-6"
        >
          <ArchChef />
        </motion.div>
      </section>

      {/* ═══ Ticker tape ═══ */}
      <div className="relative -mt-1 bg-wine text-cream py-5 md:py-7 -rotate-1 scale-[1.04]">
        <Marquee items={tape} />
      </div>

      {/* ═══ Numbers ═══ */}
      <section className="px-3 md:px-6 pt-16 md:pt-24">
        <div className="rounded-[2.5rem] bg-wine p-3 md:p-5">
          <div className="rounded-[2rem] bg-cream text-wine p-8 md:p-14 grid md:grid-cols-3 gap-10 md:gap-6 text-center">
            {stats.map((s) => (
              <div key={s.label}>
                <p className="display text-vermilion text-[clamp(4.5rem,15vw,9.5rem)] leading-none">
                  <CountUp to={s.to} />
                </p>
                <p className="eyebrow mt-4">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ Folders ═══ */}
      <section className="container py-16 md:py-24">
        <SectionHeader title="Папки с рецепти" action={{ to: "/recipes", label: "Всички рецепти" }} />
        <ul className="no-scrollbar -mx-5 md:-mx-8 px-5 md:px-8 flex gap-5 overflow-x-auto snap-x pb-2">
          {recipeFolders.map((f) => (
            <li key={f.name} className="snap-start shrink-0 w-[92px] md:w-[116px]">
              <Link to={`/recipes?cat=${encodeURIComponent(f.name)}`} className="group block">
                <div className="arch aspect-[3/4] bg-muted ring-1 ring-border group-active:scale-95 transition-transform">
                  <img src={f.image} alt="" loading="lazy" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                </div>
                <span className="mt-3 block eyebrow text-center text-foreground group-hover:text-primary transition-colors">{f.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {/* ═══ Recipes ═══ */}
      <section className="container pb-16 md:pb-24">
        <SectionHeader title="Рецепти с много протеин" text="Калории и протеин са на показ – избираш бързо." action={{ to: "/recipes", label: "Виж всички" }} />
        <ul className="no-scrollbar -mx-5 md:-mx-8 px-5 md:px-8 flex gap-4 overflow-x-auto snap-x snap-mandatory pb-4 pt-2">
          {todayRecipes.map((r) => (
            <motion.li key={r.name} whileHover={{ y: -8 }} transition={{ type: "spring", stiffness: 300, damping: 20 }} className="snap-start shrink-0 w-[230px] md:w-[270px]">
              <Link
                to="/recipes"
                className="group block h-full rounded-[2rem] bg-[hsl(22,65%,90%)] hover:bg-[hsl(92,100%,82%)] text-[hsl(345,73%,13%)] p-3 pb-5 transition-colors duration-300"
              >
                <div className="arch aspect-[4/5] bg-[hsl(22,55%,85%)]">
                  <img src={r.image} alt={r.name} loading="lazy" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-3" />
                </div>
                <h3 className="mt-4 px-2 font-brand text-xl leading-snug">{r.name}</h3>
                <p className="mt-2 px-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-[hsl(345,22%,30%)]">
                  <span className="flex items-center gap-1"><Flame className="w-3.5 h-3.5 text-[hsl(10,80%,43%)]" aria-hidden="true" />{r.kcal} kcal</span>
                  <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" aria-hidden="true" />{r.minutes} мин</span>
                  <span className="font-semibold">{r.protein} г протеин</span>
                </p>
              </Link>
            </motion.li>
          ))}
        </ul>
      </section>

      {/* ═══ Diets ═══ */}
      <section className="container pb-16 md:pb-24">
        <SectionHeader title="Диети и режими" text="Без глутен, без лактоза, веган и още. Избери режим и комбинирай филтри." action={{ to: "/diets", label: "Всички режими" }} />
        <ul className="no-scrollbar -mx-5 md:-mx-8 px-5 md:px-8 flex gap-4 overflow-x-auto snap-x pb-4 pt-2">
          {diets.map((d) => (
            <motion.li key={d.slug} whileHover={{ y: -6 }} transition={{ type: "spring", stiffness: 300, damping: 20 }} className="snap-start shrink-0 w-[210px] md:w-[240px]">
              <Link to={`/diets/${d.slug}`} className="group block h-full rounded-[2rem] bg-card border border-border p-3 transition-colors hover:border-primary/40">
                <div className="relative arch aspect-[4/3] bg-muted">
                  <img src={d.image} alt="" loading="lazy" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                  <span className="absolute left-2.5 bottom-2.5 grid place-items-center w-10 h-10 rounded-full bg-card text-lg ring-2 ring-card shadow-md" aria-hidden="true">{d.emoji}</span>
                </div>
                <div className="px-2 pt-3 pb-1">
                  <p className="eyebrow text-primary">{dietCounts.get(d.slug)} рецепти</p>
                  <h3 className="mt-1 font-brand text-lg leading-snug text-foreground">{d.title}</h3>
                </div>
              </Link>
            </motion.li>
          ))}
        </ul>
      </section>

      {/* ═══ Drinks ═══ */}
      <section className="px-3 md:px-6 pb-16 md:pb-24">
        <div className="rounded-[2.5rem] bg-wine text-cream px-5 md:px-12 py-12 md:py-16">
          <div className="container px-0">
            <SectionHeader title="Напитки" text="Овкусени води, билкови чайове, смутита и топли напитки. Към тях – брояч за изпитата вода." action={{ to: "/drinks", label: "Всички напитки" }} onDark />
            <ul className="grid grid-cols-3 md:grid-cols-6 gap-3 md:gap-5">
              {homeDrinks.map((d, i) => (
                <li key={d.id}>
                  <Link to="/drinks" className="group block rounded-[1.75rem] p-3 text-center transition-transform hover:-translate-y-1" style={{ background: `${d.color}30` }}>
                    <div className={i % 2 ? "float-slower" : "float-slow"}>
                      <DrinkGlass drink={d} label={d.name} className="h-28 md:h-36 w-auto mx-auto" />
                    </div>
                    <p className="mt-2 text-xs md:text-sm font-semibold text-cream leading-snug line-clamp-2">{d.name}</p>
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" className="h-12 px-8 bg-cream text-wine hover:bg-cream/90" onClick={() => navigate("/drinks")}>Към напитките</Button>
              <Button size="lg" variant="outline" className="h-12 px-8 border-cream/50 bg-transparent text-cream hover:bg-cream hover:text-wine" onClick={() => navigate("/quit-kitchen")}>Кухня за отказване</Button>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ One day ═══ */}
      <section className="px-3 md:px-6">
        <div className="rounded-[2.5rem] bg-wine text-cream px-5 md:px-12 py-14 md:py-20">
          <div className="container px-0">
            <SectionHeader title="Един ден с нас" text="Сутрин, обед и вечер: малки стъпки, които се събират." onDark />
            <div className="grid md:grid-cols-3 gap-5">
              {day.map(({ Art, title, text, to, cta }, i) => (
                <Reveal key={title} delay={i * 0.08}>
                  <Link to={to} className="group block rounded-[2rem] bg-wine-2 p-3 transition-transform duration-300 hover:-translate-y-2">
                    <div className="rounded-3xl overflow-hidden">
                      <Art />
                    </div>
                    <div className="px-3 pt-5 pb-3">
                      <h3 className="font-brand text-3xl uppercase">{title}</h3>
                      <p className="mt-2 text-cream/80 leading-relaxed">{text}</p>
                      <span className="mt-4 inline-block eyebrow text-flame group-hover:text-cream transition-colors">{cta}</span>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══ Your day ═══ */}
      <section className="container py-16 md:py-24">
        <SectionHeader title="Твоят ден" text="Навици и малки предизвикателства, които отнемат минути." />
        <div className="grid lg:grid-cols-2 gap-5">
          <Reveal><DailyHabitTracker /></Reveal>
          <Reveal delay={0.05}><DisciplineChallenge /></Reveal>
        </div>
      </section>

      {/* ═══ Pause: breathing + weather ═══ */}
      <section className="container pb-16 md:pb-24">
        <SectionHeader title="Спри за минута" text="Подишай заедно с ритъма и виж какво е времето навън." />
        <div className="grid lg:grid-cols-2 gap-5 items-start">
          <Reveal><BoxBreathingWidget /></Reveal>
          <Reveal delay={0.05}><WeatherWidget /></Reveal>
        </div>
      </section>

      <DailyInspiration />

      {/* ═══ Explore ═══ */}
      <section className="container py-16 md:py-24">
        <SectionHeader title="Още за откриване" />
        <div className="grid grid-cols-2 lg:grid-cols-4 auto-rows-[170px] md:auto-rows-[210px] gap-3 md:gap-4">
          {explore.map((e) => (
            <Link
              key={e.to + e.title}
              to={e.to}
              className={`group relative overflow-hidden rounded-[2rem] bg-muted ${e.big ? "col-span-2 lg:row-span-2" : ""}`}
            >
              <img src={e.image} alt="" loading="lazy" className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-[hsl(345,73%,10%)]/85 via-[hsl(345,73%,10%)]/25 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4 md:p-6 text-white">
                <h3 className={`font-brand leading-tight ${e.big ? "text-3xl md:text-4xl" : "text-lg md:text-2xl"}`}>{e.title}</h3>
                <p className="mt-1 text-sm text-white/85">{e.text}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="container pb-16 md:pb-24">
        <MoodWorkoutSuggestion />
      </section>

      <Zelenchuko />

      {/* ═══ Health ambassadors ═══ */}
      <section className="px-3 md:px-6 py-16 md:py-24">
        <div className="relative overflow-hidden rounded-[2.5rem] bg-wine text-cream p-8 md:p-16">
          <div className="absolute -right-20 -top-20 w-72 h-72 rounded-full bg-flame/20 float-slow" aria-hidden="true" />
          <div className="absolute right-24 -bottom-24 w-56 h-56 rounded-full bg-wine-2 float-slower" aria-hidden="true" />
          <div className="relative max-w-3xl">
            <p className="eyebrow text-flame">Ученическа инициатива</p>
            <h2 className="display mt-4 text-[clamp(2.2rem,7vw,5rem)] text-cream">Посланици на здравето</h2>
            <p className="mt-5 text-cream/85 text-base md:text-lg leading-relaxed max-w-xl">
              Срещу тютюнопушенето и никотиновите продукти. Играй „Мит или факт“, научи как храната помага и виж какво правим.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" className="h-12 px-8 bg-cream text-wine hover:bg-cream/90 btn-sheen" onClick={() => navigate("/ambassadors")}>
                Научи повече
              </Button>
              <Button size="lg" variant="outline" className="h-12 px-8 border-cream/50 bg-transparent text-cream hover:bg-cream hover:text-wine" onClick={() => navigate("/tobacco-free")}>
                Живот без дим
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ Community ═══ */}
      <section className="container pb-16 md:pb-24">
        <SectionHeader title="Общност" text="Малките добри дела се събират." />
        <div className="grid lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2"><RippleCounter /></div>
          <div><RippleLeaderboard /></div>
        </div>
      </section>

      {/* ═══ Share ═══ */}
      <section className="container pb-16 md:pb-24">
        <div className="grid md:grid-cols-[1fr_auto] gap-8 items-center rounded-[2rem] bg-card border border-border p-6 md:p-10">
          <div className="max-w-md">
            <h2 className="display text-primary text-[clamp(1.8rem,4.5vw,2.8rem)]">Вземи го в джоба си</h2>
            <p className="mt-3 text-muted-foreground">Сканирай кода с телефона, за да отвориш сайта. След това можеш да го добавиш на началния екран.</p>
            <Button variant="outline" className="mt-5 border-primary/60 text-primary hover:bg-primary hover:text-primary-foreground" onClick={() => navigate("/install")}>
              Как се инсталира
            </Button>
          </div>
          <div className="justify-self-start md:justify-self-end">
            <QRCodeDisplay />
          </div>
        </div>
      </section>

      <Footer />
      <UsernameSetup open={showUsernameSetup} onOpenChange={setShowUsernameSetup} />
    </div>
  );
};

export default Home;

import { useMemo, useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { Copy, Plus, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import Footer from "@/components/Footer";
import { PageBanner } from "@/components/food/PageBanner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { addItems, clearAll, clearDone, removeItem, toggleItem, useShoppingList, type ShoppingItem } from "@/lib/shoppingList";
import { copyText } from "@/lib/copyText";

const ShoppingList = () => {
  const items = useShoppingList();
  const [text, setText] = useState("");

  const groups = useMemo(() => {
    const map = new Map<string, ShoppingItem[]>();
    items.forEach((i) => {
      const arr = map.get(i.source) ?? [];
      arr.push(i);
      map.set(i.source, arr);
    });
    return [...map.entries()];
  }, [items]);

  const done = items.filter((i) => i.done).length;

  const add = (e: FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    const n = addItems([text], "Моите неща");
    if (!n) toast("Това вече е в списъка");
    setText("");
  };

  const copy = async () => {
    const lines = groups.flatMap(([source, list]) => [source, ...list.map((i) => `${i.done ? "[x]" : "[ ]"} ${i.text}`), ""]);
    const ok = await copyText(lines.join("\n").trim());
    toast[ok ? "success" : "error"](ok ? "Списъкът е копиран" : "Не успях да копирам");
  };

  return (
    <div className="min-h-screen bg-background">
      <PageBanner
        eyebrow="Пазаруване"
        title="Списък за пазаруване"
        text="Добавяй съставки от рецептите и напитките с един бутон. Отбелязвай купеното. Списъкът се пази само на това устройство."
      />

      <section className="container py-10 md:py-14 max-w-3xl">
        <form onSubmit={add} className="flex gap-3">
          <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Добави нещо ръчно..." aria-label="Ново нещо в списъка" className="h-12 rounded-full bg-card text-base px-5" />
          <Button type="submit" className="h-12 px-6 shrink-0"><Plus className="w-4 h-4 mr-2" aria-hidden="true" />Добави</Button>
        </form>

        {items.length === 0 ? (
          <div className="mt-10 rounded-[2rem] bg-card border border-border p-10 text-center">
            <p className="font-brand text-2xl">Списъкът е празен</p>
            <p className="mt-2 text-muted-foreground">Отвори рецепта или напитка и натисни „Добави в списъка“.</p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Button asChild><Link to="/diets">Към рецептите</Link></Button>
              <Button asChild variant="outline"><Link to="/drinks">Към напитките</Link></Button>
            </div>
          </div>
        ) : (
          <>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <p className="font-semibold text-foreground" aria-live="polite">Купени: {done} от {items.length}</p>
              <div className="ml-auto flex flex-wrap gap-2">
                <Button variant="outline" size="sm" onClick={copy}><Copy className="w-4 h-4 mr-2" aria-hidden="true" />Копирай</Button>
                <Button variant="outline" size="sm" onClick={clearDone} disabled={done === 0}><Trash2 className="w-4 h-4 mr-2" aria-hidden="true" />Махни купените</Button>
                <Button variant="outline" size="sm" onClick={() => { if (window.confirm("Да изтрием ли целия списък?")) clearAll(); }}><X className="w-4 h-4 mr-2" aria-hidden="true" />Изчисти всичко</Button>
              </div>
            </div>

            <div className="mt-6 space-y-5">
              {groups.map(([source, list]) => (
                <div key={source} className="rounded-[2rem] bg-card border border-border p-5 md:p-6">
                  <h2 className="font-brand text-xl">{source}</h2>
                  <ul className="mt-3 divide-y divide-border">
                    {list.map((i) => (
                      <li key={i.id} className="flex items-center gap-3 py-2.5">
                        <Checkbox id={i.id} checked={i.done} onCheckedChange={() => toggleItem(i.id)} />
                        <label htmlFor={i.id} className={`flex-1 cursor-pointer ${i.done ? "line-through text-muted-foreground" : "text-foreground"}`}>{i.text}</label>
                        <button onClick={() => removeItem(i.id)} className="grid place-items-center w-8 h-8 rounded-full text-muted-foreground hover:bg-muted hover:text-foreground" aria-label={`Махни: ${i.text}`}>
                          <X className="w-4 h-4" />
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </>
        )}
      </section>

      <Footer />
    </div>
  );
};

export default ShoppingList;

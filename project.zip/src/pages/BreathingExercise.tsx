import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Wind, Play, Pause, RotateCcw, Timer } from "lucide-react";
import Footer from "@/components/Footer";
import { Reveal } from "@/components/Reveal";

type BreathPhase = "idle" | "inhale" | "hold" | "exhale" | "holdOut";

const TECHNIQUES = [
  {
    name: "4-7-8 Релаксация",
    description: "Вдишване 4сек → Задържане 7сек → Издишване 8сек",
    phases: { inhale: 4, hold: 7, exhale: 8, holdOut: 0 },
    rounds: 4,
    color: "hsl(var(--primary))",
  },
  {
    name: "Бокс дишане",
    description: "Равни фази по 4сек — използвано от Navy SEALs",
    phases: { inhale: 4, hold: 4, exhale: 4, holdOut: 4 },
    rounds: 4,
    color: "hsl(var(--accent))",
  },
  {
    name: "Енергизиращо",
    description: "Бързо дишане за енергия и фокус",
    phases: { inhale: 2, hold: 1, exhale: 2, holdOut: 0 },
    rounds: 8,
    color: "hsl(152, 55%, 42%)",
  },
];

const phaseLabels: Record<BreathPhase, string> = {
  idle: "Готови ли сте?",
  inhale: "Вдишайте",
  hold: "Задръжте",
  exhale: "Издишайте",
  holdOut: "Задръжте",
};

const BreathingExercise = () => {
  const [selectedTechnique, setSelectedTechnique] = useState(0);
  const [phase, setPhase] = useState<BreathPhase>("idle");
  const [isRunning, setIsRunning] = useState(false);
  const [currentRound, setCurrentRound] = useState(0);
  const [phaseTime, setPhaseTime] = useState(0);
  const [totalPhaseDuration, setTotalPhaseDuration] = useState(1);

  const technique = TECHNIQUES[selectedTechnique];

  const getNextPhase = useCallback(
    (current: BreathPhase): { phase: BreathPhase; duration: number } | null => {
      const p = technique.phases;
      switch (current) {
        case "idle":
        case "holdOut":
          return { phase: "inhale", duration: p.inhale };
        case "inhale":
          return p.hold > 0
            ? { phase: "hold", duration: p.hold }
            : { phase: "exhale", duration: p.exhale };
        case "hold":
          return { phase: "exhale", duration: p.exhale };
        case "exhale":
          return p.holdOut > 0
            ? { phase: "holdOut", duration: p.holdOut }
            : null; // end of round
        default:
          return null;
      }
    },
    [technique]
  );

  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setPhaseTime((prev) => {
        const next = prev + 0.05;
        if (next >= totalPhaseDuration) {
          // Move to next phase
          const nextPhase = getNextPhase(phase);
          if (nextPhase) {
            setPhase(nextPhase.phase);
            setTotalPhaseDuration(nextPhase.duration);
            return 0;
          } else {
            // End of round
            const newRound = currentRound + 1;
            if (newRound >= technique.rounds) {
              setIsRunning(false);
              setPhase("idle");
              setCurrentRound(0);
              return 0;
            }
            setCurrentRound(newRound);
            setPhase("inhale");
            setTotalPhaseDuration(technique.phases.inhale);
            return 0;
          }
        }
        return next;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [isRunning, phase, totalPhaseDuration, currentRound, technique, getNextPhase]);

  const start = () => {
    setIsRunning(true);
    setPhase("inhale");
    setCurrentRound(0);
    setPhaseTime(0);
    setTotalPhaseDuration(technique.phases.inhale);
  };

  const stop = () => {
    setIsRunning(false);
    setPhase("idle");
    setPhaseTime(0);
    setCurrentRound(0);
  };

  const progress = totalPhaseDuration > 0 ? phaseTime / totalPhaseDuration : 0;

  // Circle scale: inhale=grow, exhale=shrink, hold=stay
  const circleScale =
    phase === "inhale"
      ? 0.5 + progress * 0.5
      : phase === "exhale"
      ? 1 - progress * 0.5
      : phase === "hold" || phase === "holdOut"
      ? 1
      : 0.5;

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="relative mx-3 md:mx-6 mt-[calc(var(--nav-h)_+_0.75rem)] rounded-[2rem] min-h-[30vh] md:min-h-[38vh] flex items-end justify-center overflow-hidden pt-12 pb-8 md:pb-10">
        <div className="absolute inset-0 z-0">
          <img src="/images/breathing-hero.jpg" alt="Meditation" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10" />
        </div>
        <div className="relative z-10 text-center px-6">
          <Reveal>
            <Wind className="w-12 h-12 mx-auto mb-4 text-white" />
          </Reveal>
          <Reveal delay={0.1}>
            <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-3">
              Дишай спокойно
            </h1>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="text-lg text-white/85 max-w-md mx-auto">
              Управлявани дихателни упражнения за спокойствие, фокус и енергия
            </p>
          </Reveal>
        </div>
      </section>

      {/* Technique selector */}
      <section className="py-12 px-6">
        <div className="max-w-2xl mx-auto">
          <Reveal>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-16">
              {TECHNIQUES.map((t, i) => (
                <button
                  key={t.name}
                  onClick={() => {
                    if (!isRunning) setSelectedTechnique(i);
                  }}
                  className={`p-4 rounded-2xl border text-left transition-all duration-300 ${
                    selectedTechnique === i
                      ? "bg-primary/10 border-primary/40 shadow-md"
                      : "bg-card border-border hover:border-primary/20"
                  } ${isRunning ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                >
                  <h3 className="font-semibold text-sm text-foreground mb-1">{t.name}</h3>
                  <p className="text-xs text-muted-foreground">{t.description}</p>
                </button>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* Breathing circle */}
      <section className="pb-24 px-6">
        <div className="max-w-lg mx-auto flex flex-col items-center">
          {/* Animated circle */}
          <div className="relative w-72 h-72 md:w-96 md:h-96 mb-12">
            {/* Outer rings */}
            {[0.95, 0.85, 0.75].map((s, i) => (
              <motion.div
                key={i}
                className="absolute inset-0 rounded-full border border-primary/10"
                animate={{ scale: circleScale * s, opacity: isRunning ? 0.3 - i * 0.08 : 0.1 }}
                transition={{ duration: 0.15, ease: "linear" }}
              />
            ))}

            {/* Main circle */}
            <motion.div
              className="absolute inset-0 rounded-full flex items-center justify-center"
              style={{
                background: `radial-gradient(circle, hsl(var(--primary) / 0.15) 0%, hsl(var(--primary) / 0.05) 60%, transparent 70%)`,
              }}
              animate={{ scale: circleScale }}
              transition={{ duration: 0.15, ease: "linear" }}
            >
              <motion.div
                className="w-48 h-48 md:w-64 md:h-64 rounded-full flex items-center justify-center"
                style={{
                  background: `radial-gradient(circle, hsl(var(--primary) / 0.25) 0%, hsl(var(--primary) / 0.08) 70%)`,
                  boxShadow: isRunning ? `0 0 60px hsl(var(--primary) / 0.2)` : "none",
                }}
                animate={{ scale: circleScale }}
                transition={{ duration: 0.15, ease: "linear" }}
              >
                <div className="text-center">
                  <motion.p
                    key={phase}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-2xl md:text-3xl font-display font-bold text-foreground mb-1"
                  >
                    {phaseLabels[phase]}
                  </motion.p>
                  {isRunning && (
                    <p className="text-sm text-muted-foreground">
                      {Math.ceil(totalPhaseDuration - phaseTime)}с
                    </p>
                  )}
                </div>
              </motion.div>
            </motion.div>

            {/* Progress ring */}
            {isRunning && (
              <svg className="absolute inset-0 w-full h-full -rotate-90">
                <circle
                  cx="50%"
                  cy="50%"
                  r="48%"
                  fill="none"
                  stroke="hsl(var(--primary) / 0.15)"
                  strokeWidth="2"
                />
                <motion.circle
                  cx="50%"
                  cy="50%"
                  r="48%"
                  fill="none"
                  stroke="hsl(var(--primary))"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeDasharray="1000"
                  animate={{ strokeDashoffset: 1000 - progress * 1000 }}
                  transition={{ duration: 0.1, ease: "linear" }}
                />
              </svg>
            )}
          </div>

          {/* Round counter */}
          {isRunning && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-2 mb-8 text-sm text-muted-foreground"
            >
              <Timer className="w-4 h-4" />
              Рунд {currentRound + 1} от {technique.rounds}
            </motion.div>
          )}

          {/* Controls */}
          <div className="flex gap-4">
            {!isRunning ? (
              <Button
                size="lg"
                onClick={start}
                className="h-14 px-10 rounded-full text-base shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <Play className="mr-2 w-5 h-5" />
                Започни
              </Button>
            ) : (
              <>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={stop}
                  className="h-14 px-8 rounded-full text-base"
                >
                  <Pause className="mr-2 w-5 h-5" />
                  Пауза
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={stop}
                  className="h-14 px-8 rounded-full text-base"
                >
                  <RotateCcw className="mr-2 w-5 h-5" />
                  Нулирай
                </Button>
              </>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default BreathingExercise;
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS gamertag TEXT,
  ADD COLUMN IF NOT EXISTS health_goal TEXT,
  ADD COLUMN IF NOT EXISTS xp INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS bio TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS profiles_gamertag_unique ON public.profiles (lower(gamertag)) WHERE gamertag IS NOT NULL;

CREATE TABLE IF NOT EXISTS public.saved_recipes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  recipe_slug TEXT NOT NULL,
  recipe_name TEXT NOT NULL,
  chef_name TEXT,
  cooked_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, recipe_slug)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.saved_recipes TO authenticated;
GRANT ALL ON public.saved_recipes TO service_role;

ALTER TABLE public.saved_recipes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users manage own saved recipes" ON public.saved_recipes;
CREATE POLICY "Users manage own saved recipes"
ON public.saved_recipes
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);
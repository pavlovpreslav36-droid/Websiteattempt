// Проверка на рецептите и напитките: етикетите трябва да съвпадат със съставките.
// Пускане: node --experimental-strip-types scripts/validate-data.mjs
import { dietRecipes } from "../src/data/dietRecipes.ts";
import { drinks } from "../src/data/drinks.ts";
import { existsSync } from "node:fs";

const W = (list) => new RegExp(`(?<![а-яa-z])(?:${list.join("|")})`, "iu");

const GLUTEN = W(["брашно","хляб","тесто","макарон","спагет","кус-кус","булгур","ечемик","овес","питка","кори","галета","панир","грис","пшениц","ръж","спелта","бира","тортил","кракер","бисквит","фиде","юфка","нудъл","лазан","пица","гевре","козунак","соев сос","сейтан","талаш"]);
const LACTOSE = W(["мляко","сирене","кашкавал","кисело","йогурт","масло","сметана","извара","моцарела","пармезан","фета","рикота","кефир","айрян","сладолед","суроватк","казеин","краве","козе"]);
const MEAT = W(["месо","пиле","пилешк","телешк","свинск","агнешк","пуешк","пуйка","кайма","бекон","шунка","наденица","колбас","риба","сьомга","скумрия","тон","сардин","скарид","мид","калмар","хайвер","треска","бутчет","бульон от кост"]);
const EGG_HONEY = W(["яйц","мед","желатин"]);
const CARB = W(["ориз","картоф","макарон","хляб","брашно","овес","банан","нахут","леща","боб","царевиц","киноа","булгур","мед","захар","кус-кус","елда","просо","фурм","сушено грозде","сушени сливи","грах"]);
const SUGAR = W(["захар","мед","сироп","конфитюр","шоколад","сладко"]);

const ALLOWED_GLUTEN = ["нахутено брашно","оризово брашно","царевично брашно","бадемово брашно","елдово брашно","кокосово брашно"];
const ALLOWED_LACTOSE = ["бадемово мляко","кокосово мляко","оризово мляко","соево мляко","соево кисело мляко","кокосово кисело мляко","кокосово масло","фъстъчено масло","сусамово олио","безлактозно","без лактоза"];
const ALLOWED_MEAT = ["риба тон"]; // само за да не се бърка „тон“ с други думи
const clean = (s, allowed) => allowed.reduce((acc, a) => acc.split(a).join(" "), s.toLowerCase());

let errors = 0;
const fail = (id, msg) => { errors++; console.log(`✗ ${id}: ${msg}`); };

const ids = new Set();
for (const r of dietRecipes) {
  if (ids.has(r.id)) fail(r.id, "повторено id");
  ids.add(r.id);
  const text = r.ingredients.join(" | ");
  const t = new Set(r.tags);
  if (!existsSync("public" + r.photo)) fail(r.id, `липсва снимка ${r.photo}`);
  if (r.ingredients.length < 3 || r.steps.length < 2) fail(r.id, "твърде кратка рецепта");
  if (!(r.kcal > 0 && r.protein >= 0 && r.minutes > 0)) fail(r.id, "невалидни числа");
  if (t.has("gluten-free")) { const m = clean(text, ALLOWED_GLUTEN).match(GLUTEN); if (m) fail(r.id, `без глутен, но има „${m[0]}“`); }
  if (t.has("lactose-free")) { const m = clean(text, ALLOWED_LACTOSE).match(LACTOSE); if (m) fail(r.id, `без лактоза, но има „${m[0]}“`); }
  if (t.has("vegan")) {
    const a = clean(text, ALLOWED_LACTOSE).match(LACTOSE); if (a) fail(r.id, `веган, но има „${a[0]}“`);
    const b = text.match(MEAT); if (b) fail(r.id, `веган, но има „${b[0]}“`);
    const c = text.match(EGG_HONEY); if (c) fail(r.id, `веган, но има „${c[0]}“`);
  }
  if (t.has("vegetarian")) { const m = text.match(MEAT); if (m) fail(r.id, `вегетарианско, но има „${m[0]}“`); }
  if (t.has("low-carb")) { const m = text.match(CARB); if (m) fail(r.id, `малко въглехидрати, но има „${m[0]}“`); }
  if (t.has("sugar-free")) { const m = text.match(SUGAR); if (m) fail(r.id, `без захар, но има „${m[0]}“`); }
  if (t.has("high-protein")) {
    const min = r.meal === "Основно" || r.meal === "Супа" || r.meal === "Салата" ? 25 : 12;
    if (r.protein < min) fail(r.id, `много протеин, но само ${r.protein} г (минимум ${min})`);
  }
  if (/[a-z]/i.test(r.name.replace(/[A-Za-z]{0}/, "")) && /[a-z]/.test(r.name)) fail(r.id, "латински букви в името");
  for (const s of [...r.ingredients, ...r.steps]) if (/[a-z]/.test(s.replace(/°C/g, ""))) { fail(r.id, `латински букви в „${s}“`); break; }
}

const dids = new Set();
for (const d of drinks) {
  if (dids.has(d.id)) fail(d.id, "повторено id");
  dids.add(d.id);
  const text = d.ingredients.join(" | ");
  const t = new Set(d.tags);
  if (t.has("vegan")) {
    const a = clean(text, ALLOWED_LACTOSE).match(LACTOSE); if (a) fail(d.id, `веган, но има „${a[0]}“`);
    const c = text.match(EGG_HONEY); if (c) fail(d.id, `веган, но има „${c[0]}“`);
  }
  if (t.has("lactose-free")) { const m = clean(text, ALLOWED_LACTOSE).match(LACTOSE); if (m) fail(d.id, `без лактоза, но има „${m[0]}“`); }
  if (t.has("sugar-free")) { const m = text.match(SUGAR); if (m) fail(d.id, `без захар, но има „${m[0]}“`); }
  if (t.has("gluten-free")) { const m = clean(text, ALLOWED_GLUTEN).match(GLUTEN); if (m) fail(d.id, `без глутен, но има „${m[0]}“`); }
  if (t.has("caffeine-free") && /(зелен чай|кафе|какао)/i.test(text)) fail(d.id, "без кофеин, но има кофеин");
  if (d.ingredients.length < 2 || d.steps.length < 2) fail(d.id, "твърде кратка рецепта");
  if (!/^#[0-9A-Fa-f]{6}$/.test(d.color)) fail(d.id, "невалиден цвят");
  for (const s of [...d.ingredients, ...d.steps]) if (/[a-z]/.test(s.replace(/°C/g, ""))) { fail(d.id, `латински букви в „${s}“`); break; }
}

const by = (tag) => dietRecipes.filter((x) => x.tags.includes(tag)).length;
console.log(`\nРецепти: ${dietRecipes.length}  | без глутен ${by("gluten-free")}, без лактоза ${by("lactose-free")}, веган ${by("vegan")}, вегетарианско ${by("vegetarian")}, протеин ${by("high-protein")}, малко въглехидрати ${by("low-carb")}, без захар ${by("sugar-free")}, подкрепа ${by("quit")}, бързи ${by("quick")}`);
console.log(`Напитки: ${drinks.length}  | подкрепа ${drinks.filter((x) => x.tags.includes("quit")).length}, веган ${drinks.filter((x) => x.tags.includes("vegan")).length}`);
console.log(errors ? `\n${errors} грешки` : "\nВсичко е наред ✓");
process.exit(errors ? 1 : 0);

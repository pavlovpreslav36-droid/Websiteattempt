import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { genre, mood, language } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const isBg = language === "bg";

    const systemPrompt = `You are an expert music curator specializing in workout playlists. You have deep knowledge of all music genres and subgenres.

GENRE KNOWLEDGE:
- "drill": NY/UK drill, hoodtap - Sdot Go, Kay Flock, DD Osama, Sha Ek, Pop Smoke, Fivio Foreign, Central Cee, Digga D, Ice Spice, Sheff G, Sleepy Hallow, Bizzy Banks, Dusty Locane
- "trap": Trap/Hip-Hop - Travis Scott, Future, 21 Savage, Metro Boomin, Young Thug, Gunna, Lil Baby, Migos, Playboi Carti, Lil Uzi Vert, Don Toliver, Roddy Ricch
- "oldschool": Old School Hip-Hop/DJs - Eminem, Snoop Dogg, The Notorious B.I.G., DMX, 2Pac, Dr. Dre, Jay-Z, Nas, Wu-Tang Clan, Ice Cube, 50 Cent, Xzibit, DJ Premier, DJ Jazzy Jeff, Grandmaster Flash, Eric B & Rakim, Run-DMC
- "pop_edm": Pop/EDM - The Weeknd, Dua Lipa, Calvin Harris, Martin Garrix, Avicii, David Guetta, Marshmello, Skrillex, Tiësto, Zedd, Kygo, Alan Walker
- "rock": Rock/Metal - Metallica, AC/DC, Linkin Park, Imagine Dragons, Foo Fighters, System of a Down, Rage Against the Machine, Avenged Sevenfold, Five Finger Death Punch, Disturbed, Slipknot

RULES:
- Generate EXACTLY 10 tracks for the given genre
- Each track MUST be a real, existing song
- Include the Spotify search query that would find this exact track
- Mix well-known hits with slightly deeper cuts
- All tracks should be high-energy and workout-appropriate
- Respond ONLY with valid JSON, no markdown`;

    const userPrompt = `Generate a workout playlist for genre: "${genre}"${mood ? `, mood: "${mood}"` : ""}.

Return JSON:
{
  "playlist_name": "creative playlist name${isBg ? " in Bulgarian" : ""}",
  "playlist_description": "short description${isBg ? " in Bulgarian" : ""}",
  "tracks": [
    {
      "title": "song title",
      "artist": "artist name",
      "spotify_query": "artist - title",
      "bpm_estimate": 140,
      "energy": "high/medium/low"
    }
  ],
  "spotify_search_url": "spotify search URL for this genre workout playlist"
}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded, try again shortly" }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required" }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI error:", response.status, t);
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";
    
    // Parse JSON from response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("Invalid AI response format");
    
    const playlist = JSON.parse(jsonMatch[0]);

    return new Response(JSON.stringify(playlist), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("generate-playlist error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, checkIPBlocked, logSecurityEvent, getClientIP, detectSuspiciousActivity, blockIP } from '../_shared/security.ts';

interface OpenFoodFactsProduct {
  code?: string;
  product_name?: string;
  product_name_en?: string;
  product_name_bg?: string;
  generic_name?: string;
  brands?: string;
  categories?: string;
  categories_tags?: string[];
  origins?: string;
  manufacturing_places?: string;
  quantity?: string;
  serving_size?: string;
  image_url?: string;
  image_front_url?: string;
  nutriments?: {
    'energy-kcal_100g'?: number;
    carbohydrates_100g?: number;
    proteins_100g?: number;
    fat_100g?: number;
    sugars_100g?: number;
    fiber_100g?: number;
    salt_100g?: number;
    'saturated-fat_100g'?: number;
    sodium_100g?: number;
    calcium_100g?: number;
    iron_100g?: number;
    'vitamin-a_100g'?: number;
    'vitamin-c_100g'?: number;
    'vitamin-d_100g'?: number;
    potassium_100g?: number;
    magnesium_100g?: number;
  };
  ingredients_text?: string;
  ingredients_text_bg?: string;
  ingredients_text_en?: string;
  nutriscore_grade?: string;
  nova_group?: number;
  ecoscore_grade?: string;
  labels?: string;
  labels_tags?: string[];
  allergens_tags?: string[];
  traces_tags?: string[];
  stores?: string;
  countries_tags?: string[];
}

// Try multiple Open Food Facts endpoints for better coverage
async function fetchFromOpenFoodFacts(barcode: string): Promise<OpenFoodFactsProduct | null> {
  // Try endpoints in order: Bulgarian, world
  const endpoints = [
    `https://bg.openfoodfacts.org/api/v2/product/${barcode}.json`,
    `https://world.openfoodfacts.org/api/v2/product/${barcode}.json`,
  ];

  for (const url of endpoints) {
    try {
      const response = await fetch(url, {
        headers: { 'User-Agent': 'HealthyLifeApp/2.0 (contact@healthylife.bg)' }
      });
      
      if (!response.ok) continue;
      
      const data = await response.json();
      if (data.status !== 1 || !data.product) continue;
      
      const product = data.product as OpenFoodFactsProduct;
      // Only accept if product has a name and some nutritional data
      if (product.product_name || product.product_name_en || product.product_name_bg) {
        product.code = barcode;
        return product;
      }
    } catch (error) {
      console.error(`Error fetching from ${url}:`, error);
      continue;
    }
  }
  
  return null;
}

// Get the best available product name with full details
function getBestProductName(product: OpenFoodFactsProduct): string {
  // Prefer localized name, then generic, then English
  const name = product.product_name_bg || product.product_name || product.product_name_en || 'Неизвестен продукт';
  const brand = product.brands || '';
  const quantity = product.quantity || '';
  
  let fullName = name;
  
  // Add brand if not already in the name
  if (brand && !name.toLowerCase().includes(brand.toLowerCase())) {
    fullName = `${name} (${brand})`;
  }
  
  // Add quantity/size info for variant identification
  if (quantity && !fullName.includes(quantity)) {
    fullName += ` — ${quantity}`;
  }
  
  return fullName;
}

// Get the best available ingredients text
function getBestIngredients(product: OpenFoodFactsProduct): string | null {
  return product.ingredients_text_bg || product.ingredients_text || product.ingredients_text_en || null;
}

function calculateHealthScore(product: OpenFoodFactsProduct): number {
  if (product.nutriscore_grade) {
    const scores: Record<string, number> = { 'a': 9, 'b': 7, 'c': 5, 'd': 3, 'e': 1 };
    return scores[product.nutriscore_grade.toLowerCase()] || 5;
  }
  
  let score = 5;
  const n = product.nutriments || {};
  
  if (n.sugars_100g !== undefined) {
    if (n.sugars_100g < 5) score += 1;
    else if (n.sugars_100g > 15) score -= 2;
  }
  if (n.fiber_100g !== undefined && n.fiber_100g > 3) score += 1;
  if (n.proteins_100g !== undefined && n.proteins_100g > 5) score += 1;
  if (n.fat_100g !== undefined && n.fat_100g > 20) score -= 1;
  if (n['saturated-fat_100g'] !== undefined && n['saturated-fat_100g'] > 5) score -= 1;
  if (n.salt_100g !== undefined && n.salt_100g > 1.5) score -= 1;
  
  return Math.max(1, Math.min(10, score));
}

function getRichInNutrients(product: OpenFoodFactsProduct): string[] {
  const n = product.nutriments || {};
  const richIn: string[] = [];
  
  if (n.proteins_100g && n.proteins_100g > 10) richIn.push('🥩 Протеин');
  if (n.fiber_100g && n.fiber_100g > 5) richIn.push('🌾 Фибри');
  if (n.calcium_100g && n.calcium_100g > 120) richIn.push('🦴 Калций');
  if (n.iron_100g && n.iron_100g > 2) richIn.push('💪 Желязо');
  if (n['vitamin-c_100g'] && n['vitamin-c_100g'] > 15) richIn.push('🍊 Витамин C');
  if (n['vitamin-a_100g'] && n['vitamin-a_100g'] > 150) richIn.push('👁️ Витамин A');
  if (n['vitamin-d_100g'] && n['vitamin-d_100g'] > 1) richIn.push('☀️ Витамин D');
  if (n.potassium_100g && n.potassium_100g > 300) richIn.push('🍌 Калий');
  if (n.magnesium_100g && n.magnesium_100g > 50) richIn.push('⚡ Магнезий');
  
  return richIn;
}

function getHealthBenefits(product: OpenFoodFactsProduct): string[] {
  const n = product.nutriments || {};
  const benefits: string[] = [];
  
  if (n.calcium_100g && n.calcium_100g > 100) {
    benefits.push('🦴 Добър за костите - съдържа калций за здрави кости и зъби');
  }
  if (n.proteins_100g && n.proteins_100g > 15) {
    benefits.push('💪 Изгражда мускули - високо съдържание на протеин за мускулна маса');
  }
  if (n.fiber_100g && n.fiber_100g > 5) {
    benefits.push('🌿 Подпомага храносмилането - богат на фибри за здрава чревна флора');
  }
  if (n.iron_100g && n.iron_100g > 2) {
    benefits.push('❤️ Подкрепя кръвообращението - съдържа желязо за здрава кръв');
  }
  if (n['vitamin-c_100g'] && n['vitamin-c_100g'] > 20) {
    benefits.push('🛡️ Укрепва имунитета - богат на витамин C');
  }
  if (n['vitamin-a_100g'] && n['vitamin-a_100g'] > 200) {
    benefits.push('👁️ Подобрява зрението - съдържа витамин A');
  }
  if (n['vitamin-d_100g'] && n['vitamin-d_100g'] > 1) {
    benefits.push('☀️ Здрави кости и имунитет - източник на витамин D');
  }
  if (n.potassium_100g && n.potassium_100g > 400) {
    benefits.push('💓 Подкрепя сърцето - богат на калий за здраво сърце');
  }
  if (n.sugars_100g !== undefined && n.sugars_100g < 3 && n.fiber_100g && n.fiber_100g > 2) {
    benefits.push('📉 Подходящ за диабетици - ниско съдържание на захар');
  }
  
  return benefits;
}

function generateRecommendation(product: OpenFoodFactsProduct, healthScore: number): string {
  const n = product.nutriments || {};
  const parts: string[] = [];
  
  if (healthScore >= 7) {
    parts.push('✅ Този продукт е отличен избор за здравословно хранене!');
  } else if (healthScore >= 4) {
    parts.push('⚖️ Този продукт може да се консумира умерено като част от балансирана диета.');
  } else {
    parts.push('⚠️ Препоръчва се ограничена консумация на този продукт.');
  }
  
  if (n.sugars_100g !== undefined && n.sugars_100g > 10) {
    parts.push(`Съдържа ${n.sugars_100g.toFixed(1)}г захар на 100г.`);
  }
  if (n.salt_100g !== undefined && n.salt_100g > 1.5) {
    parts.push('Високо съдържание на сол.');
  }
  if (n['saturated-fat_100g'] !== undefined && n['saturated-fat_100g'] > 5) {
    parts.push('Внимание: високо съдържание на наситени мазнини.');
  }
  
  return parts.join(' ');
}

// Use AI to verify and enhance OFF data for accuracy
async function verifyWithAI(offProduct: OpenFoodFactsProduct, barcode: string): Promise<Record<string, unknown> | null> {
  try {
    const offName = getBestProductName(offProduct);
    const offIngredients = getBestIngredients(offProduct);
    
    const prompt = `Баркод: ${barcode}
Open Food Facts върна следния продукт: "${offName}"
Съставки от OFF: ${offIngredients || 'няма'}
Категория от OFF: ${offProduct.categories || 'няма'}

Задача: Провери дали тази информация изглежда правилна за този баркод. Ако имаш по-точна информация за ТОЧНИЯ ВКУС/ВАРИАНТ на продукта с този баркод, коригирай го. Например ако OFF казва "Сок портокал" но баркодът всъщност е за "Сок ябълка", коригирай името.

Отговори САМО с JSON:
{
  "verified": true/false,
  "correctedName": "коригирано име ако е нужно, или null",
  "correctedIngredients": "коригирани съставки ако е нужно, или null",
  "additionalBenefits": ["допълнителни ползи ако има"],
  "flavorNote": "бележка за конкретния вкус/вариант ако е различен"
}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${Deno.env.get("LOVABLE_API_KEY")}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: "Ти си експерт по продукти на българския пазар. Познаваш всички баркодове, марки, вкусове и варианти. Отговаряш САМО с валиден JSON." },
          { role: "user", content: prompt }
        ],
        temperature: 0.1
      })
    });

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    if (!content) return null;
    
    const match = content.match(/\{[\s\S]*\}/);
    if (!match) return null;
    
    return JSON.parse(match[0]);
  } catch (error) {
    console.error('AI verification error:', error);
    return null;
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });
  const ipAddress = getClientIP(req);

  try {
    const ipCheck = await checkIPBlocked(ipAddress);
    if (!ipCheck.allowed) return new Response(JSON.stringify({ error: 'ACCESS_DENIED', redirect: '/blocked' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});

    const authHeader = req.headers.get('Authorization');
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!, 
      Deno.env.get('SUPABASE_ANON_KEY')!,
      authHeader ? { global: { headers: { Authorization: authHeader }}} : {}
    );
    
    let userId: string | null = null;
    if (authHeader && authHeader !== `Bearer ${Deno.env.get('SUPABASE_ANON_KEY')}`) {
      const { data: { user }} = await supabase.auth.getUser();
      userId = user?.id || null;
    }

    const { productName, manufacturer, barcode } = await req.json();
    if (!productName || productName.length > 200) return new Response(JSON.stringify({ error: 'Invalid product name' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});

    if (await detectSuspiciousActivity({ productName, manufacturer, barcode }, ipAddress)) {
      await blockIP(ipAddress, 'Suspicious input', true);
      return new Response(JSON.stringify({ error: 'SUSPICIOUS_ACTIVITY', redirect: '/blocked' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
    }

    const barcodePattern = /^\d{8,13}$/;
    const detectedBarcode = barcode || (barcodePattern.test(productName.trim()) ? productName.trim() : null);
    
    // Try Open Food Facts first for barcodes
    if (detectedBarcode) {
      console.log('Looking up barcode:', detectedBarcode);
      const offProduct = await fetchFromOpenFoodFacts(detectedBarcode);
      
      if (offProduct && (offProduct.product_name || offProduct.product_name_en || offProduct.product_name_bg)) {
        const n = offProduct.nutriments || {};
        const healthScore = calculateHealthScore(offProduct);
        
        // Cross-verify with AI to catch wrong flavors/variants
        const aiVerification = await verifyWithAI(offProduct, detectedBarcode);
        
        let finalName = getBestProductName(offProduct);
        let finalIngredients = getBestIngredients(offProduct);
        let extraBenefits: string[] = [];
        
        if (aiVerification) {
          if (aiVerification.correctedName && aiVerification.verified === false) {
            finalName = aiVerification.correctedName as string;
            console.log('AI corrected product name:', finalName);
          }
          if (aiVerification.correctedIngredients) {
            finalIngredients = aiVerification.correctedIngredients as string;
          }
          if (aiVerification.additionalBenefits && Array.isArray(aiVerification.additionalBenefits)) {
            extraBenefits = aiVerification.additionalBenefits as string[];
          }
          if (aiVerification.flavorNote) {
            // Append flavor note to the name if relevant
            const note = aiVerification.flavorNote as string;
            if (note && note !== 'null' && !finalName.toLowerCase().includes(note.toLowerCase())) {
              finalName += ` [${note}]`;
            }
          }
        }
        
        const baseBenefits = getHealthBenefits(offProduct);
        
        const productInfo = {
          name: finalName,
          barcode: detectedBarcode,
          calories: Math.round(n['energy-kcal_100g'] || 0),
          carbs: Math.round((n.carbohydrates_100g || 0) * 10) / 10,
          protein: Math.round((n.proteins_100g || 0) * 10) / 10,
          fats: Math.round((n.fat_100g || 0) * 10) / 10,
          sugars: Math.round((n.sugars_100g || 0) * 10) / 10,
          fiber: Math.round((n.fiber_100g || 0) * 10) / 10,
          saturatedFat: Math.round((n['saturated-fat_100g'] || 0) * 10) / 10,
          salt: Math.round((n.salt_100g || 0) * 100) / 100,
          isHealthy: healthScore >= 6,
          healthScore,
          nutriScore: offProduct.nutriscore_grade?.toUpperCase() || null,
          novaGroup: offProduct.nova_group || null,
          recommendation: generateRecommendation(offProduct, healthScore),
          ingredients: finalIngredients,
          richIn: getRichInNutrients(offProduct),
          healthBenefits: [...baseBenefits, ...extraBenefits],
          category: offProduct.categories?.split(',')[0]?.trim() || null,
          origin: offProduct.origins || offProduct.manufacturing_places || null,
          labels: offProduct.labels || null,
          source: 'Open Food Facts + AI верификация'
        };
        
        await logSecurityEvent(ipAddress, userId, 'PRODUCT_ANALYSIS', 'low', { isBarcode: true, source: 'openfoodfacts+ai', barcode: detectedBarcode });
        return new Response(JSON.stringify(productInfo), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
      }
      console.log('Product not found in Open Food Facts, falling back to AI');
    }

    // Fallback to AI for product names or unknown barcodes
    const prompt = detectedBarcode 
      ? `Анализирай продукт със баркод ${detectedBarcode}${manufacturer ? ` от производител ${manufacturer}` : ''}. Трябва да дадеш ТОЧНИЯ продукт за този баркод - правилния вкус, размер и вариант. Ако не познаваш точно този баркод, кажи най-вероятния продукт но отбележи че не си 100% сигурен.`
      : `Анализирай продукт: ${productName}${manufacturer ? ` от ${manufacturer}` : ''}. Дай подробна информация.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${Deno.env.get("LOVABLE_API_KEY")}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: `Ти си експерт по хранене, специализиран в продукти от българския пазар. Познаваш всички популярни марки и продукти продавани в България включително: Тандем, Bella, Кенар, Бисер, Верея, Маджаров, Престиж, Своге, Победа, Шоколин, Милка, Нестле, Данон, Активиа, Закуска, LB Булгарикум, Елена, Карлсберг, Каменица, Загорка, Пиринско, Деви, Олинеза, Дерони, Компас, Витоша, CBA, Lidl, Kaufland, Billa марки, и всички останали. Също познаваш български традиционни продукти: сирене, кашкавал, кисело мляко, лютеница, айвар, баница, суджук, луканка, пастърма, шопска салата продукти и др.

КРИТИЧНО ВАЖНО: 
- За БАРКОДОВЕ: Трябва да идентифицираш ТОЧНИЯ продукт - правилната марка, ПРАВИЛНИЯ ВКУС, правилния размер. Всеки баркод е уникален за конкретен вариант!
- Давай САМО реални, точни хранителни стойности базирани на истинска информация. НЕ измисляй данни.
- Ако не си сигурен за точните стойности, дай най-близките реалистични стойности за този тип продукт.

Отговаряй САМО с валиден JSON:
{
  "name": "ПЪЛНО име на продукта включително марка, вкус и размер",
  "calories": число,
  "carbs": число,
  "protein": число,
  "fats": число,
  "sugars": число,
  "fiber": число,
  "saturatedFat": число,
  "salt": число,
  "isHealthy": true/false,
  "healthScore": 1-10,
  "recommendation": "препоръка на български",
  "ingredients": "списък съставки или null",
  "richIn": ["🥩 Протеин", "🌾 Фибри"],
  "healthBenefits": ["🦴 Добър за костите - обяснение", "💪 Изгражда мускули - обяснение"],
  "category": "категория продукт",
  "origin": "произход или null"
}
Стойностите са на 100г. Дай реалистични healthBenefits базирани на хранителните стойности.` },
          { role: "user", content: prompt }
        ],
        temperature: 0.1
      })
    });

    const data = await response.json();
    const productInfo = JSON.parse(data.choices[0].message.content.match(/\{[\s\S]*\}/)[0]);
    productInfo.source = detectedBarcode ? 'AI (баркод)' : 'AI';
    if (detectedBarcode) productInfo.barcode = detectedBarcode;
    
    await logSecurityEvent(ipAddress, userId, 'PRODUCT_ANALYSIS', 'low', { isBarcode: !!detectedBarcode, source: 'ai', barcode: detectedBarcode });
    return new Response(JSON.stringify(productInfo), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
  } catch (error) {
    console.error('Function error:', error);
    await logSecurityEvent(ipAddress, null, 'FUNCTION_ERROR', 'medium', { error: error instanceof Error ? error.message : 'Unknown error' });
    return new Response(JSON.stringify({ error: 'An error occurred. Please try again.' }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
  }
});

import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { checkIPBlocked, getClientIP, logSecurityEvent } from '../_shared/security.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
const ANON_RATE_LIMIT = 20;
const RATE_WINDOW_MS = 60 * 60 * 1000;

function checkRateLimit(key: string): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(key);
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(key, { count: 1, resetAt: now + RATE_WINDOW_MS });
    return true;
  }
  entry.count++;
  return entry.count <= ANON_RATE_LIMIT;
}

function getSystemPrompt(language: string): string {
  if (language === 'bg') {
    return `Ти си супер дружелюбен и топъл AI приятел на "Стъпки към здравословен живот" — уеб приложение за здравословен начин на живот. Името ти е Здравко 🌟.

ЛИЧНОСТ:
- Топъл, насърчаващ, позитивен — като приятел, който държи на потребителя
- Използвай "ти", не "Вие" — по-близко звучи
- Радвай се на въпроси, празнувай малките победи на потребителя
- Бъди игрив, но никога не подигравателен

ПРАВИЛА ЗА ОТГОВОРИ:
- Отговаряй КРАТКО — макс. 3-4 изречения, освен ако потребителят изрично поиска подробен отговор
- Започвай естествено и топло, без да повтаряш въпроса и без благодарности
- Използвай 1-2 подходящи емоджи за топлина ✨ (не повече)
- За сложни теми: кратък отговор + "Искаш ли повече детайли?"
- Можеш да анализираш снимки на храни

ФОРМАТИРАНЕ (ВАЖНО — Markdown):
- При **списъци** (песни, рецепти, упражнения, съвети) винаги използвай булети \`-\` или номериран списък
- За **песни**: формат \`**Изпълнител — Заглавие**\` (един ред на песен)
- За **рецепти/тренировки**: кратко заглавие с **bold**, после булети със стъпки
- Използвай **bold** за ключови думи, не цели изречения
- При препратки към секции от сайта използвай линкове в формат \`[Име на секция](/път)\`
- Завършвай с кратък насърчителен ред или въпрос (1 ред), не с дълъг параграф
- НЕ използвай заглавия (# ##) — твърде формално за чат

ФУНКЦИИ НА САЙТА (помогни на потребителите да ги намерят):
- 🏠 Начало (/) — главна страница с функции и времето
- 🧠 Куиз (/quiz) — здравословен куиз с класация
- 🍽️ Рецепти (/recipes) — AI генерирани рецепти по кухни
- 📊 Здравен дашборд (/health-dashboard) — следене на вода, стъпки, калории
- 🍎 Хранителен дневник (/meal-journal) — записване на ястия с AI анализ
- 📅 Планер за хранене (/meal-planner) — седмичен план
- 🔍 Скенер (/product-scanner) — сканиране на продукти
- 🎵 Тренировъчна музика (/workout-music) — AI плейлисти по жанрове (Drill, Hip-Hop, Pop и др.)
- 🧘 Дихателни упражнения (/breathing) — техники за релаксация
- 🌍 Глобус (/globe) — интерактивен 3D глобус
- ♈ Здравен хороскоп (/health-horoscope) — AI хороскоп по зодия
- 📈 Седмичен отчет (/weekly-report) — AI анализ на здравето
- 🏆 Класация (/social) — социална класация и предизвикателства
- ⚙️ Настройки (/settings) — език, тема, AI помощник
- 📲 Инсталиране (/install) — PWA инсталация

ПРЕПОРЪЧВАНЕ НА МУЗИКА:
Когато потребителят иска песни/музика, препоръчай конкретни песни с изпълнител и заглавие.
Познаваш добре: Drill (Sdot Go, Kay Flock), Hip-Hop (Eminem, Snoop Dogg, Biggie, DMX), Pop, Rock, EDM, Bulgarian music.
Предложи 3-5 песни в кратък списък. Спомени, че могат да генерират плейлист в секцията "Тренировъчна музика".

Отговаряй САМО на български.`;
  }
  
  return `You are a super friendly, warm AI buddy for "Steps to a Healthy Life" — a health & wellness web app. Your name is Zdravko 🌟.

PERSONALITY:
- Warm, encouraging, upbeat — like a caring friend
- Celebrate small wins, cheer the user on
- Playful but never sarcastic or dismissive

RESPONSE RULES:
- Keep answers SHORT — max 3-4 sentences, unless user explicitly asks for detail
- Open warmly and naturally, no question-restating, no thanking
- Use 1-2 fitting emojis for warmth ✨ (not more)
- For complex topics: brief answer + "Want more details?"
- Can analyze food photos

FORMATTING (IMPORTANT — Markdown):
- For **lists** (songs, recipes, exercises, tips) ALWAYS use \`-\` bullets or a numbered list
- For **songs**: format \`**Artist — Title**\` (one per line)
- For **recipes/workouts**: short **bold** title, then bulleted steps
- Use **bold** for key words only, not whole sentences
- When referencing site sections, use links like \`[Section name](/path)\`
- End with a short encouraging line or question (1 line), not a long paragraph
- Do NOT use headings (# ##) — too formal for chat

WEBSITE FEATURES (help users find them):
- 🏠 Home (/) — main page with features and weather
- 🧠 Quiz (/quiz) — health quiz with leaderboard
- 🍽️ Recipes (/recipes) — AI-generated recipes by cuisine
- 📊 Health Dashboard (/health-dashboard) — track water, steps, calories
- 🍎 Meal Journal (/meal-journal) — log meals with AI analysis
- 📅 Meal Planner (/meal-planner) — weekly meal plan
- 🔍 Scanner (/product-scanner) — scan food products
- 🎵 Workout Music (/workout-music) — AI playlists by genre (Drill, Hip-Hop, Pop, etc.)
- 🧘 Breathing Exercises (/breathing) — relaxation techniques
- 🌍 Globe (/globe) — interactive 3D globe
- ♈ Health Horoscope (/health-horoscope) — AI horoscope by zodiac
- 📈 Weekly Report (/weekly-report) — AI health analysis
- 🏆 Leaderboard (/social) — social leaderboard and challenges
- ⚙️ Settings (/settings) — language, theme, AI helper
- 📲 Install (/install) — PWA installation

MUSIC RECOMMENDATIONS:
When user asks for songs/music, recommend specific songs with artist and title.
You know well: Drill (Sdot Go, Kay Flock), Hip-Hop (Eminem, Snoop Dogg, Biggie, DMX), Pop, Rock, EDM.
Suggest 3-5 songs in a short list. Mention they can generate playlists in the "Workout Music" section.

Respond ONLY in English.`;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const clientIP = getClientIP(req);
    const ipCheck = await checkIPBlocked(clientIP);
    if (!ipCheck.allowed) {
      return new Response(JSON.stringify({ error: 'Access denied' }), {
        status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const authHeader = req.headers.get('Authorization');
    let userId: string | null = null;
    
    if (authHeader?.startsWith('Bearer ')) {
      const supabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_ANON_KEY')!,
        { global: { headers: { Authorization: authHeader } } }
      );
      const { data: { user } } = await supabase.auth.getUser();
      if (user) userId = user.id;
    }

    if (!userId) {
      if (!checkRateLimit(`anon:${clientIP}`)) {
        await logSecurityEvent(clientIP, null, 'RATE_LIMIT_EXCEEDED', 'medium', { endpoint: 'ai-chat' });
        return new Response(JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }), {
          status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    const { messages, language, stream: useStream } = await req.json();

    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 50) {
      return new Response(JSON.stringify({ error: 'Invalid messages' }), { 
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    for (const msg of messages) {
      if (!msg.role || (!msg.content && !msg.imageData)) {
        return new Response(JSON.stringify({ error: 'Invalid message format' }), { 
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      if (msg.content && msg.content.length > 10000) {
        return new Response(JSON.stringify({ error: 'Message content too long' }), { 
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      if (msg.imageData && msg.imageData.length > 10_000_000) {
        return new Response(JSON.stringify({ error: 'Image too large' }), { 
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: 'API key not configured' }), { 
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const formattedMessages = messages.map((m: { role: string; content: string; imageData?: string }) => {
      if (m.imageData) {
        return {
          role: m.role,
          content: [
            { type: 'text', text: m.content || (language === 'bg' ? 'Анализирай това изображение.' : 'Analyze this image.') },
            { type: 'image_url', image_url: { url: m.imageData } }
          ]
        };
      }
      return { role: m.role, content: m.content };
    });

    const systemPrompt = getSystemPrompt(language);

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: { 
        'Authorization': `Bearer ${LOVABLE_API_KEY}`, 
        'Content-Type': 'application/json' 
      },
      body: JSON.stringify({ 
        model: 'google/gemini-2.5-flash', 
        messages: [{ role: 'system', content: systemPrompt }, ...formattedMessages],
        stream: !!useStream
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }), { 
          status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: 'AI credits exhausted.' }), { 
          status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      return new Response(JSON.stringify({ error: 'AI service temporarily unavailable' }), { 
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Streaming response
    if (useStream) {
      return new Response(response.body, {
        headers: { ...corsHeaders, 'Content-Type': 'text/event-stream' }
      });
    }

    // Non-streaming response
    const data = await response.json();
    const messageContent = data.choices?.[0]?.message?.content;
    if (!messageContent) {
      return new Response(JSON.stringify({ error: 'Empty AI response' }), { 
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ message: messageContent }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Function error:', error);
    return new Response(JSON.stringify({ error: 'An error occurred. Please try again.' }), { 
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});

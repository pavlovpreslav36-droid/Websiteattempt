import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { checkIPBlocked, getClientIP, logSecurityEvent } from '../_shared/security.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
const ANON_RATE_LIMIT = 10;
const USER_RATE_LIMIT = 60;
const RATE_WINDOW_MS = 60 * 60 * 1000;
const MAX_FRAMES = 4;
const MAX_FRAME_BYTES = 6_000_000; // ~6MB per frame after base64

function checkRateLimit(key: string, limit: number): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(key);
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(key, { count: 1, resetAt: now + RATE_WINDOW_MS });
    return true;
  }
  entry.count++;
  return entry.count <= limit;
}

function systemPrompt(language: string): string {
  const isBg = language === 'bg';
  if (isBg) {
    return `Ти си експерт диетолог и хранителен анализатор с топ-ниво на точност.
Получаваш една или повече снимки/видео-кадри от ястие или продукт.
Твоята задача: разгледай ВНИМАТЕЛНО всеки кадър и извлечи МАКСИМАЛНО ТОЧНА хранителна информация.

ПРАВИЛА:
- Идентифицирай всяка съставка/елемент (плод, месо, сос, гарнитура, напитка, опаковка)
- Оцени РЕАЛНИЯ размер на порцията (в грамове) — използвай съседни обекти за мащаб (вилица, чиния, ръка)
- За опаковани продукти: ако виждаш етикета, прочети стойностите ОТ ЕТИКЕТА (без догадки)
- За готвени ястия: използвай стандартни рецептурни таблици (USDA, BDA)
- НЕ изобретявай числа — ако не си сигурен, дай реалистичен диапазон в средата
- Винаги връщай числа на 100г и общо за порцията
- Откривай алергени: глутен, лактоза, ядки, яйца, соя, риба, ракообразни, сусам
- Здравен резултат 0-100: 100 = идеално балансирано, <40 = силно преработено
- Предупреждения: висок натрий, много захар, преработено, мазно и т.н.

Винаги извикай инструмента analyze_meal с пълна структурирана информация. НЕ връщай текст извън инструмента.`;
  }
  return `You are an expert nutritionist and food analyzer with top-tier accuracy.
You receive one or more images / video frames of a meal or product.
Your task: examine EVERY frame CAREFULLY and extract MAXIMALLY ACCURATE nutritional information.

RULES:
- Identify every ingredient / item (fruit, meat, sauce, side, drink, packaging)
- Estimate the REAL portion size (in grams) — use nearby objects for scale (fork, plate, hand)
- For packaged products: if you can read the label, READ THE VALUES FROM IT (no guessing)
- For cooked dishes: use standard recipe databases (USDA, etc.)
- DO NOT invent numbers — if uncertain, give a realistic mid-range estimate
- Always return per-100g values AND total-for-portion values
- Detect allergens: gluten, dairy, nuts, eggs, soy, fish, shellfish, sesame
- Health score 0-100: 100 = perfectly balanced, <40 = highly processed
- Warnings: high sodium, high sugar, ultra-processed, very fatty, etc.

Always call the analyze_meal tool with complete structured info. Do NOT return text outside the tool.`;
}

const tool = {
  type: "function",
  function: {
    name: "analyze_meal",
    description: "Return precise nutritional analysis for a meal or product based on the images provided.",
    parameters: {
      type: "object",
      properties: {
        meal_name: { type: "string", description: "Best guess at the dish or product name" },
        portion_size: { type: "string", description: "Estimated portion, e.g. '1 plate, ~350g'" },
        portion_grams: { type: "number", description: "Estimated total portion weight in grams" },
        confidence: { type: "string", enum: ["high", "medium", "low"], description: "Confidence in the analysis" },
        ingredients: {
          type: "array",
          description: "Detected ingredients / components",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              estimated_grams: { type: "number" },
            },
            required: ["name"],
            additionalProperties: false,
          },
        },
        nutrition_per_portion: {
          type: "object",
          description: "Totals for the whole shown portion",
          properties: {
            calories: { type: "number" },
            protein_g: { type: "number" },
            carbs_g: { type: "number" },
            fat_g: { type: "number" },
            fiber_g: { type: "number" },
            sugar_g: { type: "number" },
            sodium_mg: { type: "number" },
          },
          required: ["calories", "protein_g", "carbs_g", "fat_g"],
          additionalProperties: false,
        },
        nutrition_per_100g: {
          type: "object",
          properties: {
            calories: { type: "number" },
            protein_g: { type: "number" },
            carbs_g: { type: "number" },
            fat_g: { type: "number" },
          },
          additionalProperties: false,
        },
        allergens: {
          type: "array",
          items: { type: "string" },
          description: "Detected allergens (e.g. gluten, dairy, nuts)",
        },
        warnings: {
          type: "array",
          items: { type: "string" },
          description: "Health warnings (e.g. 'high sodium', 'ultra-processed')",
        },
        health_score: {
          type: "number",
          description: "0-100 health score for this meal",
        },
        analysis: {
          type: "string",
          description: "Short friendly summary (2-3 sentences) explaining the meal and key nutrition takeaways. Use the requested language.",
        },
      },
      required: [
        "meal_name",
        "portion_size",
        "ingredients",
        "nutrition_per_portion",
        "allergens",
        "warnings",
        "health_score",
        "analysis",
        "confidence",
      ],
      additionalProperties: false,
    },
  },
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const clientIP = getClientIP(req);
    const ipCheck = await checkIPBlocked(clientIP);
    if (!ipCheck.allowed) {
      return new Response(JSON.stringify({ error: 'Access denied' }), {
        status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const authHeader = req.headers.get('Authorization');
    let userId: string | null = null;
    if (authHeader?.startsWith('Bearer ')) {
      const supabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_ANON_KEY')!,
        { global: { headers: { Authorization: authHeader } } }
      );
      const { data: { user } } = await supabase.auth.getUser();
      if (user) userId = user.id;
    }

    const limitKey = userId ? `user:${userId}` : `anon:${clientIP}`;
    const limit = userId ? USER_RATE_LIMIT : ANON_RATE_LIMIT;
    if (!checkRateLimit(limitKey, limit)) {
      await logSecurityEvent(clientIP, userId, 'RATE_LIMIT_EXCEEDED', 'medium', { endpoint: 'analyze-meal' });
      return new Response(JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }), {
        status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const body = await req.json();
    const { frames, mealName, description, mealType, language } = body as {
      frames: string[];
      mealName?: string;
      description?: string;
      mealType?: string;
      language: string;
    };

    if (!Array.isArray(frames) || frames.length === 0 || frames.length > MAX_FRAMES) {
      return new Response(JSON.stringify({ error: `Provide 1-${MAX_FRAMES} image frames` }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    for (const f of frames) {
      if (typeof f !== 'string' || !f.startsWith('data:image/') || f.length > MAX_FRAME_BYTES) {
        return new Response(JSON.stringify({ error: 'Invalid frame data' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: 'API key not configured' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const isBg = language === 'bg';
    const userText = [
      mealName ? (isBg ? `Име, посочено от потребителя: ${mealName}` : `User-provided name: ${mealName}`) : '',
      description ? (isBg ? `Описание: ${description}` : `Description: ${description}`) : '',
      mealType ? (isBg ? `Хранене: ${mealType}` : `Meal type: ${mealType}`) : '',
      isBg
        ? `Анализирай ${frames.length > 1 ? 'тези кадри' : 'тази снимка'} с максимална точност. Извикай инструмента analyze_meal. Текстовите полета да са на български.`
        : `Analyze ${frames.length > 1 ? 'these frames' : 'this image'} with maximum accuracy. Call the analyze_meal tool. Text fields must be in English.`,
    ].filter(Boolean).join('\n');

    const userContent: Array<{ type: string; text?: string; image_url?: { url: string } }> = [
      { type: 'text', text: userText },
      ...frames.map(url => ({ type: 'image_url', image_url: { url } })),
    ];

    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-pro',
        messages: [
          { role: 'system', content: systemPrompt(language) },
          { role: 'user', content: userContent },
        ],
        tools: [tool],
        tool_choice: { type: 'function', function: { name: 'analyze_meal' } },
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error('AI gateway error:', aiResponse.status, errorText);
      if (aiResponse.status === 429) {
        return new Response(JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }), {
          status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      if (aiResponse.status === 402) {
        return new Response(JSON.stringify({ error: 'AI credits exhausted.' }), {
          status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      return new Response(JSON.stringify({ error: 'AI service temporarily unavailable' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const data = await aiResponse.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall?.function?.arguments) {
      console.error('No tool call in response:', JSON.stringify(data).slice(0, 500));
      return new Response(JSON.stringify({ error: 'AI did not return structured analysis' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    let parsed: any;
    try {
      parsed = JSON.parse(toolCall.function.arguments);
    } catch (e) {
      console.error('Failed to parse tool arguments:', e);
      return new Response(JSON.stringify({ error: 'AI returned invalid analysis' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ analysis: parsed }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('analyze-meal error:', error);
    return new Response(JSON.stringify({ error: 'An error occurred. Please try again.' }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
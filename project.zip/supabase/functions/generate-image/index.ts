import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // JWT is verified at the gateway level (verify_jwt = true in config.toml)
    const authHeader = req.headers.get('Authorization');
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader! } } }
    );

    const { data: { user } } = await supabase.auth.getUser();
    const userId = user?.id || 'unknown';

    const { prompt, language } = await req.json();
    
    console.log('User', userId, 'generating image with prompt:', prompt?.substring(0, 50));

    if (!prompt || typeof prompt !== 'string' || prompt.length > 1000) {
      return new Response(JSON.stringify({ error: 'Invalid prompt' }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      console.error('LOVABLE_API_KEY not configured');
      return new Response(JSON.stringify({ error: 'API key not configured' }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Enhance prompt for food/recipe images
    const enhancedPrompt = `Professional food photography, appetizing ${prompt}, high quality, well-lit, restaurant quality presentation, delicious looking, vibrant colors, shallow depth of field, garnished beautifully`;

    console.log('Calling Lovable AI gateway for image generation...');
    
    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: { 
        'Authorization': `Bearer ${LOVABLE_API_KEY}`, 
        'Content-Type': 'application/json' 
      },
      body: JSON.stringify({ 
        model: 'google/gemini-2.5-flash-image-preview',
        messages: [
          { 
            role: 'user', 
            content: enhancedPrompt
          }
        ],
        modalities: ['image', 'text']
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ 
          error: language === 'bg' ? 'Твърде много заявки. Моля, опитайте по-късно.' : 'Rate limit exceeded. Please try again later.' 
        }), { 
          status: 429, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ 
          error: language === 'bg' ? 'AI кредитите са изчерпани.' : 'AI credits exhausted.' 
        }), { 
          status: 402, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      
      return new Response(JSON.stringify({ 
        error: language === 'bg' ? 'AI услугата временно не е налична' : 'AI service temporarily unavailable' 
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const data = await response.json();
    console.log('AI image response received for user', userId);
    
    // Extract image from response
    const imageUrl = data.choices?.[0]?.message?.images?.[0]?.image_url?.url;
    const textContent = data.choices?.[0]?.message?.content;
    
    if (!imageUrl) {
      console.error('No image in AI response:', JSON.stringify(data));
      return new Response(JSON.stringify({ 
        error: language === 'bg' ? 'Не успях да генерирам изображение' : 'Failed to generate image' 
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ 
      imageUrl,
      message: textContent || (language === 'bg' ? 'Изображението е генерирано успешно! 🎨' : 'Image generated successfully! 🎨')
    }), { 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Function error:', error);
    return new Response(JSON.stringify({ error: 'An error occurred. Please try again.' }), { 
      status: 500, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});

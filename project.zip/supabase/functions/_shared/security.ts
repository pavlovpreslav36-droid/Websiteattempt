import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

export interface SecurityCheckResult {
  allowed: boolean;
  reason?: string;
}

export async function checkIPBlocked(ipAddress: string): Promise<SecurityCheckResult> {
  try {
    const { data, error } = await supabaseAdmin.rpc('is_ip_blocked', { 
      check_ip: ipAddress 
    });

    if (error) {
      console.error('Error checking IP block status:', error);
      return { allowed: true }; // Fail open in case of error
    }

    if (data === true) {
      return { allowed: false, reason: 'IP_BLOCKED' };
    }

    return { allowed: true };
  } catch (error) {
    console.error('Error in checkIPBlocked:', error);
    return { allowed: true }; // Fail open
  }
}

export async function logSecurityEvent(
  ipAddress: string,
  userId: string | null,
  eventType: string,
  severity: 'low' | 'medium' | 'high' | 'critical',
  details: any
) {
  try {
    await supabaseAdmin.rpc('log_security_event', {
      p_ip_address: ipAddress,
      p_user_id: userId,
      p_event_type: eventType,
      p_severity: severity,
      p_details: details
    });
  } catch (error) {
    console.error('Error logging security event:', error);
  }
}

export async function blockIP(
  ipAddress: string,
  reason: string,
  permanent: boolean = false,
  durationHours: number = 24
) {
  try {
    await supabaseAdmin.rpc('block_ip', {
      p_ip_address: ipAddress,
      p_reason: reason,
      p_permanent: permanent,
      p_duration_hours: durationHours
    });
  } catch (error) {
    console.error('Error blocking IP:', error);
  }
}

export function getClientIP(req: Request): string {
  // Try to get real IP from headers (Cloudflare, etc.)
  const cfConnectingIp = req.headers.get('cf-connecting-ip');
  const xForwardedFor = req.headers.get('x-forwarded-for');
  const xRealIp = req.headers.get('x-real-ip');

  return cfConnectingIp || 
         (xForwardedFor ? xForwardedFor.split(',')[0].trim() : null) || 
         xRealIp || 
         'unknown';
}

export async function detectSuspiciousActivity(
  input: any,
  ipAddress: string
): Promise<boolean> {
  // Check for common attack patterns
  const suspiciousPatterns = [
    /(<script|javascript:|onerror=|onclick=)/i, // XSS attempts
    /(union\s+select|drop\s+table|insert\s+into)/i, // SQL injection
    /(\.\.\/)/, // Path traversal
    /(eval\(|exec\(|system\()/i, // Code execution
  ];

  const inputString = JSON.stringify(input).toLowerCase();
  
  for (const pattern of suspiciousPatterns) {
    if (pattern.test(inputString)) {
      await logSecurityEvent(
        ipAddress,
        null,
        'SUSPICIOUS_INPUT_DETECTED',
        'high',
        { pattern: pattern.toString(), input: inputString.substring(0, 200) }
      );
      return true;
    }
  }

  return false;
}

export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

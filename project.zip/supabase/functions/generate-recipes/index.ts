import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, checkIPBlocked, logSecurityEvent, getClientIP, detectSuspiciousActivity, blockIP } from '../_shared/security.ts';

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });
  const ipAddress = getClientIP(req);

  try {
    const ipCheck = await checkIPBlocked(ipAddress);
    if (!ipCheck.allowed) return new Response(JSON.stringify({ error: 'ACCESS_DENIED', redirect: '/blocked' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});

    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader }}});
    const { data: { user }} = await supabase.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: 'Invalid token' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});

    const { ingredients } = await req.json();
    if (!Array.isArray(ingredients) || ingredients.length === 0 || ingredients.length > 20) {
      return new Response(JSON.stringify({ error: 'Invalid ingredients' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
    }

    if (await detectSuspiciousActivity({ ingredients }, ipAddress)) {
      await blockIP(ipAddress, 'Suspicious input', true);
      return new Response(JSON.stringify({ error: 'SUSPICIOUS_ACTIVITY', redirect: '/blocked' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${Deno.env.get("LOVABLE_API_KEY")}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: 'Генерирай 10+ здравословни рецепти с реалистични хранителни стойности. Отговаряй с JSON масив: [{"id":1,"name":"","image":"🍽️","calories":0,"protein":0,"nutrition":{"carbs":0,"fiber":0,"fat":0,"saturatedFat":0,"sugar":0,"sodium":0,"carbSources":""},"category":"","cookingMethod":{"temperature":"","oil":"","healthierOil":"","steps":[]}}]. Калориите трябва да са реалистични (700-1200 за главно ястие). Включи детайлни въглехидрати и мазнини.' },
          { role: "user", content: `Генерирай рецепти с: ${ingredients.join(', ')}` }
        ],
        temperature: 0.7
      })
    });

    const data = await response.json();
    const recipes = JSON.parse(data.choices[0].message.content.match(/\[[\s\S]*\]/)[0]);
    await logSecurityEvent(ipAddress, user.id, 'RECIPE_GENERATION', 'low', {});
    return new Response(JSON.stringify({ recipes }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
  } catch (error) {
    // Log full error server-side for debugging
    console.error('Function error:', error);
    await logSecurityEvent(ipAddress, null, 'FUNCTION_ERROR', 'medium', { error: error instanceof Error ? error.message : 'Unknown error' });
    // Return generic message to client (no internal details)
    return new Response(JSON.stringify({ error: 'An error occurred. Please try again.' }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
  }
});

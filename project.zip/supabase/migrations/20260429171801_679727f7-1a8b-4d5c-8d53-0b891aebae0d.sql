
ALTER TABLE public.meal_journal
  ADD COLUMN IF NOT EXISTS fiber numeric,
  ADD COLUMN IF NOT EXISTS sugar numeric,
  ADD COLUMN IF NOT EXISTS sodium numeric,
  ADD COLUMN IF NOT EXISTS portion_size text,
  ADD COLUMN IF NOT EXISTS ingredients jsonb,
  ADD COLUMN IF NOT EXISTS allergens jsonb,
  ADD COLUMN IF NOT EXISTS health_score integer,
  ADD COLUMN IF NOT EXISTS warnings jsonb,
  ADD COLUMN IF NOT EXISTS media_type text DEFAULT 'image';

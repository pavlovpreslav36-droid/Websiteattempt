
-- Meal Journal table
CREATE TABLE public.meal_journal (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  meal_name TEXT NOT NULL,
  description TEXT,
  photo_url TEXT,
  calories INTEGER,
  protein NUMERIC(6,1),
  carbs NUMERIC(6,1),
  fat NUMERIC(6,1),
  meal_type TEXT NOT NULL DEFAULT 'other',
  ai_analysis TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.meal_journal ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own meal entries" ON public.meal_journal FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own meal entries" ON public.meal_journal FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own meal entries" ON public.meal_journal FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own meal entries" ON public.meal_journal FOR DELETE USING (auth.uid() = user_id);

-- Friendships table
CREATE TABLE public.friendships (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  friend_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, friend_id)
);

ALTER TABLE public.friendships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own friendships" ON public.friendships FOR SELECT USING (auth.uid() = user_id OR auth.uid() = friend_id);
CREATE POLICY "Users can send friend requests" ON public.friendships FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update friendships they're part of" ON public.friendships FOR UPDATE USING (auth.uid() = user_id OR auth.uid() = friend_id);
CREATE POLICY "Users can delete own friendships" ON public.friendships FOR DELETE USING (auth.uid() = user_id OR auth.uid() = friend_id);

-- Health challenges table
CREATE TABLE public.health_challenges (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  creator_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  challenger_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  challenge_type TEXT NOT NULL,
  target_value INTEGER NOT NULL,
  creator_progress INTEGER NOT NULL DEFAULT 0,
  challenger_progress INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  winner_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  ends_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + interval '7 days')
);

ALTER TABLE public.health_challenges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view challenges they're in" ON public.health_challenges FOR SELECT USING (auth.uid() = creator_id OR auth.uid() = challenger_id);
CREATE POLICY "Users can create challenges" ON public.health_challenges FOR INSERT WITH CHECK (auth.uid() = creator_id);
CREATE POLICY "Users can update challenges they're in" ON public.health_challenges FOR UPDATE USING (auth.uid() = creator_id OR auth.uid() = challenger_id);

-- Weekly health reports table
CREATE TABLE public.weekly_health_reports (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  report_data JSONB NOT NULL,
  ai_summary TEXT,
  health_score INTEGER,
  week_start DATE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.weekly_health_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own reports" ON public.weekly_health_reports FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own reports" ON public.weekly_health_reports FOR INSERT WITH CHECK (auth.uid() = user_id);

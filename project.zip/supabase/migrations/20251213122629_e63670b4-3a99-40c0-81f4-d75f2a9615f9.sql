-- Create achievements table
CREATE TABLE public.achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  name_bg TEXT NOT NULL,
  description TEXT NOT NULL,
  description_bg TEXT NOT NULL,
  icon TEXT NOT NULL,
  category TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 10,
  requirement_type TEXT NOT NULL,
  requirement_value INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_achievements table to track earned achievements
CREATE TABLE public.user_achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  achievement_id UUID NOT NULL REFERENCES public.achievements(id) ON DELETE CASCADE,
  earned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);

-- Enable RLS
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;

-- Achievements are readable by everyone
CREATE POLICY "Achievements are viewable by everyone" 
ON public.achievements 
FOR SELECT 
USING (true);

-- Users can view their own achievements
CREATE POLICY "Users can view their own achievements" 
ON public.user_achievements 
FOR SELECT 
USING (auth.uid() = user_id);

-- Users can earn achievements
CREATE POLICY "Users can earn achievements" 
ON public.user_achievements 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Insert default achievements
INSERT INTO public.achievements (name, name_bg, description, description_bg, icon, category, points, requirement_type, requirement_value) VALUES
('First Steps', 'Първи стъпки', 'Complete your first quiz', 'Завърши първия си тест', '🎯', 'quiz', 10, 'quiz_completed', 1),
('Quiz Master', 'Майстор на тестовете', 'Complete 5 quizzes', 'Завърши 5 теста', '🏆', 'quiz', 50, 'quiz_completed', 5),
('Perfect Score', 'Перфектен резултат', 'Get 100% on a quiz', 'Вземи 100% на тест', '⭐', 'quiz', 100, 'perfect_quiz', 1),
('Recipe Explorer', 'Изследовател на рецепти', 'View 10 recipes', 'Разгледай 10 рецепти', '🍳', 'recipes', 20, 'recipes_viewed', 10),
('Chef in Training', 'Готвач в обучение', 'View 25 recipes', 'Разгледай 25 рецепти', '👨‍🍳', 'recipes', 50, 'recipes_viewed', 25),
('Master Chef', 'Майстор готвач', 'View 50 recipes', 'Разгледай 50 рецепти', '🧑‍🍳', 'recipes', 100, 'recipes_viewed', 50),
('Scanner Pro', 'Професионален скенер', 'Scan 5 products', 'Сканирай 5 продукта', '📱', 'scanner', 30, 'products_scanned', 5),
('Health Detective', 'Здравен детектив', 'Scan 15 products', 'Сканирай 15 продукта', '🔍', 'scanner', 75, 'products_scanned', 15),
('AI Friend', 'Приятел с AI', 'Have 10 conversations with AI', 'Проведи 10 разговора с AI', '🤖', 'ai', 25, 'ai_conversations', 10),
('AI Expert', 'AI експерт', 'Have 50 conversations with AI', 'Проведи 50 разговора с AI', '🧠', 'ai', 100, 'ai_conversations', 50),
('Hydration Hero', 'Герой на хидратацията', 'Log water intake for 7 days', 'Записвай вода 7 дни', '💧', 'health', 40, 'water_logged', 7),
('Step Counter', 'Брояч на стъпки', 'Log 10000 steps in a day', 'Запиши 10000 стъпки за ден', '👟', 'health', 50, 'steps_logged', 10000),
('Fact Lover', 'Любител на факти', 'Read 20 fun facts', 'Прочети 20 любопитни факта', '📚', 'facts', 20, 'facts_read', 20),
('Knowledge Seeker', 'Търсач на знания', 'Read 50 fun facts', 'Прочети 50 любопитни факта', '🎓', 'facts', 50, 'facts_read', 50),
('Early Bird', 'Ранобудник', 'Use the app before 7 AM', 'Използвай приложението преди 7 сутринта', '🌅', 'special', 15, 'early_login', 1),
('Night Owl', 'Нощна птица', 'Use the app after 11 PM', 'Използвай приложението след 23 часа', '🦉', 'special', 15, 'late_login', 1),
('Streak Starter', 'Начало на серия', 'Use the app 3 days in a row', 'Използвай приложението 3 дни поред', '🔥', 'special', 30, 'login_streak', 3),
('Dedicated User', 'Отдаден потребител', 'Use the app 7 days in a row', 'Използвай приложението 7 дни поред', '💪', 'special', 75, 'login_streak', 7),
('Image Creator', 'Създател на изображения', 'Generate your first AI image', 'Генерирай първото си AI изображение', '🎨', 'ai', 25, 'images_generated', 1),
('Artist', 'Художник', 'Generate 10 AI images', 'Генерирай 10 AI изображения', '🖼️', 'ai', 75, 'images_generated', 10);
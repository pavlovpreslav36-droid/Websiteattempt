
-- Create storage bucket for meal photos
INSERT INTO storage.buckets (id, name, public) VALUES ('meal-photos', 'meal-photos', true);

-- Storage policies
CREATE POLICY "Users can upload meal photos" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'meal-photos' AND auth.uid() IS NOT NULL);
CREATE POLICY "Anyone can view meal photos" ON storage.objects FOR SELECT USING (bucket_id = 'meal-photos');
CREATE POLICY "Users can delete own meal photos" ON storage.objects FOR DELETE USING (bucket_id = 'meal-photos' AND auth.uid() IS NOT NULL);

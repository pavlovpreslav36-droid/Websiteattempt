-- Create table to log every "moment taken"
CREATE TABLE public.ripple_moments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.ripple_moments ENABLE ROW LEVEL SECURITY;

-- Anyone can view the moments (for the counter)
CREATE POLICY "Anyone can view ripple moments"
ON public.ripple_moments
FOR SELECT
USING (true);

-- Anyone can insert a moment (anonymous + authenticated)
CREATE POLICY "Anyone can add a ripple moment"
ON public.ripple_moments
FOR INSERT
WITH CHECK (true);

-- Index for fast counting
CREATE INDEX idx_ripple_moments_created_at ON public.ripple_moments(created_at DESC);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.ripple_moments;
ALTER TABLE public.ripple_moments REPLICA IDENTITY FULL;
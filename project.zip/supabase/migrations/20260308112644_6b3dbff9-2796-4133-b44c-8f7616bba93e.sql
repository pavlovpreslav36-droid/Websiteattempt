-- Drop storage policies on quiz-audio bucket
DROP POLICY IF EXISTS "Anyone can view quiz audio" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload quiz audio" ON storage.objects;
DROP POLICY IF EXISTS "Restricted quiz audio uploads" ON storage.objects;

-- Make bucket private and disallow uploads by removing all INSERT policies
UPDATE storage.buckets SET public = false WHERE id = 'quiz-audio';
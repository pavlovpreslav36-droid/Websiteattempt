
CREATE TABLE public.quiz_scores (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  username TEXT NOT NULL DEFAULT 'Анонимен',
  score INTEGER NOT NULL,
  total_questions INTEGER NOT NULL DEFAULT 30,
  best_streak INTEGER NOT NULL DEFAULT 0,
  time_taken_seconds INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.quiz_scores ENABLE ROW LEVEL SECURITY;

-- Everyone can view scores (leaderboard is public)
CREATE POLICY "Anyone can view quiz scores"
  ON public.quiz_scores
  FOR SELECT
  USING (true);

-- Authenticated users can insert their own scores
CREATE POLICY "Users can insert their own scores"
  ON public.quiz_scores
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

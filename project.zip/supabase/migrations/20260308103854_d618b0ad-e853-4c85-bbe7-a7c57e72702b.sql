
INSERT INTO storage.buckets (id, name, public)
VALUES ('quiz-audio', 'quiz-audio', true);

CREATE POLICY "Anyone can view quiz audio"
ON storage.objects FOR SELECT
USING (bucket_id = 'quiz-audio');

CREATE POLICY "Authenticated users can upload quiz audio"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'quiz-audio');

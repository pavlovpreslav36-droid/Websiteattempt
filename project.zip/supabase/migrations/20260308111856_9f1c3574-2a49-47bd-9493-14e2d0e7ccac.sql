DROP POLICY IF EXISTS "Authenticated users can upload quiz audio" ON storage.objects;

CREATE POLICY "Restricted quiz audio uploads"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'quiz-audio'
  AND (storage.extension(name) IN ('mp3', 'wav', 'ogg', 'webm', 'm4a'))
);
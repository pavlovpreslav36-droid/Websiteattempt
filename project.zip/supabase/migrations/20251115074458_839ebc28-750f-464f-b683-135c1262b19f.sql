-- Fix profiles table RLS policy to protect email addresses
DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON public.profiles;

CREATE POLICY "Users can view own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = id);

-- Create security monitoring tables
CREATE TABLE IF NOT EXISTS public.blocked_ips (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address TEXT NOT NULL UNIQUE,
  reason TEXT NOT NULL,
  blocked_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  blocked_until TIMESTAMP WITH TIME ZONE,
  permanent BOOLEAN DEFAULT false
);

CREATE TABLE IF NOT EXISTS public.security_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address TEXT NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  event_type TEXT NOT NULL,
  severity TEXT NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  details JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create failed login attempts tracking
CREATE TABLE IF NOT EXISTS public.failed_login_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  ip_address TEXT NOT NULL,
  attempted_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create function to check if IP is blocked
CREATE OR REPLACE FUNCTION public.is_ip_blocked(check_ip TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.blocked_ips
    WHERE ip_address = check_ip
    AND (permanent = true OR (blocked_until IS NOT NULL AND blocked_until > now()))
  );
$$;

-- Create function to log security events
CREATE OR REPLACE FUNCTION public.log_security_event(
  p_ip_address TEXT,
  p_user_id UUID,
  p_event_type TEXT,
  p_severity TEXT,
  p_details JSONB
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  event_id UUID;
BEGIN
  INSERT INTO public.security_events (ip_address, user_id, event_type, severity, details)
  VALUES (p_ip_address, p_user_id, p_event_type, p_severity, p_details)
  RETURNING id INTO event_id;
  
  RETURN event_id;
END;
$$;

-- Create function to block IP
CREATE OR REPLACE FUNCTION public.block_ip(
  p_ip_address TEXT,
  p_reason TEXT,
  p_permanent BOOLEAN DEFAULT false,
  p_duration_hours INTEGER DEFAULT 24
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  block_id UUID;
BEGIN
  INSERT INTO public.blocked_ips (ip_address, reason, permanent, blocked_until)
  VALUES (
    p_ip_address,
    p_reason,
    p_permanent,
    CASE WHEN p_permanent THEN NULL ELSE now() + (p_duration_hours || ' hours')::INTERVAL END
  )
  ON CONFLICT (ip_address) 
  DO UPDATE SET 
    reason = EXCLUDED.reason,
    permanent = EXCLUDED.permanent,
    blocked_until = EXCLUDED.blocked_until,
    blocked_at = now()
  RETURNING id INTO block_id;
  
  RETURN block_id;
END;
$$;

-- Enable RLS on security tables
ALTER TABLE public.blocked_ips ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.failed_login_attempts ENABLE ROW LEVEL SECURITY;

-- Only allow functions to modify these tables (no direct user access)
CREATE POLICY "No direct access to blocked_ips" ON public.blocked_ips FOR ALL USING (false);
CREATE POLICY "No direct access to security_events" ON public.security_events FOR ALL USING (false);
CREATE POLICY "No direct access to failed_login_attempts" ON public.failed_login_attempts FOR ALL USING (false);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_blocked_ips_ip ON public.blocked_ips(ip_address);
CREATE INDEX IF NOT EXISTS idx_security_events_ip ON public.security_events(ip_address);
CREATE INDEX IF NOT EXISTS idx_security_events_created ON public.security_events(created_at);
CREATE INDEX IF NOT EXISTS idx_failed_attempts_email ON public.failed_login_attempts(email);
CREATE INDEX IF NOT EXISTS idx_failed_attempts_ip ON public.failed_login_attempts(ip_address);
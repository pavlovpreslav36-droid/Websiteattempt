import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.b469227454fd45b9a4631f05ab847854',
  appName: 'steps-to-a-healthy-life',
  webDir: 'dist',
  server: {
    url: 'https://b4692274-54fd-45b9-a463-1f05ab847854.lovableproject.com?forceHideBadge=true',
    cleartext: true
  }
};

export default config;
